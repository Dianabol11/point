using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;
using POS.My;

namespace POS
{
	// Token: 0x0200002B RID: 43
	[StandardModule]
	internal sealed class OrderManagment
	{
		// Token: 0x060005EF RID: 1519 RVA: 0x000380CC File Offset: 0x000362CC
		public static void SaveOrdersIntoComputer()
		{
			bool flag = Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) == 0;
			if (flag)
			{
				M_Settings.OrderNoToEdit = "";
			}
			M_Settings.OrderTakenFrom = "POS";
			flag = (Operators.CompareString(M_Settings.OrderNoToEdit, "", false) == 0);
			bool flag2;
			if (flag)
			{
				flag2 = (Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) != 0 & Operators.CompareString(M_Settings.TableNumberAction, "AddtoTable", false) != 0 & Operators.CompareString(M_Settings.TableNumberAction, "EditTable", false) != 0);
				if (flag2)
				{
					OrderManagment.SaveOrderInto_TodayOrderList_txt();
				}
				OrderManagment.SaveOrderInto_xxx_txt();
			}
			else
			{
				flag2 = (Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) != 0 & Operators.CompareString(M_Settings.TableNumberAction, "AddtoTable", false) != 0 & Operators.CompareString(M_Settings.TableNumberAction, "EditTable", false) != 0);
				if (flag2)
				{
					OrderManagment.SaveEditedOrderInto_TodayOrderList_txt();
				}
				OrderManagment.SaveEditedOrderInto_xxx_txt();
				M_Settings.OrderNoToEdit = "";
			}
			flag2 = (Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) == 0);
			if (flag2)
			{
				OrderManagment.CalculateNextOrderNumber();
				OrderManagment.SaveOrderInto_TodayOrderList_txt();
				Microsoft.VisualBasic.FileSystem.Rename(M_Settings.DataFolder + "\\Order_History\\_today\\Table" + M_Settings.TableNumber.ToString() + ".txt", M_Settings.DataFolder + "\\Order_History\\_today\\" + OrderManagment.NextOrderNumberString + ".txt");
			}
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x00038238 File Offset: 0x00036438
		private static void SaveEditedOrderInto_TodayOrderList_txt()
		{
			string[] array = File.ReadAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt");
			string text = Conversions.ToString(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(M_Settings.OrderNoToEdit + "|", M_Settings.CurrentDate()), M_Settings.CurrentTime()), "|"), M_Settings.OrderType), "|in progress|"), M_Settings.PaymentType), "|"), M_Settings.DriverName), "|"), M_Settings.OrderTakenFrom), "|"), M_Settings.CustomerTel), "|"), M_Settings.CustomerAddress), "|"), M_Settings.CustomerCity), "|"), M_Settings.CustomerPostCode), "|"), M_Calculates.OrderSubTotal.ToString()), "|"), M_Calculates.OrderDiscount.ToString()), "|"), M_Calculates.OrderDelivery.ToString()), "|"), M_Calculates.OrderServiceCharge.ToString()), "|"), M_Calculates.OrderTotal.ToString()), "|"), M_Settings.OrderComment));
			bool flag = Operators.CompareString(M_Settings.OrderType, "Takeaway", false) == 0;
			if (flag)
			{
				text = text.Replace("|in progress|", "|Complete|");
			}
			array[checked(Conversions.ToInteger(M_Settings.OrderNoToEdit) - 1)] = text;
			File.WriteAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt", array);
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x00038408 File Offset: 0x00036608
		private static void SaveEditedOrderInto_xxx_txt()
		{
			string text = "";
			bool flag;
			try
			{
				foreach (object obj in M_Settings.ShoppingCart.Items)
				{
					ListViewItem listViewItem = (ListViewItem)obj;
					text = text + listViewItem.SubItems[0].Text + "|";
					text = text + listViewItem.SubItems[1].Text + "|";
					text = text + listViewItem.SubItems[2].Text + "|";
					text = text + listViewItem.SubItems[3].Text + "|";
					text = text + listViewItem.SubItems[4].Text + "|";
					text = text + listViewItem.SubItems[5].Text + "|";
					text = text + listViewItem.SubItems[6].Text + "|";
					text = text + listViewItem.SubItems[7].Text + Environment.NewLine;
				}
			}
			finally
			{
				IEnumerator enumerator;
				flag = (enumerator is IDisposable);
				if (flag)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			text = text + "==========" + Environment.NewLine;
			text = text + M_Calculates.OrderSubTotal.ToString() + "|";
			text = text + M_Calculates.OrderDiscount.ToString() + "|";
			text = text + M_Calculates.OrderDelivery.ToString() + "|";
			text = text + M_Calculates.OrderServiceCharge.ToString() + "|";
			text += M_Calculates.OrderTotal.ToString();
			File.WriteAllText(M_Settings.DataFolder + "\\Order_History\\_today\\" + M_Settings.OrderNoToEdit + ".txt", text);
			flag = (decimal.Compare(OrderManagment.EditOrderOldDTotal, M_Calculates.OrderTotal) > 0);
			if (flag)
			{
				SuspiciousActivities.CheckSuspiciousActivitiesEditedOrders(M_Settings.OrderNoToEdit, M_Calculates.OrderTotal);
			}
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x00038638 File Offset: 0x00036838
		private static void SaveOrderInto_TodayOrderList_txt()
		{
			string right = "|DriverName|";
			bool flag = Operators.CompareString(M_Settings.CustomerNote, "", false) != 0 & Operators.CompareString(M_Settings.OrderType, "Collection", false) == 0;
			if (flag)
			{
				right = "|" + M_Settings.CustomerNote + "|";
			}
			string text = Conversions.ToString(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(OrderManagment.NextOrderNumberString + "|", M_Settings.CurrentDate()), M_Settings.CurrentTime()), "|"), M_Settings.OrderType), "|in progress|"), M_Settings.PaymentType), right), M_Settings.OrderTakenFrom), "|"), M_Settings.CustomerTel), "|"), M_Settings.CustomerAddress), "|"), M_Settings.CustomerCity), "|"), M_Settings.CustomerPostCode), "|"), M_Calculates.OrderSubTotal.ToString()), "|"), M_Calculates.OrderDiscount.ToString()), "|"), M_Calculates.OrderDelivery.ToString()), "|"), M_Calculates.OrderServiceCharge.ToString()), "|"), M_Calculates.OrderTotal.ToString()), "|"), M_Settings.OrderComment));
			flag = (Operators.CompareString(M_Settings.OrderType, "Takeaway", false) == 0);
			if (flag)
			{
				text = text.Replace("|in progress|", "|Complete|");
			}
			flag = (Operators.CompareString(M_Settings.OrderType, "Dine In", false) == 0 & Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) == 0);
			if (flag)
			{
				text = text.Replace("DriverName", "Table " + M_Settings.TableNumber.ToString());
				text = text.Replace("|in progress|", "|Complete|");
			}
			StreamWriter streamWriter = new StreamWriter(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt", true);
			streamWriter.WriteLine(text);
			streamWriter.Close();
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x00038880 File Offset: 0x00036A80
		private static void SaveOrderInto_xxx_txt()
		{
			string text = "";
			try
			{
				foreach (object obj in M_Settings.ShoppingCart.Items)
				{
					ListViewItem listViewItem = (ListViewItem)obj;
					text = text + listViewItem.SubItems[0].Text + "|";
					text = text + listViewItem.SubItems[1].Text + "|";
					text = text + listViewItem.SubItems[2].Text + "|";
					text = text + listViewItem.SubItems[3].Text + "|";
					text = text + listViewItem.SubItems[4].Text + "|";
					text = text + listViewItem.SubItems[5].Text + "|";
					text = text + listViewItem.SubItems[6].Text + "|";
					text = text + listViewItem.SubItems[7].Text + Environment.NewLine;
				}
			}
			finally
			{
				IEnumerator enumerator;
				bool flag = enumerator is IDisposable;
				if (flag)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			text = text + "==========" + Environment.NewLine;
			text = text + M_Calculates.OrderSubTotal.ToString() + "|";
			text = text + M_Calculates.OrderDiscount.ToString() + "|";
			text = text + M_Calculates.OrderDelivery.ToString() + "|";
			text = text + M_Calculates.OrderServiceCharge.ToString() + "|";
			text += M_Calculates.OrderTotal.ToString();
			File.WriteAllText(M_Settings.DataFolder + "\\Order_History\\_today\\" + OrderManagment.NextOrderNumberString + ".txt", text);
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x00038A84 File Offset: 0x00036C84
		public static void Check_todayFolder()
		{
			bool flag = !Directory.Exists(M_Settings.DataFolder + "\\Order_History\\_today");
			if (flag)
			{
				Directory.CreateDirectory(M_Settings.DataFolder + "\\Order_History\\_today");
				File.Create(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt").Dispose();
			}
			Online.postdata(Online.SoftwareDomain, "session_start.php", "create_today_folder", MySettingsProperty.Settings.ServerFolderName, "_today" + MySettingsProperty.Settings.ComputerNo, "", "", "");
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x00038B20 File Offset: 0x00036D20
		public static void CalculateNextOrderNumber()
		{
			bool flag = File.ReadAllText(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt").Length > 0;
			int num;
			if (flag)
			{
				string text = File.ReadAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt").Last<string>();
				num = Conversions.ToInteger(text.Split(new char[]
				{
					'|'
				})[0]);
			}
			else
			{
				num = 0;
			}
			OrderManagment.NextOrderNumber = checked(num + 1);
			flag = (OrderManagment.NextOrderNumber == 0);
			if (flag)
			{
				OrderManagment.NextOrderNumber = 1;
			}
			OrderManagment.NextOrderNumberString = OrderManagment.NextOrderNumber.ToString();
			flag = (OrderManagment.NextOrderNumberString.Length == 1);
			if (flag)
			{
				OrderManagment.NextOrderNumberString = "00" + OrderManagment.NextOrderNumberString;
			}
			flag = (OrderManagment.NextOrderNumberString.Length == 2);
			if (flag)
			{
				OrderManagment.NextOrderNumberString = "0" + OrderManagment.NextOrderNumberString;
			}
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00038C08 File Offset: 0x00036E08
		public static void Archive_todayFlder()
		{
			Microsoft.VisualBasic.FileIO.FileSystem.RenameDirectory(M_Settings.DataFolder + "\\Order_History\\_today", Conversions.ToString(Operators.AddObject(Operators.AddObject(MySettingsProperty.Settings.ComputerNo + "_", M_Settings.CurrentDate()), M_Settings.CurrentTime())));
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x00038C5C File Offset: 0x00036E5C
		public static void Archive_todayFlderOnline()
		{
			Online.postdata(Online.SoftwareDomain, "session_end.php", "end_today_session", MySettingsProperty.Settings.ServerFolderName, "_today" + MySettingsProperty.Settings.ComputerNo, Conversions.ToString(Operators.AddObject(Operators.AddObject(MySettingsProperty.Settings.ComputerNo + "@", M_Settings.CurrentDate()), M_Settings.CurrentTime())), "", "");
		}

		// Token: 0x060005F8 RID: 1528 RVA: 0x00038CD8 File Offset: 0x00036ED8
		public static void AddAllTakenTableOrdersIntoShoppingcart()
		{
			int num = 0;
			num = Conversions.ToInteger(M_Shopping_Cart.BringUpExistingOrderIntoShoppingCart("Table" + M_Settings.TableNumber, num));
			M_Settings.ShoppingCart.Items.Add(new ListViewItem("Divider"));
			M_Settings.ShoppingCart.Items[num].SubItems.Add("");
			M_Settings.ShoppingCart.Items[num].SubItems.Add("");
			M_Settings.ShoppingCart.Items[num].SubItems.Add("");
			M_Settings.ShoppingCart.Items[num].SubItems.Add("");
			M_Settings.ShoppingCart.Items[num].SubItems.Add("---------New Order-------");
			M_Settings.ShoppingCart.Items[num].SubItems.Add("");
			M_Settings.ShoppingCart.Items[num].SubItems.Add("");
			M_Calculates.CalculateSubTotal();
			MyProject.Forms.Index.Enabled = true;
			M_Settings.OrderType = "Dine In";
			MyProject.Forms.TableSelection.Close();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
		}

		// Token: 0x0400027B RID: 635
		public static int NextOrderNumber;

		// Token: 0x0400027C RID: 636
		public static string EditOrderOldDateTime;

		// Token: 0x0400027D RID: 637
		public static decimal EditOrderOldDTotal;

		// Token: 0x0400027E RID: 638
		public static string NextOrderNumberString;

		// Token: 0x0400027F RID: 639
		public static string SaveNewOrderInServerError;

		// Token: 0x04000280 RID: 640
		public static ArrayList AllTakenTableOrdersArrayList;
	}
}
