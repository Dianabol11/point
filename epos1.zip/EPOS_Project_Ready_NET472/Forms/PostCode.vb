using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200002C RID: 44
	[StandardModule]
	internal sealed class PostCode
	{
		// Token: 0x060005F9 RID: 1529 RVA: 0x00038E44 File Offset: 0x00037044
		public static void GetBusinessLatLang()
		{
			string businessPostcode = MySettingsProperty.Settings.BusinessPostcode;
			string str = "None";
			string text = businessPostcode.Substring(0, 1);
			string text2 = businessPostcode.Substring(0, 2);
			bool flag = File.Exists(M_Settings.PostCodesFolder + "/" + text + ".csv");
			if (flag)
			{
				str = text + ".csv";
			}
			else
			{
				flag = File.Exists(M_Settings.PostCodesFolder + "/" + text2 + ".csv");
				if (flag)
				{
					str = text2 + ".csv";
				}
				else
				{
					MessageBox.Show("Your business postcode " + businessPostcode.ToUpper() + "not found.");
				}
			}
			StreamReader streamReader = File.OpenText(M_Settings.PostCodesFolder + "/" + str);
			while (streamReader.Peek() != -1)
			{
				string text3 = streamReader.ReadLine();
				string[] array = text3.Split(new char[]
				{
					','
				});
				flag = (Operators.CompareString(businessPostcode.Replace(" ", "").ToUpper().Trim(), array[1].Replace(" ", "").ToUpper().Trim(), false) == 0);
				if (flag)
				{
					MySettingsProperty.Settings.BusinessLocationLat = array[3];
					MySettingsProperty.Settings.BusinessLocationLong = array[4];
					MySettingsProperty.Settings.Save();
					break;
				}
			}
			streamReader.Close();
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00038FC4 File Offset: 0x000371C4
		public static object GetStreetName()
		{
			try
			{
				string str = "pc";
				string text = MyProject.Forms.Incoming_Calls.PostCodeTextBox.Text;
				string str2 = "None";
				string text2 = text.Substring(0, 1);
				string text3 = text.Substring(0, 2);
				bool flag = File.Exists(str + "\\" + text2 + ".csv");
				if (flag)
				{
					str2 = text2 + ".csv";
				}
				else
				{
					flag = File.Exists(str + "\\" + text3 + ".csv");
					if (flag)
					{
						str2 = text3 + ".csv";
					}
					else
					{
						MessageBox.Show("Postcode not found.");
					}
				}
				StreamReader streamReader = File.OpenText(str + "\\" + str2);
				MyProject.Forms.Incoming_Calls.StreetNameTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.PostCodeTextBox.Focus();
				while (streamReader.Peek() != -1)
				{
					string text4 = streamReader.ReadLine();
					string[] array = text4.Split(new char[]
					{
						','
					});
					flag = (Operators.CompareString(MyProject.Forms.Incoming_Calls.PostCodeTextBox.Text.Replace(" ", "").ToUpper().Trim(), array[1].Replace(" ", "").ToUpper().Trim(), false) == 0);
					if (flag)
					{
						MyProject.Forms.Incoming_Calls.CustomerCityTextBox.Text = array[2];
						MyProject.Forms.Incoming_Calls.StreetNameTextBox.Text = " " + array[0];
						M_Settings.FocusedTextBoxForKeyboardTyping = MyProject.Forms.Incoming_Calls.StreetNameTextBox;
						MyProject.Forms.Incoming_Calls.StreetNameTextBox.Focus();
						MyProject.Forms.Incoming_Calls.StreetNameTextBox.Select(0, 0);
						return "";
					}
				}
				flag = (Operators.CompareString(MyProject.Forms.Incoming_Calls.StreetNameTextBox.Text.Replace(" ", ""), "", false) == 0);
				if (flag)
				{
					MessageBox.Show("Postcode not found.");
				}
				streamReader.Close();
			}
			catch (Exception ex)
			{
			}
			return "";
		}

		// Token: 0x060005FB RID: 1531 RVA: 0x00039258 File Offset: 0x00037458
		public static void CalculateDeliveryCharge(object CustomerPC)
		{
			try
			{
				string text = Conversions.ToString(NewLateBinding.LateGet(CustomerPC, null, "Replace", new object[]
				{
					" ",
					""
				}, null, null, null));
				text = text.Substring(0, checked(text.Length - 3));
				string left = text;
				bool flag = Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode1, false) == 0;
				if (flag)
				{
					M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode1);
				}
				else
				{
					flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode2, false) == 0);
					if (flag)
					{
						M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode2);
					}
					else
					{
						flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode3, false) == 0);
						if (flag)
						{
							M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode3);
						}
						else
						{
							flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode4, false) == 0);
							if (flag)
							{
								M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode4);
							}
							else
							{
								flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode5, false) == 0);
								if (flag)
								{
									M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode5);
								}
								else
								{
									flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode6, false) == 0);
									if (flag)
									{
										M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode6);
									}
									else
									{
										flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode7, false) == 0);
										if (flag)
										{
											M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode7);
										}
										else
										{
											flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode8, false) == 0);
											if (flag)
											{
												M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode8);
											}
											else
											{
												flag = (Operators.CompareString(left, MySettingsProperty.Settings.DeliveryPostCode9, false) == 0);
												if (flag)
												{
													M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryChargePostCode9);
												}
												else
												{
													flag = (Operators.CompareString(MySettingsProperty.Settings.DeliveryCharge, "", false) != 0);
													if (flag)
													{
														M_Calculates.OrderDelivery = Conversions.ToDecimal(MySettingsProperty.Settings.DeliveryCharge);
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
			}
		}
	}
}
