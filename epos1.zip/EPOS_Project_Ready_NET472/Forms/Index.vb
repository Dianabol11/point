using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;
using POS.My.Resources;

namespace POS
{
	// Token: 0x02000012 RID: 18
	[DesignerGenerated]
	public class Index : Form
	{
		// Token: 0x060002BF RID: 703 RVA: 0x0001C0C0 File Offset: 0x0001A2C0
		[DebuggerNonUserCode]
		public Index()
		{
			base.Load += this.Index_Load;
			List<WeakReference> _ENCList = Index.__ENCList;
			lock (_ENCList)
			{
				Index.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x0001C12C File Offset: 0x0001A32C
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x0001C17C File Offset: 0x0001A37C
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Index));
			this.DeliveryBTN = new Button();
			this.Button1 = new Button();
			this.CallerIdTimer = new Timer(this.components);
			this.DineInBTN = new Button();
			this.LatestCallsListBox = new ListBox();
			this.SoftwareLicenceLabel = new Label();
			this.ComputerNoLabel0 = new Label();
			this.MinimizeBTN = new Button();
			this.CashCarryBTN = new Button();
			this.ShopNameLabel = new Label();
			this.NoSaleBTN = new Button();
			this.DriversBTN = new Button();
			this.AdminShowBTN = new Button();
			this.Main_Panel = new Panel();
			this.DateGB = new GroupBox();
			this.ClockLBL = new Label();
			this.PictureBox2 = new PictureBox();
			this.EditOrdersBTN = new Button();
			this.TakeawayBTN = new Button();
			this.BalanceBTN = new Button();
			this.OccupiesTablesBTN = new Button();
			this.AccessCodeNo = new Label();
			this.WebON = new PictureBox();
			this.WebOnOff = new Label();
			this.WifiOnOff = new Label();
			this.WifiON = new PictureBox();
			this.PictureBox1 = new PictureBox();
			this.Timer1Min = new Timer(this.components);
			this.ClockTimer = new Timer(this.components);
			this.CheckBusinessDetailsOnServerTimer = new Timer(this.components);
			this.Main_Panel.SuspendLayout();
			this.DateGB.SuspendLayout();
			((ISupportInitialize)this.PictureBox2).BeginInit();
			((ISupportInitialize)this.WebON).BeginInit();
			((ISupportInitialize)this.WifiON).BeginInit();
			((ISupportInitialize)this.PictureBox1).BeginInit();
			this.SuspendLayout();
			this.DeliveryBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.DeliveryBTN.BackColor = Color.FromArgb(27, 94, 231);
			this.DeliveryBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.DeliveryBTN.FlatStyle = FlatStyle.Flat;
			this.DeliveryBTN.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DeliveryBTN.ForeColor = Color.Snow;
			Control deliveryBTN = this.DeliveryBTN;
			Point location = new Point(918, 14);
			deliveryBTN.Location = location;
			this.DeliveryBTN.Name = "DeliveryBTN";
			Control deliveryBTN2 = this.DeliveryBTN;
			Size size = new Size(252, 100);
			deliveryBTN2.Size = size;
			this.DeliveryBTN.TabIndex = 23;
			this.DeliveryBTN.Text = "Delivery Collection";
			this.DeliveryBTN.UseVisualStyleBackColor = false;
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button1.BackColor = Color.FromArgb(178, 1, 1);
			this.Button1.FlatAppearance.BorderColor = Color.Gainsboro;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(12, 672);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			size = new Size(106, 56);
			button2.Size = size;
			this.Button1.TabIndex = 25;
			this.Button1.Text = "Exit";
			this.Button1.UseVisualStyleBackColor = false;
			this.CallerIdTimer.Enabled = true;
			this.CallerIdTimer.Interval = 5000;
			this.DineInBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.DineInBTN.BackColor = Color.FromArgb(27, 94, 231);
			this.DineInBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.DineInBTN.FlatStyle = FlatStyle.Flat;
			this.DineInBTN.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DineInBTN.ForeColor = Color.Snow;
			Control dineInBTN = this.DineInBTN;
			location = new Point(918, 317);
			dineInBTN.Location = location;
			this.DineInBTN.Name = "DineInBTN";
			Control dineInBTN2 = this.DineInBTN;
			size = new Size(252, 100);
			dineInBTN2.Size = size;
			this.DineInBTN.TabIndex = 29;
			this.DineInBTN.Text = "Dine In";
			this.DineInBTN.UseVisualStyleBackColor = false;
			this.LatestCallsListBox.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.LatestCallsListBox.BackColor = Color.SteelBlue;
			this.LatestCallsListBox.BorderStyle = BorderStyle.None;
			this.LatestCallsListBox.Font = new Font("Arial", 21.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.LatestCallsListBox.ForeColor = Color.LightBlue;
			this.LatestCallsListBox.FormattingEnabled = true;
			this.LatestCallsListBox.ItemHeight = 33;
			Control latestCallsListBox = this.LatestCallsListBox;
			location = new Point(562, 14);
			latestCallsListBox.Location = location;
			this.LatestCallsListBox.Name = "LatestCallsListBox";
			Control latestCallsListBox2 = this.LatestCallsListBox;
			size = new Size(350, 99);
			latestCallsListBox2.Size = size;
			this.LatestCallsListBox.TabIndex = 31;
			this.LatestCallsListBox.Visible = false;
			this.SoftwareLicenceLabel.AutoSize = true;
			this.SoftwareLicenceLabel.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.SoftwareLicenceLabel.ForeColor = Color.Silver;
			Control softwareLicenceLabel = this.SoftwareLicenceLabel;
			location = new Point(22, 330);
			softwareLicenceLabel.Location = location;
			this.SoftwareLicenceLabel.Name = "SoftwareLicenceLabel";
			Control softwareLicenceLabel2 = this.SoftwareLicenceLabel;
			size = new Size(422, 18);
			softwareLicenceLabel2.Size = size;
			this.SoftwareLicenceLabel.TabIndex = 49;
			this.SoftwareLicenceLabel.Text = "Software Licence: Free for 14 days - Expires on 1234/12/12";
			this.SoftwareLicenceLabel.Visible = false;
			this.ComputerNoLabel0.AutoSize = true;
			this.ComputerNoLabel0.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ComputerNoLabel0.ForeColor = Color.Silver;
			Control computerNoLabel = this.ComputerNoLabel0;
			location = new Point(22, 307);
			computerNoLabel.Location = location;
			this.ComputerNoLabel0.Name = "ComputerNoLabel0";
			Control computerNoLabel2 = this.ComputerNoLabel0;
			size = new Size(250, 18);
			computerNoLabel2.Size = size;
			this.ComputerNoLabel0.TabIndex = 51;
			this.ComputerNoLabel0.Text = "Computer No: 1234-1234-1234-12";
			this.ComputerNoLabel0.Visible = false;
			this.MinimizeBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.MinimizeBTN.BackColor = Color.FromArgb(0, 192, 0);
			this.MinimizeBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.MinimizeBTN.FlatStyle = FlatStyle.Flat;
			this.MinimizeBTN.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.MinimizeBTN.ForeColor = Color.White;
			Control minimizeBTN = this.MinimizeBTN;
			location = new Point(124, 672);
			minimizeBTN.Location = location;
			this.MinimizeBTN.Name = "MinimizeBTN";
			Control minimizeBTN2 = this.MinimizeBTN;
			size = new Size(140, 56);
			minimizeBTN2.Size = size;
			this.MinimizeBTN.TabIndex = 38;
			this.MinimizeBTN.Text = "Minimize";
			this.MinimizeBTN.UseVisualStyleBackColor = false;
			this.CashCarryBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.CashCarryBTN.BackColor = Color.Orange;
			this.CashCarryBTN.FlatAppearance.BorderColor = Color.White;
			this.CashCarryBTN.FlatStyle = FlatStyle.Flat;
			this.CashCarryBTN.Font = new Font("Arial Narrow", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.CashCarryBTN.ForeColor = Color.Snow;
			Control cashCarryBTN = this.CashCarryBTN;
			location = new Point(272, 672);
			cashCarryBTN.Location = location;
			this.CashCarryBTN.Name = "CashCarryBTN";
			Control cashCarryBTN2 = this.CashCarryBTN;
			size = new Size(177, 56);
			cashCarryBTN2.Size = size;
			this.CashCarryBTN.TabIndex = 37;
			this.CashCarryBTN.Text = "Supplier";
			this.CashCarryBTN.UseVisualStyleBackColor = false;
			this.CashCarryBTN.Visible = false;
			this.ShopNameLabel.AutoSize = true;
			this.ShopNameLabel.Font = new Font("Arial", 36f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ShopNameLabel.ForeColor = Color.RoyalBlue;
			Control shopNameLabel = this.ShopNameLabel;
			location = new Point(15, 225);
			shopNameLabel.Location = location;
			this.ShopNameLabel.Name = "ShopNameLabel";
			Control shopNameLabel2 = this.ShopNameLabel;
			size = new Size(369, 55);
			shopNameLabel2.Size = size;
			this.ShopNameLabel.TabIndex = 37;
			this.ShopNameLabel.Text = "Your Restaurant";
			this.ShopNameLabel.Visible = false;
			this.NoSaleBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.NoSaleBTN.BackColor = Color.Lime;
			this.NoSaleBTN.FlatAppearance.BorderColor = Color.White;
			this.NoSaleBTN.FlatStyle = FlatStyle.Flat;
			this.NoSaleBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.NoSaleBTN.ForeColor = Color.Black;
			Control noSaleBTN = this.NoSaleBTN;
			location = new Point(918, 610);
			noSaleBTN.Location = location;
			this.NoSaleBTN.Name = "NoSaleBTN";
			Control noSaleBTN2 = this.NoSaleBTN;
			size = new Size(252, 56);
			noSaleBTN2.Size = size;
			this.NoSaleBTN.TabIndex = 32;
			this.NoSaleBTN.Text = "No Sale";
			this.NoSaleBTN.UseVisualStyleBackColor = false;
			this.DriversBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.DriversBTN.BackColor = Color.Lime;
			this.DriversBTN.FlatAppearance.BorderColor = Color.White;
			this.DriversBTN.FlatStyle = FlatStyle.Flat;
			this.DriversBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DriversBTN.ForeColor = Color.Black;
			Control driversBTN = this.DriversBTN;
			location = new Point(918, 227);
			driversBTN.Location = location;
			this.DriversBTN.Name = "DriversBTN";
			Control driversBTN2 = this.DriversBTN;
			size = new Size(124, 60);
			driversBTN2.Size = size;
			this.DriversBTN.TabIndex = 31;
			this.DriversBTN.Text = "Drivers";
			this.DriversBTN.UseVisualStyleBackColor = false;
			this.AdminShowBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.AdminShowBTN.BackColor = Color.DarkSlateBlue;
			this.AdminShowBTN.FlatAppearance.BorderColor = Color.White;
			this.AdminShowBTN.FlatStyle = FlatStyle.Flat;
			this.AdminShowBTN.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.AdminShowBTN.ForeColor = Color.Snow;
			Control adminShowBTN = this.AdminShowBTN;
			location = new Point(918, 672);
			adminShowBTN.Location = location;
			this.AdminShowBTN.Name = "AdminShowBTN";
			Control adminShowBTN2 = this.AdminShowBTN;
			size = new Size(252, 56);
			adminShowBTN2.Size = size;
			this.AdminShowBTN.TabIndex = 30;
			this.AdminShowBTN.Text = "Control Panel";
			this.AdminShowBTN.UseVisualStyleBackColor = false;
			this.Main_Panel.BackColor = Color.Transparent;
			this.Main_Panel.Controls.Add(this.DateGB);
			this.Main_Panel.Controls.Add(this.PictureBox2);
			this.Main_Panel.Controls.Add(this.EditOrdersBTN);
			this.Main_Panel.Controls.Add(this.TakeawayBTN);
			this.Main_Panel.Controls.Add(this.BalanceBTN);
			this.Main_Panel.Controls.Add(this.OccupiesTablesBTN);
			this.Main_Panel.Controls.Add(this.LatestCallsListBox);
			this.Main_Panel.Controls.Add(this.SoftwareLicenceLabel);
			this.Main_Panel.Controls.Add(this.MinimizeBTN);
			this.Main_Panel.Controls.Add(this.AccessCodeNo);
			this.Main_Panel.Controls.Add(this.NoSaleBTN);
			this.Main_Panel.Controls.Add(this.ComputerNoLabel0);
			this.Main_Panel.Controls.Add(this.DriversBTN);
			this.Main_Panel.Controls.Add(this.WebON);
			this.Main_Panel.Controls.Add(this.CashCarryBTN);
			this.Main_Panel.Controls.Add(this.Button1);
			this.Main_Panel.Controls.Add(this.ShopNameLabel);
			this.Main_Panel.Controls.Add(this.AdminShowBTN);
			this.Main_Panel.Controls.Add(this.DineInBTN);
			this.Main_Panel.Controls.Add(this.WebOnOff);
			this.Main_Panel.Controls.Add(this.DeliveryBTN);
			this.Main_Panel.Controls.Add(this.WifiOnOff);
			this.Main_Panel.Controls.Add(this.WifiON);
			this.Main_Panel.Controls.Add(this.PictureBox1);
			this.Main_Panel.Dock = DockStyle.Fill;
			Control main_Panel = this.Main_Panel;
			location = new Point(0, 0);
			main_Panel.Location = location;
			this.Main_Panel.Name = "Main_Panel";
			Control main_Panel2 = this.Main_Panel;
			size = new Size(1182, 740);
			main_Panel2.Size = size;
			this.Main_Panel.TabIndex = 34;
			this.DateGB.BackColor = Color.Transparent;
			this.DateGB.BackgroundImageLayout = ImageLayout.None;
			this.DateGB.Controls.Add(this.ClockLBL);
			this.DateGB.FlatStyle = FlatStyle.Popup;
			this.DateGB.Font = new Font("Arial", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DateGB.ForeColor = Color.LightSkyBlue;
			Control dateGB = this.DateGB;
			location = new Point(137, 123);
			dateGB.Location = location;
			this.DateGB.Name = "DateGB";
			Control dateGB2 = this.DateGB;
			size = new Size(247, 75);
			dateGB2.Size = size;
			this.DateGB.TabIndex = 70;
			this.DateGB.TabStop = false;
			this.DateGB.Text = "Wednesday, 00 December 0000";
			this.ClockLBL.AutoSize = true;
			this.ClockLBL.BackColor = Color.Transparent;
			this.ClockLBL.Font = new Font("Arial Black", 30f, FontStyle.Bold);
			this.ClockLBL.ForeColor = Color.DodgerBlue;
			Control clockLBL = this.ClockLBL;
			location = new Point(18, 12);
			clockLBL.Location = location;
			this.ClockLBL.Name = "ClockLBL";
			Control clockLBL2 = this.ClockLBL;
			size = new Size(212, 56);
			clockLBL2.Size = size;
			this.ClockLBL.TabIndex = 68;
			this.ClockLBL.Text = "00:00:00";
			this.PictureBox2.Image = Resources.logo_software;
			Control pictureBox = this.PictureBox2;
			location = new Point(25, 12);
			pictureBox.Location = location;
			this.PictureBox2.Name = "PictureBox2";
			Control pictureBox2 = this.PictureBox2;
			size = new Size(375, 99);
			pictureBox2.Size = size;
			this.PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
			this.PictureBox2.TabIndex = 67;
			this.PictureBox2.TabStop = false;
			this.EditOrdersBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.EditOrdersBTN.BackColor = Color.Orange;
			this.EditOrdersBTN.FlatAppearance.BorderColor = Color.White;
			this.EditOrdersBTN.FlatStyle = FlatStyle.Flat;
			this.EditOrdersBTN.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.EditOrdersBTN.ForeColor = Color.Snow;
			Control editOrdersBTN = this.EditOrdersBTN;
			location = new Point(1048, 226);
			editOrdersBTN.Location = location;
			this.EditOrdersBTN.Name = "EditOrdersBTN";
			Control editOrdersBTN2 = this.EditOrdersBTN;
			size = new Size(122, 60);
			editOrdersBTN2.Size = size;
			this.EditOrdersBTN.TabIndex = 64;
			this.EditOrdersBTN.Text = "Orders";
			this.EditOrdersBTN.UseVisualStyleBackColor = false;
			this.TakeawayBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.TakeawayBTN.BackColor = Color.FromArgb(27, 94, 231);
			this.TakeawayBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.TakeawayBTN.FlatStyle = FlatStyle.Flat;
			this.TakeawayBTN.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.TakeawayBTN.ForeColor = Color.Snow;
			Control takeawayBTN = this.TakeawayBTN;
			location = new Point(918, 120);
			takeawayBTN.Location = location;
			this.TakeawayBTN.Name = "TakeawayBTN";
			Control takeawayBTN2 = this.TakeawayBTN;
			size = new Size(252, 100);
			takeawayBTN2.Size = size;
			this.TakeawayBTN.TabIndex = 63;
			this.TakeawayBTN.Text = "Takeaway";
			this.TakeawayBTN.UseVisualStyleBackColor = false;
			this.BalanceBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.BalanceBTN.BackColor = Color.Gold;
			this.BalanceBTN.FlatStyle = FlatStyle.Flat;
			this.BalanceBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.BalanceBTN.ForeColor = Color.FromArgb(64, 0, 0);
			Control balanceBTN = this.BalanceBTN;
			location = new Point(22, 352);
			balanceBTN.Location = location;
			Control balanceBTN2 = this.BalanceBTN;
			Padding margin = new Padding(4);
			balanceBTN2.Margin = margin;
			this.BalanceBTN.Name = "BalanceBTN";
			Control balanceBTN3 = this.BalanceBTN;
			size = new Size(427, 60);
			balanceBTN3.Size = size;
			this.BalanceBTN.TabIndex = 62;
			this.BalanceBTN.Text = "click to pay";
			this.BalanceBTN.UseVisualStyleBackColor = false;
			this.BalanceBTN.Visible = false;
			this.OccupiesTablesBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.OccupiesTablesBTN.BackColor = Color.Crimson;
			this.OccupiesTablesBTN.FlatAppearance.BorderColor = Color.White;
			this.OccupiesTablesBTN.FlatStyle = FlatStyle.Flat;
			this.OccupiesTablesBTN.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.OccupiesTablesBTN.ForeColor = Color.Snow;
			Control occupiesTablesBTN = this.OccupiesTablesBTN;
			location = new Point(918, 423);
			occupiesTablesBTN.Location = location;
			this.OccupiesTablesBTN.Name = "OccupiesTablesBTN";
			Control occupiesTablesBTN2 = this.OccupiesTablesBTN;
			size = new Size(252, 73);
			occupiesTablesBTN2.Size = size;
			this.OccupiesTablesBTN.TabIndex = 61;
			this.OccupiesTablesBTN.Text = "Occupied Tables";
			this.OccupiesTablesBTN.UseVisualStyleBackColor = false;
			this.AccessCodeNo.AutoSize = true;
			this.AccessCodeNo.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.AccessCodeNo.ForeColor = Color.FromArgb(128, 255, 128);
			Control accessCodeNo = this.AccessCodeNo;
			location = new Point(22, 284);
			accessCodeNo.Location = location;
			this.AccessCodeNo.Name = "AccessCodeNo";
			Control accessCodeNo2 = this.AccessCodeNo;
			size = new Size(249, 18);
			accessCodeNo2.Size = size;
			this.AccessCodeNo.TabIndex = 53;
			this.AccessCodeNo.Text = "Online Access Code: Not Available";
			this.AccessCodeNo.Visible = false;
			this.WebON.Image = (Image)componentResourceManager.GetObject("WebON.Image");
			Control webON = this.WebON;
			location = new Point(79, 135);
			webON.Location = location;
			this.WebON.Name = "WebON";
			Control webON2 = this.WebON;
			size = new Size(35, 35);
			webON2.Size = size;
			this.WebON.SizeMode = PictureBoxSizeMode.StretchImage;
			this.WebON.TabIndex = 48;
			this.WebON.TabStop = false;
			this.WebON.Visible = false;
			this.WebOnOff.AutoSize = true;
			this.WebOnOff.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.WebOnOff.ForeColor = SystemColors.ButtonFace;
			Control webOnOff = this.WebOnOff;
			location = new Point(78, 178);
			webOnOff.Location = location;
			this.WebOnOff.Name = "WebOnOff";
			Control webOnOff2 = this.WebOnOff;
			size = new Size(38, 16);
			webOnOff2.Size = size;
			this.WebOnOff.TabIndex = 46;
			this.WebOnOff.Text = "WEB";
			this.WebOnOff.Visible = false;
			this.WifiOnOff.AutoSize = true;
			this.WifiOnOff.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.WifiOnOff.ForeColor = SystemColors.ButtonFace;
			Control wifiOnOff = this.WifiOnOff;
			location = new Point(27, 178);
			wifiOnOff.Location = location;
			this.WifiOnOff.Name = "WifiOnOff";
			Control wifiOnOff2 = this.WifiOnOff;
			size = new Size(37, 16);
			wifiOnOff2.Size = size;
			this.WifiOnOff.TabIndex = 43;
			this.WifiOnOff.Text = "WIFI";
			this.WifiOnOff.Visible = false;
			this.WifiON.Image = (Image)componentResourceManager.GetObject("WifiON.Image");
			Control wifiON = this.WifiON;
			location = new Point(27, 136);
			wifiON.Location = location;
			this.WifiON.Name = "WifiON";
			Control wifiON2 = this.WifiON;
			size = new Size(35, 35);
			wifiON2.Size = size;
			this.WifiON.SizeMode = PictureBoxSizeMode.StretchImage;
			this.WifiON.TabIndex = 42;
			this.WifiON.TabStop = false;
			this.WifiON.Visible = false;
			this.PictureBox1.Dock = DockStyle.Fill;
			this.PictureBox1.Image = Resources.bg;
			Control pictureBox3 = this.PictureBox1;
			location = new Point(0, 0);
			pictureBox3.Location = location;
			this.PictureBox1.Name = "PictureBox1";
			Control pictureBox4 = this.PictureBox1;
			size = new Size(1182, 740);
			pictureBox4.Size = size;
			this.PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
			this.PictureBox1.TabIndex = 54;
			this.PictureBox1.TabStop = false;
			this.Timer1Min.Interval = 60000;
			this.ClockTimer.Enabled = true;
			this.ClockTimer.Interval = 1000;
			this.CheckBusinessDetailsOnServerTimer.Interval = 600000;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.FromArgb(37, 44, 72);
			this.BackgroundImageLayout = ImageLayout.None;
			size = new Size(1182, 740);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.Main_Panel);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Index";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Index";
			this.WindowState = FormWindowState.Maximized;
			this.Main_Panel.ResumeLayout(false);
			this.Main_Panel.PerformLayout();
			this.DateGB.ResumeLayout(false);
			this.DateGB.PerformLayout();
			((ISupportInitialize)this.PictureBox2).EndInit();
			((ISupportInitialize)this.WebON).EndInit();
			((ISupportInitialize)this.WifiON).EndInit();
			((ISupportInitialize)this.PictureBox1).EndInit();
			this.ResumeLayout(false);
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x060002C2 RID: 706 RVA: 0x0001DB90 File Offset: 0x0001BD90
		// (set) Token: 0x060002C3 RID: 707 RVA: 0x0001DBA8 File Offset: 0x0001BDA8
		internal virtual Button DeliveryBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeliveryBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.MealNextBTN_Click);
				bool flag = this._DeliveryBTN != null;
				if (flag)
				{
					this._DeliveryBTN.Click -= value2;
				}
				this._DeliveryBTN = value;
				flag = (this._DeliveryBTN != null);
				if (flag)
				{
					this._DeliveryBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x060002C4 RID: 708 RVA: 0x0001DC08 File Offset: 0x0001BE08
		// (set) Token: 0x060002C5 RID: 709 RVA: 0x0001DC20 File Offset: 0x0001BE20
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x060002C6 RID: 710 RVA: 0x0001DC80 File Offset: 0x0001BE80
		// (set) Token: 0x060002C7 RID: 711 RVA: 0x0001DC98 File Offset: 0x0001BE98
		public virtual Timer CallerIdTimer
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CallerIdTimer;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Timer1_Tick);
				bool flag = this._CallerIdTimer != null;
				if (flag)
				{
					this._CallerIdTimer.Tick -= value2;
				}
				this._CallerIdTimer = value;
				flag = (this._CallerIdTimer != null);
				if (flag)
				{
					this._CallerIdTimer.Tick += value2;
				}
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x060002C8 RID: 712 RVA: 0x0001DCF8 File Offset: 0x0001BEF8
		// (set) Token: 0x060002C9 RID: 713 RVA: 0x0001DD10 File Offset: 0x0001BF10
		internal virtual Button DineInBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DineInBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._DineInBTN != null;
				if (flag)
				{
					this._DineInBTN.Click -= value2;
				}
				this._DineInBTN = value;
				flag = (this._DineInBTN != null);
				if (flag)
				{
					this._DineInBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x060002CA RID: 714 RVA: 0x0001DD70 File Offset: 0x0001BF70
		// (set) Token: 0x060002CB RID: 715 RVA: 0x00002A43 File Offset: 0x00000C43
		internal virtual ListBox LatestCallsListBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LatestCallsListBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._LatestCallsListBox = value;
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x060002CC RID: 716 RVA: 0x0001DD88 File Offset: 0x0001BF88
		// (set) Token: 0x060002CD RID: 717 RVA: 0x00002A4D File Offset: 0x00000C4D
		internal virtual Panel Main_Panel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Main_Panel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Main_Panel = value;
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x060002CE RID: 718 RVA: 0x0001DDA0 File Offset: 0x0001BFA0
		// (set) Token: 0x060002CF RID: 719 RVA: 0x0001DDB8 File Offset: 0x0001BFB8
		internal virtual Button AdminShowBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AdminShowBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.AdminShowBTN_Click);
				bool flag = this._AdminShowBTN != null;
				if (flag)
				{
					this._AdminShowBTN.Click -= value2;
				}
				this._AdminShowBTN = value;
				flag = (this._AdminShowBTN != null);
				if (flag)
				{
					this._AdminShowBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x060002D0 RID: 720 RVA: 0x0001DE18 File Offset: 0x0001C018
		// (set) Token: 0x060002D1 RID: 721 RVA: 0x00002A57 File Offset: 0x00000C57
		internal virtual Label ShopNameLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ShopNameLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ShopNameLabel = value;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x060002D2 RID: 722 RVA: 0x0001DE30 File Offset: 0x0001C030
		// (set) Token: 0x060002D3 RID: 723 RVA: 0x00002A61 File Offset: 0x00000C61
		internal virtual PictureBox WifiON
		{
			[DebuggerNonUserCode]
			get
			{
				return this._WifiON;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._WifiON = value;
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x060002D4 RID: 724 RVA: 0x0001DE48 File Offset: 0x0001C048
		// (set) Token: 0x060002D5 RID: 725 RVA: 0x0001DE60 File Offset: 0x0001C060
		internal virtual Timer Timer1Min
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Timer1Min;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Timer1Min_Tick);
				bool flag = this._Timer1Min != null;
				if (flag)
				{
					this._Timer1Min.Tick -= value2;
				}
				this._Timer1Min = value;
				flag = (this._Timer1Min != null);
				if (flag)
				{
					this._Timer1Min.Tick += value2;
				}
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x060002D6 RID: 726 RVA: 0x0001DEC0 File Offset: 0x0001C0C0
		// (set) Token: 0x060002D7 RID: 727 RVA: 0x00002A6B File Offset: 0x00000C6B
		internal virtual Label WifiOnOff
		{
			[DebuggerNonUserCode]
			get
			{
				return this._WifiOnOff;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._WifiOnOff = value;
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x060002D8 RID: 728 RVA: 0x0001DED8 File Offset: 0x0001C0D8
		// (set) Token: 0x060002D9 RID: 729 RVA: 0x00002A75 File Offset: 0x00000C75
		internal virtual Label WebOnOff
		{
			[DebuggerNonUserCode]
			get
			{
				return this._WebOnOff;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._WebOnOff = value;
			}
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x060002DA RID: 730 RVA: 0x0001DEF0 File Offset: 0x0001C0F0
		// (set) Token: 0x060002DB RID: 731 RVA: 0x0001DF08 File Offset: 0x0001C108
		internal virtual PictureBox WebON
		{
			[DebuggerNonUserCode]
			get
			{
				return this._WebON;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.WebON_Click);
				bool flag = this._WebON != null;
				if (flag)
				{
					this._WebON.Click -= value2;
				}
				this._WebON = value;
				flag = (this._WebON != null);
				if (flag)
				{
					this._WebON.Click += value2;
				}
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x060002DC RID: 732 RVA: 0x0001DF68 File Offset: 0x0001C168
		// (set) Token: 0x060002DD RID: 733 RVA: 0x0001DF80 File Offset: 0x0001C180
		internal virtual Button NoSaleBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoSaleBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click_1);
				bool flag = this._NoSaleBTN != null;
				if (flag)
				{
					this._NoSaleBTN.Click -= value2;
				}
				this._NoSaleBTN = value;
				flag = (this._NoSaleBTN != null);
				if (flag)
				{
					this._NoSaleBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x060002DE RID: 734 RVA: 0x0001DFE0 File Offset: 0x0001C1E0
		// (set) Token: 0x060002DF RID: 735 RVA: 0x0001DFF8 File Offset: 0x0001C1F8
		internal virtual Button DriversBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DriversBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DriversBTN_Click);
				bool flag = this._DriversBTN != null;
				if (flag)
				{
					this._DriversBTN.Click -= value2;
				}
				this._DriversBTN = value;
				flag = (this._DriversBTN != null);
				if (flag)
				{
					this._DriversBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x060002E0 RID: 736 RVA: 0x0001E058 File Offset: 0x0001C258
		// (set) Token: 0x060002E1 RID: 737 RVA: 0x00002A7F File Offset: 0x00000C7F
		internal virtual Label SoftwareLicenceLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SoftwareLicenceLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._SoftwareLicenceLabel = value;
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x060002E2 RID: 738 RVA: 0x0001E070 File Offset: 0x0001C270
		// (set) Token: 0x060002E3 RID: 739 RVA: 0x0001E088 File Offset: 0x0001C288
		internal virtual Button MinimizeBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MinimizeBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.MinimizeBTN_Click);
				bool flag = this._MinimizeBTN != null;
				if (flag)
				{
					this._MinimizeBTN.Click -= value2;
				}
				this._MinimizeBTN = value;
				flag = (this._MinimizeBTN != null);
				if (flag)
				{
					this._MinimizeBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x060002E4 RID: 740 RVA: 0x0001E0E8 File Offset: 0x0001C2E8
		// (set) Token: 0x060002E5 RID: 741 RVA: 0x0001E100 File Offset: 0x0001C300
		internal virtual Button CashCarryBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CashCarryBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CashCarryBTN_Click);
				bool flag = this._CashCarryBTN != null;
				if (flag)
				{
					this._CashCarryBTN.Click -= value2;
				}
				this._CashCarryBTN = value;
				flag = (this._CashCarryBTN != null);
				if (flag)
				{
					this._CashCarryBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x060002E6 RID: 742 RVA: 0x0001E160 File Offset: 0x0001C360
		// (set) Token: 0x060002E7 RID: 743 RVA: 0x00002A89 File Offset: 0x00000C89
		internal virtual Label ComputerNoLabel0
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ComputerNoLabel0;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ComputerNoLabel0 = value;
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x060002E8 RID: 744 RVA: 0x0001E178 File Offset: 0x0001C378
		// (set) Token: 0x060002E9 RID: 745 RVA: 0x00002A93 File Offset: 0x00000C93
		internal virtual Label AccessCodeNo
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AccessCodeNo;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AccessCodeNo = value;
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x060002EA RID: 746 RVA: 0x0001E190 File Offset: 0x0001C390
		// (set) Token: 0x060002EB RID: 747 RVA: 0x00002A9D File Offset: 0x00000C9D
		internal virtual PictureBox PictureBox1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PictureBox1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PictureBox1 = value;
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x060002EC RID: 748 RVA: 0x0001E1A8 File Offset: 0x0001C3A8
		// (set) Token: 0x060002ED RID: 749 RVA: 0x0001E1C0 File Offset: 0x0001C3C0
		internal virtual Button OccupiesTablesBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OccupiesTablesBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.OccupiesTablesBTN_Click);
				bool flag = this._OccupiesTablesBTN != null;
				if (flag)
				{
					this._OccupiesTablesBTN.Click -= value2;
				}
				this._OccupiesTablesBTN = value;
				flag = (this._OccupiesTablesBTN != null);
				if (flag)
				{
					this._OccupiesTablesBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x060002EE RID: 750 RVA: 0x0001E220 File Offset: 0x0001C420
		// (set) Token: 0x060002EF RID: 751 RVA: 0x00002AA7 File Offset: 0x00000CA7
		internal virtual Button BalanceBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BalanceBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BalanceBTN = value;
			}
		}

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x060002F0 RID: 752 RVA: 0x0001E238 File Offset: 0x0001C438
		// (set) Token: 0x060002F1 RID: 753 RVA: 0x0001E250 File Offset: 0x0001C450
		internal virtual Button TakeawayBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TakeawayBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click_1);
				bool flag = this._TakeawayBTN != null;
				if (flag)
				{
					this._TakeawayBTN.Click -= value2;
				}
				this._TakeawayBTN = value;
				flag = (this._TakeawayBTN != null);
				if (flag)
				{
					this._TakeawayBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x060002F2 RID: 754 RVA: 0x0001E2B0 File Offset: 0x0001C4B0
		// (set) Token: 0x060002F3 RID: 755 RVA: 0x0001E2C8 File Offset: 0x0001C4C8
		internal virtual Button EditOrdersBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EditOrdersBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.EditOrdersBTN_Click);
				bool flag = this._EditOrdersBTN != null;
				if (flag)
				{
					this._EditOrdersBTN.Click -= value2;
				}
				this._EditOrdersBTN = value;
				flag = (this._EditOrdersBTN != null);
				if (flag)
				{
					this._EditOrdersBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x060002F4 RID: 756 RVA: 0x0001E328 File Offset: 0x0001C528
		// (set) Token: 0x060002F5 RID: 757 RVA: 0x00002AB1 File Offset: 0x00000CB1
		internal virtual PictureBox PictureBox2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PictureBox2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PictureBox2 = value;
			}
		}

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x060002F6 RID: 758 RVA: 0x0001E340 File Offset: 0x0001C540
		// (set) Token: 0x060002F7 RID: 759 RVA: 0x00002ABB File Offset: 0x00000CBB
		internal virtual Label ClockLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ClockLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ClockLBL = value;
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x060002F8 RID: 760 RVA: 0x0001E358 File Offset: 0x0001C558
		// (set) Token: 0x060002F9 RID: 761 RVA: 0x0001E370 File Offset: 0x0001C570
		internal virtual Timer ClockTimer
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ClockTimer;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ClockTimer_Tick);
				bool flag = this._ClockTimer != null;
				if (flag)
				{
					this._ClockTimer.Tick -= value2;
				}
				this._ClockTimer = value;
				flag = (this._ClockTimer != null);
				if (flag)
				{
					this._ClockTimer.Tick += value2;
				}
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x060002FA RID: 762 RVA: 0x0001E3D0 File Offset: 0x0001C5D0
		// (set) Token: 0x060002FB RID: 763 RVA: 0x00002AC5 File Offset: 0x00000CC5
		internal virtual GroupBox DateGB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DateGB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DateGB = value;
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x060002FC RID: 764 RVA: 0x0001E3E8 File Offset: 0x0001C5E8
		// (set) Token: 0x060002FD RID: 765 RVA: 0x0001E400 File Offset: 0x0001C600
		internal virtual Timer CheckBusinessDetailsOnServerTimer
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CheckBusinessDetailsOnServerTimer;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CheckBusinessDetailsOnServer_Tick);
				bool flag = this._CheckBusinessDetailsOnServerTimer != null;
				if (flag)
				{
					this._CheckBusinessDetailsOnServerTimer.Tick -= value2;
				}
				this._CheckBusinessDetailsOnServerTimer = value;
				flag = (this._CheckBusinessDetailsOnServerTimer != null);
				if (flag)
				{
					this._CheckBusinessDetailsOnServerTimer.Tick += value2;
				}
			}
		}

		// Token: 0x060002FE RID: 766 RVA: 0x0001E460 File Offset: 0x0001C660
		private void Index_Load(object sender, EventArgs e)
		{
			Online.checkinternet();
			M_Settings.AutoCompleteActive = "no";
			string left = "no";
			bool flag = File.Exists("settings.txt") & !Directory.Exists("data");
			if (flag)
			{
				M_Settings.Create_AllFiles_AllFolders();
			}
			flag = (File.Exists("settings.txt") & Directory.Exists("data"));
			bool flag2;
			if (flag)
			{
				flag2 = (Operators.CompareString(File.ReadAllText("data\\admin\\BusinessInfo.txt"), "", false) == 0);
				if (flag2)
				{
					this.Enabled = false;
					MyProject.Forms.Register.Show();
					return;
				}
			}
			flag2 = (Operators.CompareString(MySettingsProperty.Settings.SoftwareType, "", false) != 0 & Operators.CompareString(MySettingsProperty.Settings.PostCodeFinder, "", false) != 0 & Operators.CompareString(MySettingsProperty.Settings.SoftwareWebsite, "", false) != 0 & Operators.CompareString(MySettingsProperty.Settings.FTPusername, "", false) != 0 & Operators.CompareString(MySettingsProperty.Settings.FTPpassword, "", false) != 0);
			if (flag2)
			{
				Online.CheckBusinessInfoWithServer();
				left = "yes";
			}
			flag2 = (Operators.CompareString(left, "yes", false) == 0);
			if (flag2)
			{
				try
				{
					Online.AutoMenuDownload();
					Online.AddActivityOnServer();
					flag2 = (Operators.CompareString(M_Settings.SoftwareOnlineStatus, "online", false) == 0);
					if (flag2)
					{
						this.CheckBalanceWithServer();
					}
					string[] array = File.ReadAllText("data\\admin\\BusinessInfo.txt").Split(new char[]
					{
						'|'
					});
					flag2 = (array[7].Length == 8);
					if (flag2)
					{
						MySettingsProperty.Settings.SoftwareExpiryDate = array[7];
						MySettingsProperty.Settings.LicenseNo = "";
						MySettingsProperty.Settings.Save();
					}
					flag2 = (array[7].Length > 8);
					if (flag2)
					{
						MySettingsProperty.Settings.LicenseNo = array[7];
						MySettingsProperty.Settings.SoftwareExpiryDate = "";
						MySettingsProperty.Settings.Save();
					}
				}
				catch (Exception ex)
				{
				}
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.SoftwareOnlineExpiryDate, "", false) != 0);
				if (flag2)
				{
					string text = MySettingsProperty.Settings.SoftwareOnlineExpiryDate.ToString();
					text = text.Insert(6, "/");
					text = text.Insert(4, "/");
					string text2 = Conversions.ToString(NewLateBinding.LateGet(M_Settings.CurrentDate(), null, "Insert", new object[]
					{
						6,
						"/"
					}, null, null, null));
					text2 = text2.Insert(4, "/");
					DateTime dateTime = Conversions.ToDate("#" + text + " 10:00:00 AM#");
					DateTime dateTime2 = Conversions.ToDate("#" + text2 + " 10:00:00 AM#");
					M_Settings.SoftwareOnlineExpiryDaysLeft = (dateTime.Date - dateTime2.Date).Days;
					flag2 = (M_Settings.SoftwareOnlineExpiryDaysLeft < 0);
					if (flag2)
					{
						M_Settings.SoftwareOnlineStatus = "offline";
					}
					else
					{
						M_Settings.SoftwareOnlineStatus = "online";
						M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
						flag2 = (Operators.CompareString(MySettingsProperty.Settings.DriversAccess, "y", false) == 0);
						if (flag2)
						{
							this.AccessCodeNo.Text = Conversions.ToString(Operators.AddObject("Online Access Code: ", Online.postdata(Online.SoftwareDomain, "read_driver_access_code.php", "", MySettingsProperty.Settings.BusinessName, MySettingsProperty.Settings.BusinessPostcode, "", "", "")));
						}
						M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
						flag2 = (Operators.CompareString(MySettingsProperty.Settings.DriversAccess, "n", false) == 0);
						if (flag2)
						{
							this.AccessCodeNo.Text = "Online Access Code: ******";
						}
					}
				}
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.SoftwareExpiryDate, "", false) == 0);
				if (flag2)
				{
					flag = Operators.ConditionalCompareObjectEqual(MyProject.Forms.BuyLicence.CheckLicenseNo(MySettingsProperty.Settings.LicenseNo), "LicenseOK", false);
					if (flag)
					{
						string text3 = MySettingsProperty.Settings.LicenseNo.Insert(12, "-");
						text3 = text3.Insert(8, "-");
						text3 = text3.Insert(4, "-");
						this.SoftwareLicenceLabel.Text = "Software Licence: " + text3;
					}
					else
					{
						MessageBox.Show("License number is not correct.");
						this.Close();
					}
				}
				this.ComputerNoLabel0.Visible = true;
				this.ShopNameLabel.Visible = true;
				this.AccessCodeNo.Visible = true;
				this.SoftwareLicenceLabel.Visible = true;
				MyProject.Forms.POS_Window.Visible = false;
				MyProject.Forms.POS_Window.SendToBack();
				MyProject.Forms.Incoming_Calls.Visible = false;
				MyProject.Forms.Incoming_Calls.SendToBack();
				M_Settings.Load_Settings();
				M_Shopping_Cart.Create_ShoppingCart();
				M_TLP_Category.Create_Category_TLPs();
				try
				{
					foreach (object obj in M_Settings.Category_ArrayList)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						string[] array2 = (string[])NewLateBinding.LateGet(objectValue, null, "Split", new object[]
						{
							new char[]
							{
								'|'
							}
						}, null, null, null);
						M_TLP_Sizes.Create_Sizes_TLPs(array2[0], array2[1]);
					}
				}
				finally
				{
					IEnumerator enumerator;
					flag2 = (enumerator is IDisposable);
					if (flag2)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				M_TLP_Options.Create_Options_TLPs();
				M_TLP_Foods.Create_Food_TLPs();
				flag2 = (Operators.CompareString(M_Settings.CallerIdEnabled, "yes", false) == 0);
				if (flag2)
				{
					CallerID.LoadCallerId();
				}
				this.ShopNameLabel.Text = M_Settings.ShopName;
				this.ComputerNoLabel0.Text = "Computer No: " + MySettingsProperty.Settings.ComputerNo;
				this.BackColor = Color.FromArgb(37, 44, 72);
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.LockSoftware, "yes", false) == 0);
				if (flag2)
				{
					MyProject.Forms.LockSoftware.Show();
				}
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.RemoveItemsInShoppingCart, "y", false) == 0);
				if (flag2)
				{
					MyProject.Forms.POS_Window.EditPriceBTN.Visible = true;
					MyProject.Forms.POS_Window.DecreaseQTY.Visible = true;
					MyProject.Forms.POS_Window.IncreaseQTY.Visible = true;
				}
				else
				{
					MyProject.Forms.POS_Window.EditPriceBTN.Visible = false;
					MyProject.Forms.POS_Window.DecreaseQTY.Visible = false;
					MyProject.Forms.POS_Window.IncreaseQTY.Visible = false;
				}
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.ActiveEditOrders, "y", false) == 0);
				if (flag2)
				{
				}
				this.CheckIfFreeTrialExpired();
			}
			flag2 = (Operators.CompareString(M_Settings.SoftwareOnlineStatus, "online", false) == 0);
			if (flag2)
			{
				Online.CheckIfSoftwareNewVersionIsAvailable();
			}
			flag2 = (Operators.CompareString(File.ReadAllText("data\\admin\\BusinessInfo.txt"), "Softeware Demo Version|12345678901|Address|City|Postcode|07777777777|stockportdesign.co.uk/demo|20500101|20500101", false) == 0);
			if (flag2)
			{
				MyProject.Forms.DemoSelectMenu.Show();
			}
		}

		// Token: 0x060002FF RID: 767 RVA: 0x0001EBF8 File Offset: 0x0001CDF8
		private void Button1_Click(object sender, EventArgs e)
		{
			string left = Conversions.ToString(MyProject.Forms.OccupiedTables.CheckUnpaidTables());
			bool flag = Operators.CompareString(left, "DoExit", false) == 0;
			if (flag)
			{
				MyProject.Forms.FreeFoodsOffer.Show();
			}
		}

		// Token: 0x06000300 RID: 768 RVA: 0x00002ACF File Offset: 0x00000CCF
		private void Timer1_Tick(object sender, EventArgs e)
		{
			CallerID.GetCustomerCallerId(M_Settings.CallerIdType);
		}

		// Token: 0x06000301 RID: 769 RVA: 0x00002ADE File Offset: 0x00000CDE
		private void Button3_Click(object sender, EventArgs e)
		{
			M_Settings.TableNumber = "";
			MyProject.Forms.TableSelection.Show();
		}

		// Token: 0x06000302 RID: 770 RVA: 0x0001EC40 File Offset: 0x0001CE40
		private void MealNextBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text = "";
			MyProject.Forms.Incoming_Calls.PostCodeTextBox.Text = "";
			MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text = "";
			MyProject.Forms.Incoming_Calls.StreetNameTextBox.Text = "";
			MyProject.Forms.Incoming_Calls.CustomerCityTextBox.Text = "";
			MyProject.Forms.Incoming_Calls.CustomerNoteTextBox.Text = "";
			MyProject.Forms.Incoming_Calls.PostCodeTextBox.Focus();
			M_Settings.ShowForm(MyProject.Forms.Incoming_Calls);
		}

		// Token: 0x06000303 RID: 771 RVA: 0x00002AFC File Offset: 0x00000CFC
		public void ListBox_ItemClick()
		{
			CallerID.CheckIfCustomerAlreadyHasOrder("ListBoxClick");
		}

		// Token: 0x06000304 RID: 772 RVA: 0x00002B0B File Offset: 0x00000D0B
		private void AdminShowBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.General_Settings.Show();
			MyProject.Forms.General_Settings.BringToFront();
			MyProject.Forms.General_Settings.LoginPanel.BringToFront();
		}

		// Token: 0x06000305 RID: 773 RVA: 0x00002B44 File Offset: 0x00000D44
		private void Timer1Min_Tick(object sender, EventArgs e)
		{
			SuspiciousActivities.SuspiciousActivitiesAutoCompleteOrders();
		}

		// Token: 0x06000306 RID: 774 RVA: 0x0001ED10 File Offset: 0x0001CF10
		private void Button3_Click_1(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0;
			if (flag)
			{
				MyProject.Forms.Printing_Setup.PrintOpenTill.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
			}
			MyProject.Forms.Printing_Setup.PrintOpenTill.Print();
		}

		// Token: 0x06000307 RID: 775 RVA: 0x00002B4E File Offset: 0x00000D4E
		private void MinimizeBTN_Click(object sender, EventArgs e)
		{
			this.WindowState = FormWindowState.Minimized;
			MyProject.Forms.POS_Window.WindowState = FormWindowState.Minimized;
			MyProject.Forms.Incoming_Calls.WindowState = FormWindowState.Minimized;
		}

		// Token: 0x06000308 RID: 776 RVA: 0x0001ED78 File Offset: 0x0001CF78
		private void CashCarryBTN_Click(object sender, EventArgs e)
		{
			try
			{
				NewLateBinding.LateCall(null, typeof(Process), "Start", new object[]
				{
					RuntimeHelpers.GetObjectValue(Online.CASHandCARRY())
				}, null, null, null, true);
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000309 RID: 777 RVA: 0x00002B7C File Offset: 0x00000D7C
		private void TimerAutoComplete_Tick(object sender, EventArgs e)
		{
			M_Settings.PaymentType = "Cash";
			MyProject.Forms.POS_Window.ReadyToTakeNewOrder("yes");
			SuspiciousActivities.SuspiciousActivitiesAutoCompleteOrders();
		}

		// Token: 0x0600030A RID: 778 RVA: 0x00002BA5 File Offset: 0x00000DA5
		private void DriversBTN_Click(object sender, EventArgs e)
		{
			M_Settings.OrderToDriverStatus = "yes";
			MyProject.Forms.EditOrders.Show();
		}

		// Token: 0x0600030B RID: 779 RVA: 0x0001EDDC File Offset: 0x0001CFDC
		private void CheckIfFreeTrialExpired()
		{
			bool flag = Operators.CompareString(MySettingsProperty.Settings.LockSoftware, "yes", false) == 0;
			if (!flag)
			{
				flag = (Operators.CompareString(MySettingsProperty.Settings.SoftwareExpiryDate, "", false) != 0);
				if (flag)
				{
					string text = MySettingsProperty.Settings.SoftwareExpiryDate.ToString();
					text = text.Insert(6, "/");
					text = text.Insert(4, "/");
					string text2 = Conversions.ToString(NewLateBinding.LateGet(M_Settings.CurrentDate(), null, "Insert", new object[]
					{
						6,
						"/"
					}, null, null, null));
					text2 = text2.Insert(4, "/");
					DateTime dateTime = Conversions.ToDate("#" + text + " 10:00:00 AM#");
					DateTime dateTime2 = Conversions.ToDate("#" + text2 + " 10:00:00 AM#");
					M_Settings.SoftwareExpiryDaysLeft = (dateTime.Date - dateTime2.Date).Days;
					flag = (M_Settings.SoftwareExpiryDaysLeft < 31);
					if (flag)
					{
						MyProject.Forms.BuyLicence.Show();
					}
					flag = (M_Settings.SoftwareExpiryDaysLeft < 0);
					if (flag)
					{
						this.SoftwareLicenceLabel.Text = "Software Licence: EXPIRED";
						this.SoftwareLicenceLabel.ForeColor = Color.Red;
						this.Enabled = false;
					}
					else
					{
						this.SoftwareLicenceLabel.Text = "Software Licence Expires on " + text;
					}
				}
			}
		}

		// Token: 0x0600030C RID: 780 RVA: 0x00002BC3 File Offset: 0x00000DC3
		private void OccupiesTablesBTN_Click(object sender, EventArgs e)
		{
			M_Settings.TableNumberAction = "CompleteTable";
			M_Settings.OrderType = "Dine In";
			M_Settings.TableNumber = "";
			MyProject.Forms.OccupiedTables.Show();
		}

		// Token: 0x0600030D RID: 781 RVA: 0x0001EF64 File Offset: 0x0001D164
		private void CheckBalanceWithServer()
		{
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
			this.Balance = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "partners/" + MySettingsProperty.Settings.ServerFolderName + "/balance.txt", "", "", "", "", "", ""));
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
			string[] array = this.Balance.Split(new char[]
			{
				'='
			});
			bool flag = Operators.CompareString(this.Balance, "", false) == 0;
			if (flag)
			{
				this.BalanceBTN.Visible = false;
			}
			else
			{
				this.BalanceBTN.Text = "Click To Pay £" + array[3] + " Now!";
				this.BalanceBTN.Visible = true;
				this.BalanceBTN.Click += this.BalanceBTNClick;
			}
		}

		// Token: 0x0600030E RID: 782 RVA: 0x00002BF5 File Offset: 0x00000DF5
		private void BalanceBTNClick(object sender, EventArgs e)
		{
			Process.Start(this.Balance);
			Application.Exit();
		}

		// Token: 0x0600030F RID: 783 RVA: 0x00002C0B File Offset: 0x00000E0B
		private void Button2_Click(object sender, EventArgs e)
		{
			M_Settings.OrderToDriverStatus = "no";
			MyProject.Forms.EditOrders.Show();
		}

		// Token: 0x06000310 RID: 784 RVA: 0x0001F05C File Offset: 0x0001D25C
		private void Button2_Click_1(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(MySettingsProperty.Settings.RemoveItemsInShoppingCart, "y", false) == 0;
			if (flag)
			{
				MyProject.Forms.POS_Window.EditPriceBTN.Visible = true;
				MyProject.Forms.POS_Window.DecreaseQTY.Visible = true;
				MyProject.Forms.POS_Window.IncreaseQTY.Visible = true;
			}
			else
			{
				MyProject.Forms.POS_Window.EditPriceBTN.Visible = false;
				MyProject.Forms.POS_Window.DecreaseQTY.Visible = false;
				MyProject.Forms.POS_Window.IncreaseQTY.Visible = false;
			}
			M_Settings.TableNumber = "";
			this.Enabled = true;
			M_Settings.OrderType = "Takeaway";
			M_Settings.TableNumberAction = "";
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00002C0B File Offset: 0x00000E0B
		private void EditOrdersBTN_Click(object sender, EventArgs e)
		{
			M_Settings.OrderToDriverStatus = "no";
			MyProject.Forms.EditOrders.Show();
		}

		// Token: 0x06000312 RID: 786 RVA: 0x0001F148 File Offset: 0x0001D348
		private void ClockTimer_Tick(object sender, EventArgs e)
		{
			DateTime now = DateTime.Now;
			this.ClockLBL.Text = now.ToString("HH:mm:ss");
			this.DateGB.Text = now.ToString("dddd d MMMM yyyy");
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0001F190 File Offset: 0x0001D390
		private void WebON_Click(object sender, EventArgs e)
		{
			try
			{
				Interaction.AppActivate("HOHA Software Website");
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000314 RID: 788 RVA: 0x00002C29 File Offset: 0x00000E29
		private void CheckBusinessDetailsOnServer_Tick(object sender, EventArgs e)
		{
			Online.CheckBusinessInfoWithServer();
			Online.AddActivityOnServer();
			Online.CheckWebsiteConnection();
			Online.checkinternet();
		}

		// Token: 0x0400013D RID: 317
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x0400013E RID: 318
		private IContainer components;

		// Token: 0x0400013F RID: 319
		[AccessedThroughProperty("DeliveryBTN")]
		private Button _DeliveryBTN;

		// Token: 0x04000140 RID: 320
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000141 RID: 321
		[AccessedThroughProperty("CallerIdTimer")]
		private Timer _CallerIdTimer;

		// Token: 0x04000142 RID: 322
		[AccessedThroughProperty("DineInBTN")]
		private Button _DineInBTN;

		// Token: 0x04000143 RID: 323
		[AccessedThroughProperty("LatestCallsListBox")]
		private ListBox _LatestCallsListBox;

		// Token: 0x04000144 RID: 324
		[AccessedThroughProperty("Main_Panel")]
		private Panel _Main_Panel;

		// Token: 0x04000145 RID: 325
		[AccessedThroughProperty("AdminShowBTN")]
		private Button _AdminShowBTN;

		// Token: 0x04000146 RID: 326
		[AccessedThroughProperty("ShopNameLabel")]
		private Label _ShopNameLabel;

		// Token: 0x04000147 RID: 327
		[AccessedThroughProperty("WifiON")]
		private PictureBox _WifiON;

		// Token: 0x04000148 RID: 328
		[AccessedThroughProperty("Timer1Min")]
		private Timer _Timer1Min;

		// Token: 0x04000149 RID: 329
		[AccessedThroughProperty("WifiOnOff")]
		private Label _WifiOnOff;

		// Token: 0x0400014A RID: 330
		[AccessedThroughProperty("WebOnOff")]
		private Label _WebOnOff;

		// Token: 0x0400014B RID: 331
		[AccessedThroughProperty("WebON")]
		private PictureBox _WebON;

		// Token: 0x0400014C RID: 332
		[AccessedThroughProperty("NoSaleBTN")]
		private Button _NoSaleBTN;

		// Token: 0x0400014D RID: 333
		[AccessedThroughProperty("DriversBTN")]
		private Button _DriversBTN;

		// Token: 0x0400014E RID: 334
		[AccessedThroughProperty("SoftwareLicenceLabel")]
		private Label _SoftwareLicenceLabel;

		// Token: 0x0400014F RID: 335
		[AccessedThroughProperty("MinimizeBTN")]
		private Button _MinimizeBTN;

		// Token: 0x04000150 RID: 336
		[AccessedThroughProperty("CashCarryBTN")]
		private Button _CashCarryBTN;

		// Token: 0x04000151 RID: 337
		[AccessedThroughProperty("ComputerNoLabel0")]
		private Label _ComputerNoLabel0;

		// Token: 0x04000152 RID: 338
		[AccessedThroughProperty("AccessCodeNo")]
		private Label _AccessCodeNo;

		// Token: 0x04000153 RID: 339
		[AccessedThroughProperty("PictureBox1")]
		private PictureBox _PictureBox1;

		// Token: 0x04000154 RID: 340
		[AccessedThroughProperty("OccupiesTablesBTN")]
		private Button _OccupiesTablesBTN;

		// Token: 0x04000155 RID: 341
		[AccessedThroughProperty("BalanceBTN")]
		private Button _BalanceBTN;

		// Token: 0x04000156 RID: 342
		[AccessedThroughProperty("TakeawayBTN")]
		private Button _TakeawayBTN;

		// Token: 0x04000157 RID: 343
		[AccessedThroughProperty("EditOrdersBTN")]
		private Button _EditOrdersBTN;

		// Token: 0x04000158 RID: 344
		[AccessedThroughProperty("PictureBox2")]
		private PictureBox _PictureBox2;

		// Token: 0x04000159 RID: 345
		[AccessedThroughProperty("ClockLBL")]
		private Label _ClockLBL;

		// Token: 0x0400015A RID: 346
		[AccessedThroughProperty("ClockTimer")]
		private Timer _ClockTimer;

		// Token: 0x0400015B RID: 347
		[AccessedThroughProperty("DateGB")]
		private GroupBox _DateGB;

		// Token: 0x0400015C RID: 348
		[AccessedThroughProperty("CheckBusinessDetailsOnServerTimer")]
		private Timer _CheckBusinessDetailsOnServerTimer;

		// Token: 0x0400015D RID: 349
		private int NOF;

		// Token: 0x0400015E RID: 350
		private string Balance;
	}
}
