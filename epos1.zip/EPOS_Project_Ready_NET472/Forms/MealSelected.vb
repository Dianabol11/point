using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000028 RID: 40
	[StandardModule]
	internal sealed class Meal
	{
		// Token: 0x060005CD RID: 1485 RVA: 0x00035F8C File Offset: 0x0003418C
		public static void MealSelected()
		{
			MyProject.Forms.POS_Window.Bottom_Panel.Enabled = false;
			MyProject.Forms.POS_Window.Exit_Program.Enabled = false;
			Meal.Meal_ArrayList.Clear();
			MyProject.Forms.POS_Window.MealPanel.BringToFront();
			foreach (string text in File.ReadAllLines(Conversions.ToString(Operators.AddObject(Operators.AddObject(M_Settings.MenuFolder + "\\MEAL\\", M_TLP_Foods.Convert_Food_Name_To_File_Name(M_Settings.SelectedFood)), ".txt"))))
			{
				bool flag = Operators.CompareString(text, "", false) != 0;
				if (flag)
				{
					Meal.Meal_ArrayList.Add(text);
				}
			}
			Meal.Meal_ArrayList.RemoveAt(0);
			Meal.CourseStep = -1;
			Meal.CourseStepMax = Meal.Meal_ArrayList.Count;
			M_Shopping_Cart.AddFoodToShoppingCart();
			Meal.Steps();
		}

		// Token: 0x060005CE RID: 1486 RVA: 0x00036084 File Offset: 0x00034284
		public static void Steps()
		{
			checked
			{
				Meal.CourseStep++;
				bool flag = Meal.CourseStep == Meal.CourseStepMax;
				if (flag)
				{
					Meal.BringCompleteAndMessagePanelsInFront();
				}
				flag = (Meal.CourseStep <= Meal.CourseStepMax - 1);
				if (flag)
				{
					Meal.CourseSelectionTimes = Conversions.ToInteger(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Meal.Meal_ArrayList[Meal.CourseStep], null, "Split", new object[]
					{
						new char[]
						{
							'#'
						}
					}, null, null, null), new object[]
					{
						0
					}, null));
					Meal.CourseFoods = (string[])NewLateBinding.LateGet(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Meal.Meal_ArrayList[Meal.CourseStep], null, "Split", new object[]
					{
						new char[]
						{
							'#'
						}
					}, null, null, null), new object[]
					{
						1
					}, null), null, "Split", new object[]
					{
						new char[]
						{
							'|'
						}
					}, null, null, null);
					Meal.CoursePrice = Conversions.ToDecimal(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Meal.Meal_ArrayList[Meal.CourseStep], null, "Split", new object[]
					{
						new char[]
						{
							'#'
						}
					}, null, null, null), new object[]
					{
						2
					}, null));
				}
				Meal.Count_Row_Column(Meal.CourseFoods.Count<string>());
				Meal.Call_TLP_Meal();
				foreach (string name in Meal.CourseFoods)
				{
					Meal.Create_Buttons(name);
				}
				MyProject.Forms.POS_Window.Main_Panel.Controls["TLP_Meal"].BringToFront();
			}
		}

		// Token: 0x060005CF RID: 1487 RVA: 0x0003627C File Offset: 0x0003447C
		private static void MealButtonClick(object sender, EventArgs e)
		{
			bool flag = Meal.CourseSelectionTimes == 100;
			if (flag)
			{
				M_Settings.SelectedFood = Conversions.ToString(Operators.AddObject("   ", NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null)));
				M_Shopping_Cart.AddMealToShoppingCart("Option", Meal.CoursePrice);
			}
			flag = (Meal.CourseSelectionTimes == 1);
			if (flag)
			{
				M_Settings.SelectedFood = Conversions.ToString(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null));
				M_Shopping_Cart.AddMealToShoppingCart("Food", Meal.CoursePrice);
				Meal.RemoveTLP_BTNs();
				flag = (Meal.CourseStep < checked(Meal.CourseStepMax - 1));
				if (flag)
				{
					Meal.Steps();
				}
				else
				{
					MyProject.Forms.POS_Window.Exit_Program.Enabled = true;
					Meal.BringCompleteAndMessagePanelsInFront();
					MyProject.Forms.POS_Window.Bottom_Panel.Enabled = true;
				}
			}
		}

		// Token: 0x060005D0 RID: 1488 RVA: 0x00036370 File Offset: 0x00034570
		public static void BringCompleteAndMessagePanelsInFront()
		{
			MyProject.Forms.POS_Window.CompletePanel.BringToFront();
			MyProject.Forms.POS_Window.MessageBoard.BringToFront();
			MyProject.Forms.POS_Window.MealNextBTN.SendToBack();
		}

		// Token: 0x060005D1 RID: 1489 RVA: 0x000363C0 File Offset: 0x000345C0
		public static void RemoveTLP_BTNs()
		{
			while (Meal.TLP_Meal.Controls.Count > 0)
			{
				Meal.TLP_Meal.Controls[0].Dispose();
			}
		}

		// Token: 0x060005D2 RID: 1490 RVA: 0x00036400 File Offset: 0x00034600
		public static void Call_TLP_Meal()
		{
			TableLayoutPanel tlp_Meal = Meal.TLP_Meal;
			tlp_Meal.Name = "TLP_Meal";
			tlp_Meal.RowCount = Meal.rows;
			tlp_Meal.ColumnCount = Meal.columns;
			tlp_Meal.Dock = DockStyle.Fill;
			tlp_Meal.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tlp_Meal.AutoSize = true;
			Control control = tlp_Meal;
			Padding margin = new Padding(0);
			control.Margin = margin;
			checked
			{
				tlp_Meal.Height = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Height / (double)Meal.rows);
				tlp_Meal.Width = (int)Math.Round((double)(MyProject.Forms.Index.Width - M_Settings.Right_Panel_Width) / (double)Meal.columns);
				tlp_Meal.BackColor = ColorTranslator.FromHtml(M_Settings.TLPs_bgColor);
			}
		}

		// Token: 0x060005D3 RID: 1491 RVA: 0x000364C8 File Offset: 0x000346C8
		public static void Create_TLP_Meal()
		{
			TableLayoutPanel tlp_Meal = Meal.TLP_Meal;
			tlp_Meal.Name = "TLP_Meal";
			tlp_Meal.RowCount = Meal.rows;
			tlp_Meal.ColumnCount = Meal.columns;
			tlp_Meal.Dock = DockStyle.Fill;
			tlp_Meal.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tlp_Meal.AutoSize = true;
			Control control = tlp_Meal;
			Padding margin = new Padding(0);
			control.Margin = margin;
			tlp_Meal.BackColor = ColorTranslator.FromHtml(M_Settings.TLPs_bgColor);
			MyProject.Forms.POS_Window.Main_Panel.Controls.Add(Meal.TLP_Meal);
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x0003655C File Offset: 0x0003475C
		private static void Create_Buttons(object Name)
		{
			Button button = new Button();
			Button button2 = button;
			button2.Name = Conversions.ToString(Name);
			button2.BackColor = ColorTranslator.FromHtml("#" + M_Settings.Button_bgColor);
			button2.ForeColor = ColorTranslator.FromHtml("#" + M_Settings.Button_TextColor);
			button2.Dock = DockStyle.Fill;
			button2.FlatStyle = FlatStyle.Popup;
			Control control = button2;
			Padding margin = new Padding(0, 0, 0, 0);
			control.Margin = margin;
			button2.Font = new Font("Century Gothic", 16f, FontStyle.Regular);
			checked
			{
				button2.Height = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Height / (double)Meal.rows);
				button2.Width = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Width / (double)Meal.columns);
				button2.Text = Conversions.ToString(Name);
				Meal.TLP_Meal.Controls.Add(button);
				button.Click += Meal.MealButtonClick;
			}
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x00036678 File Offset: 0x00034878
		private static void Count_Row_Column(object N)
		{
			bool flag = Operators.ConditionalCompareObjectLessEqual(N, 12, false);
			if (flag)
			{
				Meal.rows = 4;
				Meal.columns = 3;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 12, false);
			if (flag)
			{
				Meal.rows = 5;
				Meal.columns = 4;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 20, false);
			if (flag)
			{
				Meal.rows = 7;
				Meal.columns = 5;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 30, false);
			if (flag)
			{
				Meal.rows = 8;
				Meal.columns = 6;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 42, false);
			checked
			{
				if (flag)
				{
					Meal.rows = (int)Math.Round(Math.Ceiling(Math.Sqrt(Conversions.ToDouble(N))));
					Meal.columns = Meal.rows;
					Meal.rows++;
				}
			}
		}

		// Token: 0x04000260 RID: 608
		public static ArrayList Meal_ArrayList = new ArrayList();

		// Token: 0x04000261 RID: 609
		public static TableLayoutPanel TLP_Meal = new TableLayoutPanel();

		// Token: 0x04000262 RID: 610
		private static int CourseSelectionTimes;

		// Token: 0x04000263 RID: 611
		private static string[] CourseFoods;

		// Token: 0x04000264 RID: 612
		private static decimal CoursePrice;

		// Token: 0x04000265 RID: 613
		private static int rows;

		// Token: 0x04000266 RID: 614
		private static int columns;

		// Token: 0x04000267 RID: 615
		private static int N;

		// Token: 0x04000268 RID: 616
		public static int CourseStep;

		// Token: 0x04000269 RID: 617
		public static int CourseStepMax;
	}
}
