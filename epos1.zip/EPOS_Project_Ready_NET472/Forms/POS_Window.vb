using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000032 RID: 50
	[DesignerGenerated]
	public class POS_Window : Form
	{
		// Token: 0x06000627 RID: 1575 RVA: 0x0003CA9C File Offset: 0x0003AC9C
		[DebuggerNonUserCode]
		public POS_Window()
		{
			base.Load += this.POS_Window_Load;
			List<WeakReference> _ENCList = POS_Window.__ENCList;
			lock (_ENCList)
			{
				POS_Window.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x0003CB08 File Offset: 0x0003AD08
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x0003CB58 File Offset: 0x0003AD58
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Main_Panel = new Panel();
			this.MessageBoard = new Panel();
			this.POSMessageBoardText = new Label();
			this.CompletePanel = new Panel();
			this.CookingOptionsBTN = new Button();
			this.CompleteBTN = new Button();
			this.EditPriceBTN = new Button();
			this.DecreaseQTY = new Button();
			this.IncreaseQTY = new Button();
			this.CommentBTN = new Button();
			this.DiscountBTN = new Button();
			this.Exit_Program = new Button();
			this.Right_Panel = new Panel();
			this.Panel1 = new Panel();
			this.PaymentMethodTakeawayCollectionDineinPanel = new Panel();
			this.TakeawayCollectionCardBTN = new Button();
			this.TakeawayCollectionCashBTN = new Button();
			this.TotalsPanel = new Panel();
			this.DeliveryChargeLabel = new Label();
			this.TotalTextBox = new TextBox();
			this.DiscountTextBox = new TextBox();
			this.ServiceChargeLabel = new Label();
			this.SubTotalTextBox = new TextBox();
			this.TotalLabel = new Label();
			this.ServiceChargeTextBox = new TextBox();
			this.DeliveryChargeTextBox = new TextBox();
			this.SubTotalLabel = new Label();
			this.DiscountLabel = new Label();
			this.PaymentMethodDeliveryPanel = new Panel();
			this.DeliveryCardBTN = new Button();
			this.DeliveryCashBTN = new Button();
			this.MealPanel = new Panel();
			this.MealNextBTN = new Button();
			this.PgUp = new Button();
			this.PgDown = new Button();
			this.Bottom_Panel = new Panel();
			this.Main_Panel.SuspendLayout();
			this.MessageBoard.SuspendLayout();
			this.CompletePanel.SuspendLayout();
			this.Right_Panel.SuspendLayout();
			this.Panel1.SuspendLayout();
			this.PaymentMethodTakeawayCollectionDineinPanel.SuspendLayout();
			this.TotalsPanel.SuspendLayout();
			this.PaymentMethodDeliveryPanel.SuspendLayout();
			this.MealPanel.SuspendLayout();
			this.SuspendLayout();
			this.Main_Panel.BackColor = SystemColors.ActiveCaptionText;
			this.Main_Panel.BorderStyle = BorderStyle.FixedSingle;
			this.Main_Panel.Controls.Add(this.MessageBoard);
			this.Main_Panel.Dock = DockStyle.Left;
			this.Main_Panel.ForeColor = SystemColors.GradientInactiveCaption;
			Control main_Panel = this.Main_Panel;
			Point location = new Point(0, 0);
			main_Panel.Location = location;
			this.Main_Panel.Name = "Main_Panel";
			Control main_Panel2 = this.Main_Panel;
			Size size = new Size(351, 640);
			main_Panel2.Size = size;
			this.Main_Panel.TabIndex = 0;
			this.MessageBoard.BackColor = Color.SteelBlue;
			this.MessageBoard.Controls.Add(this.POSMessageBoardText);
			this.MessageBoard.Dock = DockStyle.Fill;
			this.MessageBoard.Font = new Font("Century Gothic", 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control messageBoard = this.MessageBoard;
			location = new Point(0, 0);
			messageBoard.Location = location;
			this.MessageBoard.Name = "MessageBoard";
			Control messageBoard2 = this.MessageBoard;
			size = new Size(349, 638);
			messageBoard2.Size = size;
			this.MessageBoard.TabIndex = 0;
			this.POSMessageBoardText.AutoSize = true;
			this.POSMessageBoardText.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control posmessageBoardText = this.POSMessageBoardText;
			location = new Point(24, 26);
			posmessageBoardText.Location = location;
			this.POSMessageBoardText.Name = "POSMessageBoardText";
			Control posmessageBoardText2 = this.POSMessageBoardText;
			size = new Size(190, 29);
			posmessageBoardText2.Size = size;
			this.POSMessageBoardText.TabIndex = 0;
			this.POSMessageBoardText.Text = "Message Board";
			this.CompletePanel.BackColor = Color.Transparent;
			this.CompletePanel.Controls.Add(this.CookingOptionsBTN);
			this.CompletePanel.Controls.Add(this.CompleteBTN);
			this.CompletePanel.Controls.Add(this.EditPriceBTN);
			this.CompletePanel.Controls.Add(this.DecreaseQTY);
			this.CompletePanel.Controls.Add(this.IncreaseQTY);
			Control completePanel = this.CompletePanel;
			location = new Point(0, 0);
			completePanel.Location = location;
			this.CompletePanel.Name = "CompletePanel";
			Control completePanel2 = this.CompletePanel;
			size = new Size(290, 167);
			completePanel2.Size = size;
			this.CompletePanel.TabIndex = 25;
			this.CookingOptionsBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.CookingOptionsBTN.BackColor = Color.Fuchsia;
			this.CookingOptionsBTN.FlatStyle = FlatStyle.Popup;
			this.CookingOptionsBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.CookingOptionsBTN.ForeColor = Color.WhiteSmoke;
			Control cookingOptionsBTN = this.CookingOptionsBTN;
			location = new Point(6, 58);
			cookingOptionsBTN.Location = location;
			this.CookingOptionsBTN.Name = "CookingOptionsBTN";
			Control cookingOptionsBTN2 = this.CookingOptionsBTN;
			size = new Size(124, 105);
			cookingOptionsBTN2.Size = size;
			this.CookingOptionsBTN.TabIndex = 25;
			this.CookingOptionsBTN.Text = "Cooking Options";
			this.CookingOptionsBTN.UseVisualStyleBackColor = false;
			this.CompleteBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.CompleteBTN.BackColor = Color.Crimson;
			this.CompleteBTN.Enabled = false;
			this.CompleteBTN.FlatStyle = FlatStyle.Popup;
			this.CompleteBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.CompleteBTN.ForeColor = Color.WhiteSmoke;
			Control completeBTN = this.CompleteBTN;
			location = new Point(136, 58);
			completeBTN.Location = location;
			this.CompleteBTN.Name = "CompleteBTN";
			Control completeBTN2 = this.CompleteBTN;
			size = new Size(149, 105);
			completeBTN2.Size = size;
			this.CompleteBTN.TabIndex = 22;
			this.CompleteBTN.Text = "Complete";
			this.CompleteBTN.UseVisualStyleBackColor = false;
			this.EditPriceBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.EditPriceBTN.BackColor = Color.Gold;
			this.EditPriceBTN.FlatStyle = FlatStyle.Popup;
			this.EditPriceBTN.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.EditPriceBTN.ForeColor = SystemColors.MenuText;
			Control editPriceBTN = this.EditPriceBTN;
			location = new Point(184, 4);
			editPriceBTN.Location = location;
			this.EditPriceBTN.Name = "EditPriceBTN";
			Control editPriceBTN2 = this.EditPriceBTN;
			size = new Size(101, 49);
			editPriceBTN2.Size = size;
			this.EditPriceBTN.TabIndex = 24;
			this.EditPriceBTN.Text = "Edit Price";
			this.EditPriceBTN.UseVisualStyleBackColor = false;
			this.DecreaseQTY.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.DecreaseQTY.BackColor = Color.Gold;
			this.DecreaseQTY.FlatStyle = FlatStyle.Popup;
			this.DecreaseQTY.Font = new Font("Arial", 24f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DecreaseQTY.ForeColor = SystemColors.InfoText;
			Control decreaseQTY = this.DecreaseQTY;
			location = new Point(94, 4);
			decreaseQTY.Location = location;
			this.DecreaseQTY.Name = "DecreaseQTY";
			Control decreaseQTY2 = this.DecreaseQTY;
			size = new Size(85, 49);
			decreaseQTY2.Size = size;
			this.DecreaseQTY.TabIndex = 5;
			this.DecreaseQTY.Text = "-";
			this.DecreaseQTY.UseVisualStyleBackColor = false;
			this.IncreaseQTY.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.IncreaseQTY.BackColor = Color.Gold;
			this.IncreaseQTY.FlatStyle = FlatStyle.Popup;
			this.IncreaseQTY.Font = new Font("Arial", 24f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.IncreaseQTY.ForeColor = SystemColors.InfoText;
			Control increaseQTY = this.IncreaseQTY;
			location = new Point(4, 4);
			increaseQTY.Location = location;
			this.IncreaseQTY.Name = "IncreaseQTY";
			Control increaseQTY2 = this.IncreaseQTY;
			size = new Size(85, 49);
			increaseQTY2.Size = size;
			this.IncreaseQTY.TabIndex = 7;
			this.IncreaseQTY.Text = "+";
			this.IncreaseQTY.UseVisualStyleBackColor = false;
			this.CommentBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.CommentBTN.BackColor = Color.Lime;
			this.CommentBTN.Enabled = false;
			this.CommentBTN.FlatStyle = FlatStyle.Popup;
			this.CommentBTN.Font = new Font("Arial", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.CommentBTN.ForeColor = SystemColors.MenuText;
			Control commentBTN = this.CommentBTN;
			location = new Point(5, 5);
			commentBTN.Location = location;
			this.CommentBTN.Name = "CommentBTN";
			Control commentBTN2 = this.CommentBTN;
			size = new Size(118, 75);
			commentBTN2.Size = size;
			this.CommentBTN.TabIndex = 26;
			this.CommentBTN.Text = "Comment";
			this.CommentBTN.UseVisualStyleBackColor = false;
			this.DiscountBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.DiscountBTN.BackColor = Color.Lime;
			this.DiscountBTN.Enabled = false;
			this.DiscountBTN.FlatStyle = FlatStyle.Popup;
			this.DiscountBTN.Font = new Font("Arial", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DiscountBTN.ForeColor = SystemColors.MenuText;
			Control discountBTN = this.DiscountBTN;
			location = new Point(5, 85);
			discountBTN.Location = location;
			this.DiscountBTN.Name = "DiscountBTN";
			Control discountBTN2 = this.DiscountBTN;
			size = new Size(118, 75);
			discountBTN2.Size = size;
			this.DiscountBTN.TabIndex = 25;
			this.DiscountBTN.Text = "Discount";
			this.DiscountBTN.UseVisualStyleBackColor = false;
			this.Exit_Program.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.Exit_Program.BackColor = Color.Crimson;
			this.Exit_Program.FlatStyle = FlatStyle.Popup;
			this.Exit_Program.Font = new Font("Arial Black", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Exit_Program.ForeColor = SystemColors.Window;
			Control exit_Program = this.Exit_Program;
			location = new Point(410, 0);
			exit_Program.Location = location;
			this.Exit_Program.Name = "Exit_Program";
			Control exit_Program2 = this.Exit_Program;
			size = new Size(40, 40);
			exit_Program2.Size = size;
			this.Exit_Program.TabIndex = 0;
			this.Exit_Program.Text = "X";
			this.Exit_Program.UseVisualStyleBackColor = false;
			this.Right_Panel.BackColor = Color.DodgerBlue;
			this.Right_Panel.BorderStyle = BorderStyle.FixedSingle;
			this.Right_Panel.Controls.Add(this.Panel1);
			this.Right_Panel.Controls.Add(this.Exit_Program);
			this.Right_Panel.Controls.Add(this.PgUp);
			this.Right_Panel.Controls.Add(this.PgDown);
			this.Right_Panel.Dock = DockStyle.Right;
			this.Right_Panel.ForeColor = Color.Cyan;
			Control right_Panel = this.Right_Panel;
			location = new Point(351, 0);
			right_Panel.Location = location;
			this.Right_Panel.Name = "Right_Panel";
			Control right_Panel2 = this.Right_Panel;
			size = new Size(450, 640);
			right_Panel2.Size = size;
			this.Right_Panel.TabIndex = 1;
			this.Panel1.Controls.Add(this.CompletePanel);
			this.Panel1.Controls.Add(this.PaymentMethodTakeawayCollectionDineinPanel);
			this.Panel1.Controls.Add(this.TotalsPanel);
			this.Panel1.Controls.Add(this.PaymentMethodDeliveryPanel);
			this.Panel1.Controls.Add(this.MealPanel);
			this.Panel1.Dock = DockStyle.Bottom;
			Control panel = this.Panel1;
			location = new Point(0, 471);
			panel.Location = location;
			this.Panel1.Name = "Panel1";
			Control panel2 = this.Panel1;
			size = new Size(448, 167);
			panel2.Size = size;
			this.Panel1.TabIndex = 10;
			this.PaymentMethodTakeawayCollectionDineinPanel.BackColor = Color.Transparent;
			this.PaymentMethodTakeawayCollectionDineinPanel.Controls.Add(this.DiscountBTN);
			this.PaymentMethodTakeawayCollectionDineinPanel.Controls.Add(this.CommentBTN);
			this.PaymentMethodTakeawayCollectionDineinPanel.Controls.Add(this.TakeawayCollectionCardBTN);
			this.PaymentMethodTakeawayCollectionDineinPanel.Controls.Add(this.TakeawayCollectionCashBTN);
			Control paymentMethodTakeawayCollectionDineinPanel = this.PaymentMethodTakeawayCollectionDineinPanel;
			location = new Point(0, 0);
			paymentMethodTakeawayCollectionDineinPanel.Location = location;
			this.PaymentMethodTakeawayCollectionDineinPanel.Name = "PaymentMethodTakeawayCollectionDineinPanel";
			Control paymentMethodTakeawayCollectionDineinPanel2 = this.PaymentMethodTakeawayCollectionDineinPanel;
			size = new Size(290, 167);
			paymentMethodTakeawayCollectionDineinPanel2.Size = size;
			this.PaymentMethodTakeawayCollectionDineinPanel.TabIndex = 27;
			this.TakeawayCollectionCardBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.TakeawayCollectionCardBTN.BackColor = Color.Gold;
			this.TakeawayCollectionCardBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.TakeawayCollectionCardBTN.FlatStyle = FlatStyle.Flat;
			this.TakeawayCollectionCardBTN.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.TakeawayCollectionCardBTN.ForeColor = Color.Black;
			Control takeawayCollectionCardBTN = this.TakeawayCollectionCardBTN;
			location = new Point(127, 86);
			takeawayCollectionCardBTN.Location = location;
			this.TakeawayCollectionCardBTN.Name = "TakeawayCollectionCardBTN";
			Control takeawayCollectionCardBTN2 = this.TakeawayCollectionCardBTN;
			size = new Size(160, 74);
			takeawayCollectionCardBTN2.Size = size;
			this.TakeawayCollectionCardBTN.TabIndex = 66;
			this.TakeawayCollectionCardBTN.Text = "Pay by Card";
			this.TakeawayCollectionCardBTN.UseVisualStyleBackColor = false;
			this.TakeawayCollectionCashBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.TakeawayCollectionCashBTN.BackColor = Color.Gold;
			this.TakeawayCollectionCashBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.TakeawayCollectionCashBTN.FlatStyle = FlatStyle.Flat;
			this.TakeawayCollectionCashBTN.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.TakeawayCollectionCashBTN.ForeColor = Color.Black;
			Control takeawayCollectionCashBTN = this.TakeawayCollectionCashBTN;
			location = new Point(127, 6);
			takeawayCollectionCashBTN.Location = location;
			this.TakeawayCollectionCashBTN.Name = "TakeawayCollectionCashBTN";
			Control takeawayCollectionCashBTN2 = this.TakeawayCollectionCashBTN;
			size = new Size(158, 74);
			takeawayCollectionCashBTN2.Size = size;
			this.TakeawayCollectionCashBTN.TabIndex = 65;
			this.TakeawayCollectionCashBTN.Text = "Pay Cash";
			this.TakeawayCollectionCashBTN.UseVisualStyleBackColor = false;
			this.TotalsPanel.BackColor = Color.Transparent;
			this.TotalsPanel.Controls.Add(this.DeliveryChargeLabel);
			this.TotalsPanel.Controls.Add(this.TotalTextBox);
			this.TotalsPanel.Controls.Add(this.DiscountTextBox);
			this.TotalsPanel.Controls.Add(this.ServiceChargeLabel);
			this.TotalsPanel.Controls.Add(this.SubTotalTextBox);
			this.TotalsPanel.Controls.Add(this.TotalLabel);
			this.TotalsPanel.Controls.Add(this.ServiceChargeTextBox);
			this.TotalsPanel.Controls.Add(this.DeliveryChargeTextBox);
			this.TotalsPanel.Controls.Add(this.SubTotalLabel);
			this.TotalsPanel.Controls.Add(this.DiscountLabel);
			this.TotalsPanel.Dock = DockStyle.Right;
			Control totalsPanel = this.TotalsPanel;
			location = new Point(291, 0);
			totalsPanel.Location = location;
			this.TotalsPanel.Name = "TotalsPanel";
			Control totalsPanel2 = this.TotalsPanel;
			size = new Size(157, 167);
			totalsPanel2.Size = size;
			this.TotalsPanel.TabIndex = 26;
			this.DeliveryChargeLabel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.DeliveryChargeLabel.AutoSize = true;
			this.DeliveryChargeLabel.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DeliveryChargeLabel.ForeColor = Color.LightCyan;
			Control deliveryChargeLabel = this.DeliveryChargeLabel;
			location = new Point(10, 75);
			deliveryChargeLabel.Location = location;
			this.DeliveryChargeLabel.Name = "DeliveryChargeLabel";
			Control deliveryChargeLabel2 = this.DeliveryChargeLabel;
			size = new Size(71, 19);
			deliveryChargeLabel2.Size = size;
			this.DeliveryChargeLabel.TabIndex = 17;
			this.DeliveryChargeLabel.Text = "Delivery";
			this.TotalTextBox.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.TotalTextBox.BackColor = Color.LightCyan;
			this.TotalTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.TotalTextBox.Font = new Font("Century Gothic", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control totalTextBox = this.TotalTextBox;
			location = new Point(85, 133);
			totalTextBox.Location = location;
			this.TotalTextBox.Name = "TotalTextBox";
			this.TotalTextBox.ReadOnly = true;
			Control totalTextBox2 = this.TotalTextBox;
			size = new Size(66, 27);
			totalTextBox2.Size = size;
			this.TotalTextBox.TabIndex = 2;
			this.TotalTextBox.TextAlign = HorizontalAlignment.Center;
			this.DiscountTextBox.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.DiscountTextBox.BackColor = Color.LightCyan;
			this.DiscountTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.DiscountTextBox.Font = new Font("Century Gothic", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control discountTextBox = this.DiscountTextBox;
			location = new Point(85, 40);
			discountTextBox.Location = location;
			this.DiscountTextBox.Name = "DiscountTextBox";
			this.DiscountTextBox.ReadOnly = true;
			Control discountTextBox2 = this.DiscountTextBox;
			size = new Size(66, 27);
			discountTextBox2.Size = size;
			this.DiscountTextBox.TabIndex = 18;
			this.DiscountTextBox.TextAlign = HorizontalAlignment.Center;
			this.ServiceChargeLabel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.ServiceChargeLabel.AutoSize = true;
			this.ServiceChargeLabel.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.ServiceChargeLabel.ForeColor = Color.LightCyan;
			Control serviceChargeLabel = this.ServiceChargeLabel;
			location = new Point(15, 105);
			serviceChargeLabel.Location = location;
			this.ServiceChargeLabel.Name = "ServiceChargeLabel";
			Control serviceChargeLabel2 = this.ServiceChargeLabel;
			size = new Size(66, 19);
			serviceChargeLabel2.Size = size;
			this.ServiceChargeLabel.TabIndex = 15;
			this.ServiceChargeLabel.Text = "Service";
			this.SubTotalTextBox.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.SubTotalTextBox.BackColor = Color.LightCyan;
			this.SubTotalTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.SubTotalTextBox.Font = new Font("Century Gothic", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control subTotalTextBox = this.SubTotalTextBox;
			location = new Point(85, 9);
			subTotalTextBox.Location = location;
			this.SubTotalTextBox.Name = "SubTotalTextBox";
			this.SubTotalTextBox.ReadOnly = true;
			Control subTotalTextBox2 = this.SubTotalTextBox;
			size = new Size(66, 27);
			subTotalTextBox2.Size = size;
			this.SubTotalTextBox.TabIndex = 20;
			this.SubTotalTextBox.TextAlign = HorizontalAlignment.Center;
			this.TotalLabel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.TotalLabel.AutoSize = true;
			this.TotalLabel.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.TotalLabel.ForeColor = Color.LightCyan;
			Control totalLabel = this.TotalLabel;
			location = new Point(35, 136);
			totalLabel.Location = location;
			this.TotalLabel.Name = "TotalLabel";
			Control totalLabel2 = this.TotalLabel;
			size = new Size(46, 19);
			totalLabel2.Size = size;
			this.TotalLabel.TabIndex = 11;
			this.TotalLabel.Text = "Total";
			this.ServiceChargeTextBox.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.ServiceChargeTextBox.BackColor = Color.LightCyan;
			this.ServiceChargeTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.ServiceChargeTextBox.Font = new Font("Century Gothic", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control serviceChargeTextBox = this.ServiceChargeTextBox;
			location = new Point(85, 102);
			serviceChargeTextBox.Location = location;
			this.ServiceChargeTextBox.Name = "ServiceChargeTextBox";
			this.ServiceChargeTextBox.ReadOnly = true;
			Control serviceChargeTextBox2 = this.ServiceChargeTextBox;
			size = new Size(66, 27);
			serviceChargeTextBox2.Size = size;
			this.ServiceChargeTextBox.TabIndex = 14;
			this.ServiceChargeTextBox.TextAlign = HorizontalAlignment.Center;
			this.DeliveryChargeTextBox.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.DeliveryChargeTextBox.BackColor = Color.LightCyan;
			this.DeliveryChargeTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.DeliveryChargeTextBox.Font = new Font("Century Gothic", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control deliveryChargeTextBox = this.DeliveryChargeTextBox;
			location = new Point(85, 71);
			deliveryChargeTextBox.Location = location;
			this.DeliveryChargeTextBox.Name = "DeliveryChargeTextBox";
			this.DeliveryChargeTextBox.ReadOnly = true;
			Control deliveryChargeTextBox2 = this.DeliveryChargeTextBox;
			size = new Size(66, 27);
			deliveryChargeTextBox2.Size = size;
			this.DeliveryChargeTextBox.TabIndex = 16;
			this.DeliveryChargeTextBox.TextAlign = HorizontalAlignment.Center;
			this.SubTotalLabel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.SubTotalLabel.AutoSize = true;
			this.SubTotalLabel.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.SubTotalLabel.ForeColor = Color.LightCyan;
			Control subTotalLabel = this.SubTotalLabel;
			location = new Point(0, 14);
			subTotalLabel.Location = location;
			this.SubTotalLabel.Name = "SubTotalLabel";
			Control subTotalLabel2 = this.SubTotalLabel;
			size = new Size(81, 19);
			subTotalLabel2.Size = size;
			this.SubTotalLabel.TabIndex = 21;
			this.SubTotalLabel.Text = "Sub Total";
			this.DiscountLabel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.DiscountLabel.AutoSize = true;
			this.DiscountLabel.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DiscountLabel.ForeColor = Color.LightCyan;
			Control discountLabel = this.DiscountLabel;
			location = new Point(3, 43);
			discountLabel.Location = location;
			this.DiscountLabel.Name = "DiscountLabel";
			Control discountLabel2 = this.DiscountLabel;
			size = new Size(78, 19);
			discountLabel2.Size = size;
			this.DiscountLabel.TabIndex = 19;
			this.DiscountLabel.Text = "Discount";
			this.PaymentMethodDeliveryPanel.BackColor = Color.Transparent;
			this.PaymentMethodDeliveryPanel.Controls.Add(this.DeliveryCardBTN);
			this.PaymentMethodDeliveryPanel.Controls.Add(this.DeliveryCashBTN);
			Control paymentMethodDeliveryPanel = this.PaymentMethodDeliveryPanel;
			location = new Point(0, 0);
			paymentMethodDeliveryPanel.Location = location;
			this.PaymentMethodDeliveryPanel.Name = "PaymentMethodDeliveryPanel";
			Control paymentMethodDeliveryPanel2 = this.PaymentMethodDeliveryPanel;
			size = new Size(290, 167);
			paymentMethodDeliveryPanel2.Size = size;
			this.PaymentMethodDeliveryPanel.TabIndex = 28;
			this.DeliveryCardBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.DeliveryCardBTN.BackColor = Color.Gold;
			this.DeliveryCardBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.DeliveryCardBTN.FlatStyle = FlatStyle.Flat;
			this.DeliveryCardBTN.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DeliveryCardBTN.ForeColor = Color.Black;
			Control deliveryCardBTN = this.DeliveryCardBTN;
			location = new Point(6, 86);
			deliveryCardBTN.Location = location;
			this.DeliveryCardBTN.Name = "DeliveryCardBTN";
			Control deliveryCardBTN2 = this.DeliveryCardBTN;
			size = new Size(280, 74);
			deliveryCardBTN2.Size = size;
			this.DeliveryCardBTN.TabIndex = 68;
			this.DeliveryCardBTN.Text = "Credit / Debit Card";
			this.DeliveryCardBTN.UseVisualStyleBackColor = false;
			this.DeliveryCashBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.DeliveryCashBTN.BackColor = Color.Gold;
			this.DeliveryCashBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.DeliveryCashBTN.FlatStyle = FlatStyle.Flat;
			this.DeliveryCashBTN.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DeliveryCashBTN.ForeColor = Color.Black;
			Control deliveryCashBTN = this.DeliveryCashBTN;
			location = new Point(4, 6);
			deliveryCashBTN.Location = location;
			this.DeliveryCashBTN.Name = "DeliveryCashBTN";
			Control deliveryCashBTN2 = this.DeliveryCashBTN;
			size = new Size(280, 74);
			deliveryCashBTN2.Size = size;
			this.DeliveryCashBTN.TabIndex = 67;
			this.DeliveryCashBTN.Text = "Cash";
			this.DeliveryCashBTN.UseVisualStyleBackColor = false;
			this.MealPanel.BackColor = Color.Transparent;
			this.MealPanel.Controls.Add(this.MealNextBTN);
			Control mealPanel = this.MealPanel;
			location = new Point(0, 0);
			mealPanel.Location = location;
			this.MealPanel.Name = "MealPanel";
			Control mealPanel2 = this.MealPanel;
			size = new Size(290, 167);
			mealPanel2.Size = size;
			this.MealPanel.TabIndex = 26;
			this.MealNextBTN.BackColor = Color.Crimson;
			this.MealNextBTN.FlatStyle = FlatStyle.Popup;
			this.MealNextBTN.Font = new Font("Century Gothic", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.MealNextBTN.ForeColor = SystemColors.HighlightText;
			Control mealNextBTN = this.MealNextBTN;
			location = new Point(5, 5);
			mealNextBTN.Location = location;
			this.MealNextBTN.Name = "MealNextBTN";
			Control mealNextBTN2 = this.MealNextBTN;
			size = new Size(275, 156);
			mealNextBTN2.Size = size;
			this.MealNextBTN.TabIndex = 22;
			this.MealNextBTN.Text = "Next";
			this.MealNextBTN.UseVisualStyleBackColor = false;
			this.PgUp.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.PgUp.BackColor = Color.LightSalmon;
			this.PgUp.FlatStyle = FlatStyle.Popup;
			this.PgUp.Font = new Font("Arial", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.PgUp.ForeColor = SystemColors.Window;
			Control pgUp = this.PgUp;
			location = new Point(410, 40);
			pgUp.Location = location;
			this.PgUp.Name = "PgUp";
			Control pgUp2 = this.PgUp;
			size = new Size(40, 210);
			pgUp2.Size = size;
			this.PgUp.TabIndex = 8;
			this.PgUp.Text = "UP";
			this.PgUp.UseVisualStyleBackColor = false;
			this.PgDown.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.PgDown.BackColor = Color.LightSalmon;
			this.PgDown.FlatStyle = FlatStyle.Popup;
			this.PgDown.Font = new Font("Arial", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.PgDown.ForeColor = SystemColors.Window;
			Control pgDown = this.PgDown;
			location = new Point(410, 250);
			pgDown.Location = location;
			this.PgDown.Name = "PgDown";
			Control pgDown2 = this.PgDown;
			size = new Size(40, 210);
			pgDown2.Size = size;
			this.PgDown.TabIndex = 9;
			this.PgDown.Text = "Down";
			this.PgDown.UseVisualStyleBackColor = false;
			this.Bottom_Panel.BackColor = SystemColors.GrayText;
			this.Bottom_Panel.BorderStyle = BorderStyle.FixedSingle;
			this.Bottom_Panel.Dock = DockStyle.Bottom;
			Control bottom_Panel = this.Bottom_Panel;
			location = new Point(0, 640);
			bottom_Panel.Location = location;
			this.Bottom_Panel.Name = "Bottom_Panel";
			Control bottom_Panel2 = this.Bottom_Panel;
			size = new Size(801, 100);
			bottom_Panel2.Size = size;
			this.Bottom_Panel.TabIndex = 2;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = SystemColors.Control;
			size = new Size(801, 740);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.Main_Panel);
			this.Controls.Add(this.Right_Panel);
			this.Controls.Add(this.Bottom_Panel);
			this.FormBorderStyle = FormBorderStyle.None;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "POS_Window";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Stockport Design";
			this.WindowState = FormWindowState.Maximized;
			this.Main_Panel.ResumeLayout(false);
			this.MessageBoard.ResumeLayout(false);
			this.MessageBoard.PerformLayout();
			this.CompletePanel.ResumeLayout(false);
			this.Right_Panel.ResumeLayout(false);
			this.Panel1.ResumeLayout(false);
			this.PaymentMethodTakeawayCollectionDineinPanel.ResumeLayout(false);
			this.TotalsPanel.ResumeLayout(false);
			this.TotalsPanel.PerformLayout();
			this.PaymentMethodDeliveryPanel.ResumeLayout(false);
			this.MealPanel.ResumeLayout(false);
			this.ResumeLayout(false);
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x0600062A RID: 1578 RVA: 0x0003EA68 File Offset: 0x0003CC68
		// (set) Token: 0x0600062B RID: 1579 RVA: 0x00003F0A File Offset: 0x0000210A
		internal virtual Panel Main_Panel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Main_Panel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Main_Panel = value;
			}
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x0600062C RID: 1580 RVA: 0x0003EA80 File Offset: 0x0003CC80
		// (set) Token: 0x0600062D RID: 1581 RVA: 0x00003F14 File Offset: 0x00002114
		internal virtual Panel Right_Panel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Right_Panel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Right_Panel = value;
			}
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x0600062E RID: 1582 RVA: 0x0003EA98 File Offset: 0x0003CC98
		// (set) Token: 0x0600062F RID: 1583 RVA: 0x00003F1E File Offset: 0x0000211E
		internal virtual Panel Bottom_Panel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Bottom_Panel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Bottom_Panel = value;
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000630 RID: 1584 RVA: 0x0003EAB0 File Offset: 0x0003CCB0
		// (set) Token: 0x06000631 RID: 1585 RVA: 0x00003F28 File Offset: 0x00002128
		internal virtual Panel MessageBoard
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MessageBoard;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._MessageBoard = value;
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000632 RID: 1586 RVA: 0x0003EAC8 File Offset: 0x0003CCC8
		// (set) Token: 0x06000633 RID: 1587 RVA: 0x00003F32 File Offset: 0x00002132
		internal virtual TextBox TotalTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalTextBox = value;
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000634 RID: 1588 RVA: 0x0003EAE0 File Offset: 0x0003CCE0
		// (set) Token: 0x06000635 RID: 1589 RVA: 0x0003EAF8 File Offset: 0x0003CCF8
		internal virtual Button DecreaseQTY
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DecreaseQTY;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DecreaseQTY_Click);
				bool flag = this._DecreaseQTY != null;
				if (flag)
				{
					this._DecreaseQTY.Click -= value2;
				}
				this._DecreaseQTY = value;
				flag = (this._DecreaseQTY != null);
				if (flag)
				{
					this._DecreaseQTY.Click += value2;
				}
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000636 RID: 1590 RVA: 0x0003EB58 File Offset: 0x0003CD58
		// (set) Token: 0x06000637 RID: 1591 RVA: 0x0003EB70 File Offset: 0x0003CD70
		internal virtual Button IncreaseQTY
		{
			[DebuggerNonUserCode]
			get
			{
				return this._IncreaseQTY;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.IncreaseItem_Click);
				bool flag = this._IncreaseQTY != null;
				if (flag)
				{
					this._IncreaseQTY.Click -= value2;
				}
				this._IncreaseQTY = value;
				flag = (this._IncreaseQTY != null);
				if (flag)
				{
					this._IncreaseQTY.Click += value2;
				}
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000638 RID: 1592 RVA: 0x0003EBD0 File Offset: 0x0003CDD0
		// (set) Token: 0x06000639 RID: 1593 RVA: 0x0003EBE8 File Offset: 0x0003CDE8
		internal virtual Button PgDown
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PgDown;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PgDown_Click);
				bool flag = this._PgDown != null;
				if (flag)
				{
					this._PgDown.Click -= value2;
				}
				this._PgDown = value;
				flag = (this._PgDown != null);
				if (flag)
				{
					this._PgDown.Click += value2;
				}
			}
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x0600063A RID: 1594 RVA: 0x0003EC48 File Offset: 0x0003CE48
		// (set) Token: 0x0600063B RID: 1595 RVA: 0x0003EC60 File Offset: 0x0003CE60
		internal virtual Button PgUp
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PgUp;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PgUp_Click);
				bool flag = this._PgUp != null;
				if (flag)
				{
					this._PgUp.Click -= value2;
				}
				this._PgUp = value;
				flag = (this._PgUp != null);
				if (flag)
				{
					this._PgUp.Click += value2;
				}
			}
		}

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x0600063C RID: 1596 RVA: 0x0003ECC0 File Offset: 0x0003CEC0
		// (set) Token: 0x0600063D RID: 1597 RVA: 0x00003F3C File Offset: 0x0000213C
		internal virtual Label DiscountLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DiscountLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DiscountLabel = value;
			}
		}

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x0600063E RID: 1598 RVA: 0x0003ECD8 File Offset: 0x0003CED8
		// (set) Token: 0x0600063F RID: 1599 RVA: 0x00003F46 File Offset: 0x00002146
		internal virtual Label DeliveryChargeLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeliveryChargeLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DeliveryChargeLabel = value;
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000640 RID: 1600 RVA: 0x0003ECF0 File Offset: 0x0003CEF0
		// (set) Token: 0x06000641 RID: 1601 RVA: 0x00003F50 File Offset: 0x00002150
		internal virtual TextBox DeliveryChargeTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeliveryChargeTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DeliveryChargeTextBox = value;
			}
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000642 RID: 1602 RVA: 0x0003ED08 File Offset: 0x0003CF08
		// (set) Token: 0x06000643 RID: 1603 RVA: 0x00003F5A File Offset: 0x0000215A
		internal virtual Label ServiceChargeLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ServiceChargeLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ServiceChargeLabel = value;
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000644 RID: 1604 RVA: 0x0003ED20 File Offset: 0x0003CF20
		// (set) Token: 0x06000645 RID: 1605 RVA: 0x00003F64 File Offset: 0x00002164
		internal virtual TextBox ServiceChargeTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ServiceChargeTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ServiceChargeTextBox = value;
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000646 RID: 1606 RVA: 0x0003ED38 File Offset: 0x0003CF38
		// (set) Token: 0x06000647 RID: 1607 RVA: 0x00003F6E File Offset: 0x0000216E
		internal virtual Label SubTotalLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SubTotalLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._SubTotalLabel = value;
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000648 RID: 1608 RVA: 0x0003ED50 File Offset: 0x0003CF50
		// (set) Token: 0x06000649 RID: 1609 RVA: 0x00003F78 File Offset: 0x00002178
		internal virtual TextBox SubTotalTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SubTotalTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._SubTotalTextBox = value;
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x0600064A RID: 1610 RVA: 0x0003ED68 File Offset: 0x0003CF68
		// (set) Token: 0x0600064B RID: 1611 RVA: 0x0003ED80 File Offset: 0x0003CF80
		internal virtual Button CompleteBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CompleteBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click_1);
				bool flag = this._CompleteBTN != null;
				if (flag)
				{
					this._CompleteBTN.Click -= value2;
				}
				this._CompleteBTN = value;
				flag = (this._CompleteBTN != null);
				if (flag)
				{
					this._CompleteBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x0600064C RID: 1612 RVA: 0x0003EDE0 File Offset: 0x0003CFE0
		// (set) Token: 0x0600064D RID: 1613 RVA: 0x0003EDF8 File Offset: 0x0003CFF8
		internal virtual Button EditPriceBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EditPriceBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.EditPriceBTN_Click);
				bool flag = this._EditPriceBTN != null;
				if (flag)
				{
					this._EditPriceBTN.Click -= value2;
				}
				this._EditPriceBTN = value;
				flag = (this._EditPriceBTN != null);
				if (flag)
				{
					this._EditPriceBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x0600064E RID: 1614 RVA: 0x0003EE58 File Offset: 0x0003D058
		// (set) Token: 0x0600064F RID: 1615 RVA: 0x00003F82 File Offset: 0x00002182
		internal virtual Label TotalLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalLabel = value;
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x0003EE70 File Offset: 0x0003D070
		// (set) Token: 0x06000651 RID: 1617 RVA: 0x00003F8C File Offset: 0x0000218C
		internal virtual Panel CompletePanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CompletePanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._CompletePanel = value;
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000652 RID: 1618 RVA: 0x0003EE88 File Offset: 0x0003D088
		// (set) Token: 0x06000653 RID: 1619 RVA: 0x00003F96 File Offset: 0x00002196
		internal virtual Panel TotalsPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalsPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalsPanel = value;
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000654 RID: 1620 RVA: 0x0003EEA0 File Offset: 0x0003D0A0
		// (set) Token: 0x06000655 RID: 1621 RVA: 0x0003EEB8 File Offset: 0x0003D0B8
		internal virtual Button Exit_Program
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Exit_Program;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Exit_Program != null;
				if (flag)
				{
					this._Exit_Program.Click -= value2;
				}
				this._Exit_Program = value;
				flag = (this._Exit_Program != null);
				if (flag)
				{
					this._Exit_Program.Click += value2;
				}
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000656 RID: 1622 RVA: 0x0003EF18 File Offset: 0x0003D118
		// (set) Token: 0x06000657 RID: 1623 RVA: 0x00003FA0 File Offset: 0x000021A0
		internal virtual Panel MealPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MealPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._MealPanel = value;
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000658 RID: 1624 RVA: 0x0003EF30 File Offset: 0x0003D130
		// (set) Token: 0x06000659 RID: 1625 RVA: 0x0003EF48 File Offset: 0x0003D148
		internal virtual Button MealNextBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MealNextBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.MealNextBTN_Click);
				bool flag = this._MealNextBTN != null;
				if (flag)
				{
					this._MealNextBTN.Click -= value2;
				}
				this._MealNextBTN = value;
				flag = (this._MealNextBTN != null);
				if (flag)
				{
					this._MealNextBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x0600065A RID: 1626 RVA: 0x0003EFA8 File Offset: 0x0003D1A8
		// (set) Token: 0x0600065B RID: 1627 RVA: 0x00003FAA File Offset: 0x000021AA
		internal virtual TextBox DiscountTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DiscountTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DiscountTextBox = value;
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x0600065C RID: 1628 RVA: 0x0003EFC0 File Offset: 0x0003D1C0
		// (set) Token: 0x0600065D RID: 1629 RVA: 0x00003FB4 File Offset: 0x000021B4
		internal virtual Panel PaymentMethodDeliveryPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PaymentMethodDeliveryPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PaymentMethodDeliveryPanel = value;
			}
		}

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x0600065E RID: 1630 RVA: 0x0003EFD8 File Offset: 0x0003D1D8
		// (set) Token: 0x0600065F RID: 1631 RVA: 0x00003FBE File Offset: 0x000021BE
		internal virtual Panel PaymentMethodTakeawayCollectionDineinPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PaymentMethodTakeawayCollectionDineinPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PaymentMethodTakeawayCollectionDineinPanel = value;
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000660 RID: 1632 RVA: 0x0003EFF0 File Offset: 0x0003D1F0
		// (set) Token: 0x06000661 RID: 1633 RVA: 0x00003FC8 File Offset: 0x000021C8
		internal virtual Label POSMessageBoardText
		{
			[DebuggerNonUserCode]
			get
			{
				return this._POSMessageBoardText;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._POSMessageBoardText = value;
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000662 RID: 1634 RVA: 0x0003F008 File Offset: 0x0003D208
		// (set) Token: 0x06000663 RID: 1635 RVA: 0x0003F020 File Offset: 0x0003D220
		internal virtual Button DiscountBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DiscountBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DiscountBTN_Click);
				bool flag = this._DiscountBTN != null;
				if (flag)
				{
					this._DiscountBTN.Click -= value2;
				}
				this._DiscountBTN = value;
				flag = (this._DiscountBTN != null);
				if (flag)
				{
					this._DiscountBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000664 RID: 1636 RVA: 0x0003F080 File Offset: 0x0003D280
		// (set) Token: 0x06000665 RID: 1637 RVA: 0x00003FD2 File Offset: 0x000021D2
		internal virtual Panel Panel1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Panel1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Panel1 = value;
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000666 RID: 1638 RVA: 0x0003F098 File Offset: 0x0003D298
		// (set) Token: 0x06000667 RID: 1639 RVA: 0x0003F0B0 File Offset: 0x0003D2B0
		internal virtual Button CommentBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CommentBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CommentBTN_Click);
				bool flag = this._CommentBTN != null;
				if (flag)
				{
					this._CommentBTN.Click -= value2;
				}
				this._CommentBTN = value;
				flag = (this._CommentBTN != null);
				if (flag)
				{
					this._CommentBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000668 RID: 1640 RVA: 0x0003F110 File Offset: 0x0003D310
		// (set) Token: 0x06000669 RID: 1641 RVA: 0x0003F128 File Offset: 0x0003D328
		internal virtual Button TakeawayCollectionCashBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TakeawayCollectionCashBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.TakeawayCollectionCashBTN_Click);
				bool flag = this._TakeawayCollectionCashBTN != null;
				if (flag)
				{
					this._TakeawayCollectionCashBTN.Click -= value2;
				}
				this._TakeawayCollectionCashBTN = value;
				flag = (this._TakeawayCollectionCashBTN != null);
				if (flag)
				{
					this._TakeawayCollectionCashBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x0600066A RID: 1642 RVA: 0x0003F188 File Offset: 0x0003D388
		// (set) Token: 0x0600066B RID: 1643 RVA: 0x0003F1A0 File Offset: 0x0003D3A0
		internal virtual Button TakeawayCollectionCardBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TakeawayCollectionCardBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.TakeawayCollectionCardBTN_Click);
				bool flag = this._TakeawayCollectionCardBTN != null;
				if (flag)
				{
					this._TakeawayCollectionCardBTN.Click -= value2;
				}
				this._TakeawayCollectionCardBTN = value;
				flag = (this._TakeawayCollectionCardBTN != null);
				if (flag)
				{
					this._TakeawayCollectionCardBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x0600066C RID: 1644 RVA: 0x0003F200 File Offset: 0x0003D400
		// (set) Token: 0x0600066D RID: 1645 RVA: 0x0003F218 File Offset: 0x0003D418
		internal virtual Button DeliveryCardBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeliveryCardBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DeliveryCardBTN_Click);
				bool flag = this._DeliveryCardBTN != null;
				if (flag)
				{
					this._DeliveryCardBTN.Click -= value2;
				}
				this._DeliveryCardBTN = value;
				flag = (this._DeliveryCardBTN != null);
				if (flag)
				{
					this._DeliveryCardBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x0600066E RID: 1646 RVA: 0x0003F278 File Offset: 0x0003D478
		// (set) Token: 0x0600066F RID: 1647 RVA: 0x0003F290 File Offset: 0x0003D490
		internal virtual Button DeliveryCashBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeliveryCashBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DeliveryCashBTN_Click);
				bool flag = this._DeliveryCashBTN != null;
				if (flag)
				{
					this._DeliveryCashBTN.Click -= value2;
				}
				this._DeliveryCashBTN = value;
				flag = (this._DeliveryCashBTN != null);
				if (flag)
				{
					this._DeliveryCashBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000670 RID: 1648 RVA: 0x0003F2F0 File Offset: 0x0003D4F0
		// (set) Token: 0x06000671 RID: 1649 RVA: 0x0003F308 File Offset: 0x0003D508
		internal virtual Button CookingOptionsBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CookingOptionsBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CookingOptionsBTN_Click);
				bool flag = this._CookingOptionsBTN != null;
				if (flag)
				{
					this._CookingOptionsBTN.Click -= value2;
				}
				this._CookingOptionsBTN = value;
				flag = (this._CookingOptionsBTN != null);
				if (flag)
				{
					this._CookingOptionsBTN.Click += value2;
				}
			}
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x0000225A File Offset: 0x0000045A
		private void POS_Window_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x0003F368 File Offset: 0x0003D568
		public void PMButtonClick(object PT)
		{
			M_Settings.PaymentType = Conversions.ToString(PT);
			this.ReadyToTakeNewOrder("yes");
			M_Settings.AutoCompleteActive = "no";
			this.POSMessageBoardText.Text = "";
			MyProject.Forms.Form_Glass.Hide();
			this.Hide();
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x0003F3C0 File Offset: 0x0003D5C0
		private void Button1_Click_1(object sender, EventArgs e)
		{
			try
			{
				bool flag = Operators.CompareString(offers.OFFER_FREEFOODS, "", false) != 0 & decimal.Compare(Conversions.ToDecimal(this.TotalTextBox.Text), Conversions.ToDecimal(offers.OFFER_FREEFOODS_PRICE)) >= 0;
				if (flag)
				{
					MyProject.Forms.FinalWindowOnComplete.Show();
					MyProject.Forms.FinalWindowOnComplete.FinalWindowOnComplete_FreeFoodsOffer();
				}
				else
				{
					this.FullCompleteOrder();
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x0003F460 File Offset: 0x0003D660
		public void FullCompleteOrder()
		{
			bool flag = Operators.CompareString(M_Settings.OrderType, "Delivery", false) == 0 | Operators.CompareString(M_Settings.OrderType, "Collection", false) == 0 | Operators.CompareString(M_Settings.OrderType, "Takeaway", false) == 0;
			if (flag)
			{
				this.ShowPaymentMethods();
			}
			flag = (Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) == 0 & Operators.CompareString(M_Settings.OrderType, "Dine In", false) == 0);
			if (flag)
			{
				this.ShowPaymentMethods();
			}
			else
			{
				flag = (Operators.CompareString(M_Settings.OrderType, "Dine In", false) == 0 & Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) != 0);
				if (flag)
				{
					this.ReadyToTakeNewOrder("yes");
					M_Settings.OrderType = "Dine In";
					M_Settings.TableNumber = "";
					M_Settings.NumberOfGuests = "";
					OrderManagment.NextOrderNumberString = "";
					M_Settings.AutoCompleteActive = "no";
					this.Hide();
				}
			}
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x0003F560 File Offset: 0x0003D760
		private void ShowPaymentMethods()
		{
			this.CompletePanel.SendToBack();
			bool flag = Operators.CompareString(M_Settings.OrderType, "Delivery", false) == 0;
			if (flag)
			{
				this.PaymentMethodDeliveryPanel.BringToFront();
			}
			flag = (Operators.CompareString(M_Settings.OrderType, "Collection", false) == 0 | Operators.CompareString(M_Settings.OrderType, "Takeaway", false) == 0 | Operators.CompareString(M_Settings.OrderType, "Dine In", false) == 0);
			if (flag)
			{
				this.PaymentMethodTakeawayCollectionDineinPanel.BringToFront();
			}
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x0003F5EC File Offset: 0x0003D7EC
		public void ReadyToTakeNewOrder(object HaveNewOrder)
		{
			bool flag = Conversions.ToBoolean(Operators.AndObject(Operators.CompareObjectEqual(HaveNewOrder, "yes", false), M_Settings.ShoppingCart.Items.Count > 0));
			checked
			{
				if (flag)
				{
					bool flag2 = Operators.CompareString(M_Settings.OrderType, "Dine In", false) == 0;
					if (flag2)
					{
						OrderManagment.NextOrderNumberString = "Table" + M_Settings.TableNumber;
					}
					else
					{
						OrderManagment.CalculateNextOrderNumber();
					}
					try
					{
						flag2 = (Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0);
						if (flag2)
						{
							MyProject.Forms.Printing_Setup.PrintReceipt.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
						}
						int num = 1;
						int num2 = Conversions.ToInteger(MySettingsProperty.Settings.NumberOfPrint);
						int num3 = num;
						for (;;)
						{
							int num4 = num3;
							int num5 = num2;
							if (num4 > num5)
							{
								break;
							}
							MyProject.Forms.Printing_Setup.PrintReceipt.Print();
							num3++;
						}
						string left = "n";
						flag2 = (Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) == 0 & Operators.CompareString(M_Settings.OrderType, "Dine In", false) == 0);
						if (flag2)
						{
							left = "y";
						}
						flag2 = (Operators.CompareString(left, "n", false) == 0);
						if (flag2)
						{
							flag = (Operators.CompareString(MySettingsProperty.Settings.Printer1Name, "", false) != 0);
							if (flag)
							{
								MyProject.Forms.Printing_Setup.PrintReceipt.PrinterSettings.PrinterName = MySettingsProperty.Settings.Printer1Name;
								MyProject.Forms.Printing_Setup.PrintReceipt.Print();
							}
							flag2 = (Operators.CompareString(MySettingsProperty.Settings.Printer2Name, "", false) != 0);
							if (flag2)
							{
								MyProject.Forms.Printing_Setup.PrintReceipt.PrinterSettings.PrinterName = MySettingsProperty.Settings.Printer2Name;
								MyProject.Forms.Printing_Setup.PrintReceipt.Print();
							}
						}
					}
					catch (Exception ex)
					{
					}
					OrderManagment.SaveOrdersIntoComputer();
				}
				M_Settings.ShoppingCart.Items.Clear();
				MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.StreetNameTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.CustomerCityTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.PostCodeTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Items.Clear();
				M_Calculates.OrderDiscount = 0m;
				M_Calculates.CalculateSubTotal();
				M_Settings.OrderTakenFrom = "";
				M_Settings.OrderType = "";
				M_Settings.PaymentType = "";
				M_Settings.OrderComment = "";
				M_Settings.CustomerAddress = "";
				M_Settings.CustomerPostCode = "";
				M_Settings.CustomerTel = "";
				M_Settings.CustomerCity = "";
				M_Settings.CustomerNote = "";
				M_Settings.CustomerNumberOfOrders = "";
				M_Settings.CustomerType = "";
				M_Settings.OrderNoToEditAddress = "";
				M_Settings.TableNumberAction = "";
				M_Settings.TableNumber = "";
				M_Settings.NumberOfGuests = "";
				OrderManagment.NextOrderNumber = 0;
				OrderManagment.NextOrderNumberString = "";
				OrderManagment.EditOrderOldDTotal = 0m;
				OrderManagment.EditOrderOldDateTime = "";
				M_Settings.OrderNoToEdit = "";
				this.PaymentMethodDeliveryPanel.SendToBack();
				this.PaymentMethodTakeawayCollectionDineinPanel.SendToBack();
				this.CompletePanel.BringToFront();
				Meal.CourseStep = -1;
				Meal.RemoveTLP_BTNs();
				this.MessageBoard.BringToFront();
				MyProject.Forms.Index.BringToFront();
			}
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x0000225A File Offset: 0x0000045A
		public void Button2_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00003FDC File Offset: 0x000021DC
		private void Button1_Click(object sender, EventArgs e)
		{
			this.Bottom_Panel.Enabled = true;
			this.ExitPOS();
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x0003F9D8 File Offset: 0x0003DBD8
		public void ExitPOS()
		{
			M_Settings.ShoppingCart.Items.Clear();
			M_Calculates.CalculateSubTotal();
			this.ReadyToTakeNewOrder("no");
			M_Settings.AutoCompleteActive = "no";
			this.CompletePanel.BringToFront();
			offers.CleanOffer();
			bool flag = Operators.CompareString(M_Settings.TableNumberAction, "CompleteTable", false) == 0;
			if (flag)
			{
				bool flag2 = Operators.CompareString(MySettingsProperty.Settings.RemoveItemsInShoppingCart, "y", false) == 0;
				if (flag2)
				{
					this.EditPriceBTN.Visible = true;
					this.DecreaseQTY.Visible = true;
					this.IncreaseQTY.Visible = true;
				}
				else
				{
					this.EditPriceBTN.Visible = false;
					this.DecreaseQTY.Visible = false;
					this.IncreaseQTY.Visible = false;
				}
			}
			this.POSMessageBoardText.Text = "";
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x00003FF4 File Offset: 0x000021F4
		private void Button3_Click(object sender, EventArgs e)
		{
			this.MessageBoard.BringToFront();
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x0003FABC File Offset: 0x0003DCBC
		private void PgUp_Click(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					bool flag = M_Settings.ShoppingCart.TopItem.Index - 1 >= 0;
					if (flag)
					{
						M_Settings.ShoppingCart.EnsureVisible(M_Settings.ShoppingCart.TopItem.Index - 1);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x0003FB28 File Offset: 0x0003DD28
		private void PgDown_Click(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					bool flag = Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 1.0;
					int num;
					if (flag)
					{
						num = M_Settings.ShoppingCart.TopItem.Index + 21;
					}
					flag = (Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 2.0);
					if (flag)
					{
						num = M_Settings.ShoppingCart.TopItem.Index + 19;
					}
					flag = (M_Settings.ShoppingCart.Items.Count > num);
					if (flag)
					{
						M_Settings.ShoppingCart.EnsureVisible(num + 1);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x0003FBE4 File Offset: 0x0003DDE4
		private void IncreaseItem_Click(object sender, EventArgs e)
		{
			try
			{
				bool flag = Operators.CompareString(M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[0].Text, "OFFER", false) != 0;
				if (flag)
				{
					M_Settings.BeforeOptionTXT = "    ";
					M_Shopping_Cart.QtyPlus();
				}
				M_Calculates.CalculateSubTotal();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x0003FC70 File Offset: 0x0003DE70
		private void DecreaseQTY_Click(object sender, EventArgs e)
		{
			try
			{
				bool flag = Operators.CompareString(M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[0].Text, "OFFER", false) == 0;
				if (flag)
				{
					M_Settings.ShoppingCart.Items.RemoveAt(M_Settings.ShoppingCart.FocusedItem.Index);
				}
				else
				{
					M_Settings.BeforeOptionTXT = "    ";
					M_Shopping_Cart.QtyMinus();
				}
				M_Calculates.CalculateSubTotal();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x0003FD1C File Offset: 0x0003DF1C
		private void EditPriceBTN_Click(object sender, EventArgs e)
		{
			M_Settings.BeforeOptionTXT = "    ";
			try
			{
				bool flag = M_Settings.ShoppingCart.FocusedItem.Index >= 0;
				if (flag)
				{
					MyProject.Forms.Form_Edit_Price.Show();
				}
				M_Calculates.CalculateSubTotal();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x0003FD88 File Offset: 0x0003DF88
		private void MealNextBTN_Click(object sender, EventArgs e)
		{
			Meal.RemoveTLP_BTNs();
			bool flag = Meal.CourseStep < Meal.CourseStepMax;
			if (flag)
			{
				Meal.Steps();
			}
			flag = (Meal.CourseStep == Meal.CourseStepMax);
			if (flag)
			{
				Meal.BringCompleteAndMessagePanelsInFront();
				this.Bottom_Panel.Enabled = true;
				this.Exit_Program.Enabled = true;
			}
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x00004004 File Offset: 0x00002204
		private void Button1_Click_2(object sender, EventArgs e)
		{
			offers.AddOfferToShoppingCart();
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x0000400E File Offset: 0x0000220E
		private void DiscountBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Show();
			MyProject.Forms.ApplyDiscountManually.Show();
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x00004032 File Offset: 0x00002232
		private void DeliveryCashBTN_Click(object sender, EventArgs e)
		{
			this.PMButtonClick("Cash");
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x00004042 File Offset: 0x00002242
		private void DeliveryCardBTN_Click(object sender, EventArgs e)
		{
			this.PMButtonClick("Credit/Debit Card");
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x00004052 File Offset: 0x00002252
		private void TakeawayCollectionCashBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.CalculateCustomerChange.Show();
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x00004042 File Offset: 0x00002242
		private void TakeawayCollectionCardBTN_Click(object sender, EventArgs e)
		{
			this.PMButtonClick("Credit/Debit Card");
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x00004066 File Offset: 0x00002266
		private void CommentBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.OrderCommentAdd.Show();
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x0000407A File Offset: 0x0000227A
		private void CookingOptionsBTN_Click(object sender, EventArgs e)
		{
			this.Main_Panel.Controls["CookingOptions"].BringToFront();
		}

		// Token: 0x040002CA RID: 714
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x040002CB RID: 715
		private IContainer components;

		// Token: 0x040002CC RID: 716
		[AccessedThroughProperty("Main_Panel")]
		private Panel _Main_Panel;

		// Token: 0x040002CD RID: 717
		[AccessedThroughProperty("Right_Panel")]
		private Panel _Right_Panel;

		// Token: 0x040002CE RID: 718
		[AccessedThroughProperty("Bottom_Panel")]
		private Panel _Bottom_Panel;

		// Token: 0x040002CF RID: 719
		[AccessedThroughProperty("MessageBoard")]
		private Panel _MessageBoard;

		// Token: 0x040002D0 RID: 720
		[AccessedThroughProperty("TotalTextBox")]
		private TextBox _TotalTextBox;

		// Token: 0x040002D1 RID: 721
		[AccessedThroughProperty("DecreaseQTY")]
		private Button _DecreaseQTY;

		// Token: 0x040002D2 RID: 722
		[AccessedThroughProperty("IncreaseQTY")]
		private Button _IncreaseQTY;

		// Token: 0x040002D3 RID: 723
		[AccessedThroughProperty("PgDown")]
		private Button _PgDown;

		// Token: 0x040002D4 RID: 724
		[AccessedThroughProperty("PgUp")]
		private Button _PgUp;

		// Token: 0x040002D5 RID: 725
		[AccessedThroughProperty("DiscountLabel")]
		private Label _DiscountLabel;

		// Token: 0x040002D6 RID: 726
		[AccessedThroughProperty("DeliveryChargeLabel")]
		private Label _DeliveryChargeLabel;

		// Token: 0x040002D7 RID: 727
		[AccessedThroughProperty("DeliveryChargeTextBox")]
		private TextBox _DeliveryChargeTextBox;

		// Token: 0x040002D8 RID: 728
		[AccessedThroughProperty("ServiceChargeLabel")]
		private Label _ServiceChargeLabel;

		// Token: 0x040002D9 RID: 729
		[AccessedThroughProperty("ServiceChargeTextBox")]
		private TextBox _ServiceChargeTextBox;

		// Token: 0x040002DA RID: 730
		[AccessedThroughProperty("SubTotalLabel")]
		private Label _SubTotalLabel;

		// Token: 0x040002DB RID: 731
		[AccessedThroughProperty("SubTotalTextBox")]
		private TextBox _SubTotalTextBox;

		// Token: 0x040002DC RID: 732
		[AccessedThroughProperty("CompleteBTN")]
		private Button _CompleteBTN;

		// Token: 0x040002DD RID: 733
		[AccessedThroughProperty("EditPriceBTN")]
		private Button _EditPriceBTN;

		// Token: 0x040002DE RID: 734
		[AccessedThroughProperty("TotalLabel")]
		private Label _TotalLabel;

		// Token: 0x040002DF RID: 735
		[AccessedThroughProperty("CompletePanel")]
		private Panel _CompletePanel;

		// Token: 0x040002E0 RID: 736
		[AccessedThroughProperty("TotalsPanel")]
		private Panel _TotalsPanel;

		// Token: 0x040002E1 RID: 737
		[AccessedThroughProperty("Exit_Program")]
		private Button _Exit_Program;

		// Token: 0x040002E2 RID: 738
		[AccessedThroughProperty("MealPanel")]
		private Panel _MealPanel;

		// Token: 0x040002E3 RID: 739
		[AccessedThroughProperty("MealNextBTN")]
		private Button _MealNextBTN;

		// Token: 0x040002E4 RID: 740
		[AccessedThroughProperty("DiscountTextBox")]
		private TextBox _DiscountTextBox;

		// Token: 0x040002E5 RID: 741
		[AccessedThroughProperty("PaymentMethodDeliveryPanel")]
		private Panel _PaymentMethodDeliveryPanel;

		// Token: 0x040002E6 RID: 742
		[AccessedThroughProperty("PaymentMethodTakeawayCollectionDineinPanel")]
		private Panel _PaymentMethodTakeawayCollectionDineinPanel;

		// Token: 0x040002E7 RID: 743
		[AccessedThroughProperty("POSMessageBoardText")]
		private Label _POSMessageBoardText;

		// Token: 0x040002E8 RID: 744
		[AccessedThroughProperty("DiscountBTN")]
		private Button _DiscountBTN;

		// Token: 0x040002E9 RID: 745
		[AccessedThroughProperty("Panel1")]
		private Panel _Panel1;

		// Token: 0x040002EA RID: 746
		[AccessedThroughProperty("CommentBTN")]
		private Button _CommentBTN;

		// Token: 0x040002EB RID: 747
		[AccessedThroughProperty("TakeawayCollectionCashBTN")]
		private Button _TakeawayCollectionCashBTN;

		// Token: 0x040002EC RID: 748
		[AccessedThroughProperty("TakeawayCollectionCardBTN")]
		private Button _TakeawayCollectionCardBTN;

		// Token: 0x040002ED RID: 749
		[AccessedThroughProperty("DeliveryCardBTN")]
		private Button _DeliveryCardBTN;

		// Token: 0x040002EE RID: 750
		[AccessedThroughProperty("DeliveryCashBTN")]
		private Button _DeliveryCashBTN;

		// Token: 0x040002EF RID: 751
		[AccessedThroughProperty("CookingOptionsBTN")]
		private Button _CookingOptionsBTN;
	}
}
