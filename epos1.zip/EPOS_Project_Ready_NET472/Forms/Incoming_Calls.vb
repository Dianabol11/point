using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000022 RID: 34
	[DesignerGenerated]
	public class Incoming_Calls : Form
	{
		// Token: 0x0600055A RID: 1370 RVA: 0x000316D8 File Offset: 0x0002F8D8
		public Incoming_Calls()
		{
			base.Load += this.Incoming_Calls_Load;
			List<WeakReference> _ENCList = Incoming_Calls.__ENCList;
			lock (_ENCList)
			{
				Incoming_Calls.__ENCList.Add(new WeakReference(this));
			}
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			this.InitializeComponent();
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x0003174C File Offset: 0x0002F94C
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x0600055C RID: 1372 RVA: 0x0003179C File Offset: 0x0002F99C
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.CustomerPhoneNumberTextBox = new TextBox();
			this.CustomerPhoneNumberLabel = new Label();
			this.StreetNameTextBox = new TextBox();
			this.PostCodeTextBox = new TextBox();
			this.Label1 = new Label();
			this.Label2 = new Label();
			this.KeyboardPanel = new Panel();
			this.ExitBTN = new Button();
			this.DeliveryBTN = new Button();
			this.CollectionBTN = new Button();
			this.CustomerDetailsPanel = new Panel();
			this.ShowOrderBTN = new Button();
			this.SaveCustomerBTN = new Button();
			this.Label4 = new Label();
			this.CustomerNoteTextBox = new TextBox();
			this.NewAddressBTN = new Button();
			this.CustomerSearchComboBox = new ComboBox();
			this.ShowAddressGoogleMap = new Button();
			this.Label5 = new Label();
			this.FindCustomerBTN = new Button();
			this.CustomerCityTextBox = new TextBox();
			this.Button2 = new Button();
			this.Label3 = new Label();
			this.NumberOfOrdersLBL = new Label();
			this.CustomerDetailsPanel.SuspendLayout();
			this.SuspendLayout();
			this.CustomerPhoneNumberTextBox.BackColor = SystemColors.Window;
			this.CustomerPhoneNumberTextBox.BorderStyle = BorderStyle.None;
			this.CustomerPhoneNumberTextBox.Font = new Font("Arial", 26.25f);
			Control customerPhoneNumberTextBox = this.CustomerPhoneNumberTextBox;
			Point location = new Point(181, 176);
			customerPhoneNumberTextBox.Location = location;
			this.CustomerPhoneNumberTextBox.Name = "CustomerPhoneNumberTextBox";
			Control customerPhoneNumberTextBox2 = this.CustomerPhoneNumberTextBox;
			Size size = new Size(453, 41);
			customerPhoneNumberTextBox2.Size = size;
			this.CustomerPhoneNumberTextBox.TabIndex = 1;
			this.CustomerPhoneNumberLabel.AutoSize = true;
			this.CustomerPhoneNumberLabel.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.CustomerPhoneNumberLabel.ForeColor = Color.Black;
			Control customerPhoneNumberLabel = this.CustomerPhoneNumberLabel;
			location = new Point(85, 183);
			customerPhoneNumberLabel.Location = location;
			this.CustomerPhoneNumberLabel.Name = "CustomerPhoneNumberLabel";
			Control customerPhoneNumberLabel2 = this.CustomerPhoneNumberLabel;
			size = new Size(89, 27);
			customerPhoneNumberLabel2.Size = size;
			this.CustomerPhoneNumberLabel.TabIndex = 1;
			this.CustomerPhoneNumberLabel.Text = "Phone:";
			this.StreetNameTextBox.BorderStyle = BorderStyle.None;
			this.StreetNameTextBox.Font = new Font("Arial", 26.25f);
			Control streetNameTextBox = this.StreetNameTextBox;
			location = new Point(181, 241);
			streetNameTextBox.Location = location;
			this.StreetNameTextBox.Name = "StreetNameTextBox";
			Control streetNameTextBox2 = this.StreetNameTextBox;
			size = new Size(650, 41);
			streetNameTextBox2.Size = size;
			this.StreetNameTextBox.TabIndex = 5;
			this.PostCodeTextBox.BorderStyle = BorderStyle.None;
			this.PostCodeTextBox.CharacterCasing = CharacterCasing.Upper;
			this.PostCodeTextBox.Font = new Font("Arial", 26.25f);
			Control postCodeTextBox = this.PostCodeTextBox;
			location = new Point(181, 370);
			postCodeTextBox.Location = location;
			this.PostCodeTextBox.Name = "PostCodeTextBox";
			Control postCodeTextBox2 = this.PostCodeTextBox;
			size = new Size(188, 41);
			postCodeTextBox2.Size = size;
			this.PostCodeTextBox.TabIndex = 1;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.Black;
			Control label = this.Label1;
			location = new Point(114, 313);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(60, 27);
			label2.Size = size;
			this.Label1.TabIndex = 6;
			this.Label1.Text = "City:";
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label2.ForeColor = Color.Black;
			Control label3 = this.Label2;
			location = new Point(64, 248);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(107, 27);
			label4.Size = size;
			this.Label2.TabIndex = 7;
			this.Label2.Text = "Address:";
			this.KeyboardPanel.Dock = DockStyle.Bottom;
			Control keyboardPanel = this.KeyboardPanel;
			location = new Point(0, 496);
			keyboardPanel.Location = location;
			this.KeyboardPanel.Name = "KeyboardPanel";
			Control keyboardPanel2 = this.KeyboardPanel;
			size = new Size(1200, 17);
			keyboardPanel2.Size = size;
			this.KeyboardPanel.TabIndex = 9;
			this.ExitBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.ExitBTN.BackColor = Color.Crimson;
			this.ExitBTN.FlatStyle = FlatStyle.Popup;
			this.ExitBTN.Font = new Font("Arial", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.ExitBTN.ForeColor = SystemColors.HighlightText;
			Control exitBTN = this.ExitBTN;
			location = new Point(1148, 12);
			exitBTN.Location = location;
			this.ExitBTN.Name = "ExitBTN";
			Control exitBTN2 = this.ExitBTN;
			size = new Size(40, 40);
			exitBTN2.Size = size;
			this.ExitBTN.TabIndex = 26;
			this.ExitBTN.Text = "x";
			this.ExitBTN.UseVisualStyleBackColor = false;
			this.DeliveryBTN.BackColor = Color.Lime;
			this.DeliveryBTN.Enabled = false;
			this.DeliveryBTN.FlatAppearance.BorderColor = Color.White;
			this.DeliveryBTN.FlatAppearance.BorderSize = 2;
			this.DeliveryBTN.FlatAppearance.MouseDownBackColor = Color.FromArgb(128, 255, 128);
			this.DeliveryBTN.FlatAppearance.MouseOverBackColor = Color.Lime;
			this.DeliveryBTN.FlatStyle = FlatStyle.Flat;
			this.DeliveryBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control deliveryBTN = this.DeliveryBTN;
			location = new Point(578, 306);
			deliveryBTN.Location = location;
			this.DeliveryBTN.Name = "DeliveryBTN";
			Control deliveryBTN2 = this.DeliveryBTN;
			size = new Size(207, 107);
			deliveryBTN2.Size = size;
			this.DeliveryBTN.TabIndex = 27;
			this.DeliveryBTN.Text = "Delivery";
			this.DeliveryBTN.UseVisualStyleBackColor = false;
			this.CollectionBTN.BackColor = Color.Lime;
			this.CollectionBTN.Enabled = false;
			this.CollectionBTN.FlatAppearance.BorderColor = Color.White;
			this.CollectionBTN.FlatAppearance.BorderSize = 2;
			this.CollectionBTN.FlatAppearance.MouseDownBackColor = Color.FromArgb(128, 255, 128);
			this.CollectionBTN.FlatAppearance.MouseOverBackColor = Color.Lime;
			this.CollectionBTN.FlatStyle = FlatStyle.Flat;
			this.CollectionBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control collectionBTN = this.CollectionBTN;
			location = new Point(792, 306);
			collectionBTN.Location = location;
			this.CollectionBTN.Name = "CollectionBTN";
			Control collectionBTN2 = this.CollectionBTN;
			size = new Size(212, 107);
			collectionBTN2.Size = size;
			this.CollectionBTN.TabIndex = 28;
			this.CollectionBTN.Text = "Collection";
			this.CollectionBTN.UseVisualStyleBackColor = false;
			this.CustomerDetailsPanel.Controls.Add(this.NumberOfOrdersLBL);
			this.CustomerDetailsPanel.Controls.Add(this.ShowOrderBTN);
			this.CustomerDetailsPanel.Controls.Add(this.SaveCustomerBTN);
			this.CustomerDetailsPanel.Controls.Add(this.Label4);
			this.CustomerDetailsPanel.Controls.Add(this.ExitBTN);
			this.CustomerDetailsPanel.Controls.Add(this.CustomerNoteTextBox);
			this.CustomerDetailsPanel.Controls.Add(this.NewAddressBTN);
			this.CustomerDetailsPanel.Controls.Add(this.CustomerSearchComboBox);
			this.CustomerDetailsPanel.Controls.Add(this.ShowAddressGoogleMap);
			this.CustomerDetailsPanel.Controls.Add(this.Label5);
			this.CustomerDetailsPanel.Controls.Add(this.FindCustomerBTN);
			this.CustomerDetailsPanel.Controls.Add(this.CustomerCityTextBox);
			this.CustomerDetailsPanel.Controls.Add(this.PostCodeTextBox);
			this.CustomerDetailsPanel.Controls.Add(this.Button2);
			this.CustomerDetailsPanel.Controls.Add(this.Label3);
			this.CustomerDetailsPanel.Controls.Add(this.DeliveryBTN);
			this.CustomerDetailsPanel.Controls.Add(this.CustomerPhoneNumberTextBox);
			this.CustomerDetailsPanel.Controls.Add(this.CollectionBTN);
			this.CustomerDetailsPanel.Controls.Add(this.CustomerPhoneNumberLabel);
			this.CustomerDetailsPanel.Controls.Add(this.Label2);
			this.CustomerDetailsPanel.Controls.Add(this.StreetNameTextBox);
			this.CustomerDetailsPanel.Controls.Add(this.Label1);
			this.CustomerDetailsPanel.Dock = DockStyle.Top;
			Control customerDetailsPanel = this.CustomerDetailsPanel;
			location = new Point(0, 0);
			customerDetailsPanel.Location = location;
			this.CustomerDetailsPanel.Name = "CustomerDetailsPanel";
			Control customerDetailsPanel2 = this.CustomerDetailsPanel;
			size = new Size(1200, 475);
			customerDetailsPanel2.Size = size;
			this.CustomerDetailsPanel.TabIndex = 29;
			this.ShowOrderBTN.BackColor = Color.Lime;
			this.ShowOrderBTN.FlatStyle = FlatStyle.Flat;
			this.ShowOrderBTN.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control showOrderBTN = this.ShowOrderBTN;
			location = new Point(578, 306);
			showOrderBTN.Location = location;
			this.ShowOrderBTN.Name = "ShowOrderBTN";
			Control showOrderBTN2 = this.ShowOrderBTN;
			size = new Size(426, 107);
			showOrderBTN2.Size = size;
			this.ShowOrderBTN.TabIndex = 52;
			this.ShowOrderBTN.Text = "Show Order";
			this.ShowOrderBTN.UseVisualStyleBackColor = false;
			this.ShowOrderBTN.Visible = false;
			this.SaveCustomerBTN.BackColor = Color.LightSkyBlue;
			this.SaveCustomerBTN.FlatAppearance.BorderColor = Color.White;
			this.SaveCustomerBTN.FlatAppearance.BorderSize = 2;
			this.SaveCustomerBTN.FlatAppearance.MouseDownBackColor = Color.CornflowerBlue;
			this.SaveCustomerBTN.FlatAppearance.MouseOverBackColor = Color.CornflowerBlue;
			this.SaveCustomerBTN.FlatStyle = FlatStyle.Flat;
			this.SaveCustomerBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control saveCustomerBTN = this.SaveCustomerBTN;
			location = new Point(845, 174);
			saveCustomerBTN.Location = location;
			this.SaveCustomerBTN.Name = "SaveCustomerBTN";
			Control saveCustomerBTN2 = this.SaveCustomerBTN;
			size = new Size(159, 46);
			saveCustomerBTN2.Size = size;
			this.SaveCustomerBTN.TabIndex = 51;
			this.SaveCustomerBTN.Text = "Save Customer";
			this.SaveCustomerBTN.UseVisualStyleBackColor = false;
			this.Label4.AutoSize = true;
			this.Label4.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label4.ForeColor = Color.Black;
			Control label5 = this.Label4;
			location = new Point(21, 47);
			label5.Location = location;
			this.Label4.Name = "Label4";
			Control label6 = this.Label4;
			size = new Size(153, 27);
			label6.Size = size;
			this.Label4.TabIndex = 50;
			this.Label4.Text = "Name / Note:";
			this.CustomerNoteTextBox.BackColor = SystemColors.Window;
			this.CustomerNoteTextBox.BorderStyle = BorderStyle.None;
			this.CustomerNoteTextBox.Font = new Font("Arial", 26.25f);
			Control customerNoteTextBox = this.CustomerNoteTextBox;
			location = new Point(181, 40);
			customerNoteTextBox.Location = location;
			this.CustomerNoteTextBox.Name = "CustomerNoteTextBox";
			Control customerNoteTextBox2 = this.CustomerNoteTextBox;
			size = new Size(823, 41);
			customerNoteTextBox2.Size = size;
			this.CustomerNoteTextBox.TabIndex = 49;
			this.NewAddressBTN.BackColor = Color.Lime;
			this.NewAddressBTN.FlatAppearance.BorderColor = Color.White;
			this.NewAddressBTN.FlatAppearance.BorderSize = 2;
			this.NewAddressBTN.FlatAppearance.MouseDownBackColor = Color.GreenYellow;
			this.NewAddressBTN.FlatAppearance.MouseOverBackColor = Color.LawnGreen;
			this.NewAddressBTN.FlatStyle = FlatStyle.Flat;
			this.NewAddressBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control newAddressBTN = this.NewAddressBTN;
			location = new Point(651, 174);
			newAddressBTN.Location = location;
			this.NewAddressBTN.Name = "NewAddressBTN";
			Control newAddressBTN2 = this.NewAddressBTN;
			size = new Size(180, 46);
			newAddressBTN2.Size = size;
			this.NewAddressBTN.TabIndex = 47;
			this.NewAddressBTN.Text = "New Address";
			this.NewAddressBTN.UseVisualStyleBackColor = false;
			this.CustomerSearchComboBox.AutoCompleteMode = AutoCompleteMode.Suggest;
			this.CustomerSearchComboBox.DropDownWidth = 820;
			this.CustomerSearchComboBox.Font = new Font("Arial", 26.25f);
			this.CustomerSearchComboBox.FormattingEnabled = true;
			this.CustomerSearchComboBox.ItemHeight = 40;
			Control customerSearchComboBox = this.CustomerSearchComboBox;
			location = new Point(181, 105);
			customerSearchComboBox.Location = location;
			this.CustomerSearchComboBox.Name = "CustomerSearchComboBox";
			Control customerSearchComboBox2 = this.CustomerSearchComboBox;
			size = new Size(650, 48);
			customerSearchComboBox2.Size = size;
			this.CustomerSearchComboBox.TabIndex = 46;
			this.ShowAddressGoogleMap.BackColor = Color.Gold;
			this.ShowAddressGoogleMap.FlatAppearance.BorderColor = Color.White;
			this.ShowAddressGoogleMap.FlatAppearance.BorderSize = 2;
			this.ShowAddressGoogleMap.FlatAppearance.MouseDownBackColor = Color.Gold;
			this.ShowAddressGoogleMap.FlatAppearance.MouseOverBackColor = Color.DarkOrange;
			this.ShowAddressGoogleMap.FlatStyle = FlatStyle.Flat;
			this.ShowAddressGoogleMap.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control showAddressGoogleMap = this.ShowAddressGoogleMap;
			location = new Point(845, 239);
			showAddressGoogleMap.Location = location;
			this.ShowAddressGoogleMap.Name = "ShowAddressGoogleMap";
			Control showAddressGoogleMap2 = this.ShowAddressGoogleMap;
			size = new Size(159, 46);
			showAddressGoogleMap2.Size = size;
			this.ShowAddressGoogleMap.TabIndex = 45;
			this.ShowAddressGoogleMap.Text = "Google Map";
			this.ShowAddressGoogleMap.UseVisualStyleBackColor = false;
			this.Label5.AutoSize = true;
			this.Label5.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label5.ForeColor = Color.Black;
			Control label7 = this.Label5;
			location = new Point(80, 115);
			label7.Location = location;
			this.Label5.Name = "Label5";
			Control label8 = this.Label5;
			size = new Size(95, 27);
			label8.Size = size;
			this.Label5.TabIndex = 43;
			this.Label5.Text = "Search:";
			this.FindCustomerBTN.BackColor = Color.Gold;
			this.FindCustomerBTN.FlatAppearance.BorderColor = Color.White;
			this.FindCustomerBTN.FlatAppearance.BorderSize = 2;
			this.FindCustomerBTN.FlatAppearance.MouseDownBackColor = Color.Gold;
			this.FindCustomerBTN.FlatAppearance.MouseOverBackColor = Color.DarkOrange;
			this.FindCustomerBTN.FlatStyle = FlatStyle.Flat;
			this.FindCustomerBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control findCustomerBTN = this.FindCustomerBTN;
			location = new Point(845, 105);
			findCustomerBTN.Location = location;
			this.FindCustomerBTN.Name = "FindCustomerBTN";
			Control findCustomerBTN2 = this.FindCustomerBTN;
			size = new Size(158, 48);
			findCustomerBTN2.Size = size;
			this.FindCustomerBTN.TabIndex = 39;
			this.FindCustomerBTN.Text = "Search";
			this.FindCustomerBTN.UseVisualStyleBackColor = false;
			this.CustomerCityTextBox.BorderStyle = BorderStyle.None;
			this.CustomerCityTextBox.Font = new Font("Arial", 26.25f);
			Control customerCityTextBox = this.CustomerCityTextBox;
			location = new Point(181, 306);
			customerCityTextBox.Location = location;
			this.CustomerCityTextBox.Name = "CustomerCityTextBox";
			Control customerCityTextBox2 = this.CustomerCityTextBox;
			size = new Size(381, 41);
			customerCityTextBox2.Size = size;
			this.CustomerCityTextBox.TabIndex = 32;
			this.Button2.BackColor = Color.Gold;
			this.Button2.FlatAppearance.BorderColor = Color.White;
			this.Button2.FlatAppearance.BorderSize = 2;
			this.Button2.FlatAppearance.MouseDownBackColor = Color.Gold;
			this.Button2.FlatAppearance.MouseOverBackColor = Color.DarkOrange;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control button = this.Button2;
			location = new Point(384, 370);
			button.Location = location;
			this.Button2.Name = "Button2";
			Control button2 = this.Button2;
			size = new Size(178, 43);
			button2.Size = size;
			this.Button2.TabIndex = 33;
			this.Button2.Text = "Find Address";
			this.Button2.UseVisualStyleBackColor = false;
			this.Label3.AutoSize = true;
			this.Label3.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label3.ForeColor = Color.Black;
			Control label9 = this.Label3;
			location = new Point(51, 377);
			label9.Location = location;
			this.Label3.Name = "Label3";
			Control label10 = this.Label3;
			size = new Size(119, 27);
			label10.Size = size;
			this.Label3.TabIndex = 34;
			this.Label3.Text = "Postcode:";
			this.NumberOfOrdersLBL.AutoSize = true;
			this.NumberOfOrdersLBL.Font = new Font("Arial", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.NumberOfOrdersLBL.ForeColor = Color.Black;
			Control numberOfOrdersLBL = this.NumberOfOrdersLBL;
			location = new Point(637, 428);
			numberOfOrdersLBL.Location = location;
			this.NumberOfOrdersLBL.Name = "NumberOfOrdersLBL";
			Control numberOfOrdersLBL2 = this.NumberOfOrdersLBL;
			size = new Size(263, 24);
			numberOfOrdersLBL2.Size = size;
			this.NumberOfOrdersLBL.TabIndex = 53;
			this.NumberOfOrdersLBL.Text = "Number of previous orders:";
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.CornflowerBlue;
			size = new Size(1200, 513);
			this.ClientSize = size;
			this.Controls.Add(this.CustomerDetailsPanel);
			this.Controls.Add(this.KeyboardPanel);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "Incoming_Calls";
			this.Text = "Incoming_Calls";
			this.WindowState = FormWindowState.Maximized;
			this.CustomerDetailsPanel.ResumeLayout(false);
			this.CustomerDetailsPanel.PerformLayout();
			this.ResumeLayout(false);
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x0600055D RID: 1373 RVA: 0x00032D14 File Offset: 0x00030F14
		// (set) Token: 0x0600055E RID: 1374 RVA: 0x00032D2C File Offset: 0x00030F2C
		internal virtual TextBox CustomerPhoneNumberTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CustomerPhoneNumberTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CustomerPhoneNumberTextBox_TextChanged);
				EventHandler value3 = new EventHandler(this.CustomerPhoneNumberTextBox_focused);
				EventHandler value4 = new EventHandler(this.CustomerPhoneNumberTextBox_GotFocus);
				bool flag = this._CustomerPhoneNumberTextBox != null;
				if (flag)
				{
					this._CustomerPhoneNumberTextBox.TextChanged -= value2;
					this._CustomerPhoneNumberTextBox.Click -= value3;
					this._CustomerPhoneNumberTextBox.GotFocus -= value4;
				}
				this._CustomerPhoneNumberTextBox = value;
				flag = (this._CustomerPhoneNumberTextBox != null);
				if (flag)
				{
					this._CustomerPhoneNumberTextBox.TextChanged += value2;
					this._CustomerPhoneNumberTextBox.Click += value3;
					this._CustomerPhoneNumberTextBox.GotFocus += value4;
				}
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x0600055F RID: 1375 RVA: 0x00032DDC File Offset: 0x00030FDC
		// (set) Token: 0x06000560 RID: 1376 RVA: 0x00003B46 File Offset: 0x00001D46
		internal virtual Label CustomerPhoneNumberLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CustomerPhoneNumberLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._CustomerPhoneNumberLabel = value;
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x06000561 RID: 1377 RVA: 0x00032DF4 File Offset: 0x00030FF4
		// (set) Token: 0x06000562 RID: 1378 RVA: 0x00032E0C File Offset: 0x0003100C
		internal virtual TextBox StreetNameTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._StreetNameTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.StreetNameTextBox_TextChanged);
				EventHandler value3 = new EventHandler(this.StreetNameTextBox_focused);
				EventHandler value4 = new EventHandler(this.StreetNameTextBox_GotFocus);
				bool flag = this._StreetNameTextBox != null;
				if (flag)
				{
					this._StreetNameTextBox.TextChanged -= value2;
					this._StreetNameTextBox.Click -= value3;
					this._StreetNameTextBox.GotFocus -= value4;
				}
				this._StreetNameTextBox = value;
				flag = (this._StreetNameTextBox != null);
				if (flag)
				{
					this._StreetNameTextBox.TextChanged += value2;
					this._StreetNameTextBox.Click += value3;
					this._StreetNameTextBox.GotFocus += value4;
				}
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x06000563 RID: 1379 RVA: 0x00032EBC File Offset: 0x000310BC
		// (set) Token: 0x06000564 RID: 1380 RVA: 0x00032ED4 File Offset: 0x000310D4
		internal virtual TextBox PostCodeTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PostCodeTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PostCodeTextBox_TextChanged);
				KeyEventHandler value3 = new KeyEventHandler(this.PostCodeTextBox_KeyDown);
				EventHandler value4 = new EventHandler(this.PostCodeTextBox_focused);
				EventHandler value5 = new EventHandler(this.PostCodeTextBox_GotFocus);
				bool flag = this._PostCodeTextBox != null;
				if (flag)
				{
					this._PostCodeTextBox.TextChanged -= value2;
					this._PostCodeTextBox.KeyDown -= value3;
					this._PostCodeTextBox.Click -= value4;
					this._PostCodeTextBox.GotFocus -= value5;
				}
				this._PostCodeTextBox = value;
				flag = (this._PostCodeTextBox != null);
				if (flag)
				{
					this._PostCodeTextBox.TextChanged += value2;
					this._PostCodeTextBox.KeyDown += value3;
					this._PostCodeTextBox.Click += value4;
					this._PostCodeTextBox.GotFocus += value5;
				}
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x06000565 RID: 1381 RVA: 0x00032FB0 File Offset: 0x000311B0
		// (set) Token: 0x06000566 RID: 1382 RVA: 0x00003B50 File Offset: 0x00001D50
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000567 RID: 1383 RVA: 0x00032FC8 File Offset: 0x000311C8
		// (set) Token: 0x06000568 RID: 1384 RVA: 0x00003B5A File Offset: 0x00001D5A
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000569 RID: 1385 RVA: 0x00032FE0 File Offset: 0x000311E0
		// (set) Token: 0x0600056A RID: 1386 RVA: 0x00003B64 File Offset: 0x00001D64
		internal virtual Panel KeyboardPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._KeyboardPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._KeyboardPanel = value;
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x0600056B RID: 1387 RVA: 0x00032FF8 File Offset: 0x000311F8
		// (set) Token: 0x0600056C RID: 1388 RVA: 0x00033010 File Offset: 0x00031210
		internal virtual Button ExitBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ExitBTN_Click);
				bool flag = this._ExitBTN != null;
				if (flag)
				{
					this._ExitBTN.Click -= value2;
				}
				this._ExitBTN = value;
				flag = (this._ExitBTN != null);
				if (flag)
				{
					this._ExitBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x0600056D RID: 1389 RVA: 0x00033070 File Offset: 0x00031270
		// (set) Token: 0x0600056E RID: 1390 RVA: 0x00033088 File Offset: 0x00031288
		internal virtual Button DeliveryBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeliveryBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DeliveryBYN_Click);
				bool flag = this._DeliveryBTN != null;
				if (flag)
				{
					this._DeliveryBTN.Click -= value2;
				}
				this._DeliveryBTN = value;
				flag = (this._DeliveryBTN != null);
				if (flag)
				{
					this._DeliveryBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x0600056F RID: 1391 RVA: 0x000330E8 File Offset: 0x000312E8
		// (set) Token: 0x06000570 RID: 1392 RVA: 0x00033100 File Offset: 0x00031300
		internal virtual Button CollectionBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CollectionBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CollectionBTN_Click);
				bool flag = this._CollectionBTN != null;
				if (flag)
				{
					this._CollectionBTN.Click -= value2;
				}
				this._CollectionBTN = value;
				flag = (this._CollectionBTN != null);
				if (flag)
				{
					this._CollectionBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000571 RID: 1393 RVA: 0x00033160 File Offset: 0x00031360
		// (set) Token: 0x06000572 RID: 1394 RVA: 0x00033178 File Offset: 0x00031378
		internal virtual Panel CustomerDetailsPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CustomerDetailsPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				PaintEventHandler value2 = new PaintEventHandler(this.Panel1_Paint);
				bool flag = this._CustomerDetailsPanel != null;
				if (flag)
				{
					this._CustomerDetailsPanel.Paint -= value2;
				}
				this._CustomerDetailsPanel = value;
				flag = (this._CustomerDetailsPanel != null);
				if (flag)
				{
					this._CustomerDetailsPanel.Paint += value2;
				}
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000573 RID: 1395 RVA: 0x000331D8 File Offset: 0x000313D8
		// (set) Token: 0x06000574 RID: 1396 RVA: 0x000331F0 File Offset: 0x000313F0
		internal virtual TextBox CustomerCityTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CustomerCityTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CustomerCityTextBox_focused);
				EventHandler value3 = new EventHandler(this.CustomerCityTextBox_GotFocus);
				bool flag = this._CustomerCityTextBox != null;
				if (flag)
				{
					this._CustomerCityTextBox.Click -= value2;
					this._CustomerCityTextBox.GotFocus -= value3;
				}
				this._CustomerCityTextBox = value;
				flag = (this._CustomerCityTextBox != null);
				if (flag)
				{
					this._CustomerCityTextBox.Click += value2;
					this._CustomerCityTextBox.GotFocus += value3;
				}
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000575 RID: 1397 RVA: 0x00033278 File Offset: 0x00031478
		// (set) Token: 0x06000576 RID: 1398 RVA: 0x00033290 File Offset: 0x00031490
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x06000577 RID: 1399 RVA: 0x000332F0 File Offset: 0x000314F0
		// (set) Token: 0x06000578 RID: 1400 RVA: 0x00003B6E File Offset: 0x00001D6E
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000579 RID: 1401 RVA: 0x00033308 File Offset: 0x00031508
		// (set) Token: 0x0600057A RID: 1402 RVA: 0x00033320 File Offset: 0x00031520
		internal virtual Button FindCustomerBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FindCustomerBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.FindCustomerBTN_Click);
				bool flag = this._FindCustomerBTN != null;
				if (flag)
				{
					this._FindCustomerBTN.Click -= value2;
				}
				this._FindCustomerBTN = value;
				flag = (this._FindCustomerBTN != null);
				if (flag)
				{
					this._FindCustomerBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x0600057B RID: 1403 RVA: 0x00033380 File Offset: 0x00031580
		// (set) Token: 0x0600057C RID: 1404 RVA: 0x00003B78 File Offset: 0x00001D78
		internal virtual Label Label5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label5 = value;
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x0600057D RID: 1405 RVA: 0x00033398 File Offset: 0x00031598
		// (set) Token: 0x0600057E RID: 1406 RVA: 0x000333B0 File Offset: 0x000315B0
		internal virtual Button ShowAddressGoogleMap
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ShowAddressGoogleMap;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click_1);
				bool flag = this._ShowAddressGoogleMap != null;
				if (flag)
				{
					this._ShowAddressGoogleMap.Click -= value2;
				}
				this._ShowAddressGoogleMap = value;
				flag = (this._ShowAddressGoogleMap != null);
				if (flag)
				{
					this._ShowAddressGoogleMap.Click += value2;
				}
			}
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x0600057F RID: 1407 RVA: 0x00033410 File Offset: 0x00031610
		// (set) Token: 0x06000580 RID: 1408 RVA: 0x00033428 File Offset: 0x00031628
		internal virtual ComboBox CustomerSearchComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CustomerSearchComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CustomerSearchComboBox_SelectedIndexChanged);
				KeyPressEventHandler value3 = new KeyPressEventHandler(this.CustomerSearchComboBox_KeyPress);
				EventHandler value4 = new EventHandler(this.CustomerSearchComboBox_TextChanged);
				EventHandler value5 = new EventHandler(this.CustomerSearchComboBox_GotFocus);
				bool flag = this._CustomerSearchComboBox != null;
				if (flag)
				{
					this._CustomerSearchComboBox.SelectedIndexChanged -= value2;
					this._CustomerSearchComboBox.KeyPress -= value3;
					this._CustomerSearchComboBox.TextChanged -= value4;
					this._CustomerSearchComboBox.GotFocus -= value5;
				}
				this._CustomerSearchComboBox = value;
				flag = (this._CustomerSearchComboBox != null);
				if (flag)
				{
					this._CustomerSearchComboBox.SelectedIndexChanged += value2;
					this._CustomerSearchComboBox.KeyPress += value3;
					this._CustomerSearchComboBox.TextChanged += value4;
					this._CustomerSearchComboBox.GotFocus += value5;
				}
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000581 RID: 1409 RVA: 0x00033504 File Offset: 0x00031704
		// (set) Token: 0x06000582 RID: 1410 RVA: 0x0003351C File Offset: 0x0003171C
		internal virtual Button NewAddressBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NewAddressBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NewAddressBTN_Click);
				bool flag = this._NewAddressBTN != null;
				if (flag)
				{
					this._NewAddressBTN.Click -= value2;
				}
				this._NewAddressBTN = value;
				flag = (this._NewAddressBTN != null);
				if (flag)
				{
					this._NewAddressBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000583 RID: 1411 RVA: 0x0003357C File Offset: 0x0003177C
		// (set) Token: 0x06000584 RID: 1412 RVA: 0x00003B82 File Offset: 0x00001D82
		internal virtual Label Label4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label4 = value;
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000585 RID: 1413 RVA: 0x00033594 File Offset: 0x00031794
		// (set) Token: 0x06000586 RID: 1414 RVA: 0x000335AC File Offset: 0x000317AC
		internal virtual TextBox CustomerNoteTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CustomerNoteTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CustomerNoteTextBox_focused);
				EventHandler value3 = new EventHandler(this.CustomerNoteTextBox_GotFocus1);
				bool flag = this._CustomerNoteTextBox != null;
				if (flag)
				{
					this._CustomerNoteTextBox.Click -= value2;
					this._CustomerNoteTextBox.GotFocus -= value3;
				}
				this._CustomerNoteTextBox = value;
				flag = (this._CustomerNoteTextBox != null);
				if (flag)
				{
					this._CustomerNoteTextBox.Click += value2;
					this._CustomerNoteTextBox.GotFocus += value3;
				}
			}
		}

		// Token: 0x17000212 RID: 530
		// (get) Token: 0x06000587 RID: 1415 RVA: 0x00033634 File Offset: 0x00031834
		// (set) Token: 0x06000588 RID: 1416 RVA: 0x0003364C File Offset: 0x0003184C
		internal virtual Button SaveCustomerBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SaveCustomerBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click_2);
				bool flag = this._SaveCustomerBTN != null;
				if (flag)
				{
					this._SaveCustomerBTN.Click -= value2;
				}
				this._SaveCustomerBTN = value;
				flag = (this._SaveCustomerBTN != null);
				if (flag)
				{
					this._SaveCustomerBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000589 RID: 1417 RVA: 0x000336AC File Offset: 0x000318AC
		// (set) Token: 0x0600058A RID: 1418 RVA: 0x000336C4 File Offset: 0x000318C4
		internal virtual Button ShowOrderBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ShowOrderBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click_3);
				bool flag = this._ShowOrderBTN != null;
				if (flag)
				{
					this._ShowOrderBTN.Click -= value2;
				}
				this._ShowOrderBTN = value;
				flag = (this._ShowOrderBTN != null);
				if (flag)
				{
					this._ShowOrderBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x0600058B RID: 1419 RVA: 0x00033724 File Offset: 0x00031924
		// (set) Token: 0x0600058C RID: 1420 RVA: 0x00003B8C File Offset: 0x00001D8C
		internal virtual Label NumberOfOrdersLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NumberOfOrdersLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._NumberOfOrdersLBL = value;
			}
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x0003373C File Offset: 0x0003193C
		private void Incoming_Calls_Load(object sender, EventArgs e)
		{
			this.LockSoftwareCheck();
			bool flag = Operators.CompareString(MySettingsProperty.Settings.BusinessName, "Softeware Demo Version", false) == 0;
			if (flag)
			{
				this.CustomerPhoneNumberTextBox.Text = "07777777777";
				this.StreetNameTextBox.Text = "123 London Road";
				this.CustomerCityTextBox.Text = "Manchester";
				this.PostCodeTextBox.Text = "M11AA";
			}
			this.KeyboardPanel.Width = this.Width;
			this.KeyboardPanel.Height = checked(this.Height - this.CustomerDetailsPanel.Height);
			Keyboard.MyKeyboard(this.KeyboardPanel, this.Width, this.KeyboardPanel.Height);
			flag = (this.CustomerSearchComboBox.Items.Count == 0);
			if (flag)
			{
				this.PostCodeTextBox.Focus();
				M_Settings.FocusedTextBoxForKeyboardTyping = this.PostCodeTextBox;
			}
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x0003383C File Offset: 0x00031A3C
		private void LockSoftwareCheck()
		{
			bool flag = Operators.CompareString(this.CustomerPhoneNumberTextBox.Text, MySettingsProperty.Settings.LockSoftwareNumber, false) == 0;
			if (flag)
			{
				bool flag2 = Operators.CompareString(MySettingsProperty.Settings.LockSoftware, "", false) == 0;
				if (flag2)
				{
					MySettingsProperty.Settings.LockSoftware = "yes";
					MySettingsProperty.Settings.Save();
					Application.Exit();
				}
				else
				{
					MySettingsProperty.Settings.LockSoftware = "";
					MySettingsProperty.Settings.Save();
					this.Close();
					Application.Exit();
				}
			}
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x000338D8 File Offset: 0x00031AD8
		private void PostCodeTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.KeyCode.Equals(Keys.Return);
			if (flag)
			{
				PostCode.GetStreetName();
			}
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x00003B96 File Offset: 0x00001D96
		private void Button1_Click(object sender, EventArgs e)
		{
			M_Settings.CursorLocationInTextbox = 0;
			PostCode.GetStreetName();
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x00003BA6 File Offset: 0x00001DA6
		private void ExitBTN_Click(object sender, EventArgs e)
		{
			this.ClearCustomerSearchComboBox();
			this.Close();
			MyProject.Forms.Index.BringToFront();
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x00033908 File Offset: 0x00031B08
		private void DeliveryBYN_Click(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			PostCode.CalculateDeliveryCharge(this.PostCodeTextBox.Text);
			MyProject.Forms.POS_Window.DeliveryChargeTextBox.Text = Strings.Format(M_Calculates.OrderDelivery, "0.00");
			this.UpdateOrderDetails("Delivery");
			bool flag = Customers.CustomerArrayIndex < 0;
			if (flag)
			{
				Customers.AddCustomerInto_Customers_txt_File();
			}
			flag = (Customers.CustomerArrayIndex >= 0);
			if (flag)
			{
				Customers.UpdateCustomerAt_Customers_txt_File(Customers.CustomerArrayIndex);
			}
			this.ClearCustomerSearchComboBox();
			this.Hide();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x000339B4 File Offset: 0x00031BB4
		private void CollectionBTN_Click(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			this.UpdateOrderDetails("Collection");
			bool flag = Customers.CustomerArrayIndex < 0;
			if (flag)
			{
				Customers.AddCustomerInto_Customers_txt_File();
			}
			flag = (Customers.CustomerArrayIndex >= 0);
			if (flag)
			{
				Customers.UpdateCustomerAt_Customers_txt_File(Customers.CustomerArrayIndex);
			}
			this.ClearCustomerSearchComboBox();
			this.Hide();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x00033A28 File Offset: 0x00031C28
		private void UpdateOrderDetails(object OT)
		{
			M_Settings.OrderType = Conversions.ToString(OT);
			M_Settings.CustomerAddress = this.StreetNameTextBox.Text;
			M_Settings.CustomerPostCode = this.PostCodeTextBox.Text;
			M_Settings.CustomerTel = this.CustomerPhoneNumberTextBox.Text;
			M_Settings.CustomerCity = this.CustomerCityTextBox.Text;
			M_Settings.CustomerNote = this.CustomerNoteTextBox.Text;
			M_Settings.TableNumber = "";
			M_Settings.TableNumberAction = "";
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x0000225A File Offset: 0x0000045A
		public void SearchCustomers()
		{
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x00003BC8 File Offset: 0x00001DC8
		private void Panel1_Paint(object sender, PaintEventArgs e)
		{
			this.KeyboardPanel.Height = checked(this.Height - this.CustomerDetailsPanel.Height);
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00003BEA File Offset: 0x00001DEA
		private void CustomerSearchComboBox_GotFocus(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = true;
			this.CustomerSearchComboBox.Text = "";
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x00003C06 File Offset: 0x00001E06
		private void CustomerNoteTextBox_GotFocus1(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.CustomerNoteTextBox;
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00003C1C File Offset: 0x00001E1C
		private void StreetNameTextBox_GotFocus(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.StreetNameTextBox;
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x00003C32 File Offset: 0x00001E32
		private void CustomerCityTextBox_GotFocus(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.CustomerCityTextBox;
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x00003C48 File Offset: 0x00001E48
		private void PostCodeTextBox_GotFocus(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.PostCodeTextBox;
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00003C5E File Offset: 0x00001E5E
		private void CustomerPhoneNumberTextBox_GotFocus(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.CustomerPhoneNumberTextBox;
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x000026F5 File Offset: 0x000008F5
		private void Button6_Click(object sender, EventArgs e)
		{
			Process.Start("osk");
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x00003C74 File Offset: 0x00001E74
		private void StreetNameTextBox_focused(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.StreetNameTextBox;
			M_Settings.CursorLocationInTextbox = M_Settings.FocusedTextBoxForKeyboardTyping.SelectionStart;
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00003C99 File Offset: 0x00001E99
		private void CustomerSearchTextBox_focused(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.CursorLocationInTextbox = M_Settings.FocusedTextBoxForKeyboardTyping.SelectionStart;
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x00003CB3 File Offset: 0x00001EB3
		private void CustomerNoteTextBox_focused(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.CustomerNoteTextBox;
			M_Settings.CursorLocationInTextbox = M_Settings.FocusedTextBoxForKeyboardTyping.SelectionStart;
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00003CD8 File Offset: 0x00001ED8
		private void CustomerCityTextBox_focused(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.CustomerCityTextBox;
			M_Settings.CursorLocationInTextbox = M_Settings.FocusedTextBoxForKeyboardTyping.SelectionStart;
		}

		// Token: 0x060005A2 RID: 1442 RVA: 0x00003CFD File Offset: 0x00001EFD
		private void CustomerPhoneNumberTextBox_focused(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.CustomerPhoneNumberTextBox;
			M_Settings.CursorLocationInTextbox = M_Settings.FocusedTextBoxForKeyboardTyping.SelectionStart;
		}

		// Token: 0x060005A3 RID: 1443 RVA: 0x00003D22 File Offset: 0x00001F22
		private void PostCodeTextBox_focused(object sender, EventArgs e)
		{
			this.FocusedSearchComboBoxForKeyboardTyping = false;
			M_Settings.FocusedTextBoxForKeyboardTyping = this.PostCodeTextBox;
			M_Settings.CursorLocationInTextbox = M_Settings.FocusedTextBoxForKeyboardTyping.SelectionStart;
		}

		// Token: 0x060005A4 RID: 1444 RVA: 0x00033AA8 File Offset: 0x00031CA8
		private void Button2_Click(object sender, EventArgs e)
		{
			try
			{
				bool flag = Directory.GetFiles("pc").Length == 0;
				if (flag)
				{
					MessageBox.Show("The postcode finder does not function in the demo version." + Environment.NewLine + "If you have purchased a license, please contact our support through WhatsApp to activate it.");
				}
				else
				{
					PostCode.GetStreetName();
					flag = (Operators.CompareString(M_Settings.FocusedTextBoxForKeyboardTyping.Name, "StreetNameTextBox", false) == 0);
					if (flag)
					{
						M_Settings.CursorLocationInTextbox = 0;
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x00003D47 File Offset: 0x00001F47
		private void FindCustomerBTN_Click(object sender, EventArgs e)
		{
			Customers.CustomerMultiAddresses.Clear();
			Customers.CustomerMultiAddressesAllInfo.Clear();
			this.CustomerSearchComboBox.Items.Clear();
			Customers.FindCustomer(this.CustomerSearchComboBox.Text);
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00003D83 File Offset: 0x00001F83
		private void BadMarkBTN_Click(object sender, EventArgs e)
		{
			M_Settings.CustomerType = "Bad";
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00003D91 File Offset: 0x00001F91
		private void RemoveBadMarkBTN_Click(object sender, EventArgs e)
		{
			M_Settings.CustomerType = "";
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x00033B34 File Offset: 0x00031D34
		private void Button1_Click_1(object sender, EventArgs e)
		{
			string text = "https://www.google.com/maps?saddr=";
			text += M_Settings.ShopAddress.Replace(" ", "+");
			text += "&daddr=";
			bool flag = Operators.CompareString(this.StreetNameTextBox.Text, "", false) != 0;
			if (flag)
			{
				text = text + this.StreetNameTextBox.Text.Replace(" ", "+") + "+";
			}
			flag = (Operators.CompareString(this.CustomerCityTextBox.Text, "", false) != 0);
			if (flag)
			{
				text = text + this.CustomerCityTextBox.Text.Replace(" ", "+") + "+";
			}
			flag = (Operators.CompareString(this.PostCodeTextBox.Text, "", false) != 0);
			if (flag)
			{
				text += this.PostCodeTextBox.Text.Replace(" ", "+");
			}
			Process.Start(text);
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x0000225A File Offset: 0x0000045A
		private void CustomerSearchComboBox_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0000225A File Offset: 0x0000045A
		private void CustomerSearchComboBox_KeyPress(object sender, KeyPressEventArgs e)
		{
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x00003D9F File Offset: 0x00001F9F
		public void ClearCustomerSearchComboBox()
		{
			M_Settings.CustomerNumberOfOrders = Conversions.ToString(0);
			Customers.CustomerMultiAddresses.Clear();
			Customers.CustomerMultiAddressesAllInfo.Clear();
			this.CustomerSearchComboBox.Items.Clear();
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00033C44 File Offset: 0x00031E44
		private void CustomerSearchComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				int selectedIndex = this.CustomerSearchComboBox.SelectedIndex;
				this.CustomerPhoneNumberTextBox.Text = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					0
				}, null));
				this.StreetNameTextBox.Text = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					1
				}, null));
				this.CustomerCityTextBox.Text = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					2
				}, null));
				this.PostCodeTextBox.Text = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					3
				}, null));
				string text = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					4
				}, null));
				M_Settings.CustomerNumberOfOrders = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					5
				}, null));
				M_Settings.CustomerLastCallDate = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					6
				}, null));
				this.CustomerNoteTextBox.Text = Strings.Trim(Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[selectedIndex], null, "Split", new object[]
				{
					"|"
				}, null, null, null), new object[]
				{
					7
				}, null)));
				Customers.CustomerArrayIndex = Array.IndexOf(Customers.AllCustomersArray, RuntimeHelpers.GetObjectValue(Customers.CustomerMultiAddressesAllInfo[selectedIndex]));
				this.NumberOfOrdersLBL.Text = "Number of previous orders: " + M_Settings.CustomerNumberOfOrders.ToString();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x00033F6C File Offset: 0x0003216C
		private void CustomerPhoneNumberTextBox_TextChanged(object sender, EventArgs e)
		{
			bool flag = this.CustomerPhoneNumberTextBox.Text.Length > 8;
			if (flag)
			{
				this.CollectionBTN.Enabled = true;
				this.DeliveryBTN.Enabled = true;
			}
			else
			{
				this.CollectionBTN.Enabled = false;
				this.DeliveryBTN.Enabled = false;
			}
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x00033FCC File Offset: 0x000321CC
		private void PostCodeTextBox_TextChanged(object sender, EventArgs e)
		{
			bool flag = this.CustomerPhoneNumberTextBox.Text.Length > 8 & this.StreetNameTextBox.Text.Length > 3 & this.PostCodeTextBox.Text.Length > 3;
			if (flag)
			{
				this.DeliveryBTN.Enabled = true;
			}
			else
			{
				this.DeliveryBTN.Enabled = false;
			}
		}

		// Token: 0x060005AF RID: 1455 RVA: 0x00033FCC File Offset: 0x000321CC
		private void StreetNameTextBox_TextChanged(object sender, EventArgs e)
		{
			bool flag = this.CustomerPhoneNumberTextBox.Text.Length > 8 & this.StreetNameTextBox.Text.Length > 3 & this.PostCodeTextBox.Text.Length > 3;
			if (flag)
			{
				this.DeliveryBTN.Enabled = true;
			}
			else
			{
				this.DeliveryBTN.Enabled = false;
			}
		}

		// Token: 0x060005B0 RID: 1456 RVA: 0x00034038 File Offset: 0x00032238
		private void NewAddressBTN_Click(object sender, EventArgs e)
		{
			Customers.CustomerArrayIndex = 0;
			this.StreetNameTextBox.Text = "";
			this.CustomerCityTextBox.Text = "";
			this.PostCodeTextBox.Text = "";
			M_Settings.FocusedTextBoxForKeyboardTyping = this.PostCodeTextBox;
		}

		// Token: 0x060005B1 RID: 1457 RVA: 0x0003408C File Offset: 0x0003228C
		private void Button1_Click_2(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					bool flag = Operators.CompareString(this.CustomerPhoneNumberTextBox.Text, "", false) != 0 & Operators.CompareString(this.PostCodeTextBox.Text, "", false) != 0;
					if (flag)
					{
						string text = this.CustomerPhoneNumberTextBox.Text + "|";
						text = text + this.StreetNameTextBox.Text + "|";
						text = text + this.CustomerCityTextBox.Text + "|";
						text = text + this.PostCodeTextBox.Text + "|";
						text += "|";
						text += "1|";
						text = Conversions.ToString(Operators.AddObject(text, Operators.AddObject(M_Settings.CurrentDate(), "|")));
						text += this.CustomerNoteTextBox.Text;
						Array.Resize<string>(ref Customers.AllCustomersArray, Customers.AllCustomersArray.Count<string>() + 1);
						Customers.AllCustomersArray[Customers.AllCustomersArray.Count<string>() - 1] = text;
						File.WriteAllLines(M_Settings.DataFolder + "\\_Customers.txt", Customers.AllCustomersArray);
						flag = Operators.ConditionalCompareObjectEqual(Online.checkinternet(), "HOHA_PING_IS_OK", false);
						if (flag)
						{
							Online.AddCustomerServer(text);
						}
						this.ClearCustomerSearchComboBox();
						this.Close();
						MyProject.Forms.Index.BringToFront();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x0003422C File Offset: 0x0003242C
		private void Button1_Click_3(object sender, EventArgs e)
		{
			this.ShowOrderBTN.Visible = false;
			M_Settings.CustomerAddress = this.StreetNameTextBox.Text;
			M_Settings.CustomerPostCode = this.PostCodeTextBox.Text;
			M_Settings.CustomerTel = this.CustomerPhoneNumberTextBox.Text;
			M_Settings.CustomerCity = this.CustomerCityTextBox.Text;
			M_Settings.CustomerNote = this.CustomerNoteTextBox.Text;
			M_Settings.OrderNoToEdit = M_Settings.OrderNoToEditAddress;
			PostCode.CalculateDeliveryCharge(this.PostCodeTextBox.Text);
			this.Close();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
			M_Shopping_Cart.BringUpExistingOrderIntoShoppingCart(M_Settings.OrderNoToEdit, 0);
		}

		// Token: 0x0400023B RID: 571
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x0400023C RID: 572
		private IContainer components;

		// Token: 0x0400023D RID: 573
		[AccessedThroughProperty("CustomerPhoneNumberTextBox")]
		private TextBox _CustomerPhoneNumberTextBox;

		// Token: 0x0400023E RID: 574
		[AccessedThroughProperty("CustomerPhoneNumberLabel")]
		private Label _CustomerPhoneNumberLabel;

		// Token: 0x0400023F RID: 575
		[AccessedThroughProperty("StreetNameTextBox")]
		private TextBox _StreetNameTextBox;

		// Token: 0x04000240 RID: 576
		[AccessedThroughProperty("PostCodeTextBox")]
		private TextBox _PostCodeTextBox;

		// Token: 0x04000241 RID: 577
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000242 RID: 578
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x04000243 RID: 579
		[AccessedThroughProperty("KeyboardPanel")]
		private Panel _KeyboardPanel;

		// Token: 0x04000244 RID: 580
		[AccessedThroughProperty("ExitBTN")]
		private Button _ExitBTN;

		// Token: 0x04000245 RID: 581
		[AccessedThroughProperty("DeliveryBTN")]
		private Button _DeliveryBTN;

		// Token: 0x04000246 RID: 582
		[AccessedThroughProperty("CollectionBTN")]
		private Button _CollectionBTN;

		// Token: 0x04000247 RID: 583
		[AccessedThroughProperty("CustomerDetailsPanel")]
		private Panel _CustomerDetailsPanel;

		// Token: 0x04000248 RID: 584
		[AccessedThroughProperty("CustomerCityTextBox")]
		private TextBox _CustomerCityTextBox;

		// Token: 0x04000249 RID: 585
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x0400024A RID: 586
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x0400024B RID: 587
		[AccessedThroughProperty("FindCustomerBTN")]
		private Button _FindCustomerBTN;

		// Token: 0x0400024C RID: 588
		[AccessedThroughProperty("Label5")]
		private Label _Label5;

		// Token: 0x0400024D RID: 589
		[AccessedThroughProperty("ShowAddressGoogleMap")]
		private Button _ShowAddressGoogleMap;

		// Token: 0x0400024E RID: 590
		[AccessedThroughProperty("CustomerSearchComboBox")]
		private ComboBox _CustomerSearchComboBox;

		// Token: 0x0400024F RID: 591
		[AccessedThroughProperty("NewAddressBTN")]
		private Button _NewAddressBTN;

		// Token: 0x04000250 RID: 592
		[AccessedThroughProperty("Label4")]
		private Label _Label4;

		// Token: 0x04000251 RID: 593
		[AccessedThroughProperty("CustomerNoteTextBox")]
		private TextBox _CustomerNoteTextBox;

		// Token: 0x04000252 RID: 594
		[AccessedThroughProperty("SaveCustomerBTN")]
		private Button _SaveCustomerBTN;

		// Token: 0x04000253 RID: 595
		[AccessedThroughProperty("ShowOrderBTN")]
		private Button _ShowOrderBTN;

		// Token: 0x04000254 RID: 596
		[AccessedThroughProperty("NumberOfOrdersLBL")]
		private Label _NumberOfOrdersLBL;

		// Token: 0x04000255 RID: 597
		public bool FocusedSearchComboBoxForKeyboardTyping;
	}
}
