using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000037 RID: 55
	[DesignerGenerated]
	public class Register : Form
	{
		// Token: 0x0600069E RID: 1694 RVA: 0x00041BEC File Offset: 0x0003FDEC
		[DebuggerNonUserCode]
		public Register()
		{
			base.Load += this.Register_Load;
			List<WeakReference> _ENCList = Register.__ENCList;
			lock (_ENCList)
			{
				Register.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x00041C4C File Offset: 0x0003FE4C
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && this.components != null)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x00041C90 File Offset: 0x0003FE90
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.RegisterBTN = new Button();
			this.BNTextbox = new TextBox();
			this.BPCTextbox = new TextBox();
			this.Label1 = new Label();
			this.Label2 = new Label();
			this.Label3 = new Label();
			this.BADDTextBox = new TextBox();
			this.Label4 = new Label();
			this.BCityTextBox = new TextBox();
			this.Label5 = new Label();
			this.BPhoneTextBox = new TextBox();
			this.Button1 = new Button();
			this.Label7 = new Label();
			this.Label8 = new Label();
			this.MOBTextBox = new TextBox();
			this.Label9 = new Label();
			this.Label10 = new Label();
			this.Label11 = new Label();
			this.Label12 = new Label();
			this.Label13 = new Label();
			this.Label14 = new Label();
			this.DownloadPB = new ProgressBar();
			this.WebsiteTextBox = new TextBox();
			this.Label15 = new Label();
			this.Label6 = new Label();
			this.Label16 = new Label();
			this.Label17 = new Label();
			this.EmailTextBox = new TextBox();
			this.Label18 = new Label();
			this.Label19 = new Label();
			base.SuspendLayout();
			this.RegisterBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.RegisterBTN.BackColor = Color.SteelBlue;
			this.RegisterBTN.FlatStyle = FlatStyle.Flat;
			this.RegisterBTN.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.RegisterBTN.ForeColor = Color.Snow;
			Control registerBTN = this.RegisterBTN;
			Point location = new Point(288, 439);
			registerBTN.Location = location;
			this.RegisterBTN.Name = "RegisterBTN";
			Control registerBTN2 = this.RegisterBTN;
			Size size = new Size(138, 43);
			registerBTN2.Size = size;
			this.RegisterBTN.TabIndex = 9;
			this.RegisterBTN.Text = "Save";
			this.RegisterBTN.UseVisualStyleBackColor = false;
			this.BNTextbox.BackColor = Color.FromArgb(244, 244, 244);
			this.BNTextbox.BorderStyle = BorderStyle.FixedSingle;
			this.BNTextbox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.BNTextbox.ForeColor = Color.Black;
			Control bntextbox = this.BNTextbox;
			location = new Point(204, 94);
			bntextbox.Location = location;
			Control bntextbox2 = this.BNTextbox;
			Padding margin = new Padding(8);
			bntextbox2.Margin = margin;
			this.BNTextbox.Name = "BNTextbox";
			Control bntextbox3 = this.BNTextbox;
			size = new Size(222, 26);
			bntextbox3.Size = size;
			this.BNTextbox.TabIndex = 1;
			this.BPCTextbox.BackColor = Color.FromArgb(244, 244, 244);
			this.BPCTextbox.BorderStyle = BorderStyle.FixedSingle;
			this.BPCTextbox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.BPCTextbox.ForeColor = Color.Black;
			Control bpctextbox = this.BPCTextbox;
			location = new Point(204, 223);
			bpctextbox.Location = location;
			Control bpctextbox2 = this.BPCTextbox;
			margin = new Padding(8);
			bpctextbox2.Margin = margin;
			this.BPCTextbox.Name = "BPCTextbox";
			Control bpctextbox3 = this.BPCTextbox;
			size = new Size(222, 26);
			bpctextbox3.Size = size;
			this.BPCTextbox.TabIndex = 4;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.Black;
			Control label = this.Label1;
			location = new Point(72, 96);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(111, 19);
			label2.Size = size;
			this.Label1.TabIndex = 3;
			this.Label1.Text = "Shop's Name";
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label2.ForeColor = Color.Black;
			Control label3 = this.Label2;
			location = new Point(101, 225);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(82, 19);
			label4.Size = size;
			this.Label2.TabIndex = 4;
			this.Label2.Text = "Postcode";
			this.Label3.AutoSize = true;
			this.Label3.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label3.ForeColor = Color.Black;
			Control label5 = this.Label3;
			location = new Point(110, 138);
			label5.Location = location;
			this.Label3.Name = "Label3";
			Control label6 = this.Label3;
			size = new Size(73, 19);
			label6.Size = size;
			this.Label3.TabIndex = 6;
			this.Label3.Text = "Address";
			this.BADDTextBox.BackColor = Color.FromArgb(244, 244, 244);
			this.BADDTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.BADDTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.BADDTextBox.ForeColor = Color.Black;
			Control baddtextBox = this.BADDTextBox;
			location = new Point(204, 136);
			baddtextBox.Location = location;
			Control baddtextBox2 = this.BADDTextBox;
			margin = new Padding(8);
			baddtextBox2.Margin = margin;
			this.BADDTextBox.Name = "BADDTextBox";
			Control baddtextBox3 = this.BADDTextBox;
			size = new Size(222, 26);
			baddtextBox3.Size = size;
			this.BADDTextBox.TabIndex = 2;
			this.Label4.AutoSize = true;
			this.Label4.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label4.ForeColor = Color.Black;
			Control label7 = this.Label4;
			location = new Point(144, 180);
			label7.Location = location;
			this.Label4.Name = "Label4";
			Control label8 = this.Label4;
			size = new Size(39, 19);
			label8.Size = size;
			this.Label4.TabIndex = 8;
			this.Label4.Text = "City";
			this.BCityTextBox.BackColor = Color.FromArgb(244, 244, 244);
			this.BCityTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.BCityTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.BCityTextBox.ForeColor = Color.Black;
			Control bcityTextBox = this.BCityTextBox;
			location = new Point(204, 178);
			bcityTextBox.Location = location;
			Control bcityTextBox2 = this.BCityTextBox;
			margin = new Padding(8);
			bcityTextBox2.Margin = margin;
			this.BCityTextBox.Name = "BCityTextBox";
			Control bcityTextBox3 = this.BCityTextBox;
			size = new Size(222, 26);
			bcityTextBox3.Size = size;
			this.BCityTextBox.TabIndex = 3;
			this.Label5.AutoSize = true;
			this.Label5.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label5.ForeColor = Color.Black;
			Control label9 = this.Label5;
			location = new Point(94, 267);
			label9.Location = location;
			this.Label5.Name = "Label5";
			Control label10 = this.Label5;
			size = new Size(89, 19);
			label10.Size = size;
			this.Label5.TabIndex = 10;
			this.Label5.Text = "Shop's Tel";
			this.BPhoneTextBox.BackColor = Color.FromArgb(244, 244, 244);
			this.BPhoneTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.BPhoneTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.BPhoneTextBox.ForeColor = Color.Black;
			Control bphoneTextBox = this.BPhoneTextBox;
			location = new Point(204, 265);
			bphoneTextBox.Location = location;
			Control bphoneTextBox2 = this.BPhoneTextBox;
			margin = new Padding(8);
			bphoneTextBox2.Margin = margin;
			this.BPhoneTextBox.Name = "BPhoneTextBox";
			Control bphoneTextBox3 = this.BPhoneTextBox;
			size = new Size(222, 26);
			bphoneTextBox3.Size = size;
			this.BPhoneTextBox.TabIndex = 5;
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button1.BackColor = Color.Crimson;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 12f, FontStyle.Bold);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(70, 439);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			size = new Size(138, 43);
			button2.Size = size;
			this.Button1.TabIndex = 10;
			this.Button1.Text = "Exit";
			this.Button1.UseVisualStyleBackColor = false;
			this.Label7.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.Label7.AutoSize = true;
			this.Label7.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label7.ForeColor = Color.Black;
			Control label11 = this.Label7;
			location = new Point(55, 22);
			label11.Location = location;
			this.Label7.Name = "Label7";
			Control label12 = this.Label7;
			size = new Size(371, 27);
			label12.Size = size;
			this.Label7.TabIndex = 13;
			this.Label7.Text = "Please fill in all required fields (  )";
			this.Label7.TextAlign = ContentAlignment.TopCenter;
			this.Label8.AutoSize = true;
			this.Label8.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label8.ForeColor = Color.Black;
			Control label13 = this.Label8;
			location = new Point(12, 309);
			label13.Location = location;
			this.Label8.Name = "Label8";
			Control label14 = this.Label8;
			size = new Size(171, 19);
			label14.Size = size;
			this.Label8.TabIndex = 15;
			this.Label8.Text = "Shop Owner's Mobile";
			this.MOBTextBox.BackColor = Color.FromArgb(244, 244, 244);
			this.MOBTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.MOBTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.MOBTextBox.ForeColor = Color.Black;
			Control mobtextBox = this.MOBTextBox;
			location = new Point(204, 307);
			mobtextBox.Location = location;
			Control mobtextBox2 = this.MOBTextBox;
			margin = new Padding(8);
			mobtextBox2.Margin = margin;
			this.MOBTextBox.Name = "MOBTextBox";
			Control mobtextBox3 = this.MOBTextBox;
			size = new Size(222, 26);
			mobtextBox3.Size = size;
			this.MOBTextBox.TabIndex = 6;
			this.Label9.AutoSize = true;
			this.Label9.Font = new Font("Arial Black", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label9.ForeColor = Color.Crimson;
			Control label15 = this.Label9;
			location = new Point(182, 97);
			label15.Location = location;
			this.Label9.Name = "Label9";
			Control label16 = this.Label9;
			size = new Size(19, 23);
			label16.Size = size;
			this.Label9.TabIndex = 16;
			this.Label9.Text = "*";
			this.Label10.AutoSize = true;
			this.Label10.Font = new Font("Arial Black", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label10.ForeColor = Color.Crimson;
			Control label17 = this.Label10;
			location = new Point(182, 139);
			label17.Location = location;
			this.Label10.Name = "Label10";
			Control label18 = this.Label10;
			size = new Size(19, 23);
			label18.Size = size;
			this.Label10.TabIndex = 17;
			this.Label10.Text = "*";
			this.Label11.AutoSize = true;
			this.Label11.Font = new Font("Arial Black", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label11.ForeColor = Color.Crimson;
			Control label19 = this.Label11;
			location = new Point(182, 181);
			label19.Location = location;
			this.Label11.Name = "Label11";
			Control label20 = this.Label11;
			size = new Size(19, 23);
			label20.Size = size;
			this.Label11.TabIndex = 18;
			this.Label11.Text = "*";
			this.Label12.AutoSize = true;
			this.Label12.Font = new Font("Arial Black", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label12.ForeColor = Color.Crimson;
			Control label21 = this.Label12;
			location = new Point(182, 226);
			label21.Location = location;
			this.Label12.Name = "Label12";
			Control label22 = this.Label12;
			size = new Size(19, 23);
			label22.Size = size;
			this.Label12.TabIndex = 19;
			this.Label12.Text = "*";
			this.Label13.AutoSize = true;
			this.Label13.Font = new Font("Arial Black", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label13.ForeColor = Color.Crimson;
			Control label23 = this.Label13;
			location = new Point(182, 268);
			label23.Location = location;
			this.Label13.Name = "Label13";
			Control label24 = this.Label13;
			size = new Size(19, 23);
			label24.Size = size;
			this.Label13.TabIndex = 20;
			this.Label13.Text = "*";
			this.Label14.AutoSize = true;
			this.Label14.Font = new Font("Arial Black", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label14.ForeColor = Color.Crimson;
			Control label25 = this.Label14;
			location = new Point(182, 310);
			label25.Location = location;
			this.Label14.Name = "Label14";
			Control label26 = this.Label14;
			size = new Size(19, 23);
			label26.Size = size;
			this.Label14.TabIndex = 21;
			this.Label14.Text = "*";
			this.DownloadPB.Dock = DockStyle.Bottom;
			Control downloadPB = this.DownloadPB;
			location = new Point(0, 508);
			downloadPB.Location = location;
			this.DownloadPB.Name = "DownloadPB";
			Control downloadPB2 = this.DownloadPB;
			size = new Size(477, 10);
			downloadPB2.Size = size;
			this.DownloadPB.TabIndex = 22;
			this.DownloadPB.Visible = false;
			this.WebsiteTextBox.BackColor = Color.FromArgb(244, 244, 244);
			this.WebsiteTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.WebsiteTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.WebsiteTextBox.ForeColor = Color.Black;
			Control websiteTextBox = this.WebsiteTextBox;
			location = new Point(204, 387);
			websiteTextBox.Location = location;
			Control websiteTextBox2 = this.WebsiteTextBox;
			margin = new Padding(8);
			websiteTextBox2.Margin = margin;
			this.WebsiteTextBox.Name = "WebsiteTextBox";
			Control websiteTextBox3 = this.WebsiteTextBox;
			size = new Size(222, 26);
			websiteTextBox3.Size = size;
			this.WebsiteTextBox.TabIndex = 8;
			this.Label15.AutoSize = true;
			this.Label15.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label15.ForeColor = Color.Black;
			Control label27 = this.Label15;
			location = new Point(13, 391);
			label27.Location = location;
			this.Label15.Name = "Label15";
			Control label28 = this.Label15;
			size = new Size(124, 19);
			label28.Size = size;
			this.Label15.TabIndex = 24;
			this.Label15.Text = "Website or VAT";
			this.Label6.AutoSize = true;
			this.Label6.Font = new Font("Arial", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label6.ForeColor = Color.Crimson;
			Control label29 = this.Label6;
			location = new Point(136, 391);
			label29.Location = location;
			this.Label6.Name = "Label6";
			Control label30 = this.Label6;
			size = new Size(61, 16);
			label30.Size = size;
			this.Label6.TabIndex = 25;
			this.Label6.Text = "(optional)";
			this.Label16.AutoSize = true;
			this.Label16.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label16.ForeColor = Color.Crimson;
			Control label31 = this.Label16;
			location = new Point(397, 30);
			label31.Location = location;
			this.Label16.Name = "Label16";
			Control label32 = this.Label16;
			size = new Size(17, 22);
			label32.Size = size;
			this.Label16.TabIndex = 26;
			this.Label16.Text = "*";
			this.Label17.AutoSize = true;
			this.Label17.Font = new Font("Arial Black", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label17.ForeColor = Color.Crimson;
			Control label33 = this.Label17;
			location = new Point(182, 349);
			label33.Location = location;
			this.Label17.Name = "Label17";
			Control label34 = this.Label17;
			size = new Size(19, 23);
			label34.Size = size;
			this.Label17.TabIndex = 29;
			this.Label17.Text = "*";
			this.EmailTextBox.BackColor = Color.FromArgb(244, 244, 244);
			this.EmailTextBox.BorderStyle = BorderStyle.FixedSingle;
			this.EmailTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.EmailTextBox.ForeColor = Color.Black;
			Control emailTextBox = this.EmailTextBox;
			location = new Point(204, 346);
			emailTextBox.Location = location;
			Control emailTextBox2 = this.EmailTextBox;
			margin = new Padding(8);
			emailTextBox2.Margin = margin;
			this.EmailTextBox.Name = "EmailTextBox";
			Control emailTextBox3 = this.EmailTextBox;
			size = new Size(222, 26);
			emailTextBox3.Size = size;
			this.EmailTextBox.TabIndex = 7;
			this.Label18.AutoSize = true;
			this.Label18.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label18.ForeColor = Color.Black;
			Control label35 = this.Label18;
			location = new Point(20, 349);
			label35.Location = location;
			this.Label18.Name = "Label18";
			Control label36 = this.Label18;
			size = new Size(163, 19);
			label36.Size = size;
			this.Label18.TabIndex = 28;
			this.Label18.Text = "Shop Owner's Email";
			this.Label19.AutoSize = true;
			this.Label19.Font = new Font("Arial Narrow", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label19.ForeColor = Color.Crimson;
			Control label37 = this.Label19;
			location = new Point(274, 485);
			label37.Location = location;
			this.Label19.Name = "Label19";
			Control label38 = this.Label19;
			size = new Size(167, 20);
			label38.Size = size;
			this.Label19.TabIndex = 30;
			this.Label19.Text = "Internet Connection Needed.";
			this.Label19.Visible = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleDimensions = autoScaleDimensions;
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Gold;
			size = new Size(477, 518);
			base.ClientSize = size;
			base.ControlBox = false;
			base.Controls.Add(this.Label19);
			base.Controls.Add(this.Label17);
			base.Controls.Add(this.EmailTextBox);
			base.Controls.Add(this.Label18);
			base.Controls.Add(this.Label16);
			base.Controls.Add(this.Label6);
			base.Controls.Add(this.WebsiteTextBox);
			base.Controls.Add(this.Label15);
			base.Controls.Add(this.DownloadPB);
			base.Controls.Add(this.Button1);
			base.Controls.Add(this.Label14);
			base.Controls.Add(this.Label7);
			base.Controls.Add(this.RegisterBTN);
			base.Controls.Add(this.BPhoneTextBox);
			base.Controls.Add(this.Label13);
			base.Controls.Add(this.Label4);
			base.Controls.Add(this.Label5);
			base.Controls.Add(this.Label12);
			base.Controls.Add(this.BCityTextBox);
			base.Controls.Add(this.BNTextbox);
			base.Controls.Add(this.Label3);
			base.Controls.Add(this.Label11);
			base.Controls.Add(this.MOBTextBox);
			base.Controls.Add(this.BPCTextbox);
			base.Controls.Add(this.BADDTextBox);
			base.Controls.Add(this.Label10);
			base.Controls.Add(this.Label8);
			base.Controls.Add(this.Label1);
			base.Controls.Add(this.Label2);
			base.Controls.Add(this.Label9);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "Register";
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Software Settings";
			base.TopMost = true;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x060006A1 RID: 1697 RVA: 0x000040C1 File Offset: 0x000022C1
		// (set) Token: 0x060006A2 RID: 1698 RVA: 0x000433C8 File Offset: 0x000415C8
		internal virtual Button RegisterBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._RegisterBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.RegisterBTN_Click);
				if (this._RegisterBTN != null)
				{
					this._RegisterBTN.Click -= value2;
				}
				this._RegisterBTN = value;
				if (this._RegisterBTN != null)
				{
					this._RegisterBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x060006A3 RID: 1699 RVA: 0x000040C9 File Offset: 0x000022C9
		// (set) Token: 0x060006A4 RID: 1700 RVA: 0x000040D1 File Offset: 0x000022D1
		internal virtual TextBox BNTextbox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BNTextbox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BNTextbox = value;
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x060006A5 RID: 1701 RVA: 0x000040DA File Offset: 0x000022DA
		// (set) Token: 0x060006A6 RID: 1702 RVA: 0x000040E2 File Offset: 0x000022E2
		internal virtual TextBox BPCTextbox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BPCTextbox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BPCTextbox = value;
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x060006A7 RID: 1703 RVA: 0x000040EB File Offset: 0x000022EB
		// (set) Token: 0x060006A8 RID: 1704 RVA: 0x000040F3 File Offset: 0x000022F3
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x060006A9 RID: 1705 RVA: 0x000040FC File Offset: 0x000022FC
		// (set) Token: 0x060006AA RID: 1706 RVA: 0x00004104 File Offset: 0x00002304
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x060006AB RID: 1707 RVA: 0x0000410D File Offset: 0x0000230D
		// (set) Token: 0x060006AC RID: 1708 RVA: 0x00004115 File Offset: 0x00002315
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x060006AD RID: 1709 RVA: 0x0000411E File Offset: 0x0000231E
		// (set) Token: 0x060006AE RID: 1710 RVA: 0x00004126 File Offset: 0x00002326
		internal virtual TextBox BADDTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BADDTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BADDTextBox = value;
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x060006AF RID: 1711 RVA: 0x0000412F File Offset: 0x0000232F
		// (set) Token: 0x060006B0 RID: 1712 RVA: 0x00004137 File Offset: 0x00002337
		internal virtual Label Label4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label4 = value;
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x060006B1 RID: 1713 RVA: 0x00004140 File Offset: 0x00002340
		// (set) Token: 0x060006B2 RID: 1714 RVA: 0x00004148 File Offset: 0x00002348
		internal virtual TextBox BCityTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BCityTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BCityTextBox = value;
			}
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x060006B3 RID: 1715 RVA: 0x00004151 File Offset: 0x00002351
		// (set) Token: 0x060006B4 RID: 1716 RVA: 0x00004159 File Offset: 0x00002359
		internal virtual Label Label5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label5 = value;
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x060006B5 RID: 1717 RVA: 0x00004162 File Offset: 0x00002362
		// (set) Token: 0x060006B6 RID: 1718 RVA: 0x0000416A File Offset: 0x0000236A
		internal virtual TextBox BPhoneTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BPhoneTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BPhoneTextBox = value;
			}
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x060006B7 RID: 1719 RVA: 0x00004173 File Offset: 0x00002373
		// (set) Token: 0x060006B8 RID: 1720 RVA: 0x00043418 File Offset: 0x00041618
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				if (this._Button1 != null)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				if (this._Button1 != null)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x060006B9 RID: 1721 RVA: 0x0000417B File Offset: 0x0000237B
		// (set) Token: 0x060006BA RID: 1722 RVA: 0x00004183 File Offset: 0x00002383
		internal virtual Label Label7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label7 = value;
			}
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x060006BB RID: 1723 RVA: 0x0000418C File Offset: 0x0000238C
		// (set) Token: 0x060006BC RID: 1724 RVA: 0x00004194 File Offset: 0x00002394
		internal virtual Label Label8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label8 = value;
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x060006BD RID: 1725 RVA: 0x0000419D File Offset: 0x0000239D
		// (set) Token: 0x060006BE RID: 1726 RVA: 0x000041A5 File Offset: 0x000023A5
		internal virtual TextBox MOBTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MOBTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._MOBTextBox = value;
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x060006BF RID: 1727 RVA: 0x000041AE File Offset: 0x000023AE
		// (set) Token: 0x060006C0 RID: 1728 RVA: 0x000041B6 File Offset: 0x000023B6
		internal virtual Label Label9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label9 = value;
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x060006C1 RID: 1729 RVA: 0x000041BF File Offset: 0x000023BF
		// (set) Token: 0x060006C2 RID: 1730 RVA: 0x000041C7 File Offset: 0x000023C7
		internal virtual Label Label10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label10 = value;
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x060006C3 RID: 1731 RVA: 0x000041D0 File Offset: 0x000023D0
		// (set) Token: 0x060006C4 RID: 1732 RVA: 0x000041D8 File Offset: 0x000023D8
		internal virtual Label Label11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label11 = value;
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x060006C5 RID: 1733 RVA: 0x000041E1 File Offset: 0x000023E1
		// (set) Token: 0x060006C6 RID: 1734 RVA: 0x000041E9 File Offset: 0x000023E9
		internal virtual Label Label12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label12 = value;
			}
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x060006C7 RID: 1735 RVA: 0x000041F2 File Offset: 0x000023F2
		// (set) Token: 0x060006C8 RID: 1736 RVA: 0x000041FA File Offset: 0x000023FA
		internal virtual Label Label13
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label13;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label13 = value;
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x060006C9 RID: 1737 RVA: 0x00004203 File Offset: 0x00002403
		// (set) Token: 0x060006CA RID: 1738 RVA: 0x0000420B File Offset: 0x0000240B
		internal virtual Label Label14
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label14;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label14 = value;
			}
		}

		// Token: 0x17000255 RID: 597
		// (get) Token: 0x060006CB RID: 1739 RVA: 0x00004214 File Offset: 0x00002414
		// (set) Token: 0x060006CC RID: 1740 RVA: 0x0000421C File Offset: 0x0000241C
		internal virtual ProgressBar DownloadPB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DownloadPB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DownloadPB = value;
			}
		}

		// Token: 0x17000256 RID: 598
		// (get) Token: 0x060006CD RID: 1741 RVA: 0x00004225 File Offset: 0x00002425
		// (set) Token: 0x060006CE RID: 1742 RVA: 0x0000422D File Offset: 0x0000242D
		internal virtual TextBox WebsiteTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._WebsiteTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._WebsiteTextBox = value;
			}
		}

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x060006CF RID: 1743 RVA: 0x00004236 File Offset: 0x00002436
		// (set) Token: 0x060006D0 RID: 1744 RVA: 0x0000423E File Offset: 0x0000243E
		internal virtual Label Label15
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label15;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label15 = value;
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x060006D1 RID: 1745 RVA: 0x00004247 File Offset: 0x00002447
		// (set) Token: 0x060006D2 RID: 1746 RVA: 0x0000424F File Offset: 0x0000244F
		internal virtual Label Label6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label6 = value;
			}
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x060006D3 RID: 1747 RVA: 0x00004258 File Offset: 0x00002458
		// (set) Token: 0x060006D4 RID: 1748 RVA: 0x00004260 File Offset: 0x00002460
		internal virtual Label Label16
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label16;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label16 = value;
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x060006D5 RID: 1749 RVA: 0x00004269 File Offset: 0x00002469
		// (set) Token: 0x060006D6 RID: 1750 RVA: 0x00004271 File Offset: 0x00002471
		internal virtual Label Label17
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label17;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label17 = value;
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x060006D7 RID: 1751 RVA: 0x0000427A File Offset: 0x0000247A
		// (set) Token: 0x060006D8 RID: 1752 RVA: 0x00004282 File Offset: 0x00002482
		internal virtual TextBox EmailTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EmailTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._EmailTextBox = value;
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x060006D9 RID: 1753 RVA: 0x0000428B File Offset: 0x0000248B
		// (set) Token: 0x060006DA RID: 1754 RVA: 0x00004293 File Offset: 0x00002493
		internal virtual Label Label18
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label18;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label18 = value;
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x060006DB RID: 1755 RVA: 0x0000429C File Offset: 0x0000249C
		// (set) Token: 0x060006DC RID: 1756 RVA: 0x000042A4 File Offset: 0x000024A4
		internal virtual Label Label19
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label19;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label19 = value;
			}
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x00043468 File Offset: 0x00041668
		private void Register_Load(object sender, EventArgs e)
		{
			if (Operators.ConditionalCompareObjectEqual(Online.checkinternet(), "HOHA_PING_IS_OK", false))
			{
				this.RegisterBTN.Enabled = true;
				this.Label19.Visible = false;
			}
			else
			{
				this.RegisterBTN.Enabled = false;
				this.Label19.Visible = true;
			}
			int num = 0;
			checked
			{
				foreach (string left in File.ReadAllLines("settings.txt"))
				{
					num++;
					if (num == 1 & Operators.CompareString(left, "y", false) == 0)
					{
						MySettingsProperty.Settings.SoftwareType = "ONLINE MODE";
					}
					if (num == 1 & Operators.CompareString(left, "n", false) == 0)
					{
						MySettingsProperty.Settings.SoftwareType = "OFFLINE MODE";
					}
					if (num == 2 & Operators.CompareString(left, "y", false) == 0)
					{
						MySettingsProperty.Settings.PostCodeFinder = "y";
					}
					if (num == 2 & Operators.CompareString(left, "n", false) == 0)
					{
						MySettingsProperty.Settings.PostCodeFinder = "n";
					}
					if (num == 3 & Operators.CompareString(left, "ARTECH AD102", false) == 0)
					{
						MySettingsProperty.Settings.CallerIdEnabled = "yes";
						MySettingsProperty.Settings.CallerIdType = "ARTECH AD102";
						MySettingsProperty.Settings.Save();
						M_Settings.CallerIdType = "ARTECH AD102";
						MyProject.Forms.Index.CallerIdTimer.Start();
						CallerID.LoadCallerId();
					}
					if (num == 3 & Operators.CompareString(left, "n", false) == 0)
					{
						MySettingsProperty.Settings.CallerIdEnabled = "no";
						MySettingsProperty.Settings.CallerIdType = "";
						MySettingsProperty.Settings.Save();
						M_Settings.CallerIdType = "";
					}
				}
				MySettingsProperty.Settings.SoftwareWebsite = "";
				MySettingsProperty.Settings.FTPusername = "";
				MySettingsProperty.Settings.FTPpassword = "Sed2254@";
				MySettingsProperty.Settings.Save();
				if (Operators.ConditionalCompareObjectNotEqual(Online.checkinternet(), "HOHA_PING_IS_OK", false))
				{
					this.RegisterBTN.Enabled = false;
					this.RegisterBTN.Text = "No Internet";
					this.RegisterBTN.Refresh();
				}
			}
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x00043690 File Offset: 0x00041890
		private void RegisterBTN_Click(object sender, EventArgs e)
		{
			if (this.BNTextbox.Text.Length < 2 | this.BADDTextBox.Text.Length < 4 | this.BCityTextBox.Text.Length < 3 | this.BPCTextbox.Text.Length < 5 | this.BPhoneTextBox.Text.Length < 7)
			{
				MessageBox.Show("Please fill in all required fields correctly.");
				return;
			}
			if (Operators.CompareString(this.MOBTextBox.Text.Length.ToString(), "11", false) != 0 | Operators.CompareString(this.MOBTextBox.Text.Substring(0, 2), "07", false) != 0)
			{
				MessageBox.Show("Mobile number is not correct.");
				return;
			}
			this.RegisterBTN.Text = "Please Wait...";
			this.RegisterBTN.Refresh();
			DateTime now = DateAndTime.Now;
			MySettingsProperty.Settings.SoftwareExpiryDate = now.AddDays(14.0).ToString("yyyyMMdd");
			MySettingsProperty.Settings.SoftwareOnlineExpiryDate = now.AddDays(14.0).ToString("yyyyMMdd");
			MySettingsProperty.Settings.Save();
			M_Settings.ShopName = this.BNTextbox.Text;
			M_Settings.ShopPhone = this.BPhoneTextBox.Text;
			M_Settings.ShopAddress = this.BADDTextBox.Text;
			M_Settings.ShopCity = this.BCityTextBox.Text;
			M_Settings.ShopPostCode = this.BPCTextbox.Text;
			M_Settings.OwnerMobile = this.MOBTextBox.Text;
			M_Settings.ShopWebsite = this.WebsiteTextBox.Text;
			MySettingsProperty.Settings.BusinessName = M_Settings.ShopName;
			MySettingsProperty.Settings.BusinessTel = M_Settings.ShopPhone;
			MySettingsProperty.Settings.BusinessAddress = M_Settings.ShopAddress;
			MySettingsProperty.Settings.BusinessCity = M_Settings.ShopCity;
			MySettingsProperty.Settings.BusinessPostcode = M_Settings.ShopPostCode;
			MySettingsProperty.Settings.ShopOwnerMobile = M_Settings.OwnerMobile;
			MySettingsProperty.Settings.WebsiteURL = M_Settings.ShopWebsite;
			MySettingsProperty.Settings.BusinessEmail = this.EmailTextBox.Text;
			MySettingsProperty.Settings.Save();
			try
			{
				if (Operators.ConditionalCompareObjectNotEqual(Online.checkinternet(), "HOHA_PING_IS_OK", false))
				{
					MessageBox.Show("This computer has no internet connection.");
				}
				else
				{
					this.DownloadPB.Visible = true;
					this.DownloadPB.Value = 0;
					string v = string.Concat(new string[]
					{
						M_Settings.ShopAddress,
						" - ",
						M_Settings.ShopCity,
						" - ",
						M_Settings.ShopPostCode
					});
					string text = string.Concat(new string[]
					{
						M_Settings.ShopName,
						"|",
						M_Settings.ShopPhone,
						"|",
						M_Settings.ShopAddress,
						"|",
						M_Settings.ShopCity,
						"|",
						M_Settings.ShopPostCode,
						"|",
						M_Settings.OwnerMobile,
						"|",
						M_Settings.ShopWebsite,
						"|",
						now.AddDays(14.0).ToString("yyyyMMdd"),
						"|",
						now.AddDays(14.0).ToString("yyyyMMdd")
					});
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
					string text2 = Conversions.ToString(Online.postdata(MySettingsProperty.Settings.SoftwareWebsite, "first_time_registration.php", "CheckExistingPartner", M_Settings.ShopName, M_Settings.ShopPostCode, v, M_Settings.OwnerMobile + "," + M_Settings.ShopPhone.Replace(" ", ""), text));
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
					string[] array = text2.Split(new char[]
					{
						'|'
					});
					this.DownloadPB.Value = 10;
					if (Operators.CompareString(array[0], "ExistingPartnersAnotherAccountCreated", false) == 0)
					{
						"partners/" + array[1] + "/data/admin";
						Online.DownloadFile("partners/" + array[1] + "/data/admin", "BusinessInfo.txt", "data\\admin");
						this.DownloadPB.Value = 80;
						MySettingsProperty.Settings.ServerFolderName = array[1];
						MySettingsProperty.Settings.ComputerNo = array[2];
						if (array[3].Length == 8)
						{
							MySettingsProperty.Settings.SoftwareExpiryDate = array[3];
						}
						else
						{
							MySettingsProperty.Settings.LicenseNo = array[3];
						}
						MySettingsProperty.Settings.Save();
						this.DownloadPB.Value = 90;
						Online.AutoMenuDownload();
						this.DownloadPB.Value = 100;
					}
					if (Operators.CompareString(array[0], "PartnersAccountCreated", false) == 0)
					{
						this.CreateAccount(array[1], array[2], text);
					}
					this.RegisterBTN.Text = "Save";
					this.RegisterBTN.Enabled = true;
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
					Online.postdata(MySettingsProperty.Settings.SoftwareWebsite, "first_time_registration.php", "ShopOwnerEmail", MySettingsProperty.Settings.ServerFolderName, this.EmailTextBox.Text, this.MOBTextBox.Text, "", "");
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
					File.Delete("settings.txt");
					Process.Start("HOHA.exe");
					base.Close();
					MyProject.Forms.Index.Close();
				}
			}
			catch (Exception)
			{
				base.Close();
				MyProject.Forms.Index.Close();
			}
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x000042AD File Offset: 0x000024AD
		private void CreateAccount(object R1, object R2, object BusinessInfoText)
		{
			MySettingsProperty.Settings.ServerFolderName = Conversions.ToString(R1);
			MySettingsProperty.Settings.ComputerNo = Conversions.ToString(R2);
			MySettingsProperty.Settings.Save();
			File.WriteAllText("Data\\admin\\BusinessInfo.txt", Conversions.ToString(BusinessInfoText));
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x000038C7 File Offset: 0x00001AC7
		private void Button1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x040002F3 RID: 755
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x040002F4 RID: 756
		private IContainer components;

		// Token: 0x040002F5 RID: 757
		[AccessedThroughProperty("RegisterBTN")]
		private Button _RegisterBTN;

		// Token: 0x040002F6 RID: 758
		[AccessedThroughProperty("BNTextbox")]
		private TextBox _BNTextbox;

		// Token: 0x040002F7 RID: 759
		[AccessedThroughProperty("BPCTextbox")]
		private TextBox _BPCTextbox;

		// Token: 0x040002F8 RID: 760
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x040002F9 RID: 761
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x040002FA RID: 762
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x040002FB RID: 763
		[AccessedThroughProperty("BADDTextBox")]
		private TextBox _BADDTextBox;

		// Token: 0x040002FC RID: 764
		[AccessedThroughProperty("Label4")]
		private Label _Label4;

		// Token: 0x040002FD RID: 765
		[AccessedThroughProperty("BCityTextBox")]
		private TextBox _BCityTextBox;

		// Token: 0x040002FE RID: 766
		[AccessedThroughProperty("Label5")]
		private Label _Label5;

		// Token: 0x040002FF RID: 767
		[AccessedThroughProperty("BPhoneTextBox")]
		private TextBox _BPhoneTextBox;

		// Token: 0x04000300 RID: 768
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000301 RID: 769
		[AccessedThroughProperty("Label7")]
		private Label _Label7;

		// Token: 0x04000302 RID: 770
		[AccessedThroughProperty("Label8")]
		private Label _Label8;

		// Token: 0x04000303 RID: 771
		[AccessedThroughProperty("MOBTextBox")]
		private TextBox _MOBTextBox;

		// Token: 0x04000304 RID: 772
		[AccessedThroughProperty("Label9")]
		private Label _Label9;

		// Token: 0x04000305 RID: 773
		[AccessedThroughProperty("Label10")]
		private Label _Label10;

		// Token: 0x04000306 RID: 774
		[AccessedThroughProperty("Label11")]
		private Label _Label11;

		// Token: 0x04000307 RID: 775
		[AccessedThroughProperty("Label12")]
		private Label _Label12;

		// Token: 0x04000308 RID: 776
		[AccessedThroughProperty("Label13")]
		private Label _Label13;

		// Token: 0x04000309 RID: 777
		[AccessedThroughProperty("Label14")]
		private Label _Label14;

		// Token: 0x0400030A RID: 778
		[AccessedThroughProperty("DownloadPB")]
		private ProgressBar _DownloadPB;

		// Token: 0x0400030B RID: 779
		[AccessedThroughProperty("WebsiteTextBox")]
		private TextBox _WebsiteTextBox;

		// Token: 0x0400030C RID: 780
		[AccessedThroughProperty("Label15")]
		private Label _Label15;

		// Token: 0x0400030D RID: 781
		[AccessedThroughProperty("Label6")]
		private Label _Label6;

		// Token: 0x0400030E RID: 782
		[AccessedThroughProperty("Label16")]
		private Label _Label16;

		// Token: 0x0400030F RID: 783
		[AccessedThroughProperty("Label17")]
		private Label _Label17;

		// Token: 0x04000310 RID: 784
		[AccessedThroughProperty("EmailTextBox")]
		private TextBox _EmailTextBox;

		// Token: 0x04000311 RID: 785
		[AccessedThroughProperty("Label18")]
		private Label _Label18;

		// Token: 0x04000312 RID: 786
		[AccessedThroughProperty("Label19")]
		private Label _Label19;
	}
}
