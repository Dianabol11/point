using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200001F RID: 31
	[DesignerGenerated]
	public class FinalWindowOnComplete : Form
	{
		// Token: 0x06000511 RID: 1297 RVA: 0x0002F08C File Offset: 0x0002D28C
		[DebuggerNonUserCode]
		public FinalWindowOnComplete()
		{
			base.Load += this.FinalWindowOnComplete_Load;
			List<WeakReference> _ENCList = FinalWindowOnComplete.__ENCList;
			lock (_ENCList)
			{
				FinalWindowOnComplete.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x0002F0F8 File Offset: 0x0002D2F8
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x0002F148 File Offset: 0x0002D348
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.ExitCancel = new Button();
			this.FreeFoodsOfferPanel = new Panel();
			this.Button1 = new Button();
			this.SuspendLayout();
			this.ExitCancel.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.ExitCancel.BackColor = Color.Crimson;
			this.ExitCancel.FlatAppearance.BorderColor = Color.White;
			this.ExitCancel.FlatAppearance.BorderSize = 2;
			this.ExitCancel.FlatAppearance.CheckedBackColor = Color.Silver;
			this.ExitCancel.FlatStyle = FlatStyle.Flat;
			this.ExitCancel.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.ExitCancel.ForeColor = Color.White;
			Control exitCancel = this.ExitCancel;
			Point location = new Point(267, 477);
			exitCancel.Location = location;
			this.ExitCancel.Name = "ExitCancel";
			Control exitCancel2 = this.ExitCancel;
			Size size = new Size(129, 40);
			exitCancel2.Size = size;
			this.ExitCancel.TabIndex = 7;
			this.ExitCancel.Text = "Exit";
			this.ExitCancel.UseVisualStyleBackColor = false;
			this.FreeFoodsOfferPanel.BackColor = Color.MidnightBlue;
			this.FreeFoodsOfferPanel.Dock = DockStyle.Top;
			Control freeFoodsOfferPanel = this.FreeFoodsOfferPanel;
			location = new Point(0, 0);
			freeFoodsOfferPanel.Location = location;
			this.FreeFoodsOfferPanel.Name = "FreeFoodsOfferPanel";
			Control freeFoodsOfferPanel2 = this.FreeFoodsOfferPanel;
			size = new Size(406, 469);
			freeFoodsOfferPanel2.Size = size;
			this.FreeFoodsOfferPanel.TabIndex = 8;
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.Button1.BackColor = Color.Orange;
			this.Button1.FlatAppearance.BorderColor = Color.White;
			this.Button1.FlatAppearance.BorderSize = 2;
			this.Button1.FlatAppearance.CheckedBackColor = Color.Silver;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(12, 475);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			size = new Size(173, 40);
			button2.Size = size;
			this.Button1.TabIndex = 9;
			this.Button1.Text = "No Free Offer";
			this.Button1.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.SlateBlue;
			size = new Size(406, 527);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.ExitCancel);
			this.Controls.Add(this.FreeFoodsOfferPanel);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "FinalWindowOnComplete";
			this.ShowIcon = false;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "FinalWindowOnComplete";
			this.TopMost = true;
			this.ResumeLayout(false);
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x06000514 RID: 1300 RVA: 0x0002F4D8 File Offset: 0x0002D6D8
		// (set) Token: 0x06000515 RID: 1301 RVA: 0x0002F4F0 File Offset: 0x0002D6F0
		internal virtual Button ExitCancel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitCancel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ExitCancel_Click);
				bool flag = this._ExitCancel != null;
				if (flag)
				{
					this._ExitCancel.Click -= value2;
				}
				this._ExitCancel = value;
				flag = (this._ExitCancel != null);
				if (flag)
				{
					this._ExitCancel.Click += value2;
				}
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x06000516 RID: 1302 RVA: 0x0002F550 File Offset: 0x0002D750
		// (set) Token: 0x06000517 RID: 1303 RVA: 0x00003A81 File Offset: 0x00001C81
		internal virtual Panel FreeFoodsOfferPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FreeFoodsOfferPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FreeFoodsOfferPanel = value;
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x06000518 RID: 1304 RVA: 0x0002F568 File Offset: 0x0002D768
		// (set) Token: 0x06000519 RID: 1305 RVA: 0x0002F580 File Offset: 0x0002D780
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x0002F5E0 File Offset: 0x0002D7E0
		public void FinalWindowOnComplete_FreeFoodsOffer()
		{
			TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel2 = tableLayoutPanel;
			tableLayoutPanel2.Name = "FreeFoodsOfferTLP";
			tableLayoutPanel2.RowCount = offers.OFFER_FREEFOODS.Split(new char[]
			{
				'#'
			}).Count<string>();
			tableLayoutPanel2.ColumnCount = 1;
			tableLayoutPanel2.Dock = DockStyle.Fill;
			tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel2.AutoSize = true;
			Control control = tableLayoutPanel2;
			Padding margin = new Padding(0);
			control.Margin = margin;
			tableLayoutPanel2.BackColor = ColorTranslator.FromHtml("Gold");
			checked
			{
				tableLayoutPanel2.Height = (int)Math.Round((double)this.FreeFoodsOfferPanel.Height / (double)offers.OFFER_FREEFOODS.Split(new char[]
				{
					'#'
				}).Count<string>());
				this.FreeFoodsOfferPanel.Controls.Add(tableLayoutPanel);
				foreach (string text in offers.OFFER_FREEFOODS.Split(new char[]
				{
					'#'
				}))
				{
					Button button = new Button();
					Button button2 = button;
					button2.Name = text;
					button2.ForeColor = ColorTranslator.FromHtml("#ffffff");
					button2.BackColor = ColorTranslator.FromHtml("#1f79e0");
					button2.Dock = DockStyle.Top;
					button2.FlatStyle = FlatStyle.Popup;
					Control control2 = button2;
					margin = new Padding(0, 0, 0, 0);
					control2.Margin = margin;
					button2.Font = new Font("Century Gothic", 16f, FontStyle.Bold);
					button2.Height = (int)Math.Round((double)this.FreeFoodsOfferPanel.Height / (double)offers.OFFER_FREEFOODS.Split(new char[]
					{
						'#'
					}).Count<string>());
					button2.Text = text;
					this.FreeFoodsOfferPanel.Controls["FreeFoodsOfferTLP"].Controls.Add(button);
					button.Click += this.FoodButtonClick;
				}
			}
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x0002F7F0 File Offset: 0x0002D9F0
		private void FoodButtonClick(object sender, EventArgs e)
		{
			try
			{
				int count = M_Settings.ShoppingCart.Items.Count;
				M_Settings.ShoppingCart.Items.Add(new ListViewItem("OFFER"));
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				NewLateBinding.LateCall(M_Settings.ShoppingCart.Items[count].SubItems, null, "Add", new object[]
				{
					Operators.AddObject("FREE ", NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null))
				}, null, null, null, true);
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].Font = new Font(M_Settings.ShoppingCart.Font, FontStyle.Bold);
				M_Settings.ShoppingCart.TopItem = M_Settings.ShoppingCart.Items[checked(M_Settings.ShoppingCart.Items.Count - 1)];
				M_Settings.ShoppingCart.Refresh();
				M_Calculates.CalculateSubTotal();
				offers.CleanOffer();
			}
			catch (Exception ex)
			{
			}
			MyProject.Forms.Form_Glass.Hide();
			this.Hide();
			MyProject.Forms.POS_Window.FullCompleteOrder();
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x00003A8B File Offset: 0x00001C8B
		private void ExitCancel_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Hide();
			this.Hide();
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x0002F9F8 File Offset: 0x0002DBF8
		private void FinalWindowOnComplete_Load(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Show();
			bool flag = Operators.CompareString(offers.OFFER_FREEFOODS, "", false) != 0;
			if (flag)
			{
				this.FreeFoodsOfferPanel.Show();
			}
			else
			{
				this.FreeFoodsOfferPanel.Hide();
			}
			offers.CleanOffer();
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x00003AA6 File Offset: 0x00001CA6
		private void Button1_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Hide();
			this.Hide();
			MyProject.Forms.POS_Window.FullCompleteOrder();
		}

		// Token: 0x04000220 RID: 544
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000221 RID: 545
		private IContainer components;

		// Token: 0x04000222 RID: 546
		[AccessedThroughProperty("ExitCancel")]
		private Button _ExitCancel;

		// Token: 0x04000223 RID: 547
		[AccessedThroughProperty("FreeFoodsOfferPanel")]
		private Panel _FreeFoodsOfferPanel;

		// Token: 0x04000224 RID: 548
		[AccessedThroughProperty("Button1")]
		private Button _Button1;
	}
}
