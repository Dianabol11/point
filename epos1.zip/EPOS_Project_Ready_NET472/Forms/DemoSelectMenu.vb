using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;
using POS.My;

namespace POS
{
	// Token: 0x0200001C RID: 28
	[DesignerGenerated]
	public class DemoSelectMenu : Form
	{
		// Token: 0x0600049B RID: 1179 RVA: 0x00026C9C File Offset: 0x00024E9C
		[DebuggerNonUserCode]
		public DemoSelectMenu()
		{
			base.Load += this.DemoSelectMenu_Load;
			List<WeakReference> _ENCList = DemoSelectMenu.__ENCList;
			lock (_ENCList)
			{
				DemoSelectMenu.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00026CFC File Offset: 0x00024EFC
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (disposing && this.components != null)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x00026D40 File Offset: 0x00024F40
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Button5 = new Button();
			this.Button4 = new Button();
			this.Label20 = new Label();
			this.Button3 = new Button();
			this.Button2 = new Button();
			this.Button1 = new Button();
			this.Label1 = new Label();
			base.SuspendLayout();
			this.Button5.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button5.BackColor = Color.RoyalBlue;
			this.Button5.FlatStyle = FlatStyle.Flat;
			this.Button5.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button5.ForeColor = Color.Snow;
			Control button = this.Button5;
			Point location = new Point(36, 247);
			button.Location = location;
			this.Button5.Name = "Button5";
			Control button2 = this.Button5;
			Size size = new Size(338, 73);
			button2.Size = size;
			this.Button5.TabIndex = 42;
			this.Button5.Text = "Shisha Bar Menu";
			this.Button5.UseVisualStyleBackColor = false;
			this.Button4.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button4.BackColor = Color.RoyalBlue;
			this.Button4.FlatStyle = FlatStyle.Flat;
			this.Button4.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button4.ForeColor = Color.Snow;
			Control button3 = this.Button4;
			location = new Point(36, 326);
			button3.Location = location;
			this.Button4.Name = "Button4";
			Control button4 = this.Button4;
			size = new Size(338, 73);
			button4.Size = size;
			this.Button4.TabIndex = 41;
			this.Button4.Text = "Coffee Shop Menu";
			this.Button4.UseVisualStyleBackColor = false;
			this.Label20.AutoSize = true;
			this.Label20.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label20.ForeColor = Color.Black;
			Control label = this.Label20;
			location = new Point(61, 21);
			label.Location = location;
			this.Label20.Name = "Label20";
			Control label2 = this.Label20;
			size = new Size(275, 27);
			label2.Size = size;
			this.Label20.TabIndex = 40;
			this.Label20.Text = "Download Sample Menu";
			this.Button3.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button3.BackColor = Color.RoyalBlue;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button3.ForeColor = Color.Snow;
			Control button5 = this.Button3;
			location = new Point(36, 89);
			button5.Location = location;
			this.Button3.Name = "Button3";
			Control button6 = this.Button3;
			size = new Size(337, 73);
			button6.Size = size;
			this.Button3.TabIndex = 39;
			this.Button3.Text = "Takeaway (Pizza - Kebab - Burger) Menu";
			this.Button3.UseVisualStyleBackColor = false;
			this.Button2.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button2.BackColor = Color.RoyalBlue;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button2.ForeColor = Color.Snow;
			Control button7 = this.Button2;
			location = new Point(36, 168);
			button7.Location = location;
			this.Button2.Name = "Button2";
			Control button8 = this.Button2;
			size = new Size(337, 73);
			button8.Size = size;
			this.Button2.TabIndex = 38;
			this.Button2.Text = "Indian Menu";
			this.Button2.UseVisualStyleBackColor = false;
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button1.BackColor = Color.Crimson;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 12f, FontStyle.Bold);
			this.Button1.ForeColor = Color.White;
			Control button9 = this.Button1;
			location = new Point(362, 5);
			button9.Location = location;
			this.Button1.Name = "Button1";
			Control button10 = this.Button1;
			size = new Size(50, 43);
			button10.Size = size;
			this.Button1.TabIndex = 37;
			this.Button1.Text = "X";
			this.Button1.UseVisualStyleBackColor = false;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 12f);
			this.Label1.ForeColor = Color.Crimson;
			Control label3 = this.Label1;
			location = new Point(99, 50);
			label3.Location = location;
			this.Label1.Name = "Label1";
			Control label4 = this.Label1;
			size = new Size(198, 18);
			label4.Size = size;
			this.Label1.TabIndex = 44;
			this.Label1.Text = "You can only use one menu.";
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleDimensions = autoScaleDimensions;
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Gold;
			size = new Size(415, 432);
			base.ClientSize = size;
			base.Controls.Add(this.Label1);
			base.Controls.Add(this.Button5);
			base.Controls.Add(this.Button4);
			base.Controls.Add(this.Label20);
			base.Controls.Add(this.Button3);
			base.Controls.Add(this.Button2);
			base.Controls.Add(this.Button1);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Name = "DemoSelectMenu";
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "DemoSelectMenu";
			base.TopMost = true;
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x0600049E RID: 1182 RVA: 0x0000387D File Offset: 0x00001A7D
		// (set) Token: 0x0600049F RID: 1183 RVA: 0x00027380 File Offset: 0x00025580
		internal virtual Button Button5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click);
				if (this._Button5 != null)
				{
					this._Button5.Click -= value2;
				}
				this._Button5 = value;
				if (this._Button5 != null)
				{
					this._Button5.Click += value2;
				}
			}
		}

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x060004A0 RID: 1184 RVA: 0x00003885 File Offset: 0x00001A85
		// (set) Token: 0x060004A1 RID: 1185 RVA: 0x000273D0 File Offset: 0x000255D0
		internal virtual Button Button4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				if (this._Button4 != null)
				{
					this._Button4.Click -= value2;
				}
				this._Button4 = value;
				if (this._Button4 != null)
				{
					this._Button4.Click += value2;
				}
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x060004A2 RID: 1186 RVA: 0x0000388D File Offset: 0x00001A8D
		// (set) Token: 0x060004A3 RID: 1187 RVA: 0x00003895 File Offset: 0x00001A95
		internal virtual Label Label20
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label20;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label20 = value;
			}
		}

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x060004A4 RID: 1188 RVA: 0x0000389E File Offset: 0x00001A9E
		// (set) Token: 0x060004A5 RID: 1189 RVA: 0x00027420 File Offset: 0x00025620
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				if (this._Button3 != null)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				if (this._Button3 != null)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x060004A6 RID: 1190 RVA: 0x000038A6 File Offset: 0x00001AA6
		// (set) Token: 0x060004A7 RID: 1191 RVA: 0x00027470 File Offset: 0x00025670
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				if (this._Button2 != null)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				if (this._Button2 != null)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x060004A8 RID: 1192 RVA: 0x000038AE File Offset: 0x00001AAE
		// (set) Token: 0x060004A9 RID: 1193 RVA: 0x000274C0 File Offset: 0x000256C0
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				if (this._Button1 != null)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				if (this._Button1 != null)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x060004AA RID: 1194 RVA: 0x000038B6 File Offset: 0x00001AB6
		// (set) Token: 0x060004AB RID: 1195 RVA: 0x000038BE File Offset: 0x00001ABE
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x000038C7 File Offset: 0x00001AC7
		private void Button1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x00027510 File Offset: 0x00025710
		private void SampleMenu(object x)
		{
			Microsoft.VisualBasic.FileIO.FileSystem.RenameDirectory("menu", "menu_d1");
			Microsoft.VisualBasic.FileIO.FileSystem.RenameDirectory(Conversions.ToString(Operators.AddObject("menu", x)), "menu");
			if (Directory.Exists("menucafe"))
			{
				Microsoft.VisualBasic.FileIO.FileSystem.RenameDirectory("menucafe", "menu_d2");
			}
			if (Directory.Exists("menuindian"))
			{
				Microsoft.VisualBasic.FileIO.FileSystem.RenameDirectory("menuindian", "menu_d");
			}
			if (Directory.Exists("menushisha"))
			{
				Microsoft.VisualBasic.FileIO.FileSystem.RenameDirectory("menushisha", "menu_d4");
			}
			if (Directory.Exists("menutakeaway"))
			{
				Microsoft.VisualBasic.FileIO.FileSystem.RenameDirectory("menutakeaway", "menu_d5");
			}
			base.Close();
			MyProject.Forms.Index.Close();
			Process.Start("HOHA.exe");
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x000038CE File Offset: 0x00001ACE
		private void Button3_Click(object sender, EventArgs e)
		{
			this.DemoSoftwareSettings();
			this.SampleMenu("takeaway");
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x000038E1 File Offset: 0x00001AE1
		private void Button2_Click(object sender, EventArgs e)
		{
			this.DemoSoftwareSettings();
			MySettingsProperty.Settings.CategoryRows = "2";
			MySettingsProperty.Settings.Save();
			this.SampleMenu("indian");
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x0000390D File Offset: 0x00001B0D
		private void Button5_Click(object sender, EventArgs e)
		{
			this.DemoSoftwareSettings();
			this.SampleMenu("shisha");
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x00003920 File Offset: 0x00001B20
		private void Button4_Click(object sender, EventArgs e)
		{
			this.DemoSoftwareSettings();
			this.SampleMenu("cafe");
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x00003933 File Offset: 0x00001B33
		private void DemoSelectMenu_Load(object sender, EventArgs e)
		{
			MyProject.Forms.Index.Enabled = false;
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x000275D4 File Offset: 0x000257D4
		private void DemoSoftwareSettings()
		{
			MySettingsProperty.Settings.SoftwareType = "ONLINE MODE";
			MySettingsProperty.Settings.PostCodeFinder = "yes";
			MySettingsProperty.Settings.CallerIdEnabled = "yes";
			MySettingsProperty.Settings.CallerIdType = "ARTECH AD102";
			MySettingsProperty.Settings.SoftwareWebsite = "hoha.co.uk";
			MySettingsProperty.Settings.FTPusername = "";
			MySettingsProperty.Settings.FTPpassword = "";
			string text = Strings.Format(DateTime.Now.AddDays(30.0), "yyyyMMdd");
			MySettingsProperty.Settings.SoftwareExpiryDate = text;
			MySettingsProperty.Settings.SoftwareOnlineExpiryDate = text;
			StreamWriter streamWriter = new StreamWriter("data/admin/BusinessInfo.txt");
			streamWriter.Write("Softeware Demo Version|12345678901|Address|City|Postcode|07777777777|stockportdesign.co.uk/demo|" + text + "|" + text);
			streamWriter.Close();
			M_Settings.ShopName = "Softeware Demo Version";
			M_Settings.ShopPhone = "12345678901";
			M_Settings.ShopAddress = "Shop Address";
			M_Settings.ShopCity = "City";
			M_Settings.ShopPostCode = "Postcode";
			M_Settings.OwnerMobile = "07777777777";
			M_Settings.ShopWebsite = "";
			MySettingsProperty.Settings.BusinessName = M_Settings.ShopName;
			MySettingsProperty.Settings.BusinessTel = M_Settings.ShopPhone;
			MySettingsProperty.Settings.BusinessAddress = M_Settings.ShopAddress;
			MySettingsProperty.Settings.BusinessCity = M_Settings.ShopCity;
			MySettingsProperty.Settings.BusinessPostcode = M_Settings.ShopPostCode;
			MySettingsProperty.Settings.ShopOwnerMobile = M_Settings.OwnerMobile;
			MySettingsProperty.Settings.WebsiteURL = M_Settings.ShopWebsite;
			MySettingsProperty.Settings.BusinessEmail = "";
			MySettingsProperty.Settings.SafeMode = "n";
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x040001C7 RID: 455
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x040001C8 RID: 456
		private IContainer components;

		// Token: 0x040001C9 RID: 457
		[AccessedThroughProperty("Button5")]
		private Button _Button5;

		// Token: 0x040001CA RID: 458
		[AccessedThroughProperty("Button4")]
		private Button _Button4;

		// Token: 0x040001CB RID: 459
		[AccessedThroughProperty("Label20")]
		private Label _Label20;

		// Token: 0x040001CC RID: 460
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x040001CD RID: 461
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x040001CE RID: 462
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x040001CF RID: 463
		[AccessedThroughProperty("Label1")]
		private Label _Label1;
	}
}
