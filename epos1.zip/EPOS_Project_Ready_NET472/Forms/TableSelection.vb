using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000038 RID: 56
	[DesignerGenerated]
	public class TableSelection : Form
	{
		// Token: 0x060006E2 RID: 1762 RVA: 0x00043C54 File Offset: 0x00041E54
		[DebuggerNonUserCode]
		public TableSelection()
		{
			base.Load += this.TableSelection_Load;
			List<WeakReference> _ENCList = TableSelection.__ENCList;
			lock (_ENCList)
			{
				TableSelection.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x00043CC0 File Offset: 0x00041EC0
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x00043D10 File Offset: 0x00041F10
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.ExitBTN = new Button();
			this.SelectTableBTN = new Button();
			this.Button11 = new Button();
			this.Button10 = new Button();
			this.Button9 = new Button();
			this.Button8 = new Button();
			this.Button7 = new Button();
			this.Button6 = new Button();
			this.Button5 = new Button();
			this.Button4 = new Button();
			this.Button3 = new Button();
			this.Button2 = new Button();
			this.Button1 = new Button();
			this.TableNumberTextBox = new TextBox();
			this.Label1 = new Label();
			this.NoOfGuestsTB = new TextBox();
			this.Label2 = new Label();
			this.SuspendLayout();
			this.ExitBTN.BackColor = Color.Crimson;
			this.ExitBTN.FlatStyle = FlatStyle.Flat;
			this.ExitBTN.Font = new Font("Arial", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ExitBTN.ForeColor = Color.White;
			Control exitBTN = this.ExitBTN;
			Point location = new Point(284, 12);
			exitBTN.Location = location;
			this.ExitBTN.Name = "ExitBTN";
			Control exitBTN2 = this.ExitBTN;
			Size size = new Size(40, 40);
			exitBTN2.Size = size;
			this.ExitBTN.TabIndex = 1;
			this.ExitBTN.Text = "X";
			this.ExitBTN.UseVisualStyleBackColor = false;
			this.SelectTableBTN.BackColor = Color.Lime;
			this.SelectTableBTN.FlatStyle = FlatStyle.Flat;
			this.SelectTableBTN.Font = new Font("Arial", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.SelectTableBTN.ForeColor = Color.Black;
			Control selectTableBTN = this.SelectTableBTN;
			location = new Point(12, 522);
			selectTableBTN.Location = location;
			this.SelectTableBTN.Name = "SelectTableBTN";
			Control selectTableBTN2 = this.SelectTableBTN;
			size = new Size(312, 80);
			selectTableBTN2.Size = size;
			this.SelectTableBTN.TabIndex = 30;
			this.SelectTableBTN.Text = "Select Table";
			this.SelectTableBTN.UseVisualStyleBackColor = false;
			this.Button11.BackColor = Color.Crimson;
			this.Button11.FlatStyle = FlatStyle.Flat;
			this.Button11.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button11.ForeColor = Color.White;
			Control button = this.Button11;
			location = new Point(224, 434);
			button.Location = location;
			this.Button11.Name = "Button11";
			Control button2 = this.Button11;
			size = new Size(100, 80);
			button2.Size = size;
			this.Button11.TabIndex = 28;
			this.Button11.Text = "Delete";
			this.Button11.UseVisualStyleBackColor = false;
			this.Button10.BackColor = Color.Gainsboro;
			this.Button10.FlatStyle = FlatStyle.Flat;
			this.Button10.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button3 = this.Button10;
			location = new Point(12, 434);
			button3.Location = location;
			this.Button10.Name = "Button10";
			Control button4 = this.Button10;
			size = new Size(206, 80);
			button4.Size = size;
			this.Button10.TabIndex = 27;
			this.Button10.Text = "0";
			this.Button10.UseVisualStyleBackColor = false;
			this.Button9.BackColor = Color.Gainsboro;
			this.Button9.FlatStyle = FlatStyle.Flat;
			this.Button9.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button5 = this.Button9;
			location = new Point(224, 348);
			button5.Location = location;
			this.Button9.Name = "Button9";
			Control button6 = this.Button9;
			size = new Size(100, 80);
			button6.Size = size;
			this.Button9.TabIndex = 26;
			this.Button9.Text = "9";
			this.Button9.UseVisualStyleBackColor = false;
			this.Button8.BackColor = Color.Gainsboro;
			this.Button8.FlatStyle = FlatStyle.Flat;
			this.Button8.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button7 = this.Button8;
			location = new Point(118, 348);
			button7.Location = location;
			this.Button8.Name = "Button8";
			Control button8 = this.Button8;
			size = new Size(100, 80);
			button8.Size = size;
			this.Button8.TabIndex = 25;
			this.Button8.Text = "8";
			this.Button8.UseVisualStyleBackColor = false;
			this.Button7.BackColor = Color.Gainsboro;
			this.Button7.FlatStyle = FlatStyle.Flat;
			this.Button7.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button9 = this.Button7;
			location = new Point(12, 348);
			button9.Location = location;
			this.Button7.Name = "Button7";
			Control button10 = this.Button7;
			size = new Size(100, 80);
			button10.Size = size;
			this.Button7.TabIndex = 24;
			this.Button7.Text = "7";
			this.Button7.UseVisualStyleBackColor = false;
			this.Button6.BackColor = Color.Gainsboro;
			this.Button6.FlatStyle = FlatStyle.Flat;
			this.Button6.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button11 = this.Button6;
			location = new Point(224, 262);
			button11.Location = location;
			this.Button6.Name = "Button6";
			Control button12 = this.Button6;
			size = new Size(100, 80);
			button12.Size = size;
			this.Button6.TabIndex = 23;
			this.Button6.Text = "6";
			this.Button6.UseVisualStyleBackColor = false;
			this.Button5.BackColor = Color.Gainsboro;
			this.Button5.FlatStyle = FlatStyle.Flat;
			this.Button5.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button13 = this.Button5;
			location = new Point(118, 262);
			button13.Location = location;
			this.Button5.Name = "Button5";
			Control button14 = this.Button5;
			size = new Size(100, 80);
			button14.Size = size;
			this.Button5.TabIndex = 22;
			this.Button5.Text = "5";
			this.Button5.UseVisualStyleBackColor = false;
			this.Button4.BackColor = Color.Gainsboro;
			this.Button4.FlatStyle = FlatStyle.Flat;
			this.Button4.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button15 = this.Button4;
			location = new Point(12, 262);
			button15.Location = location;
			this.Button4.Name = "Button4";
			Control button16 = this.Button4;
			size = new Size(100, 80);
			button16.Size = size;
			this.Button4.TabIndex = 21;
			this.Button4.Text = "4";
			this.Button4.UseVisualStyleBackColor = false;
			this.Button3.BackColor = Color.Gainsboro;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button17 = this.Button3;
			location = new Point(224, 176);
			button17.Location = location;
			this.Button3.Name = "Button3";
			Control button18 = this.Button3;
			size = new Size(100, 80);
			button18.Size = size;
			this.Button3.TabIndex = 20;
			this.Button3.Text = "3";
			this.Button3.UseVisualStyleBackColor = false;
			this.Button2.BackColor = Color.Gainsboro;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button19 = this.Button2;
			location = new Point(118, 176);
			button19.Location = location;
			this.Button2.Name = "Button2";
			Control button20 = this.Button2;
			size = new Size(100, 80);
			button20.Size = size;
			this.Button2.TabIndex = 19;
			this.Button2.Text = "2";
			this.Button2.UseVisualStyleBackColor = false;
			this.Button1.BackColor = Color.Gainsboro;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button21 = this.Button1;
			location = new Point(12, 176);
			button21.Location = location;
			this.Button1.Name = "Button1";
			Control button22 = this.Button1;
			size = new Size(100, 80);
			button22.Size = size;
			this.Button1.TabIndex = 18;
			this.Button1.Text = "1";
			this.Button1.UseVisualStyleBackColor = false;
			this.TableNumberTextBox.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control tableNumberTextBox = this.TableNumberTextBox;
			location = new Point(118, 58);
			tableNumberTextBox.Location = location;
			this.TableNumberTextBox.Name = "TableNumberTextBox";
			this.TableNumberTextBox.ReadOnly = true;
			Control tableNumberTextBox2 = this.TableNumberTextBox;
			size = new Size(206, 39);
			tableNumberTextBox2.Size = size;
			this.TableNumberTextBox.TabIndex = 17;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control label = this.Label1;
			location = new Point(15, 67);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(97, 24);
			label2.Size = size;
			this.Label1.TabIndex = 16;
			this.Label1.Text = "Table No:";
			this.NoOfGuestsTB.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control noOfGuestsTB = this.NoOfGuestsTB;
			location = new Point(205, 113);
			noOfGuestsTB.Location = location;
			this.NoOfGuestsTB.Name = "NoOfGuestsTB";
			this.NoOfGuestsTB.ReadOnly = true;
			Control noOfGuestsTB2 = this.NoOfGuestsTB;
			size = new Size(119, 39);
			noOfGuestsTB2.Size = size;
			this.NoOfGuestsTB.TabIndex = 32;
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Arial", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control label3 = this.Label2;
			location = new Point(15, 122);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(184, 24);
			label4.Size = size;
			this.Label2.TabIndex = 31;
			this.Label2.Text = "Number of Guests:";
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Gold;
			size = new Size(336, 614);
			this.ClientSize = size;
			this.Controls.Add(this.NoOfGuestsTB);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.SelectTableBTN);
			this.Controls.Add(this.Button11);
			this.Controls.Add(this.Button10);
			this.Controls.Add(this.Button9);
			this.Controls.Add(this.Button8);
			this.Controls.Add(this.Button7);
			this.Controls.Add(this.Button6);
			this.Controls.Add(this.Button5);
			this.Controls.Add(this.Button4);
			this.Controls.Add(this.Button3);
			this.Controls.Add(this.Button2);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.TableNumberTextBox);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.ExitBTN);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "TableSelection";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "TableSelection";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x060006E5 RID: 1765 RVA: 0x00044AE0 File Offset: 0x00042CE0
		// (set) Token: 0x060006E6 RID: 1766 RVA: 0x00044AF8 File Offset: 0x00042CF8
		internal virtual Button ExitBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ExitBTN_Click);
				bool flag = this._ExitBTN != null;
				if (flag)
				{
					this._ExitBTN.Click -= value2;
				}
				this._ExitBTN = value;
				flag = (this._ExitBTN != null);
				if (flag)
				{
					this._ExitBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x060006E7 RID: 1767 RVA: 0x00044B58 File Offset: 0x00042D58
		// (set) Token: 0x060006E8 RID: 1768 RVA: 0x00044B70 File Offset: 0x00042D70
		internal virtual Button SelectTableBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SelectTableBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.SelectTableBTN_Click);
				bool flag = this._SelectTableBTN != null;
				if (flag)
				{
					this._SelectTableBTN.Click -= value2;
				}
				this._SelectTableBTN = value;
				flag = (this._SelectTableBTN != null);
				if (flag)
				{
					this._SelectTableBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x060006E9 RID: 1769 RVA: 0x00044BD0 File Offset: 0x00042DD0
		// (set) Token: 0x060006EA RID: 1770 RVA: 0x00044BE8 File Offset: 0x00042DE8
		internal virtual Button Button11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button11_Click);
				bool flag = this._Button11 != null;
				if (flag)
				{
					this._Button11.Click -= value2;
				}
				this._Button11 = value;
				flag = (this._Button11 != null);
				if (flag)
				{
					this._Button11.Click += value2;
				}
			}
		}

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x060006EB RID: 1771 RVA: 0x00044C48 File Offset: 0x00042E48
		// (set) Token: 0x060006EC RID: 1772 RVA: 0x00044C60 File Offset: 0x00042E60
		internal virtual Button Button10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button10_Click);
				bool flag = this._Button10 != null;
				if (flag)
				{
					this._Button10.Click -= value2;
				}
				this._Button10 = value;
				flag = (this._Button10 != null);
				if (flag)
				{
					this._Button10.Click += value2;
				}
			}
		}

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x060006ED RID: 1773 RVA: 0x00044CC0 File Offset: 0x00042EC0
		// (set) Token: 0x060006EE RID: 1774 RVA: 0x00044CD8 File Offset: 0x00042ED8
		internal virtual Button Button9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button9_Click);
				bool flag = this._Button9 != null;
				if (flag)
				{
					this._Button9.Click -= value2;
				}
				this._Button9 = value;
				flag = (this._Button9 != null);
				if (flag)
				{
					this._Button9.Click += value2;
				}
			}
		}

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x060006EF RID: 1775 RVA: 0x00044D38 File Offset: 0x00042F38
		// (set) Token: 0x060006F0 RID: 1776 RVA: 0x00044D50 File Offset: 0x00042F50
		internal virtual Button Button8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button8_Click);
				bool flag = this._Button8 != null;
				if (flag)
				{
					this._Button8.Click -= value2;
				}
				this._Button8 = value;
				flag = (this._Button8 != null);
				if (flag)
				{
					this._Button8.Click += value2;
				}
			}
		}

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x060006F1 RID: 1777 RVA: 0x00044DB0 File Offset: 0x00042FB0
		// (set) Token: 0x060006F2 RID: 1778 RVA: 0x00044DC8 File Offset: 0x00042FC8
		internal virtual Button Button7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button7_Click);
				bool flag = this._Button7 != null;
				if (flag)
				{
					this._Button7.Click -= value2;
				}
				this._Button7 = value;
				flag = (this._Button7 != null);
				if (flag)
				{
					this._Button7.Click += value2;
				}
			}
		}

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x060006F3 RID: 1779 RVA: 0x00044E28 File Offset: 0x00043028
		// (set) Token: 0x060006F4 RID: 1780 RVA: 0x00044E40 File Offset: 0x00043040
		internal virtual Button Button6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button6_Click);
				bool flag = this._Button6 != null;
				if (flag)
				{
					this._Button6.Click -= value2;
				}
				this._Button6 = value;
				flag = (this._Button6 != null);
				if (flag)
				{
					this._Button6.Click += value2;
				}
			}
		}

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x060006F5 RID: 1781 RVA: 0x00044EA0 File Offset: 0x000430A0
		// (set) Token: 0x060006F6 RID: 1782 RVA: 0x00044EB8 File Offset: 0x000430B8
		internal virtual Button Button5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click);
				bool flag = this._Button5 != null;
				if (flag)
				{
					this._Button5.Click -= value2;
				}
				this._Button5 = value;
				flag = (this._Button5 != null);
				if (flag)
				{
					this._Button5.Click += value2;
				}
			}
		}

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x060006F7 RID: 1783 RVA: 0x00044F18 File Offset: 0x00043118
		// (set) Token: 0x060006F8 RID: 1784 RVA: 0x00044F30 File Offset: 0x00043130
		internal virtual Button Button4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				bool flag = this._Button4 != null;
				if (flag)
				{
					this._Button4.Click -= value2;
				}
				this._Button4 = value;
				flag = (this._Button4 != null);
				if (flag)
				{
					this._Button4.Click += value2;
				}
			}
		}

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x060006F9 RID: 1785 RVA: 0x00044F90 File Offset: 0x00043190
		// (set) Token: 0x060006FA RID: 1786 RVA: 0x00044FA8 File Offset: 0x000431A8
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x060006FB RID: 1787 RVA: 0x00045008 File Offset: 0x00043208
		// (set) Token: 0x060006FC RID: 1788 RVA: 0x00045020 File Offset: 0x00043220
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x060006FD RID: 1789 RVA: 0x00045080 File Offset: 0x00043280
		// (set) Token: 0x060006FE RID: 1790 RVA: 0x00045098 File Offset: 0x00043298
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x060006FF RID: 1791 RVA: 0x000450F8 File Offset: 0x000432F8
		// (set) Token: 0x06000700 RID: 1792 RVA: 0x00045110 File Offset: 0x00043310
		internal virtual TextBox TableNumberTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TableNumberTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.TableNumberTextBox_Click);
				bool flag = this._TableNumberTextBox != null;
				if (flag)
				{
					this._TableNumberTextBox.Click -= value2;
				}
				this._TableNumberTextBox = value;
				flag = (this._TableNumberTextBox != null);
				if (flag)
				{
					this._TableNumberTextBox.Click += value2;
				}
			}
		}

		// Token: 0x1700026C RID: 620
		// (get) Token: 0x06000701 RID: 1793 RVA: 0x00045170 File Offset: 0x00043370
		// (set) Token: 0x06000702 RID: 1794 RVA: 0x000042F6 File Offset: 0x000024F6
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x06000703 RID: 1795 RVA: 0x00045188 File Offset: 0x00043388
		// (set) Token: 0x06000704 RID: 1796 RVA: 0x000451A0 File Offset: 0x000433A0
		internal virtual TextBox NoOfGuestsTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfGuestsTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NoOfGuestsTB_Click);
				bool flag = this._NoOfGuestsTB != null;
				if (flag)
				{
					this._NoOfGuestsTB.Click -= value2;
				}
				this._NoOfGuestsTB = value;
				flag = (this._NoOfGuestsTB != null);
				if (flag)
				{
					this._NoOfGuestsTB.Click += value2;
				}
			}
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x06000705 RID: 1797 RVA: 0x00045200 File Offset: 0x00043400
		// (set) Token: 0x06000706 RID: 1798 RVA: 0x00004300 File Offset: 0x00002500
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x06000707 RID: 1799 RVA: 0x00045218 File Offset: 0x00043418
		private void TableSelection_Load(object sender, EventArgs e)
		{
			MyProject.Forms.Index.Enabled = false;
			this.TableNumberTextBox.Text = "";
			this.NoOfGuestsTB.Text = "";
			this.SelectedTextBox = this.TableNumberTextBox;
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x00045268 File Offset: 0x00043468
		private void SelectTableBTN_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.TableNumberTextBox.Text, "", false) == 0;
			if (flag)
			{
				MessageBox.Show("Please enter table number");
			}
			else
			{
				flag = (Conversions.ToInteger(this.TableNumberTextBox.Text) == 0);
				if (flag)
				{
					MessageBox.Show("Table number can not be zero.");
					this.TableNumberTextBox.Text = "";
				}
				else
				{
					M_Settings.TableNumber = Conversions.ToString(Conversions.ToInteger(this.TableNumberTextBox.Text));
					flag = (Operators.CompareString(this.NoOfGuestsTB.Text, "", false) != 0);
					if (flag)
					{
						M_Settings.NumberOfGuests = this.NoOfGuestsTB.Text;
					}
					flag = (Operators.CompareString(this.NoOfGuestsTB.Text, "", false) == 0);
					if (flag)
					{
						M_Settings.NumberOfGuests = "N/A";
					}
					flag = File.Exists(M_Settings.DataFolder + "\\Order_History\\_today\\Table" + this.TableNumberTextBox.Text + ".txt");
					if (flag)
					{
						M_Settings.TableNumberAction = "EditTable";
						flag = (Operators.CompareString(M_Settings.NumberOfGuests, "", false) != 0);
						if (flag)
						{
							string[] source = File.ReadAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\Table" + M_Settings.TableNumber.ToString() + ".txt");
							string[] array = source.Skip(0).ToArray<string>();
							array[0] = "Divider|||||" + M_Settings.NumberOfGuests + " Guests||";
							File.WriteAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\Table" + M_Settings.TableNumber.ToString() + ".txt", array);
						}
						OrderManagment.AddAllTakenTableOrdersIntoShoppingcart();
					}
					else
					{
						M_Settings.TableNumberAction = "AddtoTable";
					}
					MyProject.Forms.POS_Window.POSMessageBoardText.Text = string.Concat(new string[]
					{
						"Table : ",
						M_Settings.TableNumber,
						" - ",
						M_Settings.NumberOfGuests,
						" Guests"
					});
					flag = (Operators.CompareString(M_Settings.NumberOfGuests, "", false) != 0 & Operators.CompareString(M_Settings.TableNumberAction, "AddtoTable", false) == 0);
					if (flag)
					{
						M_Settings.ShoppingCart.Items.Add(new ListViewItem("Divider"));
						M_Settings.ShoppingCart.Items[0].SubItems.Add("");
						M_Settings.ShoppingCart.Items[0].SubItems.Add("");
						M_Settings.ShoppingCart.Items[0].SubItems.Add("");
						M_Settings.ShoppingCart.Items[0].SubItems.Add("");
						M_Settings.ShoppingCart.Items[0].SubItems.Add(M_Settings.NumberOfGuests + " Guests");
						M_Settings.ShoppingCart.Items[0].SubItems.Add("");
						M_Settings.ShoppingCart.Items[0].SubItems.Add("");
					}
					MyProject.Forms.Index.Enabled = true;
					M_Settings.OrderType = "Dine In";
					this.Close();
					M_Settings.ShowForm(MyProject.Forms.POS_Window);
				}
			}
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x000455DC File Offset: 0x000437DC
		private void ReadNumberOfGuests()
		{
			try
			{
				bool flag = File.Exists(M_Settings.DataFolder + "\\Order_History\\_today\\Table" + this.TableNumberTextBox.Text + ".txt");
				if (flag)
				{
					string text = File.ReadAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\Table" + this.TableNumberTextBox.Text + ".txt").First<string>();
					flag = text.Contains("Guests");
					if (flag)
					{
						text = text.Replace(" Guests", "");
						text = text.Replace("Divider", "");
						text = text.Replace("|", "");
						this.NoOfGuestsTB.Text = text;
					}
				}
				else
				{
					this.NoOfGuestsTB.Text = "";
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x0000430A File Offset: 0x0000250A
		private void NoOfGuestsTB_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox = this.NoOfGuestsTB;
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x0000431A File Offset: 0x0000251A
		private void TableNumberTextBox_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox = this.TableNumberTextBox;
		}

		// Token: 0x0600070C RID: 1804 RVA: 0x000456C8 File Offset: 0x000438C8
		private void Button1_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "1";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x0600070D RID: 1805 RVA: 0x00045714 File Offset: 0x00043914
		private void Button2_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "2";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x0600070E RID: 1806 RVA: 0x00045760 File Offset: 0x00043960
		private void Button3_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "3";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x0600070F RID: 1807 RVA: 0x000457AC File Offset: 0x000439AC
		private void Button4_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "4";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x06000710 RID: 1808 RVA: 0x000457F8 File Offset: 0x000439F8
		private void Button5_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "5";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x06000711 RID: 1809 RVA: 0x00045844 File Offset: 0x00043A44
		private void Button6_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "6";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x00045890 File Offset: 0x00043A90
		private void Button7_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "7";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x000458DC File Offset: 0x00043ADC
		private void Button8_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "8";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x00045928 File Offset: 0x00043B28
		private void Button9_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "9";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x00045974 File Offset: 0x00043B74
		private void Button10_Click(object sender, EventArgs e)
		{
			this.SelectedTextBox.Text = this.SelectedTextBox.Text + "0";
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.ReadNumberOfGuests();
			}
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x000459C0 File Offset: 0x00043BC0
		private void Button11_Click(object sender, EventArgs e)
		{
			bool flag = this.SelectedTextBox == this.TableNumberTextBox;
			if (flag)
			{
				this.TableNumberTextBox.Text = "";
				this.NoOfGuestsTB.Text = "";
			}
			flag = (this.SelectedTextBox == this.NoOfGuestsTB);
			if (flag)
			{
				this.NoOfGuestsTB.Text = "";
			}
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x0000432A File Offset: 0x0000252A
		private void ExitBTN_Click(object sender, EventArgs e)
		{
			M_Settings.TableNumber = "";
			MyProject.Forms.Index.Enabled = true;
			this.Close();
		}

		// Token: 0x04000313 RID: 787
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000314 RID: 788
		private IContainer components;

		// Token: 0x04000315 RID: 789
		[AccessedThroughProperty("ExitBTN")]
		private Button _ExitBTN;

		// Token: 0x04000316 RID: 790
		[AccessedThroughProperty("SelectTableBTN")]
		private Button _SelectTableBTN;

		// Token: 0x04000317 RID: 791
		[AccessedThroughProperty("Button11")]
		private Button _Button11;

		// Token: 0x04000318 RID: 792
		[AccessedThroughProperty("Button10")]
		private Button _Button10;

		// Token: 0x04000319 RID: 793
		[AccessedThroughProperty("Button9")]
		private Button _Button9;

		// Token: 0x0400031A RID: 794
		[AccessedThroughProperty("Button8")]
		private Button _Button8;

		// Token: 0x0400031B RID: 795
		[AccessedThroughProperty("Button7")]
		private Button _Button7;

		// Token: 0x0400031C RID: 796
		[AccessedThroughProperty("Button6")]
		private Button _Button6;

		// Token: 0x0400031D RID: 797
		[AccessedThroughProperty("Button5")]
		private Button _Button5;

		// Token: 0x0400031E RID: 798
		[AccessedThroughProperty("Button4")]
		private Button _Button4;

		// Token: 0x0400031F RID: 799
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x04000320 RID: 800
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x04000321 RID: 801
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000322 RID: 802
		[AccessedThroughProperty("TableNumberTextBox")]
		private TextBox _TableNumberTextBox;

		// Token: 0x04000323 RID: 803
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000324 RID: 804
		[AccessedThroughProperty("NoOfGuestsTB")]
		private TextBox _NoOfGuestsTB;

		// Token: 0x04000325 RID: 805
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x04000326 RID: 806
		private TextBox SelectedTextBox;
	}
}
