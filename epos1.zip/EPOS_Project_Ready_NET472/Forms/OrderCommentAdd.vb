using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000031 RID: 49
	[DesignerGenerated]
	public class OrderCommentAdd : Form
	{
		// Token: 0x06000612 RID: 1554 RVA: 0x0003C25C File Offset: 0x0003A45C
		[DebuggerNonUserCode]
		public OrderCommentAdd()
		{
			base.Load += this.OrderCommentAdd_Load;
			List<WeakReference> _ENCList = OrderCommentAdd.__ENCList;
			lock (_ENCList)
			{
				OrderCommentAdd.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x0003C2C8 File Offset: 0x0003A4C8
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x0003C318 File Offset: 0x0003A518
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Panel1 = new Panel();
			this.OrderCommentTextBox = new TextBox();
			this.Label1 = new Label();
			this.Panel2 = new Panel();
			this.OccupiesTablesBTN = new Button();
			this.NoSaleBTN = new Button();
			this.Label2 = new Label();
			this.Panel2.SuspendLayout();
			this.SuspendLayout();
			this.Panel1.Dock = DockStyle.Bottom;
			Control panel = this.Panel1;
			Point location = new Point(0, 121);
			panel.Location = location;
			this.Panel1.Name = "Panel1";
			Control panel2 = this.Panel1;
			Size size = new Size(993, 316);
			panel2.Size = size;
			this.Panel1.TabIndex = 0;
			this.OrderCommentTextBox.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control orderCommentTextBox = this.OrderCommentTextBox;
			location = new Point(116, 58);
			orderCommentTextBox.Location = location;
			this.OrderCommentTextBox.Name = "OrderCommentTextBox";
			Control orderCommentTextBox2 = this.OrderCommentTextBox;
			size = new Size(865, 35);
			orderCommentTextBox2.Size = size;
			this.OrderCommentTextBox.TabIndex = 1;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control label = this.Label1;
			location = new Point(12, 66);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(98, 22);
			label2.Size = size;
			this.Label1.TabIndex = 2;
			this.Label1.Text = "Comment:";
			this.Panel2.Controls.Add(this.OccupiesTablesBTN);
			this.Panel2.Controls.Add(this.NoSaleBTN);
			this.Panel2.Dock = DockStyle.Bottom;
			Control panel3 = this.Panel2;
			location = new Point(0, 437);
			panel3.Location = location;
			this.Panel2.Name = "Panel2";
			Control panel4 = this.Panel2;
			size = new Size(993, 86);
			panel4.Size = size;
			this.Panel2.TabIndex = 3;
			this.OccupiesTablesBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.OccupiesTablesBTN.BackColor = Color.Crimson;
			this.OccupiesTablesBTN.FlatAppearance.BorderColor = Color.White;
			this.OccupiesTablesBTN.FlatStyle = FlatStyle.Flat;
			this.OccupiesTablesBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.OccupiesTablesBTN.ForeColor = Color.Snow;
			Control occupiesTablesBTN = this.OccupiesTablesBTN;
			location = new Point(506, 18);
			occupiesTablesBTN.Location = location;
			this.OccupiesTablesBTN.Name = "OccupiesTablesBTN";
			Control occupiesTablesBTN2 = this.OccupiesTablesBTN;
			size = new Size(220, 56);
			occupiesTablesBTN2.Size = size;
			this.OccupiesTablesBTN.TabIndex = 63;
			this.OccupiesTablesBTN.Text = "Exit";
			this.OccupiesTablesBTN.UseVisualStyleBackColor = false;
			this.NoSaleBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.NoSaleBTN.BackColor = Color.Lime;
			this.NoSaleBTN.FlatAppearance.BorderColor = Color.White;
			this.NoSaleBTN.FlatStyle = FlatStyle.Flat;
			this.NoSaleBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.NoSaleBTN.ForeColor = Color.Black;
			Control noSaleBTN = this.NoSaleBTN;
			location = new Point(761, 18);
			noSaleBTN.Location = location;
			this.NoSaleBTN.Name = "NoSaleBTN";
			Control noSaleBTN2 = this.NoSaleBTN;
			size = new Size(220, 56);
			noSaleBTN2.Size = size;
			this.NoSaleBTN.TabIndex = 62;
			this.NoSaleBTN.Text = "Save";
			this.NoSaleBTN.UseVisualStyleBackColor = false;
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label2.ForeColor = Color.DarkSlateBlue;
			Control label3 = this.Label2;
			location = new Point(272, 22);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(412, 22);
			label4.Size = size;
			this.Label2.TabIndex = 4;
			this.Label2.Text = "Comment will be printed at the buttom of receipt";
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = SystemColors.ActiveCaption;
			size = new Size(993, 523);
			this.ClientSize = size;
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.OrderCommentTextBox);
			this.Controls.Add(this.Panel1);
			this.Controls.Add(this.Panel2);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "OrderCommentAdd";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "OrderComment";
			this.TopMost = true;
			this.Panel2.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000615 RID: 1557 RVA: 0x0003C8DC File Offset: 0x0003AADC
		// (set) Token: 0x06000616 RID: 1558 RVA: 0x00003EA0 File Offset: 0x000020A0
		internal virtual Panel Panel1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Panel1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Panel1 = value;
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x06000617 RID: 1559 RVA: 0x0003C8F4 File Offset: 0x0003AAF4
		// (set) Token: 0x06000618 RID: 1560 RVA: 0x00003EAA File Offset: 0x000020AA
		internal virtual TextBox OrderCommentTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderCommentTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._OrderCommentTextBox = value;
			}
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000619 RID: 1561 RVA: 0x0003C90C File Offset: 0x0003AB0C
		// (set) Token: 0x0600061A RID: 1562 RVA: 0x00003EB4 File Offset: 0x000020B4
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x0600061B RID: 1563 RVA: 0x0003C924 File Offset: 0x0003AB24
		// (set) Token: 0x0600061C RID: 1564 RVA: 0x00003EBE File Offset: 0x000020BE
		internal virtual Panel Panel2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Panel2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Panel2 = value;
			}
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x0600061D RID: 1565 RVA: 0x0003C93C File Offset: 0x0003AB3C
		// (set) Token: 0x0600061E RID: 1566 RVA: 0x0003C954 File Offset: 0x0003AB54
		internal virtual Button OccupiesTablesBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OccupiesTablesBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.OccupiesTablesBTN_Click);
				bool flag = this._OccupiesTablesBTN != null;
				if (flag)
				{
					this._OccupiesTablesBTN.Click -= value2;
				}
				this._OccupiesTablesBTN = value;
				flag = (this._OccupiesTablesBTN != null);
				if (flag)
				{
					this._OccupiesTablesBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x0600061F RID: 1567 RVA: 0x0003C9B4 File Offset: 0x0003ABB4
		// (set) Token: 0x06000620 RID: 1568 RVA: 0x0003C9CC File Offset: 0x0003ABCC
		internal virtual Button NoSaleBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoSaleBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NoSaleBTN_Click);
				bool flag = this._NoSaleBTN != null;
				if (flag)
				{
					this._NoSaleBTN.Click -= value2;
				}
				this._NoSaleBTN = value;
				flag = (this._NoSaleBTN != null);
				if (flag)
				{
					this._NoSaleBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000621 RID: 1569 RVA: 0x0003CA2C File Offset: 0x0003AC2C
		// (set) Token: 0x06000622 RID: 1570 RVA: 0x00003EC8 File Offset: 0x000020C8
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x0003CA44 File Offset: 0x0003AC44
		private void OrderCommentAdd_Load(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Show();
			Keyboard.MyKeyboard(this.Panel1, this.Panel1.Width, this.Panel1.Height);
			M_Settings.FocusedTextBoxForKeyboardTyping = this.OrderCommentTextBox;
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x00003422 File Offset: 0x00001622
		private void OccupiesTablesBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x00003ED2 File Offset: 0x000020D2
		private void NoSaleBTN_Click(object sender, EventArgs e)
		{
			M_Settings.OrderComment = this.OrderCommentTextBox.Text;
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x040002C1 RID: 705
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x040002C2 RID: 706
		private IContainer components;

		// Token: 0x040002C3 RID: 707
		[AccessedThroughProperty("Panel1")]
		private Panel _Panel1;

		// Token: 0x040002C4 RID: 708
		[AccessedThroughProperty("OrderCommentTextBox")]
		private TextBox _OrderCommentTextBox;

		// Token: 0x040002C5 RID: 709
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x040002C6 RID: 710
		[AccessedThroughProperty("Panel2")]
		private Panel _Panel2;

		// Token: 0x040002C7 RID: 711
		[AccessedThroughProperty("OccupiesTablesBTN")]
		private Button _OccupiesTablesBTN;

		// Token: 0x040002C8 RID: 712
		[AccessedThroughProperty("NoSaleBTN")]
		private Button _NoSaleBTN;

		// Token: 0x040002C9 RID: 713
		[AccessedThroughProperty("Label2")]
		private Label _Label2;
	}
}
