using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000017 RID: 23
	[DesignerGenerated]
	public class OccupiedTables : Form
	{
		// Token: 0x060003CC RID: 972 RVA: 0x00020794 File Offset: 0x0001E994
		[DebuggerNonUserCode]
		public OccupiedTables()
		{
			base.Load += this.OccupiedTables_Load;
			List<WeakReference> _ENCList = OccupiedTables.__ENCList;
			lock (_ENCList)
			{
				OccupiedTables.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x060003CD RID: 973 RVA: 0x00020800 File Offset: 0x0001EA00
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060003CE RID: 974 RVA: 0x00020850 File Offset: 0x0001EA50
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.OccupiedTablesFLT = new FlowLayoutPanel();
			this.AllTablesAreFreeLabel = new Label();
			this.ExitBTN = new Button();
			this.OccupiedTablesFLT.SuspendLayout();
			this.SuspendLayout();
			this.OccupiedTablesFLT.AutoScroll = true;
			this.OccupiedTablesFLT.BackColor = SystemColors.GradientActiveCaption;
			this.OccupiedTablesFLT.Controls.Add(this.AllTablesAreFreeLabel);
			this.OccupiedTablesFLT.Dock = DockStyle.Fill;
			Control occupiedTablesFLT = this.OccupiedTablesFLT;
			Point location = new Point(0, 0);
			occupiedTablesFLT.Location = location;
			this.OccupiedTablesFLT.Name = "OccupiedTablesFLT";
			Control occupiedTablesFLT2 = this.OccupiedTablesFLT;
			Size size = new Size(675, 481);
			occupiedTablesFLT2.Size = size;
			this.OccupiedTablesFLT.TabIndex = 0;
			this.AllTablesAreFreeLabel.AutoSize = true;
			this.AllTablesAreFreeLabel.Font = new Font("Arial", 21.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control allTablesAreFreeLabel = this.AllTablesAreFreeLabel;
			location = new Point(3, 0);
			allTablesAreFreeLabel.Location = location;
			this.AllTablesAreFreeLabel.Name = "AllTablesAreFreeLabel";
			Control allTablesAreFreeLabel2 = this.AllTablesAreFreeLabel;
			size = new Size(242, 33);
			allTablesAreFreeLabel2.Size = size;
			this.AllTablesAreFreeLabel.TabIndex = 0;
			this.AllTablesAreFreeLabel.Text = "All tables are free";
			this.ExitBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.ExitBTN.BackColor = Color.FromArgb(178, 1, 1);
			this.ExitBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.ExitBTN.FlatStyle = FlatStyle.Flat;
			this.ExitBTN.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ExitBTN.ForeColor = Color.White;
			Control exitBTN = this.ExitBTN;
			location = new Point(557, 413);
			exitBTN.Location = location;
			this.ExitBTN.Name = "ExitBTN";
			Control exitBTN2 = this.ExitBTN;
			size = new Size(106, 56);
			exitBTN2.Size = size;
			this.ExitBTN.TabIndex = 26;
			this.ExitBTN.Text = "Exit";
			this.ExitBTN.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(675, 481);
			this.ClientSize = size;
			this.Controls.Add(this.ExitBTN);
			this.Controls.Add(this.OccupiedTablesFLT);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "OccupiedTables";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "OccupiedTables";
			this.TopMost = true;
			this.WindowState = FormWindowState.Maximized;
			this.OccupiedTablesFLT.ResumeLayout(false);
			this.OccupiedTablesFLT.PerformLayout();
			this.ResumeLayout(false);
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x060003CF RID: 975 RVA: 0x00020B60 File Offset: 0x0001ED60
		// (set) Token: 0x060003D0 RID: 976 RVA: 0x000031ED File Offset: 0x000013ED
		internal virtual FlowLayoutPanel OccupiedTablesFLT
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OccupiedTablesFLT;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._OccupiedTablesFLT = value;
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x060003D1 RID: 977 RVA: 0x00020B78 File Offset: 0x0001ED78
		// (set) Token: 0x060003D2 RID: 978 RVA: 0x00020B90 File Offset: 0x0001ED90
		internal virtual Button ExitBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._ExitBTN != null;
				if (flag)
				{
					this._ExitBTN.Click -= value2;
				}
				this._ExitBTN = value;
				flag = (this._ExitBTN != null);
				if (flag)
				{
					this._ExitBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x060003D3 RID: 979 RVA: 0x00020BF0 File Offset: 0x0001EDF0
		// (set) Token: 0x060003D4 RID: 980 RVA: 0x000031F7 File Offset: 0x000013F7
		internal virtual Label AllTablesAreFreeLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AllTablesAreFreeLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AllTablesAreFreeLabel = value;
			}
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0000221E File Offset: 0x0000041E
		private void Button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x00020C08 File Offset: 0x0001EE08
		private void OccupiedTables_Load(object sender, EventArgs e)
		{
			string[] files = Directory.GetFiles(M_Settings.DataFolder + "\\Order_History\\_today", "Table*.txt");
			bool flag = files.Length > 0;
			if (flag)
			{
				this.AllTablesAreFreeLabel.Visible = false;
			}
			else
			{
				this.AllTablesAreFreeLabel.Visible = true;
			}
			Array.Sort<string>(files);
			foreach (string text in files)
			{
				text = Path.GetFileName(text);
				text = text.Replace(".txt", "");
				this.CreateOccupiedTableBTN(text);
			}
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00020CA0 File Offset: 0x0001EEA0
		private void CreateOccupiedTableBTN(object TNo)
		{
			Button button = new Button();
			Button button2 = button;
			button2.Name = TNo.ToString();
			button2.BackColor = ColorTranslator.FromHtml("#275078");
			button2.ForeColor = ColorTranslator.FromHtml("#" + M_Settings.Button_TextColor);
			button2.FlatStyle = FlatStyle.Popup;
			Control control = button2;
			Padding margin = new Padding(0, 0, 0, 0);
			control.Margin = margin;
			button2.Font = new Font("Century Gothic", 16f, FontStyle.Regular);
			button2.Height = 80;
			button2.Width = 150;
			button2.Text = TNo.ToString();
			this.OccupiedTablesFLT.Controls.Add(button);
			button.Click += this.OccupieButtonClick;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x00020D70 File Offset: 0x0001EF70
		private void OccupieButtonClick(object sender, EventArgs e)
		{
			string text = Conversions.ToString(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null));
			M_Settings.TableNumber = text.Replace("Table", "");
			M_Settings.TableNumberAction = "CompleteTable";
			OrderManagment.AddAllTakenTableOrdersIntoShoppingcart();
			MyProject.Forms.POS_Window.PaymentMethodTakeawayCollectionDineinPanel.BringToFront();
			this.Close();
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x00020DDC File Offset: 0x0001EFDC
		public object CheckUnpaidTables()
		{
			string result = "";
			try
			{
				string[] files = Directory.GetFiles(M_Settings.DataFolder + "\\Order_History\\_today", "Table*.txt");
				bool flag = files.Length > 0;
				if (flag)
				{
					MessageBox.Show("You have unpaid tables." + Environment.NewLine + "Please click on Occupied Tables and complete all tables.");
				}
				else
				{
					result = "DoExit";
				}
			}
			catch (Exception ex)
			{
			}
			return result;
		}

		// Token: 0x0400016D RID: 365
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x0400016E RID: 366
		private IContainer components;

		// Token: 0x0400016F RID: 367
		[AccessedThroughProperty("OccupiedTablesFLT")]
		private FlowLayoutPanel _OccupiedTablesFLT;

		// Token: 0x04000170 RID: 368
		[AccessedThroughProperty("ExitBTN")]
		private Button _ExitBTN;

		// Token: 0x04000171 RID: 369
		[AccessedThroughProperty("AllTablesAreFreeLabel")]
		private Label _AllTablesAreFreeLabel;
	}
}
