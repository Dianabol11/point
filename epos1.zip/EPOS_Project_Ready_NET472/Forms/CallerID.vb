using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.Compatibility.VB6;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000024 RID: 36
	[StandardModule]
	internal sealed class CallerID
	{
		// Token: 0x060005B9 RID: 1465
		[DllImport("kernel32", CharSet = CharSet.Ansi, EntryPoint = "LoadLibraryA", ExactSpelling = true, SetLastError = true)]
		public static extern int LoadLibrary([MarshalAs(UnmanagedType.VBByRefStr)] ref string lpLibFileName);

		// Token: 0x060005BA RID: 1466
		[DllImport("AD101Device.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern void AD101_InitDevice(int hWnd);

		// Token: 0x060005BB RID: 1467
		[DllImport("AD101Device.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int AD101_GetDevice();

		// Token: 0x060005BC RID: 1468
		[DllImport("AD101Device.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern void AD101_FreeDevice();

		// Token: 0x060005BD RID: 1469
		[DllImport("AD101Device.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int AD101_GetCallerID(int nLine, [MarshalAs(UnmanagedType.VBByRefStr)] ref string szCallerIDBuffer, [MarshalAs(UnmanagedType.VBByRefStr)] ref string szName, [MarshalAs(UnmanagedType.VBByRefStr)] ref string szTime);

		// Token: 0x060005BE RID: 1470 RVA: 0x00034738 File Offset: 0x00032938
		public static void LoadCallerId()
		{
			try
			{
				bool flag = Operators.CompareString(M_Settings.CallerIdType, "ARTECH AD102", false) == 0;
				if (flag)
				{
					string text = MyProject.Application.Info.DirectoryPath + "\\AD101Device.dll";
					CallerID.LoadLibrary(ref text);
					CallerID.AD101_InitDevice(MyProject.Forms.Incoming_Calls.Handle.ToInt32());
					CallerID.AD101_GetDevice();
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x000347C8 File Offset: 0x000329C8
		public static void CallerIdFree(object CallerIdType)
		{
			try
			{
				bool flag = Operators.ConditionalCompareObjectEqual(CallerIdType, "ARTECH AD102", false);
				if (flag)
				{
					CallerID.AD101_FreeDevice();
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x00034814 File Offset: 0x00032A14
		public static void GetCustomerCallerId(object CallerIdType)
		{
			try
			{
				bool flag = Operators.ConditionalCompareObjectEqual(CallerIdType, "ARTECH AD102", false);
				if (flag)
				{
					FixedLengthString fixedLengthString = new FixedLengthString(128);
					FixedLengthString fixedLengthString2 = new FixedLengthString(128);
					FixedLengthString fixedLengthString3 = new FixedLengthString(128);
					FixedLengthString fixedLengthString4 = new FixedLengthString(128);
					fixedLengthString.Value = new string('\0', 128);
					fixedLengthString2.Value = new string('\0', 128);
					fixedLengthString3.Value = new string('\0', 128);
					fixedLengthString4.Value = new string('\0', 128);
					int nLine = 0;
					FixedLengthString fixedLengthString5 = fixedLengthString;
					string value = fixedLengthString5.Value;
					FixedLengthString fixedLengthString6 = fixedLengthString2;
					string value2 = fixedLengthString6.Value;
					FixedLengthString fixedLengthString7 = fixedLengthString3;
					string value3 = fixedLengthString7.Value;
					int num = CallerID.AD101_GetCallerID(nLine, ref value, ref value2, ref value3);
					fixedLengthString7.Value = value3;
					fixedLengthString6.Value = value2;
					fixedLengthString5.Value = value;
					object obj = num;
					M_Settings.CallingCustomerTel = fixedLengthString.Value;
					flag = (Operators.CompareString(M_Settings.CallingCustomerTel, M_Settings.LatestCustomerTel, false) != 0 & Operators.CompareString(fixedLengthString.Value, fixedLengthString4.Value, false) != 0);
					if (flag)
					{
						MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text = fixedLengthString.Value;
						M_Settings.LatestCustomerTel = fixedLengthString.Value;
						CallerID.CheckIfCustomerAlreadyHasOrder("CallerID");
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005C1 RID: 1473 RVA: 0x000349A8 File Offset: 0x00032BA8
		public static void CheckIfCustomerAlreadyHasOrder(object SourceCall)
		{
			MyProject.Forms.Incoming_Calls.Show();
			bool flag = Operators.ConditionalCompareObjectNotEqual(SourceCall, "ListBoxClick", false);
			if (flag)
			{
				ListBox latestCallsListBox = MyProject.Forms.Index.LatestCallsListBox;
				Index VB$t_ref$S1 = MyProject.Forms.Index;
				latestCallsListBox.MouseClick += delegate(object a0, MouseEventArgs a1)
				{
					VB$t_ref$S1.ListBox_ItemClick();
				};
				MyProject.Forms.Index.LatestCallsListBox.Items.Insert(0, string.Concat(new string[]
				{
					DateAndTime.Hour(DateAndTime.Now).ToString(),
					":",
					DateAndTime.Minute(DateAndTime.Now).ToString(),
					" - ",
					MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text
				}));
				flag = (MyProject.Forms.Index.LatestCallsListBox.Items.Count > 0);
				if (flag)
				{
					MyProject.Forms.Index.LatestCallsListBox.Show();
				}
			}
			flag = Operators.ConditionalCompareObjectEqual(SourceCall, "ListBoxClick", false);
			if (flag)
			{
				string text = MyProject.Forms.Index.LatestCallsListBox.SelectedItem.ToString();
				MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text = text.Substring(text.IndexOf(" - ")).Replace(" - ", "");
			}
			flag = File.Exists(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt");
			if (flag)
			{
				string[] array = File.ReadAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt");
				foreach (string text2 in array)
				{
					flag = (Operators.CompareString(text2.Split(new char[]
					{
						'|'
					})[7], MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text, false) == 0);
					if (flag)
					{
						bool flag2 = MyProject.Forms.Incoming_Calls.Visible;
						if (flag2)
						{
							MyProject.Forms.Incoming_Calls.Hide();
						}
						flag2 = !MyProject.Forms.CustomerReCall.Visible;
						if (flag2)
						{
							MyProject.Forms.CustomerReCall.Show();
						}
						MyProject.Forms.CustomerReCall.CustomerReCallTodayOrderListData(text2);
						return;
					}
				}
			}
			OrderManagment.CalculateNextOrderNumber();
			Customers.FindCustomer(MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text);
		}
	}
}
