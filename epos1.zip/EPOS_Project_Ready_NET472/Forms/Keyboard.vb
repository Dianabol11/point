using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000027 RID: 39
	[StandardModule]
	internal sealed class Keyboard
	{
		// Token: 0x060005C9 RID: 1481 RVA: 0x00035420 File Offset: 0x00033620
		public static object MyKeyboard(object KeyboardPlace, object KeyboardPlaceWidth, object KeyboardPlaceHeight)
		{
			string[] array = new string[]
			{
				"1",
				"2",
				"3",
				"4",
				"5",
				"6",
				"7",
				"8",
				"9",
				"0",
				"Delete"
			};
			string[] array2 = new string[]
			{
				"Q",
				"W",
				"E",
				"R",
				"T",
				"Y",
				"U",
				"I",
				"O",
				"P",
				"-"
			};
			string[] array3 = new string[]
			{
				"A",
				"S",
				"D",
				"F",
				"G",
				"H",
				"J",
				"K",
				"L",
				"@",
				"+"
			};
			string[] array4 = new string[]
			{
				"Z",
				"X",
				"C",
				"V",
				" ",
				"B",
				"N",
				"M",
				"."
			};
			TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel2 = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel3 = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel4 = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel5 = tableLayoutPanel;
			tableLayoutPanel5.RowCount = 1;
			tableLayoutPanel5.ColumnCount = 11;
			tableLayoutPanel5.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel5.Dock = DockStyle.Bottom;
			tableLayoutPanel5.Height = Convert.ToInt32(Conversions.ToDecimal(Operators.DivideObject(KeyboardPlaceHeight, 4)));
			tableLayoutPanel5.Width = Conversions.ToInteger(KeyboardPlaceWidth);
			Control control = tableLayoutPanel5;
			Padding margin = new Padding(0);
			control.Margin = margin;
			tableLayoutPanel5.BackColor = Color.LimeGreen;
			TableLayoutPanel tableLayoutPanel6 = tableLayoutPanel2;
			tableLayoutPanel6.RowCount = 1;
			tableLayoutPanel6.ColumnCount = 11;
			tableLayoutPanel6.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel6.Dock = DockStyle.Bottom;
			tableLayoutPanel6.Height = Convert.ToInt32(Conversions.ToDecimal(Operators.DivideObject(KeyboardPlaceHeight, 4)));
			tableLayoutPanel6.Width = Conversions.ToInteger(KeyboardPlaceWidth);
			Control control2 = tableLayoutPanel6;
			margin = new Padding(0);
			control2.Margin = margin;
			tableLayoutPanel6.BackColor = Color.SteelBlue;
			TableLayoutPanel tableLayoutPanel7 = tableLayoutPanel3;
			tableLayoutPanel7.RowCount = 1;
			tableLayoutPanel7.ColumnCount = 11;
			tableLayoutPanel7.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel7.Dock = DockStyle.Bottom;
			tableLayoutPanel7.Height = Convert.ToInt32(Conversions.ToDecimal(Operators.DivideObject(KeyboardPlaceHeight, 4)));
			tableLayoutPanel7.Width = Conversions.ToInteger(KeyboardPlaceWidth);
			Control control3 = tableLayoutPanel7;
			margin = new Padding(0);
			control3.Margin = margin;
			tableLayoutPanel7.BackColor = Color.SteelBlue;
			TableLayoutPanel tableLayoutPanel8 = tableLayoutPanel4;
			tableLayoutPanel8.RowCount = 1;
			tableLayoutPanel8.ColumnCount = 10;
			tableLayoutPanel8.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel8.Dock = DockStyle.Bottom;
			tableLayoutPanel8.Height = Convert.ToInt32(Conversions.ToDecimal(Operators.DivideObject(KeyboardPlaceHeight, 4)));
			tableLayoutPanel8.Width = Conversions.ToInteger(KeyboardPlaceWidth);
			Control control4 = tableLayoutPanel8;
			margin = new Padding(0);
			control4.Margin = margin;
			tableLayoutPanel8.BackColor = Color.SteelBlue;
			object instance = NewLateBinding.LateGet(KeyboardPlace, null, "Controls", new object[0], null, null, null);
			Type type = null;
			string memberName = "Add";
			object[] array5 = new object[]
			{
				tableLayoutPanel
			};
			object[] arguments = array5;
			string[] argumentNames = null;
			Type[] typeArguments = null;
			bool[] array6 = new bool[]
			{
				true
			};
			NewLateBinding.LateCall(instance, type, memberName, arguments, argumentNames, typeArguments, array6, true);
			if (array6[0])
			{
				tableLayoutPanel = (TableLayoutPanel)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array5[0]), typeof(TableLayoutPanel));
			}
			object instance2 = NewLateBinding.LateGet(KeyboardPlace, null, "Controls", new object[0], null, null, null);
			Type type2 = null;
			string memberName2 = "Add";
			object[] array7 = new object[]
			{
				tableLayoutPanel2
			};
			object[] arguments2 = array7;
			string[] argumentNames2 = null;
			Type[] typeArguments2 = null;
			array6 = new bool[]
			{
				true
			};
			NewLateBinding.LateCall(instance2, type2, memberName2, arguments2, argumentNames2, typeArguments2, array6, true);
			if (array6[0])
			{
				tableLayoutPanel2 = (TableLayoutPanel)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array7[0]), typeof(TableLayoutPanel));
			}
			object instance3 = NewLateBinding.LateGet(KeyboardPlace, null, "Controls", new object[0], null, null, null);
			Type type3 = null;
			string memberName3 = "Add";
			array7 = new object[]
			{
				tableLayoutPanel3
			};
			object[] arguments3 = array7;
			string[] argumentNames3 = null;
			Type[] typeArguments3 = null;
			array6 = new bool[]
			{
				true
			};
			NewLateBinding.LateCall(instance3, type3, memberName3, arguments3, argumentNames3, typeArguments3, array6, true);
			if (array6[0])
			{
				tableLayoutPanel3 = (TableLayoutPanel)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array7[0]), typeof(TableLayoutPanel));
			}
			object instance4 = NewLateBinding.LateGet(KeyboardPlace, null, "Controls", new object[0], null, null, null);
			Type type4 = null;
			string memberName4 = "Add";
			array7 = new object[]
			{
				tableLayoutPanel4
			};
			object[] arguments4 = array7;
			string[] argumentNames4 = null;
			Type[] typeArguments4 = null;
			array6 = new bool[]
			{
				true
			};
			NewLateBinding.LateCall(instance4, type4, memberName4, arguments4, argumentNames4, typeArguments4, array6, true);
			if (array6[0])
			{
				tableLayoutPanel4 = (TableLayoutPanel)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array7[0]), typeof(TableLayoutPanel));
			}
			foreach (string t in array)
			{
				Keyboard.Create_BTNs(t, tableLayoutPanel, 11, RuntimeHelpers.GetObjectValue(KeyboardPlaceWidth), RuntimeHelpers.GetObjectValue(KeyboardPlaceHeight));
			}
			foreach (string t2 in array2)
			{
				Keyboard.Create_BTNs(t2, tableLayoutPanel2, 11, RuntimeHelpers.GetObjectValue(KeyboardPlaceWidth), RuntimeHelpers.GetObjectValue(KeyboardPlaceHeight));
			}
			foreach (string t3 in array3)
			{
				Keyboard.Create_BTNs(t3, tableLayoutPanel3, 11, RuntimeHelpers.GetObjectValue(KeyboardPlaceWidth), RuntimeHelpers.GetObjectValue(KeyboardPlaceHeight));
			}
			foreach (string t4 in array4)
			{
				Keyboard.Create_BTNs(t4, tableLayoutPanel4, 11, RuntimeHelpers.GetObjectValue(KeyboardPlaceWidth), RuntimeHelpers.GetObjectValue(KeyboardPlaceHeight));
			}
			return "";
		}

		// Token: 0x060005CA RID: 1482 RVA: 0x00035AC8 File Offset: 0x00033CC8
		private static void Create_BTNs(object T, object TLP, object N, object KeyboardPlaceWidth, object KeyboardPlaceHeight)
		{
			decimal num = Conversions.ToDecimal(Operators.DivideObject(KeyboardPlaceWidth, N));
			bool flag = Operators.ConditionalCompareObjectEqual(T, " ", false);
			if (flag)
			{
				num = decimal.Multiply(num, 3m);
			}
			decimal value = Conversions.ToDecimal(Operators.DivideObject(KeyboardPlaceHeight, 4));
			Button button = new Button();
			Button button2 = button;
			button2.Name = Conversions.ToString(T);
			button2.Dock = DockStyle.Fill;
			button2.FlatStyle = FlatStyle.Popup;
			Control control = button2;
			Padding margin = new Padding(0, 0, 0, 0);
			control.Margin = margin;
			button2.Font = new Font("Arial", 16f, FontStyle.Bold);
			button2.Width = Convert.ToInt32(num);
			button2.Height = Convert.ToInt32(value);
			button2.Text = Conversions.ToString(T);
			flag = Operators.ConditionalCompareObjectEqual(T, "Delete", false);
			if (flag)
			{
				button2.BackColor = Color.Crimson;
				button2.ForeColor = Color.WhiteSmoke;
			}
			object instance = NewLateBinding.LateGet(TLP, null, "Controls", new object[0], null, null, null);
			Type type = null;
			string memberName = "Add";
			object[] array = new object[]
			{
				button
			};
			object[] arguments = array;
			string[] argumentNames = null;
			Type[] typeArguments = null;
			bool[] array2 = new bool[]
			{
				true
			};
			NewLateBinding.LateCall(instance, type, memberName, arguments, argumentNames, typeArguments, array2, true);
			if (array2[0])
			{
				button = (Button)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(Button));
			}
			button.Click += Keyboard.KeyboardButtonClick;
		}

		// Token: 0x060005CB RID: 1483 RVA: 0x00035C3C File Offset: 0x00033E3C
		private static void KeyboardButtonClick(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					bool flag = MyProject.Forms.Incoming_Calls.FocusedSearchComboBoxForKeyboardTyping;
					if (flag)
					{
						bool flag2 = Operators.CompareString(MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text, "", false) == 0;
						if (flag2)
						{
							M_Settings.CursorLocationInTextbox = 0;
						}
						flag2 = (M_Settings.CursorLocationInTextbox < 0);
						if (flag2)
						{
							M_Settings.CursorLocationInTextbox = 0;
						}
						flag2 = (M_Settings.CursorLocationInTextbox > MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text.Length);
						if (flag2)
						{
							M_Settings.CursorLocationInTextbox = MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text.Length;
						}
						flag2 = Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null), "Delete", false);
						if (flag2)
						{
							flag = (M_Settings.CursorLocationInTextbox == 0);
							if (flag)
							{
								M_Settings.CursorLocationInTextbox = 1;
							}
							string text = MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text;
							string str = text.Substring(0, M_Settings.CursorLocationInTextbox - 1);
							string str2 = text.Substring(M_Settings.CursorLocationInTextbox);
							MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text = str + str2;
							M_Settings.CursorLocationInTextbox--;
						}
						flag2 = Operators.ConditionalCompareObjectNotEqual(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null), "Delete", false);
						if (flag2)
						{
							MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text = MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text.Insert(M_Settings.CursorLocationInTextbox, Conversions.ToString(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null)));
							M_Settings.CursorLocationInTextbox++;
						}
					}
					else
					{
						bool flag2 = Operators.CompareString(M_Settings.FocusedTextBoxForKeyboardTyping.Text, "", false) == 0;
						if (flag2)
						{
							M_Settings.CursorLocationInTextbox = 0;
						}
						flag2 = (M_Settings.CursorLocationInTextbox < 0);
						if (flag2)
						{
							M_Settings.CursorLocationInTextbox = 0;
						}
						flag2 = (M_Settings.CursorLocationInTextbox > M_Settings.FocusedTextBoxForKeyboardTyping.Text.Length);
						if (flag2)
						{
							M_Settings.CursorLocationInTextbox = M_Settings.FocusedTextBoxForKeyboardTyping.Text.Length;
						}
						flag2 = Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null), "Delete", false);
						if (flag2)
						{
							flag = (M_Settings.CursorLocationInTextbox == 0);
							if (flag)
							{
								M_Settings.CursorLocationInTextbox = 1;
							}
							string text2 = M_Settings.FocusedTextBoxForKeyboardTyping.Text;
							string str3 = text2.Substring(0, M_Settings.CursorLocationInTextbox - 1);
							string str4 = text2.Substring(M_Settings.CursorLocationInTextbox);
							M_Settings.FocusedTextBoxForKeyboardTyping.Text = str3 + str4;
							M_Settings.CursorLocationInTextbox--;
						}
						flag2 = Operators.ConditionalCompareObjectNotEqual(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null), "Delete", false);
						if (flag2)
						{
							M_Settings.FocusedTextBoxForKeyboardTyping.Text = M_Settings.FocusedTextBoxForKeyboardTyping.Text.Insert(M_Settings.CursorLocationInTextbox, Conversions.ToString(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null)));
							M_Settings.CursorLocationInTextbox++;
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}
	}
}
