using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200002F RID: 47
	[StandardModule]
	internal sealed class M_Shopping_Cart
	{
		// Token: 0x06000604 RID: 1540 RVA: 0x0003A0C4 File Offset: 0x000382C4
		public static object BringUpExistingOrderIntoShoppingCart(object OrderNo, object i)
		{
			M_Settings.OrderNoToEdit = Conversions.ToString(OrderNo);
			string[] array = File.ReadAllLines(Conversions.ToString(Operators.AddObject(Operators.AddObject(M_Settings.DataFolder + "\\Order_History\\_today\\", OrderNo), ".txt")));
			string left = "no";
			foreach (string text in array)
			{
				bool flag = Operators.CompareString(left, "yes", false) == 0;
				if (flag)
				{
					MyProject.Forms.POS_Window.SubTotalTextBox.Text = text.Split(new char[]
					{
						'|'
					})[0];
					MyProject.Forms.POS_Window.DiscountTextBox.Text = text.Split(new char[]
					{
						'|'
					})[1];
					MyProject.Forms.POS_Window.DeliveryChargeTextBox.Text = text.Split(new char[]
					{
						'|'
					})[2];
					MyProject.Forms.POS_Window.Text = text.Split(new char[]
					{
						'|'
					})[3];
					MyProject.Forms.POS_Window.TotalTextBox.Text = text.Split(new char[]
					{
						'|'
					})[4];
					break;
				}
				flag = text.Contains("==");
				if (flag)
				{
					M_Calculates.CalculateSubTotal();
					left = "yes";
				}
				else
				{
					M_Settings.ShoppingCart.Items.Add(new ListViewItem(text.Split(new char[]
					{
						'|'
					})[0]));
					object instance = NewLateBinding.LateGet(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
					{
						RuntimeHelpers.GetObjectValue(i)
					}, null, null, null), null, "SubItems", new object[0], null, null, null);
					Type type = null;
					string memberName = "Add";
					object[] array3 = new object[1];
					object[] array4 = array3;
					int num = 0;
					string[] array5 = text.Split(new char[]
					{
						'|'
					});
					string[] array6 = array5;
					int num2 = 1;
					array4[num] = array6[num2];
					object[] array7 = array3;
					object[] arguments = array7;
					string[] argumentNames = null;
					Type[] typeArguments = null;
					bool[] array8 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(instance, type, memberName, arguments, argumentNames, typeArguments, array8, true);
					if (array8[0])
					{
						array5[num2] = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array7[0]), typeof(string));
					}
					object instance2 = NewLateBinding.LateGet(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
					{
						RuntimeHelpers.GetObjectValue(i)
					}, null, null, null), null, "SubItems", new object[0], null, null, null);
					Type type2 = null;
					string memberName2 = "Add";
					array3 = new object[1];
					object[] array9 = array3;
					int num3 = 0;
					array5 = text.Split(new char[]
					{
						'|'
					});
					string[] array10 = array5;
					num2 = 2;
					array9[num3] = array10[num2];
					object[] array11 = array3;
					object[] arguments2 = array11;
					string[] argumentNames2 = null;
					Type[] typeArguments2 = null;
					array8 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(instance2, type2, memberName2, arguments2, argumentNames2, typeArguments2, array8, true);
					if (array8[0])
					{
						array5[num2] = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array11[0]), typeof(string));
					}
					object instance3 = NewLateBinding.LateGet(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
					{
						RuntimeHelpers.GetObjectValue(i)
					}, null, null, null), null, "SubItems", new object[0], null, null, null);
					Type type3 = null;
					string memberName3 = "Add";
					array3 = new object[1];
					object[] array12 = array3;
					int num4 = 0;
					array5 = text.Split(new char[]
					{
						'|'
					});
					string[] array13 = array5;
					num2 = 3;
					array12[num4] = array13[num2];
					array11 = array3;
					object[] arguments3 = array11;
					string[] argumentNames3 = null;
					Type[] typeArguments3 = null;
					array8 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(instance3, type3, memberName3, arguments3, argumentNames3, typeArguments3, array8, true);
					if (array8[0])
					{
						array5[num2] = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array11[0]), typeof(string));
					}
					object instance4 = NewLateBinding.LateGet(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
					{
						RuntimeHelpers.GetObjectValue(i)
					}, null, null, null), null, "SubItems", new object[0], null, null, null);
					Type type4 = null;
					string memberName4 = "Add";
					array3 = new object[1];
					object[] array14 = array3;
					int num5 = 0;
					array5 = text.Split(new char[]
					{
						'|'
					});
					string[] array15 = array5;
					num2 = 4;
					array14[num5] = array15[num2];
					array11 = array3;
					object[] arguments4 = array11;
					string[] argumentNames4 = null;
					Type[] typeArguments4 = null;
					array8 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(instance4, type4, memberName4, arguments4, argumentNames4, typeArguments4, array8, true);
					if (array8[0])
					{
						array5[num2] = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array11[0]), typeof(string));
					}
					object instance5 = NewLateBinding.LateGet(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
					{
						RuntimeHelpers.GetObjectValue(i)
					}, null, null, null), null, "SubItems", new object[0], null, null, null);
					Type type5 = null;
					string memberName5 = "Add";
					array3 = new object[1];
					object[] array16 = array3;
					int num6 = 0;
					array5 = text.Split(new char[]
					{
						'|'
					});
					string[] array17 = array5;
					num2 = 5;
					array16[num6] = array17[num2];
					array11 = array3;
					object[] arguments5 = array11;
					string[] argumentNames5 = null;
					Type[] typeArguments5 = null;
					array8 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(instance5, type5, memberName5, arguments5, argumentNames5, typeArguments5, array8, true);
					if (array8[0])
					{
						array5[num2] = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array11[0]), typeof(string));
					}
					object instance6 = NewLateBinding.LateGet(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
					{
						RuntimeHelpers.GetObjectValue(i)
					}, null, null, null), null, "SubItems", new object[0], null, null, null);
					Type type6 = null;
					string memberName6 = "Add";
					array3 = new object[1];
					object[] array18 = array3;
					int num7 = 0;
					array5 = text.Split(new char[]
					{
						'|'
					});
					string[] array19 = array5;
					num2 = 6;
					array18[num7] = array19[num2];
					array11 = array3;
					object[] arguments6 = array11;
					string[] argumentNames6 = null;
					Type[] typeArguments6 = null;
					array8 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(instance6, type6, memberName6, arguments6, argumentNames6, typeArguments6, array8, true);
					if (array8[0])
					{
						array5[num2] = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array11[0]), typeof(string));
					}
					object instance7 = NewLateBinding.LateGet(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
					{
						RuntimeHelpers.GetObjectValue(i)
					}, null, null, null), null, "SubItems", new object[0], null, null, null);
					Type type7 = null;
					string memberName7 = "Add";
					array3 = new object[1];
					object[] array20 = array3;
					int num8 = 0;
					array5 = text.Split(new char[]
					{
						'|'
					});
					string[] array21 = array5;
					num2 = 7;
					array20[num8] = array21[num2];
					array11 = array3;
					object[] arguments7 = array11;
					string[] argumentNames7 = null;
					Type[] typeArguments7 = null;
					array8 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(instance7, type7, memberName7, arguments7, argumentNames7, typeArguments7, array8, true);
					if (array8[0])
					{
						array5[num2] = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array11[0]), typeof(string));
					}
					flag = (Operators.CompareString(text.Split(new char[]
					{
						'|'
					})[0], "Food", false) == 0);
					if (flag)
					{
						NewLateBinding.LateSetComplex(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
						{
							RuntimeHelpers.GetObjectValue(i)
						}, null, null, null), null, "Font", new object[]
						{
							new Font(M_Settings.ShoppingCart.Font, FontStyle.Bold)
						}, null, null, false, true);
					}
					flag = (Operators.CompareString(text.Split(new char[]
					{
						'|'
					})[0], "Option", false) == 0);
					if (flag)
					{
						NewLateBinding.LateSetComplex(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
						{
							RuntimeHelpers.GetObjectValue(i)
						}, null, null, null), null, "Font", new object[]
						{
							new Font(M_Settings.ShoppingCart.Font, FontStyle.Regular)
						}, null, null, false, true);
					}
					flag = (Operators.CompareString(text.Split(new char[]
					{
						'|'
					})[0], "Divider", false) == 0);
					if (flag)
					{
						NewLateBinding.LateSetComplex(NewLateBinding.LateGet(M_Settings.ShoppingCart.Items, null, "Item", new object[]
						{
							RuntimeHelpers.GetObjectValue(i)
						}, null, null, null), null, "Font", new object[]
						{
							new Font(M_Settings.ShoppingCart.Font, FontStyle.Bold)
						}, null, null, false, true);
					}
					i = Operators.AddObject(i, 1);
				}
			}
			return i;
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x0003A94C File Offset: 0x00038B4C
		public static void AddMealToShoppingCart(object FoodType, object CoursePrice)
		{
			try
			{
				int count = M_Settings.ShoppingCart.Items.Count;
				M_Settings.SelectedSize = "";
				string text = "   " + M_Settings.SelectedFood;
				M_Settings.SelectedCategory = "Meal";
				M_Settings.SelectedOptionTLP = "";
				M_Settings.SelectedFoodPrice = 0m;
				M_Settings.ShoppingCart.Items.Add(new ListViewItem("Option"));
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedCategory);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedSize);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedOptionTLP);
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].SubItems.Add(text);
				bool flag = Operators.ConditionalCompareObjectEqual(CoursePrice, 0, false);
				if (flag)
				{
					M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				}
				flag = Operators.ConditionalCompareObjectGreater(CoursePrice, 0, false);
				bool[] array2;
				if (flag)
				{
					object subItems = M_Settings.ShoppingCart.Items[count].SubItems;
					Type type = null;
					string memberName = "Add";
					object[] array = new object[]
					{
						RuntimeHelpers.GetObjectValue(CoursePrice)
					};
					object[] arguments = array;
					string[] argumentNames = null;
					Type[] typeArguments = null;
					array2 = new bool[]
					{
						true
					};
					NewLateBinding.LateCall(subItems, type, memberName, arguments, argumentNames, typeArguments, array2, true);
					if (array2[0])
					{
						CoursePrice = RuntimeHelpers.GetObjectValue(array[0]);
					}
				}
				object subItems2 = M_Settings.ShoppingCart.Items[count].SubItems;
				Type type2 = null;
				string memberName2 = "Add";
				object[] array3 = new object[]
				{
					RuntimeHelpers.GetObjectValue(CoursePrice)
				};
				object[] arguments2 = array3;
				string[] argumentNames2 = null;
				Type[] typeArguments2 = null;
				array2 = new bool[]
				{
					true
				};
				NewLateBinding.LateCall(subItems2, type2, memberName2, arguments2, argumentNames2, typeArguments2, array2, true);
				if (array2[0])
				{
					CoursePrice = RuntimeHelpers.GetObjectValue(array3[0]);
				}
				flag = Operators.ConditionalCompareObjectEqual(FoodType, "Food", false);
				if (flag)
				{
					M_Settings.ShoppingCart.Items[count].Font = new Font(M_Settings.ShoppingCart.Font, FontStyle.Bold);
				}
				flag = Operators.ConditionalCompareObjectEqual(FoodType, "Option", false);
				if (flag)
				{
					M_Settings.ShoppingCart.Items[count].Font = new Font(M_Settings.ShoppingCart.Font, FontStyle.Regular);
				}
				M_Settings.ShoppingCart.TopItem = M_Settings.ShoppingCart.Items[checked(M_Settings.ShoppingCart.Items.Count - 1)];
				M_Calculates.CalculateSubTotal();
			}
			catch (Exception ex)
			{
				MessageBox.Show("AddMealToShoppingCart");
			}
		}

		// Token: 0x06000606 RID: 1542 RVA: 0x0003AC40 File Offset: 0x00038E40
		public static void Create_ShoppingCart()
		{
			ListView shoppingCart = M_Settings.ShoppingCart;
			shoppingCart.BorderStyle = BorderStyle.FixedSingle;
			shoppingCart.Dock = DockStyle.Top;
			shoppingCart.Font = new Font("Arial", 12f, FontStyle.Regular);
			shoppingCart.Scrollable = true;
			shoppingCart.HideSelection = false;
			shoppingCart.Columns.Add("Type", 0);
			shoppingCart.Columns.Add("Category", 0);
			shoppingCart.Columns.Add("Size", 0);
			shoppingCart.Columns.Add("TLP", 0);
			shoppingCart.Columns.Add("Qty", 40, HorizontalAlignment.Center);
			shoppingCart.Columns.Add("Name", 310, HorizontalAlignment.Left);
			shoppingCart.Columns.Add("Price", 60, HorizontalAlignment.Center);
			shoppingCart.Columns.Add("UnitPrice", 0, HorizontalAlignment.Center);
			shoppingCart.View = View.Details;
			shoppingCart.GridLines = true;
			shoppingCart.FullRowSelect = true;
			shoppingCart.MultiSelect = false;
			shoppingCart.BorderStyle = BorderStyle.None;
			shoppingCart.LabelWrap = true;
			shoppingCart.HeaderStyle = ColumnHeaderStyle.None;
			MyProject.Forms.POS_Window.SubTotalTextBox.Text = Conversions.ToString(M_Calculates.OrderSubTotal);
			MyProject.Forms.POS_Window.DiscountTextBox.Text = Conversions.ToString(M_Calculates.OrderDiscount);
			MyProject.Forms.POS_Window.DeliveryChargeTextBox.Text = Conversions.ToString(M_Calculates.OrderDelivery);
			MyProject.Forms.POS_Window.ServiceChargeTextBox.Text = Conversions.ToString(M_Calculates.OrderServiceCharge);
			MyProject.Forms.POS_Window.TotalTextBox.Text = Conversions.ToString(M_Calculates.OrderTotal);
			M_Shopping_Cart.DeFocuseShoppingCartItem();
			MyProject.Forms.POS_Window.Right_Panel.Controls.Add(M_Settings.ShoppingCart);
			M_Settings.ShoppingCart.Click += M_Shopping_Cart.ShoppingCart_SelectedIndexChanged;
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x0003AE38 File Offset: 0x00039038
		public static void AddOptionsToShoppingCart()
		{
			checked
			{
				try
				{
					int count = M_Settings.ShoppingCart.Items.Count;
					string text = "";
					bool flag = decimal.Compare(M_Settings.SelectedOptionPrice, 0m) != 0;
					if (flag)
					{
						text = M_Settings.SelectedOptionPrice.ToString();
					}
					flag = (Operators.CompareString(M_Settings.BeforeOptionTXT, "   NO ", false) == 0);
					if (flag)
					{
						text = "";
						M_Settings.SelectedOptionPrice = 0m;
					}
					flag = (Operators.CompareString(M_Settings.BeforeOptionTXT, "   FREE ", false) == 0);
					if (flag)
					{
						text = "";
						M_Settings.SelectedOptionPrice = 0m;
					}
					try
					{
						int index = M_Settings.ShoppingCart.FocusedItem.Index + 1;
						M_Settings.SelectedCategory = M_Settings.ShoppingCart.Items[index].SubItems[1].Text;
						M_Settings.SelectedSize = M_Settings.ShoppingCart.Items[index].SubItems[2].Text;
						M_Settings.SelectedOptionTLP = M_Settings.ShoppingCart.Items[index].SubItems[3].Text;
						M_Settings.ShoppingCart.Items.Insert(index, new ListViewItem("Option"));
						M_Settings.ShoppingCart.Items[index].SubItems.Add(M_Settings.SelectedCategory);
						M_Settings.ShoppingCart.Items[index].SubItems.Add(M_Settings.SelectedSize);
						M_Settings.ShoppingCart.Items[index].SubItems.Add(M_Settings.SelectedOptionTLP);
						M_Settings.ShoppingCart.Items[index].SubItems.Add("");
						M_Settings.ShoppingCart.Items[index].SubItems.Add(M_Settings.BeforeOptionTXT + M_Settings.SelectedOption);
						M_Settings.ShoppingCart.Items[index].SubItems.Add(text);
						M_Settings.ShoppingCart.Items[index].SubItems.Add(Conversions.ToString(M_Settings.SelectedOptionPrice));
					}
					catch (Exception ex)
					{
						M_Settings.ShoppingCart.Items.Add(new ListViewItem("Option"));
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedCategory);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedSize);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedOptionTLP);
						M_Settings.ShoppingCart.Items[count].SubItems.Add("");
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.BeforeOptionTXT + M_Settings.SelectedOption);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(text);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(Conversions.ToString(M_Settings.SelectedOptionPrice));
					}
					M_Settings.ShoppingCart.TopItem = M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.Items.Count - 1];
					M_Settings.BeforeOptionTXT = "    ";
					M_Calculates.CalculateSubTotal();
				}
				catch (Exception ex2)
				{
				}
			}
		}

		// Token: 0x06000608 RID: 1544 RVA: 0x0003B200 File Offset: 0x00039400
		public static void AddFoodToShoppingCart()
		{
			try
			{
				int count = M_Settings.ShoppingCart.Items.Count;
				bool flag = Operators.CompareString(M_Settings.SelectedSize, "", false) == 0;
				string text;
				if (flag)
				{
					text = M_Settings.SelectedFood;
				}
				else
				{
					text = M_Settings.SelectedSize + " " + M_Settings.SelectedFood;
				}
				M_Settings.ShoppingCart.Items.Add(new ListViewItem("Food"));
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedCategory);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedSize);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedOptionTLP);
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].SubItems.Add(text);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(Conversions.ToString(M_Settings.SelectedFoodPrice));
				M_Settings.ShoppingCart.Items[count].SubItems.Add(Conversions.ToString(M_Settings.SelectedFoodPrice));
				M_Settings.ShoppingCart.Items[count].Font = new Font(M_Settings.ShoppingCart.Font, FontStyle.Bold);
				M_Settings.ShoppingCart.TopItem = M_Settings.ShoppingCart.Items[checked(M_Settings.ShoppingCart.Items.Count - 1)];
				M_Calculates.CalculateSubTotal();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000609 RID: 1545 RVA: 0x0003B3E8 File Offset: 0x000395E8
		private static void ShoppingCart_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				bool flag = Operators.CompareString(M_Settings.ShoppingCart.SelectedItems[0].SubItems[0].Text, "Divider", false) == 0;
				if (flag)
				{
					MyProject.Forms.POS_Window.EditPriceBTN.Visible = false;
					MyProject.Forms.POS_Window.IncreaseQTY.Visible = false;
					MyProject.Forms.POS_Window.DecreaseQTY.Visible = false;
				}
				else
				{
					MyProject.Forms.POS_Window.EditPriceBTN.Visible = true;
					MyProject.Forms.POS_Window.IncreaseQTY.Visible = true;
					MyProject.Forms.POS_Window.DecreaseQTY.Visible = true;
				}
				MyProject.Forms.POS_Window.CompletePanel.BringToFront();
				string text = M_Settings.ShoppingCart.SelectedItems[0].SubItems[3].Text;
				MyProject.Forms.POS_Window.Main_Panel.Controls[text].BringToFront();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600060A RID: 1546 RVA: 0x0003B538 File Offset: 0x00039738
		public static void QtyMinus()
		{
			checked
			{
				try
				{
					int index = M_Settings.ShoppingCart.FocusedItem.Index;
					string text = M_Settings.ShoppingCart.Items[index].SubItems[0].Text;
					string text2 = M_Settings.ShoppingCart.Items[index].SubItems[4].Text;
					bool flag = Operators.CompareString(text2, "", false) == 0;
					int num;
					if (flag)
					{
						num = 1;
					}
					else
					{
						num = Conversions.ToInteger(text2);
					}
					decimal d = Conversions.ToDecimal(M_Settings.ShoppingCart.Items[index].SubItems[7].Text);
					flag = (Operators.CompareString(text, "Food", false) == 0 & num == 1);
					if (flag)
					{
						M_Settings.ShoppingCart.Items.RemoveAt(index);
						while (Operators.CompareString(M_Settings.ShoppingCart.Items[index].SubItems[0].Text, "Food", false) != 0)
						{
							M_Settings.ShoppingCart.Items.RemoveAt(index);
							MyProject.Forms.POS_Window.MessageBoard.BringToFront();
						}
					}
					flag = (Operators.CompareString(text, "Food", false) == 0 & num > 1);
					if (flag)
					{
						num--;
						flag = (num == 1);
						if (flag)
						{
							M_Settings.ShoppingCart.SelectedItems[0].SubItems[4].Text = "";
						}
						else
						{
							M_Settings.ShoppingCart.SelectedItems[0].SubItems[4].Text = num.ToString();
						}
						M_Settings.ShoppingCart.SelectedItems[0].SubItems[6].Text = decimal.Multiply(new decimal(num), d).ToString();
					}
					flag = (Operators.CompareString(text, "Option", false) == 0);
					if (flag)
					{
						M_Settings.ShoppingCart.Items.RemoveAt(index);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x0003B784 File Offset: 0x00039984
		public static void QtyPlus()
		{
			checked
			{
				try
				{
					int count = M_Settings.ShoppingCart.Items.Count;
					int num = M_Settings.ShoppingCart.FocusedItem.Index;
					string text = M_Settings.ShoppingCart.Items[num].SubItems[0].Text;
					decimal d = Conversions.ToDecimal(M_Settings.ShoppingCart.Items[num].SubItems[7].Text);
					int num2 = 1;
					bool flag = Operators.CompareString(M_Settings.ShoppingCart.Items[num].SubItems[4].Text, "", false) != 0;
					if (flag)
					{
						num2 = Conversions.ToInteger(M_Settings.ShoppingCart.Items[num].SubItems[4].Text);
					}
					decimal num3 = decimal.Multiply(new decimal(num2), d);
					string left;
					try
					{
						left = M_Settings.ShoppingCart.Items[num + 1].SubItems[0].Text;
					}
					catch (Exception ex)
					{
						left = "";
					}
					flag = (Operators.CompareString(left, "Food", false) == 0 | Operators.CompareString(left, "", false) == 0);
					if (flag)
					{
						num2++;
						M_Settings.ShoppingCart.Items[num].SubItems[4].Text = num2.ToString();
						M_Settings.ShoppingCart.Items[num].SubItems[6].Text = decimal.Multiply(new decimal(num2), d).ToString();
					}
					flag = (Operators.CompareString(left, "Option", false) == 0);
					if (flag)
					{
						M_Settings.ShoppingCart.Items.Add(new ListViewItem("Food"));
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[1].Text);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[2].Text);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[3].Text);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[4].Text);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[5].Text);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[6].Text);
						M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[7].Text);
						M_Settings.ShoppingCart.Items[count].Font = new Font(M_Settings.ShoppingCart.Font, FontStyle.Bold);
						count = M_Settings.ShoppingCart.Items.Count;
						num++;
						while (Operators.CompareString(M_Settings.ShoppingCart.Items[num].SubItems[0].Text, "Food", false) != 0)
						{
							M_Settings.ShoppingCart.Items.Add(new ListViewItem("Option"));
							M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[1].Text);
							M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[2].Text);
							M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[3].Text);
							M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[4].Text);
							M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[5].Text);
							M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[6].Text);
							M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.ShoppingCart.Items[num].SubItems[7].Text);
							M_Settings.ShoppingCart.Items[count].Font = new Font(M_Settings.ShoppingCart.Font, FontStyle.Regular);
							count = M_Settings.ShoppingCart.Items.Count;
							num++;
						}
					}
					M_Settings.ShoppingCart.TopItem = M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.Items.Count - 1];
				}
				catch (Exception ex2)
				{
				}
			}
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x0003BE10 File Offset: 0x0003A010
		public static void DeFocuseShoppingCartItem()
		{
			try
			{
				try
				{
					foreach (object obj in M_Settings.ShoppingCart.Items)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						NewLateBinding.LateSet(objectValue, null, "Focused", new object[]
						{
							false
						}, null, null);
					}
				}
				finally
				{
					IEnumerator enumerator;
					bool flag = enumerator is IDisposable;
					if (flag)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("DeFocuseShoppingCartItem");
			}
		}
	}
}
