using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace POS
{
	// Token: 0x02000021 RID: 33
	[DesignerGenerated]
	public class Form_Glass : Form
	{
		// Token: 0x06000555 RID: 1365 RVA: 0x00031574 File Offset: 0x0002F774
		[DebuggerNonUserCode]
		public Form_Glass()
		{
			List<WeakReference> _ENCList = Form_Glass.__ENCList;
			lock (_ENCList)
			{
				Form_Glass.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x000315CC File Offset: 0x0002F7CC
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x0003161C File Offset: 0x0002F81C
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.SuspendLayout();
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Black;
			Size clientSize = new Size(784, 551);
			this.ClientSize = clientSize;
			this.Enabled = false;
			this.ForeColor = Color.White;
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "Form_Glass";
			this.Opacity = 0.7;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.TransparencyKey = Color.DarkOrange;
			this.WindowState = FormWindowState.Maximized;
			this.ResumeLayout(false);
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x0000221E File Offset: 0x0000041E
		private void Button1_Click_2(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x04000239 RID: 569
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x0400023A RID: 570
		private IContainer components;
	}
}
