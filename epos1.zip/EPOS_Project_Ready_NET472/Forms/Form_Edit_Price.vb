using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000020 RID: 32
	[DesignerGenerated]
	public class Form_Edit_Price : Form
	{
		// Token: 0x06000520 RID: 1312 RVA: 0x0002FA54 File Offset: 0x0002DC54
		[DebuggerNonUserCode]
		public Form_Edit_Price()
		{
			base.Load += this.Form_Edit_Price_Load;
			List<WeakReference> _ENCList = Form_Edit_Price.__ENCList;
			lock (_ENCList)
			{
				Form_Edit_Price.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x0002FAC0 File Offset: 0x0002DCC0
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x0002FB10 File Offset: 0x0002DD10
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Button1 = new Button();
			this.FlowLayoutPanel1 = new FlowLayoutPanel();
			this.Button2 = new Button();
			this.Button3 = new Button();
			this.Button4 = new Button();
			this.Button5 = new Button();
			this.Button6 = new Button();
			this.Button7 = new Button();
			this.Button8 = new Button();
			this.Button9 = new Button();
			this.Button10 = new Button();
			this.Button11 = new Button();
			this.SaveBTN = new Button();
			this.DeleteBTN = new Button();
			this.TextBox1 = new TextBox();
			this.Label1 = new Label();
			this.Button12 = new Button();
			this.FlowLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			this.Button1.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button = this.Button1;
			Point location = new Point(3, 3);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			Size size = new Size(121, 53);
			button2.Size = size;
			this.Button1.TabIndex = 0;
			this.Button1.Text = "1";
			this.Button1.UseVisualStyleBackColor = true;
			this.FlowLayoutPanel1.Controls.Add(this.Button1);
			this.FlowLayoutPanel1.Controls.Add(this.Button2);
			this.FlowLayoutPanel1.Controls.Add(this.Button3);
			this.FlowLayoutPanel1.Controls.Add(this.Button4);
			this.FlowLayoutPanel1.Controls.Add(this.Button5);
			this.FlowLayoutPanel1.Controls.Add(this.Button6);
			this.FlowLayoutPanel1.Controls.Add(this.Button7);
			this.FlowLayoutPanel1.Controls.Add(this.Button8);
			this.FlowLayoutPanel1.Controls.Add(this.Button9);
			this.FlowLayoutPanel1.Controls.Add(this.Button10);
			this.FlowLayoutPanel1.Controls.Add(this.Button11);
			this.FlowLayoutPanel1.Controls.Add(this.SaveBTN);
			this.FlowLayoutPanel1.Dock = DockStyle.Bottom;
			Control flowLayoutPanel = this.FlowLayoutPanel1;
			location = new Point(0, 110);
			flowLayoutPanel.Location = location;
			this.FlowLayoutPanel1.Name = "FlowLayoutPanel1";
			Control flowLayoutPanel2 = this.FlowLayoutPanel1;
			size = new Size(385, 240);
			flowLayoutPanel2.Size = size;
			this.FlowLayoutPanel1.TabIndex = 2;
			this.Button2.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button3 = this.Button2;
			location = new Point(130, 3);
			button3.Location = location;
			this.Button2.Name = "Button2";
			Control button4 = this.Button2;
			size = new Size(121, 53);
			button4.Size = size;
			this.Button2.TabIndex = 1;
			this.Button2.Text = "2";
			this.Button2.UseVisualStyleBackColor = true;
			this.Button3.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button5 = this.Button3;
			location = new Point(257, 3);
			button5.Location = location;
			this.Button3.Name = "Button3";
			Control button6 = this.Button3;
			size = new Size(121, 53);
			button6.Size = size;
			this.Button3.TabIndex = 2;
			this.Button3.Text = "3";
			this.Button3.UseVisualStyleBackColor = true;
			this.Button4.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button7 = this.Button4;
			location = new Point(3, 62);
			button7.Location = location;
			this.Button4.Name = "Button4";
			Control button8 = this.Button4;
			size = new Size(121, 53);
			button8.Size = size;
			this.Button4.TabIndex = 3;
			this.Button4.Text = "4";
			this.Button4.UseVisualStyleBackColor = true;
			this.Button5.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button9 = this.Button5;
			location = new Point(130, 62);
			button9.Location = location;
			this.Button5.Name = "Button5";
			Control button10 = this.Button5;
			size = new Size(121, 53);
			button10.Size = size;
			this.Button5.TabIndex = 4;
			this.Button5.Text = "5";
			this.Button5.UseVisualStyleBackColor = true;
			this.Button6.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button11 = this.Button6;
			location = new Point(257, 62);
			button11.Location = location;
			this.Button6.Name = "Button6";
			Control button12 = this.Button6;
			size = new Size(121, 53);
			button12.Size = size;
			this.Button6.TabIndex = 5;
			this.Button6.Text = "6";
			this.Button6.UseVisualStyleBackColor = true;
			this.Button7.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button13 = this.Button7;
			location = new Point(3, 121);
			button13.Location = location;
			this.Button7.Name = "Button7";
			Control button14 = this.Button7;
			size = new Size(121, 53);
			button14.Size = size;
			this.Button7.TabIndex = 6;
			this.Button7.Text = "7";
			this.Button7.UseVisualStyleBackColor = true;
			this.Button8.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button15 = this.Button8;
			location = new Point(130, 121);
			button15.Location = location;
			this.Button8.Name = "Button8";
			Control button16 = this.Button8;
			size = new Size(121, 53);
			button16.Size = size;
			this.Button8.TabIndex = 7;
			this.Button8.Text = "8";
			this.Button8.UseVisualStyleBackColor = true;
			this.Button9.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button17 = this.Button9;
			location = new Point(257, 121);
			button17.Location = location;
			this.Button9.Name = "Button9";
			Control button18 = this.Button9;
			size = new Size(121, 53);
			button18.Size = size;
			this.Button9.TabIndex = 8;
			this.Button9.Text = "9";
			this.Button9.UseVisualStyleBackColor = true;
			this.Button10.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button19 = this.Button10;
			location = new Point(3, 180);
			button19.Location = location;
			this.Button10.Name = "Button10";
			Control button20 = this.Button10;
			size = new Size(121, 53);
			button20.Size = size;
			this.Button10.TabIndex = 9;
			this.Button10.Text = "0";
			this.Button10.UseVisualStyleBackColor = true;
			this.Button11.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button21 = this.Button11;
			location = new Point(130, 180);
			button21.Location = location;
			this.Button11.Name = "Button11";
			Control button22 = this.Button11;
			size = new Size(121, 53);
			button22.Size = size;
			this.Button11.TabIndex = 10;
			this.Button11.Text = ".";
			this.Button11.UseVisualStyleBackColor = true;
			this.SaveBTN.BackColor = Color.Lime;
			this.SaveBTN.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control saveBTN = this.SaveBTN;
			location = new Point(257, 180);
			saveBTN.Location = location;
			this.SaveBTN.Name = "SaveBTN";
			Control saveBTN2 = this.SaveBTN;
			size = new Size(121, 53);
			saveBTN2.Size = size;
			this.SaveBTN.TabIndex = 11;
			this.SaveBTN.Text = "Save";
			this.SaveBTN.UseVisualStyleBackColor = false;
			this.DeleteBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.DeleteBTN.BackColor = Color.Crimson;
			this.DeleteBTN.Font = new Font("Century Gothic", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DeleteBTN.ForeColor = Color.White;
			Control deleteBTN = this.DeleteBTN;
			location = new Point(257, 51);
			deleteBTN.Location = location;
			this.DeleteBTN.Name = "DeleteBTN";
			Control deleteBTN2 = this.DeleteBTN;
			size = new Size(121, 53);
			deleteBTN2.Size = size;
			this.DeleteBTN.TabIndex = 12;
			this.DeleteBTN.Text = "Delete";
			this.DeleteBTN.UseVisualStyleBackColor = false;
			this.TextBox1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.TextBox1.Font = new Font("Century Gothic", 26.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control textBox = this.TextBox1;
			location = new Point(3, 54);
			textBox.Location = location;
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.ReadOnly = true;
			Control textBox2 = this.TextBox1;
			size = new Size(248, 50);
			textBox2.Size = size;
			this.TextBox1.TabIndex = 13;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Century Gothic", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.Crimson;
			Control label = this.Label1;
			location = new Point(12, 16);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(79, 25);
			label2.Size = size;
			this.Label1.TabIndex = 14;
			this.Label1.Text = "Label1";
			this.Button12.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.Button12.BackColor = Color.Crimson;
			this.Button12.FlatStyle = FlatStyle.Flat;
			this.Button12.Font = new Font("Century Gothic", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button12.ForeColor = Color.White;
			Control button23 = this.Button12;
			location = new Point(350, 0);
			button23.Location = location;
			this.Button12.Name = "Button12";
			Control button24 = this.Button12;
			size = new Size(35, 35);
			button24.Size = size;
			this.Button12.TabIndex = 15;
			this.Button12.Text = "X";
			this.Button12.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(385, 350);
			this.ClientSize = size;
			this.Controls.Add(this.Button12);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.TextBox1);
			this.Controls.Add(this.DeleteBTN);
			this.Controls.Add(this.FlowLayoutPanel1);
			this.FormBorderStyle = FormBorderStyle.None;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form_Edit_Price";
			this.ShowIcon = false;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.TopMost = true;
			this.FlowLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x06000523 RID: 1315 RVA: 0x000307D4 File Offset: 0x0002E9D4
		// (set) Token: 0x06000524 RID: 1316 RVA: 0x000307EC File Offset: 0x0002E9EC
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x06000525 RID: 1317 RVA: 0x0003084C File Offset: 0x0002EA4C
		// (set) Token: 0x06000526 RID: 1318 RVA: 0x00003ADE File Offset: 0x00001CDE
		internal virtual FlowLayoutPanel FlowLayoutPanel1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FlowLayoutPanel1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FlowLayoutPanel1 = value;
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x06000527 RID: 1319 RVA: 0x00030864 File Offset: 0x0002EA64
		// (set) Token: 0x06000528 RID: 1320 RVA: 0x0003087C File Offset: 0x0002EA7C
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x06000529 RID: 1321 RVA: 0x000308DC File Offset: 0x0002EADC
		// (set) Token: 0x0600052A RID: 1322 RVA: 0x000308F4 File Offset: 0x0002EAF4
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x0600052B RID: 1323 RVA: 0x00030954 File Offset: 0x0002EB54
		// (set) Token: 0x0600052C RID: 1324 RVA: 0x0003096C File Offset: 0x0002EB6C
		internal virtual Button Button4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				bool flag = this._Button4 != null;
				if (flag)
				{
					this._Button4.Click -= value2;
				}
				this._Button4 = value;
				flag = (this._Button4 != null);
				if (flag)
				{
					this._Button4.Click += value2;
				}
			}
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x0600052D RID: 1325 RVA: 0x000309CC File Offset: 0x0002EBCC
		// (set) Token: 0x0600052E RID: 1326 RVA: 0x000309E4 File Offset: 0x0002EBE4
		internal virtual Button Button5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click);
				bool flag = this._Button5 != null;
				if (flag)
				{
					this._Button5.Click -= value2;
				}
				this._Button5 = value;
				flag = (this._Button5 != null);
				if (flag)
				{
					this._Button5.Click += value2;
				}
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x0600052F RID: 1327 RVA: 0x00030A44 File Offset: 0x0002EC44
		// (set) Token: 0x06000530 RID: 1328 RVA: 0x00030A5C File Offset: 0x0002EC5C
		internal virtual Button Button6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button6_Click);
				bool flag = this._Button6 != null;
				if (flag)
				{
					this._Button6.Click -= value2;
				}
				this._Button6 = value;
				flag = (this._Button6 != null);
				if (flag)
				{
					this._Button6.Click += value2;
				}
			}
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x06000531 RID: 1329 RVA: 0x00030ABC File Offset: 0x0002ECBC
		// (set) Token: 0x06000532 RID: 1330 RVA: 0x00030AD4 File Offset: 0x0002ECD4
		internal virtual Button Button7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button7_Click);
				bool flag = this._Button7 != null;
				if (flag)
				{
					this._Button7.Click -= value2;
				}
				this._Button7 = value;
				flag = (this._Button7 != null);
				if (flag)
				{
					this._Button7.Click += value2;
				}
			}
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x06000533 RID: 1331 RVA: 0x00030B34 File Offset: 0x0002ED34
		// (set) Token: 0x06000534 RID: 1332 RVA: 0x00030B4C File Offset: 0x0002ED4C
		internal virtual Button Button8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button8_Click);
				bool flag = this._Button8 != null;
				if (flag)
				{
					this._Button8.Click -= value2;
				}
				this._Button8 = value;
				flag = (this._Button8 != null);
				if (flag)
				{
					this._Button8.Click += value2;
				}
			}
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x06000535 RID: 1333 RVA: 0x00030BAC File Offset: 0x0002EDAC
		// (set) Token: 0x06000536 RID: 1334 RVA: 0x00030BC4 File Offset: 0x0002EDC4
		internal virtual Button Button9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button9_Click);
				bool flag = this._Button9 != null;
				if (flag)
				{
					this._Button9.Click -= value2;
				}
				this._Button9 = value;
				flag = (this._Button9 != null);
				if (flag)
				{
					this._Button9.Click += value2;
				}
			}
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x06000537 RID: 1335 RVA: 0x00030C24 File Offset: 0x0002EE24
		// (set) Token: 0x06000538 RID: 1336 RVA: 0x00030C3C File Offset: 0x0002EE3C
		internal virtual Button Button10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button10_Click);
				bool flag = this._Button10 != null;
				if (flag)
				{
					this._Button10.Click -= value2;
				}
				this._Button10 = value;
				flag = (this._Button10 != null);
				if (flag)
				{
					this._Button10.Click += value2;
				}
			}
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x06000539 RID: 1337 RVA: 0x00030C9C File Offset: 0x0002EE9C
		// (set) Token: 0x0600053A RID: 1338 RVA: 0x00030CB4 File Offset: 0x0002EEB4
		internal virtual Button Button11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button11_Click);
				bool flag = this._Button11 != null;
				if (flag)
				{
					this._Button11.Click -= value2;
				}
				this._Button11 = value;
				flag = (this._Button11 != null);
				if (flag)
				{
					this._Button11.Click += value2;
				}
			}
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x0600053B RID: 1339 RVA: 0x00030D14 File Offset: 0x0002EF14
		// (set) Token: 0x0600053C RID: 1340 RVA: 0x00030D2C File Offset: 0x0002EF2C
		internal virtual Button SaveBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SaveBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.SaveBTN_Click);
				bool flag = this._SaveBTN != null;
				if (flag)
				{
					this._SaveBTN.Click -= value2;
				}
				this._SaveBTN = value;
				flag = (this._SaveBTN != null);
				if (flag)
				{
					this._SaveBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x0600053D RID: 1341 RVA: 0x00030D8C File Offset: 0x0002EF8C
		// (set) Token: 0x0600053E RID: 1342 RVA: 0x00030DA4 File Offset: 0x0002EFA4
		internal virtual Button DeleteBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeleteBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DeleteBTN_Click);
				bool flag = this._DeleteBTN != null;
				if (flag)
				{
					this._DeleteBTN.Click -= value2;
				}
				this._DeleteBTN = value;
				flag = (this._DeleteBTN != null);
				if (flag)
				{
					this._DeleteBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x0600053F RID: 1343 RVA: 0x00030E04 File Offset: 0x0002F004
		// (set) Token: 0x06000540 RID: 1344 RVA: 0x00003AE8 File Offset: 0x00001CE8
		internal virtual TextBox TextBox1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TextBox1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TextBox1 = value;
			}
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x06000541 RID: 1345 RVA: 0x00030E1C File Offset: 0x0002F01C
		// (set) Token: 0x06000542 RID: 1346 RVA: 0x00003AF2 File Offset: 0x00001CF2
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x06000543 RID: 1347 RVA: 0x00030E34 File Offset: 0x0002F034
		// (set) Token: 0x06000544 RID: 1348 RVA: 0x00030E4C File Offset: 0x0002F04C
		internal virtual Button Button12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button12_Click);
				bool flag = this._Button12 != null;
				if (flag)
				{
					this._Button12.Click -= value2;
				}
				this._Button12 = value;
				flag = (this._Button12 != null);
				if (flag)
				{
					this._Button12.Click += value2;
				}
			}
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x00030EAC File Offset: 0x0002F0AC
		private void Form_Edit_Price_Load(object sender, EventArgs e)
		{
			this.TextBox1.Text = Conversions.ToString(Math.Abs(Conversions.ToDecimal(M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[7].Text)));
			this.Label1.Text = M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[5].Text;
			this.FirstBtnClick = "y";
			MyProject.Forms.Form_Glass.Show();
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x00003AFC File Offset: 0x00001CFC
		private void DeleteBTN_Click(object sender, EventArgs e)
		{
			this.TextBox1.Text = "";
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x00030F5C File Offset: 0x0002F15C
		private void SaveBTN_Click(object sender, EventArgs e)
		{
			bool flag = this.TextBox1.Text.Length > 0;
			if (flag)
			{
				bool flag2 = Operators.CompareString(M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[4].Text, "", false) == 0;
				int value;
				if (flag2)
				{
					value = 1;
				}
				else
				{
					value = Conversions.ToInteger(M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[4].Text);
				}
				decimal num = Conversions.ToDecimal(this.TextBox1.Text);
				flag2 = (Operators.CompareString(M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[0].Text, "OFFER", false) == 0);
				if (flag2)
				{
					num = decimal.Multiply(num, -1m);
				}
				M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[7].Text = num.ToString();
				M_Settings.ShoppingCart.Items[M_Settings.ShoppingCart.FocusedItem.Index].SubItems[6].Text = decimal.Multiply(new decimal(value), num).ToString();
				MyProject.Forms.Form_Glass.Hide();
				this.Close();
			}
			M_Calculates.CalculateSubTotal();
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x000310FC File Offset: 0x0002F2FC
		private void Button1_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "1";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "1";
			}
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x00031164 File Offset: 0x0002F364
		private void Button2_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "2";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "2";
			}
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x000311CC File Offset: 0x0002F3CC
		private void Button3_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "3";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "3";
			}
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x00031234 File Offset: 0x0002F434
		private void Button4_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "4";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "4";
			}
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x0003129C File Offset: 0x0002F49C
		private void Button5_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "5";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "5";
			}
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x00031304 File Offset: 0x0002F504
		private void Button6_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "6";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "6";
			}
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x0003136C File Offset: 0x0002F56C
		private void Button7_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "7";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "7";
			}
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x000313D4 File Offset: 0x0002F5D4
		private void Button8_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "8";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "8";
			}
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x0003143C File Offset: 0x0002F63C
		private void Button9_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "9";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "9";
			}
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x000314A4 File Offset: 0x0002F6A4
		private void Button10_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "0";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + "0";
			}
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x0003150C File Offset: 0x0002F70C
		private void Button11_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.FirstBtnClick, "y", false) == 0;
			if (flag)
			{
				this.TextBox1.Text = "0.";
				this.FirstBtnClick = "n";
			}
			else
			{
				this.TextBox1.Text = this.TextBox1.Text + ".";
			}
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x00003B11 File Offset: 0x00001D11
		private void Button12_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Hide();
			this.Close();
		}

		// Token: 0x04000225 RID: 549
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000226 RID: 550
		private IContainer components;

		// Token: 0x04000227 RID: 551
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000228 RID: 552
		[AccessedThroughProperty("FlowLayoutPanel1")]
		private FlowLayoutPanel _FlowLayoutPanel1;

		// Token: 0x04000229 RID: 553
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x0400022A RID: 554
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x0400022B RID: 555
		[AccessedThroughProperty("Button4")]
		private Button _Button4;

		// Token: 0x0400022C RID: 556
		[AccessedThroughProperty("Button5")]
		private Button _Button5;

		// Token: 0x0400022D RID: 557
		[AccessedThroughProperty("Button6")]
		private Button _Button6;

		// Token: 0x0400022E RID: 558
		[AccessedThroughProperty("Button7")]
		private Button _Button7;

		// Token: 0x0400022F RID: 559
		[AccessedThroughProperty("Button8")]
		private Button _Button8;

		// Token: 0x04000230 RID: 560
		[AccessedThroughProperty("Button9")]
		private Button _Button9;

		// Token: 0x04000231 RID: 561
		[AccessedThroughProperty("Button10")]
		private Button _Button10;

		// Token: 0x04000232 RID: 562
		[AccessedThroughProperty("Button11")]
		private Button _Button11;

		// Token: 0x04000233 RID: 563
		[AccessedThroughProperty("SaveBTN")]
		private Button _SaveBTN;

		// Token: 0x04000234 RID: 564
		[AccessedThroughProperty("DeleteBTN")]
		private Button _DeleteBTN;

		// Token: 0x04000235 RID: 565
		[AccessedThroughProperty("TextBox1")]
		private TextBox _TextBox1;

		// Token: 0x04000236 RID: 566
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000237 RID: 567
		[AccessedThroughProperty("Button12")]
		private Button _Button12;

		// Token: 0x04000238 RID: 568
		private string FirstBtnClick;
	}
}
