using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace POS
{
	// Token: 0x0200000B RID: 11
	[DesignerGenerated]
	public class AdminIndex : Form
	{
		// Token: 0x0600007A RID: 122 RVA: 0x00006138 File Offset: 0x00004338
		[DebuggerNonUserCode]
		public AdminIndex()
		{
			List<WeakReference> _ENCList = AdminIndex.__ENCList;
			lock (_ENCList)
			{
				AdminIndex.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00006190 File Offset: 0x00004390
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x0600007C RID: 124 RVA: 0x000061E0 File Offset: 0x000043E0
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Button1 = new Button();
			this.SuspendLayout();
			Control button = this.Button1;
			Point location = new Point(12, 12);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			Size size = new Size(198, 69);
			button2.Size = size;
			this.Button1.TabIndex = 2;
			this.Button1.Text = "General Settings";
			this.Button1.UseVisualStyleBackColor = true;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(634, 297);
			this.ClientSize = size;
			this.Controls.Add(this.Button1);
			this.Name = "AdminIndex";
			this.Text = "AdminIndex";
			this.ResumeLayout(false);
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x0600007D RID: 125 RVA: 0x000062E4 File Offset: 0x000044E4
		// (set) Token: 0x0600007E RID: 126 RVA: 0x0000211E File Offset: 0x0000031E
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Button1 = value;
			}
		}

		// Token: 0x04000031 RID: 49
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000032 RID: 50
		private IContainer components;

		// Token: 0x04000033 RID: 51
		[AccessedThroughProperty("Button1")]
		private Button _Button1;
	}
}
