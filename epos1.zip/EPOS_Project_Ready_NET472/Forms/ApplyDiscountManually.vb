using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000018 RID: 24
	[DesignerGenerated]
	public class ApplyDiscountManually : Form
	{
		// Token: 0x060003DB RID: 987 RVA: 0x00020E64 File Offset: 0x0001F064
		[DebuggerNonUserCode]
		public ApplyDiscountManually()
		{
			base.Load += this.ApplyDiscountManually_Load;
			List<WeakReference> _ENCList = ApplyDiscountManually.__ENCList;
			lock (_ENCList)
			{
				ApplyDiscountManually.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x060003DC RID: 988 RVA: 0x00020ED0 File Offset: 0x0001F0D0
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060003DD RID: 989 RVA: 0x00020F20 File Offset: 0x0001F120
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.NoDiscountBTN = new Button();
			this.DiscountAmountBTN = new Button();
			this.Button11 = new Button();
			this.Button10 = new Button();
			this.Button9 = new Button();
			this.Button8 = new Button();
			this.Button7 = new Button();
			this.Button6 = new Button();
			this.Button5 = new Button();
			this.Button4 = new Button();
			this.Button3 = new Button();
			this.Button2 = new Button();
			this.Button1 = new Button();
			this.DiscountTextBox = new TextBox();
			this.Label1 = new Label();
			this.DiscountPercentBTN = new Button();
			this.Button12 = new Button();
			this.ExitBTN = new Button();
			this.SuspendLayout();
			this.NoDiscountBTN.Anchor = AnchorStyles.Bottom;
			this.NoDiscountBTN.BackColor = Color.Crimson;
			this.NoDiscountBTN.FlatStyle = FlatStyle.Popup;
			this.NoDiscountBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.NoDiscountBTN.ForeColor = SystemColors.Window;
			Control noDiscountBTN = this.NoDiscountBTN;
			Point location = new Point(23, 489);
			noDiscountBTN.Location = location;
			this.NoDiscountBTN.Name = "NoDiscountBTN";
			Control noDiscountBTN2 = this.NoDiscountBTN;
			Size size = new Size(236, 53);
			noDiscountBTN2.Size = size;
			this.NoDiscountBTN.TabIndex = 1;
			this.NoDiscountBTN.Text = "Remove All Discounts";
			this.NoDiscountBTN.UseVisualStyleBackColor = false;
			this.DiscountAmountBTN.Anchor = AnchorStyles.Bottom;
			this.DiscountAmountBTN.BackColor = Color.Lime;
			this.DiscountAmountBTN.Enabled = false;
			this.DiscountAmountBTN.FlatStyle = FlatStyle.Flat;
			this.DiscountAmountBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DiscountAmountBTN.ForeColor = Color.Black;
			Control discountAmountBTN = this.DiscountAmountBTN;
			location = new Point(23, 388);
			discountAmountBTN.Location = location;
			this.DiscountAmountBTN.Name = "DiscountAmountBTN";
			Control discountAmountBTN2 = this.DiscountAmountBTN;
			size = new Size(115, 95);
			discountAmountBTN2.Size = size;
			this.DiscountAmountBTN.TabIndex = 44;
			this.DiscountAmountBTN.Text = "£\r\nDiscount";
			this.DiscountAmountBTN.UseVisualStyleBackColor = false;
			this.Button11.BackColor = Color.Gold;
			this.Button11.FlatStyle = FlatStyle.Flat;
			this.Button11.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button11.ForeColor = Color.Black;
			Control button = this.Button11;
			location = new Point(184, 304);
			button.Location = location;
			this.Button11.Name = "Button11";
			Control button2 = this.Button11;
			size = new Size(75, 75);
			button2.Size = size;
			this.Button11.TabIndex = 43;
			this.Button11.Text = "Delete";
			this.Button11.UseVisualStyleBackColor = false;
			this.Button10.BackColor = Color.Gainsboro;
			this.Button10.FlatStyle = FlatStyle.Flat;
			this.Button10.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button3 = this.Button10;
			location = new Point(22, 303);
			button3.Location = location;
			this.Button10.Name = "Button10";
			Control button4 = this.Button10;
			size = new Size(75, 75);
			button4.Size = size;
			this.Button10.TabIndex = 42;
			this.Button10.Text = "0";
			this.Button10.UseVisualStyleBackColor = false;
			this.Button9.BackColor = Color.Gainsboro;
			this.Button9.FlatStyle = FlatStyle.Flat;
			this.Button9.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button5 = this.Button9;
			location = new Point(184, 222);
			button5.Location = location;
			this.Button9.Name = "Button9";
			Control button6 = this.Button9;
			size = new Size(75, 75);
			button6.Size = size;
			this.Button9.TabIndex = 41;
			this.Button9.Text = "9";
			this.Button9.UseVisualStyleBackColor = false;
			this.Button8.BackColor = Color.Gainsboro;
			this.Button8.FlatStyle = FlatStyle.Flat;
			this.Button8.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button7 = this.Button8;
			location = new Point(103, 222);
			button7.Location = location;
			this.Button8.Name = "Button8";
			Control button8 = this.Button8;
			size = new Size(75, 75);
			button8.Size = size;
			this.Button8.TabIndex = 40;
			this.Button8.Text = "8";
			this.Button8.UseVisualStyleBackColor = false;
			this.Button7.BackColor = Color.Gainsboro;
			this.Button7.FlatStyle = FlatStyle.Flat;
			this.Button7.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button9 = this.Button7;
			location = new Point(22, 222);
			button9.Location = location;
			this.Button7.Name = "Button7";
			Control button10 = this.Button7;
			size = new Size(75, 75);
			button10.Size = size;
			this.Button7.TabIndex = 39;
			this.Button7.Text = "7";
			this.Button7.UseVisualStyleBackColor = false;
			this.Button6.BackColor = Color.Gainsboro;
			this.Button6.FlatStyle = FlatStyle.Flat;
			this.Button6.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button11 = this.Button6;
			location = new Point(184, 141);
			button11.Location = location;
			this.Button6.Name = "Button6";
			Control button12 = this.Button6;
			size = new Size(75, 75);
			button12.Size = size;
			this.Button6.TabIndex = 38;
			this.Button6.Text = "6";
			this.Button6.UseVisualStyleBackColor = false;
			this.Button5.BackColor = Color.Gainsboro;
			this.Button5.FlatStyle = FlatStyle.Flat;
			this.Button5.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button13 = this.Button5;
			location = new Point(103, 141);
			button13.Location = location;
			this.Button5.Name = "Button5";
			Control button14 = this.Button5;
			size = new Size(75, 75);
			button14.Size = size;
			this.Button5.TabIndex = 37;
			this.Button5.Text = "5";
			this.Button5.UseVisualStyleBackColor = false;
			this.Button4.BackColor = Color.Gainsboro;
			this.Button4.FlatStyle = FlatStyle.Flat;
			this.Button4.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button15 = this.Button4;
			location = new Point(22, 141);
			button15.Location = location;
			this.Button4.Name = "Button4";
			Control button16 = this.Button4;
			size = new Size(75, 75);
			button16.Size = size;
			this.Button4.TabIndex = 36;
			this.Button4.Text = "4";
			this.Button4.UseVisualStyleBackColor = false;
			this.Button3.BackColor = Color.Gainsboro;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button17 = this.Button3;
			location = new Point(184, 60);
			button17.Location = location;
			this.Button3.Name = "Button3";
			Control button18 = this.Button3;
			size = new Size(75, 75);
			button18.Size = size;
			this.Button3.TabIndex = 35;
			this.Button3.Text = "3";
			this.Button3.UseVisualStyleBackColor = false;
			this.Button2.BackColor = Color.Gainsboro;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button19 = this.Button2;
			location = new Point(103, 60);
			button19.Location = location;
			this.Button2.Name = "Button2";
			Control button20 = this.Button2;
			size = new Size(75, 75);
			button20.Size = size;
			this.Button2.TabIndex = 34;
			this.Button2.Text = "2";
			this.Button2.UseVisualStyleBackColor = false;
			this.Button1.BackColor = Color.Gainsboro;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button21 = this.Button1;
			location = new Point(22, 60);
			button21.Location = location;
			this.Button1.Name = "Button1";
			Control button22 = this.Button1;
			size = new Size(75, 75);
			button22.Size = size;
			this.Button1.TabIndex = 33;
			this.Button1.Text = "1";
			this.Button1.UseVisualStyleBackColor = false;
			this.DiscountTextBox.Font = new Font("Arial", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control discountTextBox = this.DiscountTextBox;
			location = new Point(140, 21);
			discountTextBox.Location = location;
			this.DiscountTextBox.Name = "DiscountTextBox";
			this.DiscountTextBox.ReadOnly = true;
			Control discountTextBox2 = this.DiscountTextBox;
			size = new Size(78, 32);
			discountTextBox2.Size = size;
			this.DiscountTextBox.TabIndex = 32;
			this.DiscountTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.WhiteSmoke;
			Control label = this.Label1;
			location = new Point(27, 24);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(107, 24);
			label2.Size = size;
			this.Label1.TabIndex = 31;
			this.Label1.Text = "Discount:";
			this.DiscountPercentBTN.Anchor = AnchorStyles.Bottom;
			this.DiscountPercentBTN.BackColor = Color.Lime;
			this.DiscountPercentBTN.Enabled = false;
			this.DiscountPercentBTN.FlatStyle = FlatStyle.Flat;
			this.DiscountPercentBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DiscountPercentBTN.ForeColor = Color.Black;
			Control discountPercentBTN = this.DiscountPercentBTN;
			location = new Point(144, 388);
			discountPercentBTN.Location = location;
			this.DiscountPercentBTN.Name = "DiscountPercentBTN";
			Control discountPercentBTN2 = this.DiscountPercentBTN;
			size = new Size(115, 95);
			discountPercentBTN2.Size = size;
			this.DiscountPercentBTN.TabIndex = 45;
			this.DiscountPercentBTN.Text = "%\r\nDiscount";
			this.DiscountPercentBTN.UseVisualStyleBackColor = false;
			this.Button12.BackColor = Color.Gainsboro;
			this.Button12.FlatStyle = FlatStyle.Flat;
			this.Button12.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button23 = this.Button12;
			location = new Point(103, 303);
			button23.Location = location;
			this.Button12.Name = "Button12";
			Control button24 = this.Button12;
			size = new Size(75, 75);
			button24.Size = size;
			this.Button12.TabIndex = 46;
			this.Button12.Text = ".";
			this.Button12.UseVisualStyleBackColor = false;
			this.ExitBTN.Anchor = AnchorStyles.Bottom;
			this.ExitBTN.BackColor = Color.Crimson;
			this.ExitBTN.FlatStyle = FlatStyle.Popup;
			this.ExitBTN.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ExitBTN.ForeColor = SystemColors.Window;
			Control exitBTN = this.ExitBTN;
			location = new Point(236, 3);
			exitBTN.Location = location;
			this.ExitBTN.Name = "ExitBTN";
			Control exitBTN2 = this.ExitBTN;
			size = new Size(45, 36);
			exitBTN2.Size = size;
			this.ExitBTN.TabIndex = 47;
			this.ExitBTN.Text = "x";
			this.ExitBTN.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.SteelBlue;
			size = new Size(284, 555);
			this.ClientSize = size;
			this.Controls.Add(this.ExitBTN);
			this.Controls.Add(this.Button12);
			this.Controls.Add(this.DiscountPercentBTN);
			this.Controls.Add(this.DiscountTextBox);
			this.Controls.Add(this.NoDiscountBTN);
			this.Controls.Add(this.DiscountAmountBTN);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.Button6);
			this.Controls.Add(this.Button11);
			this.Controls.Add(this.Button5);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.Button7);
			this.Controls.Add(this.Button10);
			this.Controls.Add(this.Button4);
			this.Controls.Add(this.Button2);
			this.Controls.Add(this.Button8);
			this.Controls.Add(this.Button9);
			this.Controls.Add(this.Button3);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "ApplyDiscountManually";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "ApplyDiscountManually";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x060003DE RID: 990 RVA: 0x00021E90 File Offset: 0x00020090
		// (set) Token: 0x060003DF RID: 991 RVA: 0x00021EA8 File Offset: 0x000200A8
		internal virtual Button NoDiscountBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoDiscountBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NoDiscountBTN_Click);
				bool flag = this._NoDiscountBTN != null;
				if (flag)
				{
					this._NoDiscountBTN.Click -= value2;
				}
				this._NoDiscountBTN = value;
				flag = (this._NoDiscountBTN != null);
				if (flag)
				{
					this._NoDiscountBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x060003E0 RID: 992 RVA: 0x00021F08 File Offset: 0x00020108
		// (set) Token: 0x060003E1 RID: 993 RVA: 0x00021F20 File Offset: 0x00020120
		internal virtual Button DiscountAmountBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DiscountAmountBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DiscountAmountBTN_Click);
				bool flag = this._DiscountAmountBTN != null;
				if (flag)
				{
					this._DiscountAmountBTN.Click -= value2;
				}
				this._DiscountAmountBTN = value;
				flag = (this._DiscountAmountBTN != null);
				if (flag)
				{
					this._DiscountAmountBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x060003E2 RID: 994 RVA: 0x00021F80 File Offset: 0x00020180
		// (set) Token: 0x060003E3 RID: 995 RVA: 0x00021F98 File Offset: 0x00020198
		internal virtual Button Button11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button11_Click);
				bool flag = this._Button11 != null;
				if (flag)
				{
					this._Button11.Click -= value2;
				}
				this._Button11 = value;
				flag = (this._Button11 != null);
				if (flag)
				{
					this._Button11.Click += value2;
				}
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x060003E4 RID: 996 RVA: 0x00021FF8 File Offset: 0x000201F8
		// (set) Token: 0x060003E5 RID: 997 RVA: 0x00022010 File Offset: 0x00020210
		internal virtual Button Button10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button10_Click);
				bool flag = this._Button10 != null;
				if (flag)
				{
					this._Button10.Click -= value2;
				}
				this._Button10 = value;
				flag = (this._Button10 != null);
				if (flag)
				{
					this._Button10.Click += value2;
				}
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x060003E6 RID: 998 RVA: 0x00022070 File Offset: 0x00020270
		// (set) Token: 0x060003E7 RID: 999 RVA: 0x00022088 File Offset: 0x00020288
		internal virtual Button Button9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button9_Click);
				bool flag = this._Button9 != null;
				if (flag)
				{
					this._Button9.Click -= value2;
				}
				this._Button9 = value;
				flag = (this._Button9 != null);
				if (flag)
				{
					this._Button9.Click += value2;
				}
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x060003E8 RID: 1000 RVA: 0x000220E8 File Offset: 0x000202E8
		// (set) Token: 0x060003E9 RID: 1001 RVA: 0x00022100 File Offset: 0x00020300
		internal virtual Button Button8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button8_Click);
				bool flag = this._Button8 != null;
				if (flag)
				{
					this._Button8.Click -= value2;
				}
				this._Button8 = value;
				flag = (this._Button8 != null);
				if (flag)
				{
					this._Button8.Click += value2;
				}
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x060003EA RID: 1002 RVA: 0x00022160 File Offset: 0x00020360
		// (set) Token: 0x060003EB RID: 1003 RVA: 0x00022178 File Offset: 0x00020378
		internal virtual Button Button7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button7_Click);
				bool flag = this._Button7 != null;
				if (flag)
				{
					this._Button7.Click -= value2;
				}
				this._Button7 = value;
				flag = (this._Button7 != null);
				if (flag)
				{
					this._Button7.Click += value2;
				}
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x060003EC RID: 1004 RVA: 0x000221D8 File Offset: 0x000203D8
		// (set) Token: 0x060003ED RID: 1005 RVA: 0x000221F0 File Offset: 0x000203F0
		internal virtual Button Button6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button6_Click);
				bool flag = this._Button6 != null;
				if (flag)
				{
					this._Button6.Click -= value2;
				}
				this._Button6 = value;
				flag = (this._Button6 != null);
				if (flag)
				{
					this._Button6.Click += value2;
				}
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x060003EE RID: 1006 RVA: 0x00022250 File Offset: 0x00020450
		// (set) Token: 0x060003EF RID: 1007 RVA: 0x00022268 File Offset: 0x00020468
		internal virtual Button Button5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click);
				bool flag = this._Button5 != null;
				if (flag)
				{
					this._Button5.Click -= value2;
				}
				this._Button5 = value;
				flag = (this._Button5 != null);
				if (flag)
				{
					this._Button5.Click += value2;
				}
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x060003F0 RID: 1008 RVA: 0x000222C8 File Offset: 0x000204C8
		// (set) Token: 0x060003F1 RID: 1009 RVA: 0x000222E0 File Offset: 0x000204E0
		internal virtual Button Button4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				bool flag = this._Button4 != null;
				if (flag)
				{
					this._Button4.Click -= value2;
				}
				this._Button4 = value;
				flag = (this._Button4 != null);
				if (flag)
				{
					this._Button4.Click += value2;
				}
			}
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x060003F2 RID: 1010 RVA: 0x00022340 File Offset: 0x00020540
		// (set) Token: 0x060003F3 RID: 1011 RVA: 0x00022358 File Offset: 0x00020558
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x000223B8 File Offset: 0x000205B8
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x000223D0 File Offset: 0x000205D0
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x060003F6 RID: 1014 RVA: 0x00022430 File Offset: 0x00020630
		// (set) Token: 0x060003F7 RID: 1015 RVA: 0x00022448 File Offset: 0x00020648
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x060003F8 RID: 1016 RVA: 0x000224A8 File Offset: 0x000206A8
		// (set) Token: 0x060003F9 RID: 1017 RVA: 0x0000320E File Offset: 0x0000140E
		internal virtual TextBox DiscountTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DiscountTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DiscountTextBox = value;
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x060003FA RID: 1018 RVA: 0x000224C0 File Offset: 0x000206C0
		// (set) Token: 0x060003FB RID: 1019 RVA: 0x00003218 File Offset: 0x00001418
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x060003FC RID: 1020 RVA: 0x000224D8 File Offset: 0x000206D8
		// (set) Token: 0x060003FD RID: 1021 RVA: 0x000224F0 File Offset: 0x000206F0
		internal virtual Button DiscountPercentBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DiscountPercentBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DiscountPercentBTN_Click);
				bool flag = this._DiscountPercentBTN != null;
				if (flag)
				{
					this._DiscountPercentBTN.Click -= value2;
				}
				this._DiscountPercentBTN = value;
				flag = (this._DiscountPercentBTN != null);
				if (flag)
				{
					this._DiscountPercentBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x060003FE RID: 1022 RVA: 0x00022550 File Offset: 0x00020750
		// (set) Token: 0x060003FF RID: 1023 RVA: 0x00022568 File Offset: 0x00020768
		internal virtual Button Button12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button12_Click);
				bool flag = this._Button12 != null;
				if (flag)
				{
					this._Button12.Click -= value2;
				}
				this._Button12 = value;
				flag = (this._Button12 != null);
				if (flag)
				{
					this._Button12.Click += value2;
				}
			}
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x06000400 RID: 1024 RVA: 0x000225C8 File Offset: 0x000207C8
		// (set) Token: 0x06000401 RID: 1025 RVA: 0x000225E0 File Offset: 0x000207E0
		internal virtual Button ExitBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ExitBTN_Click);
				bool flag = this._ExitBTN != null;
				if (flag)
				{
					this._ExitBTN.Click -= value2;
				}
				this._ExitBTN = value;
				flag = (this._ExitBTN != null);
				if (flag)
				{
					this._ExitBTN.Click += value2;
				}
			}
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x00022640 File Offset: 0x00020840
		private void EnterDiscount()
		{
			bool flag = this.DiscountTextBox.Text.Length > 0;
			if (flag)
			{
				this.DiscountAmountBTN.Enabled = true;
				this.DiscountPercentBTN.Enabled = true;
			}
			this.DiscountAmountBTN.Text = "£" + this.DiscountTextBox.Text + Environment.NewLine + "Discount";
			this.DiscountPercentBTN.Text = this.DiscountTextBox.Text + "%" + Environment.NewLine + "Discount";
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00003222 File Offset: 0x00001422
		private void Button11_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = "";
			this.EnterDiscount();
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0000323E File Offset: 0x0000143E
		private void Button1_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "1";
			this.EnterDiscount();
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x0000326A File Offset: 0x0000146A
		private void Button2_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "2";
			this.EnterDiscount();
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00003296 File Offset: 0x00001496
		private void Button3_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "3";
			this.EnterDiscount();
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x000032C2 File Offset: 0x000014C2
		private void Button4_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "4";
			this.EnterDiscount();
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x000032EE File Offset: 0x000014EE
		private void Button5_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "5";
			this.EnterDiscount();
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x0000331A File Offset: 0x0000151A
		private void Button6_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "6";
			this.EnterDiscount();
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x00003346 File Offset: 0x00001546
		private void Button7_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "7";
			this.EnterDiscount();
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00003372 File Offset: 0x00001572
		private void Button8_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "8";
			this.EnterDiscount();
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x0000339E File Offset: 0x0000159E
		private void Button9_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "9";
			this.EnterDiscount();
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x000033CA File Offset: 0x000015CA
		private void Button10_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + "0";
			this.EnterDiscount();
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x000033F6 File Offset: 0x000015F6
		private void Button12_Click(object sender, EventArgs e)
		{
			this.DiscountTextBox.Text = this.DiscountTextBox.Text + ".";
			this.EnterDiscount();
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x000226D8 File Offset: 0x000208D8
		private void DiscountPercentBTN_Click(object sender, EventArgs e)
		{
			decimal d = new decimal(Conversions.ToInteger(this.DiscountTextBox.Text));
			bool flag = decimal.Compare(d, 100m) < 0;
			if (flag)
			{
				M_Calculates.OrderDiscount = Math.Round(decimal.Divide(decimal.Multiply(M_Calculates.OrderSubTotal, Conversions.ToDecimal(this.DiscountTextBox.Text)), 100m), 2);
				MyProject.Forms.POS_Window.DiscountTextBox.Text = Strings.Format(M_Calculates.OrderDiscount, "0.00");
				M_Calculates.CalculateDelivery();
				MyProject.Forms.Form_Glass.Close();
				this.Close();
			}
			else
			{
				MessageBox.Show("Discount can not be more than 100%");
			}
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x0002279C File Offset: 0x0002099C
		private void DiscountAmountBTN_Click(object sender, EventArgs e)
		{
			decimal num = Math.Round(Conversions.ToDecimal(this.DiscountTextBox.Text), 2);
			bool flag = decimal.Compare(num, M_Calculates.OrderSubTotal) < 0;
			if (flag)
			{
				M_Calculates.OrderDiscount = num;
				MyProject.Forms.POS_Window.DiscountTextBox.Text = Strings.Format(M_Calculates.OrderDiscount, "0.00");
				M_Calculates.CalculateDelivery();
				MyProject.Forms.Form_Glass.Close();
				this.Close();
			}
			else
			{
				MessageBox.Show("Discount can not be more than order's sub total.");
			}
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x00022830 File Offset: 0x00020A30
		private void NoDiscountBTN_Click(object sender, EventArgs e)
		{
			M_Calculates.OrderDiscount = 0m;
			MyProject.Forms.POS_Window.DiscountTextBox.Text = Strings.Format(M_Calculates.OrderDiscount, "0.00");
			M_Calculates.CalculateDelivery();
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x00003422 File Offset: 0x00001622
		private void ExitBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0000343D File Offset: 0x0000163D
		private void ApplyDiscountManually_Load(object sender, EventArgs e)
		{
			this.DiscountAmountBTN.Enabled = false;
			this.DiscountPercentBTN.Enabled = false;
		}

		// Token: 0x04000172 RID: 370
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000173 RID: 371
		private IContainer components;

		// Token: 0x04000174 RID: 372
		[AccessedThroughProperty("NoDiscountBTN")]
		private Button _NoDiscountBTN;

		// Token: 0x04000175 RID: 373
		[AccessedThroughProperty("DiscountAmountBTN")]
		private Button _DiscountAmountBTN;

		// Token: 0x04000176 RID: 374
		[AccessedThroughProperty("Button11")]
		private Button _Button11;

		// Token: 0x04000177 RID: 375
		[AccessedThroughProperty("Button10")]
		private Button _Button10;

		// Token: 0x04000178 RID: 376
		[AccessedThroughProperty("Button9")]
		private Button _Button9;

		// Token: 0x04000179 RID: 377
		[AccessedThroughProperty("Button8")]
		private Button _Button8;

		// Token: 0x0400017A RID: 378
		[AccessedThroughProperty("Button7")]
		private Button _Button7;

		// Token: 0x0400017B RID: 379
		[AccessedThroughProperty("Button6")]
		private Button _Button6;

		// Token: 0x0400017C RID: 380
		[AccessedThroughProperty("Button5")]
		private Button _Button5;

		// Token: 0x0400017D RID: 381
		[AccessedThroughProperty("Button4")]
		private Button _Button4;

		// Token: 0x0400017E RID: 382
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x0400017F RID: 383
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x04000180 RID: 384
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000181 RID: 385
		[AccessedThroughProperty("DiscountTextBox")]
		private TextBox _DiscountTextBox;

		// Token: 0x04000182 RID: 386
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000183 RID: 387
		[AccessedThroughProperty("DiscountPercentBTN")]
		private Button _DiscountPercentBTN;

		// Token: 0x04000184 RID: 388
		[AccessedThroughProperty("Button12")]
		private Button _Button12;

		// Token: 0x04000185 RID: 389
		[AccessedThroughProperty("ExitBTN")]
		private Button _ExitBTN;
	}
}
