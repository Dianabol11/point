using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000019 RID: 25
	[DesignerGenerated]
	public class AssignOrderToDriver : Form
	{
		// Token: 0x06000415 RID: 1045 RVA: 0x00022890 File Offset: 0x00020A90
		[DebuggerNonUserCode]
		public AssignOrderToDriver()
		{
			base.Load += this.AssignOrderToDriver_Load;
			List<WeakReference> _ENCList = AssignOrderToDriver.__ENCList;
			lock (_ENCList)
			{
				AssignOrderToDriver.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x000228FC File Offset: 0x00020AFC
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0002294C File Offset: 0x00020B4C
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.DriversPanel = new Panel();
			this.Panel2 = new Panel();
			this.ExitBTN = new Button();
			this.AddressLBL = new Label();
			this.CityPostcodeLBL = new Label();
			this.Panel2.SuspendLayout();
			this.SuspendLayout();
			this.DriversPanel.BackColor = SystemColors.Control;
			this.DriversPanel.Dock = DockStyle.Fill;
			Control driversPanel = this.DriversPanel;
			Point location = new Point(0, 74);
			driversPanel.Location = location;
			this.DriversPanel.Name = "DriversPanel";
			Control driversPanel2 = this.DriversPanel;
			Size size = new Size(500, 480);
			driversPanel2.Size = size;
			this.DriversPanel.TabIndex = 0;
			this.Panel2.BackColor = Color.LightSteelBlue;
			this.Panel2.Controls.Add(this.CityPostcodeLBL);
			this.Panel2.Controls.Add(this.AddressLBL);
			this.Panel2.Controls.Add(this.ExitBTN);
			this.Panel2.Dock = DockStyle.Top;
			Control panel = this.Panel2;
			location = new Point(0, 0);
			panel.Location = location;
			this.Panel2.Name = "Panel2";
			Control panel2 = this.Panel2;
			size = new Size(500, 74);
			panel2.Size = size;
			this.Panel2.TabIndex = 1;
			this.ExitBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.ExitBTN.BackColor = Color.FromArgb(178, 1, 1);
			this.ExitBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.ExitBTN.FlatStyle = FlatStyle.Flat;
			this.ExitBTN.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ExitBTN.ForeColor = Color.White;
			Control exitBTN = this.ExitBTN;
			location = new Point(430, 12);
			exitBTN.Location = location;
			this.ExitBTN.Name = "ExitBTN";
			Control exitBTN2 = this.ExitBTN;
			size = new Size(58, 52);
			exitBTN2.Size = size;
			this.ExitBTN.TabIndex = 32;
			this.ExitBTN.Text = "X";
			this.ExitBTN.UseVisualStyleBackColor = false;
			this.AddressLBL.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.AddressLBL.AutoSize = true;
			this.AddressLBL.Font = new Font("Arial Narrow", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.AddressLBL.ForeColor = Color.Black;
			Control addressLBL = this.AddressLBL;
			location = new Point(12, 11);
			addressLBL.Location = location;
			this.AddressLBL.Name = "AddressLBL";
			Control addressLBL2 = this.AddressLBL;
			size = new Size(61, 23);
			addressLBL2.Size = size;
			this.AddressLBL.TabIndex = 33;
			this.AddressLBL.Text = "Label1";
			this.CityPostcodeLBL.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.CityPostcodeLBL.AutoSize = true;
			this.CityPostcodeLBL.Font = new Font("Arial Narrow", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.CityPostcodeLBL.ForeColor = Color.Black;
			Control cityPostcodeLBL = this.CityPostcodeLBL;
			location = new Point(12, 41);
			cityPostcodeLBL.Location = location;
			this.CityPostcodeLBL.Name = "CityPostcodeLBL";
			Control cityPostcodeLBL2 = this.CityPostcodeLBL;
			size = new Size(61, 23);
			cityPostcodeLBL2.Size = size;
			this.CityPostcodeLBL.TabIndex = 34;
			this.CityPostcodeLBL.Text = "Label1";
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(500, 554);
			this.ClientSize = size;
			this.Controls.Add(this.DriversPanel);
			this.Controls.Add(this.Panel2);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "AssignOrderToDriver";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "AssignOrderToDriver";
			this.TopMost = true;
			this.Panel2.ResumeLayout(false);
			this.Panel2.PerformLayout();
			this.ResumeLayout(false);
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000418 RID: 1048 RVA: 0x00022DC4 File Offset: 0x00020FC4
		// (set) Token: 0x06000419 RID: 1049 RVA: 0x00003468 File Offset: 0x00001668
		internal virtual Panel DriversPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DriversPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DriversPanel = value;
			}
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x0600041A RID: 1050 RVA: 0x00022DDC File Offset: 0x00020FDC
		// (set) Token: 0x0600041B RID: 1051 RVA: 0x00003472 File Offset: 0x00001672
		internal virtual Panel Panel2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Panel2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Panel2 = value;
			}
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x0600041C RID: 1052 RVA: 0x00022DF4 File Offset: 0x00020FF4
		// (set) Token: 0x0600041D RID: 1053 RVA: 0x00022E0C File Offset: 0x0002100C
		internal virtual Button ExitBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._ExitBTN != null;
				if (flag)
				{
					this._ExitBTN.Click -= value2;
				}
				this._ExitBTN = value;
				flag = (this._ExitBTN != null);
				if (flag)
				{
					this._ExitBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x0600041E RID: 1054 RVA: 0x00022E6C File Offset: 0x0002106C
		// (set) Token: 0x0600041F RID: 1055 RVA: 0x0000347C File Offset: 0x0000167C
		internal virtual Label AddressLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AddressLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AddressLBL = value;
			}
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000420 RID: 1056 RVA: 0x00022E84 File Offset: 0x00021084
		// (set) Token: 0x06000421 RID: 1057 RVA: 0x00003486 File Offset: 0x00001686
		internal virtual Label CityPostcodeLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CityPostcodeLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._CityPostcodeLBL = value;
			}
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x00022E9C File Offset: 0x0002109C
		private void AssignOrderToDriver_Load(object sender, EventArgs e)
		{
			this.AddressLBL.Text = M_Settings.CustomerAddress;
			this.CityPostcodeLBL.Text = M_Settings.CustomerCity + ", " + M_Settings.CustomerPostCode;
			string text = File.ReadAllText(M_Settings.DataFolder + "/_Drivers.txt");
			string[] array = text.Split(new char[]
			{
				'|'
			});
			TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel2 = tableLayoutPanel;
			tableLayoutPanel2.Name = "DriversTLP";
			tableLayoutPanel2.RowCount = array.Count<string>();
			tableLayoutPanel2.ColumnCount = 1;
			tableLayoutPanel2.Dock = DockStyle.Top;
			tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel2.AutoSize = true;
			Control control = tableLayoutPanel2;
			Padding margin = new Padding(0);
			control.Margin = margin;
			tableLayoutPanel2.BackColor = ColorTranslator.FromHtml("Gold");
			checked
			{
				tableLayoutPanel2.Height = (int)Math.Round((double)this.DriversPanel.Height / (double)array.Count<string>());
				this.DriversPanel.Controls.Add(tableLayoutPanel);
				foreach (string text2 in array)
				{
					Button button = new Button();
					Button button2 = button;
					button2.Name = text2;
					button2.ForeColor = ColorTranslator.FromHtml("#ffffff");
					button2.BackColor = ColorTranslator.FromHtml("#1f79e0");
					button2.Dock = DockStyle.Fill;
					button2.FlatStyle = FlatStyle.Popup;
					Control control2 = button2;
					margin = new Padding(0, 0, 0, 0);
					control2.Margin = margin;
					button2.Font = new Font("Century Gothic", 16f, FontStyle.Bold);
					button2.Height = (int)Math.Round((double)this.DriversPanel.Height / (double)array.Count<string>());
					button2.Text = text2.Split(new char[]
					{
						'-'
					})[0].Trim();
					this.DriversPanel.Controls["DriversTLP"].Controls.Add(button);
					button.Click += this.DriverButtonClick;
				}
			}
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x000230D0 File Offset: 0x000212D0
		private void DriverButtonClick(object sender, EventArgs e)
		{
			MyProject.Forms.EditOrders.ActiveOrdersArray[Conversions.ToInteger(M_Settings.OrderToDriverStatus)] = MyProject.Forms.EditOrders.ActiveOrdersArray[Conversions.ToInteger(M_Settings.OrderToDriverStatus)].Replace("DriverName", Conversions.ToString(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null)));
			MyProject.Forms.EditOrders.ActiveOrdersArray[Conversions.ToInteger(M_Settings.OrderToDriverStatus)] = MyProject.Forms.EditOrders.ActiveOrdersArray[Conversions.ToInteger(M_Settings.OrderToDriverStatus)].Replace("in progress", "Complete");
			File.WriteAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt", MyProject.Forms.EditOrders.ActiveOrdersArray);
			M_Settings.OrderToDriverStatus = "no";
			MyProject.Forms.EditOrders.Close();
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x00003490 File Offset: 0x00001690
		private void Button1_Click(object sender, EventArgs e)
		{
			M_Settings.OrderToDriverStatus = "no";
			MyProject.Forms.EditOrders.Close();
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x04000186 RID: 390
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000187 RID: 391
		private IContainer components;

		// Token: 0x04000188 RID: 392
		[AccessedThroughProperty("DriversPanel")]
		private Panel _DriversPanel;

		// Token: 0x04000189 RID: 393
		[AccessedThroughProperty("Panel2")]
		private Panel _Panel2;

		// Token: 0x0400018A RID: 394
		[AccessedThroughProperty("ExitBTN")]
		private Button _ExitBTN;

		// Token: 0x0400018B RID: 395
		[AccessedThroughProperty("AddressLBL")]
		private Label _AddressLBL;

		// Token: 0x0400018C RID: 396
		[AccessedThroughProperty("CityPostcodeLBL")]
		private Label _CityPostcodeLBL;
	}
}
