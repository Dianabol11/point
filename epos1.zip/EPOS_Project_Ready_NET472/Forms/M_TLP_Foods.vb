using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000034 RID: 52
	[StandardModule]
	internal sealed class M_TLP_Foods
	{
		// Token: 0x0600068C RID: 1676 RVA: 0x000402D0 File Offset: 0x0003E4D0
		public static void Create_Food_TLPs()
		{
			try
			{
				foreach (object obj in M_Settings.Category_ArrayList)
				{
					object objectValue = RuntimeHelpers.GetObjectValue(obj);
					string[] array = (string[])NewLateBinding.LateGet(objectValue, null, "Split", new object[]
					{
						new char[]
						{
							'|'
						}
					}, null, null, null);
					M_TLP_Foods.Category_Folder = M_Settings.MenuFolder + "\\" + array[0];
					bool flag = Operators.CompareString(array[1], "no", false) == 0;
					if (flag)
					{
						M_TLP_Foods.TLP_Name = array[0] + "Foods";
						M_TLP_Foods.Count_Row_Column(M_TLP_Foods.Category_Folder);
						M_TLP_Foods.Create_TLP(M_TLP_Foods.TLP_Name);
						M_TLP_Foods.Add_Buttons_in_TLP(M_TLP_Foods.TLP_Name, M_TLP_Foods.Category_Folder);
					}
					flag = (Operators.CompareString(array[1], "no", false) != 0);
					if (flag)
					{
						string[] array2 = array[1].Split(new char[]
						{
							'&'
						});
						foreach (string text in array2)
						{
							M_TLP_Foods.Size_Folder = Conversions.ToString(Operators.AddObject(M_Settings.MenuFolder + "\\" + array[0] + "\\", M_TLP_Foods.Convert_Food_Name_To_File_Name(text)));
							M_TLP_Foods.TLP_Name = array[0] + text + "Foods";
							M_TLP_Foods.Count_Row_Column(M_TLP_Foods.Size_Folder);
							M_TLP_Foods.Create_TLP(M_TLP_Foods.TLP_Name);
							M_TLP_Foods.Add_Buttons_in_TLP(M_TLP_Foods.TLP_Name, M_TLP_Foods.Size_Folder);
						}
					}
				}
			}
			finally
			{
				IEnumerator enumerator;
				bool flag = enumerator is IDisposable;
				if (flag)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x000404B8 File Offset: 0x0003E6B8
		private static void Add_Buttons_in_TLP(object TLP_Name, object Folder)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(Conversions.ToString(Folder));
			FileInfo[] files = directoryInfo.GetFiles("*.txt", SearchOption.TopDirectoryOnly);
			bool flag = files.Count<FileInfo>() > 0;
			checked
			{
				if (flag)
				{
					foreach (FileInfo fileInfo in files)
					{
						bool flag2 = Operators.CompareString(fileInfo.Name, "_Options.txt", false) == 0;
						if (!flag2)
						{
							string text = fileInfo.ToString();
							string text2 = File.ReadAllLines(Conversions.ToString(Operators.AddObject(Operators.AddObject(Folder, "\\"), fileInfo.ToString())))[0];
							string[] array2 = text2.Split(new char[]
							{
								'|'
							});
							flag2 = (Operators.CompareString(array2[0], "no", false) != 0);
							if (flag2)
							{
								M_Settings.Button_bgColor = array2[0];
							}
							string text3 = array2[1];
							string str = M_Settings.Button_bgColor;
							string str2 = M_Settings.Button_TextColor;
							try
							{
								flag2 = (array2[3].Length == 6);
								if (flag2)
								{
									str = array2[3];
								}
								flag2 = (array2[4].Length == 6);
								if (flag2)
								{
									str2 = array2[4];
								}
							}
							catch (Exception ex)
							{
							}
							float value = Convert.ToSingle(Conversions.ToDecimal(array2[2]));
							int num = 16;
							string text4 = Conversions.ToString(M_TLP_Foods.Convert_File_Name_To_Food_Name(fileInfo.ToString()));
							decimal value2 = new decimal((double)(MyProject.Forms.Index.Width - M_Settings.Right_Panel_Width) / (double)M_Settings.columns);
							Font font = new Font("Arial", 16f, FontStyle.Regular);
							font = (Font)M_Settings.GetFontFitIntoButton(text4, Convert.ToInt32(value2), font);
							num = (int)Math.Round((double)Math.Min((float)num, font.Size));
							Button button = new Button();
							Button button2 = button;
							button2.Name = Conversions.ToString(value);
							button2.BackColor = ColorTranslator.FromHtml("#" + str);
							button2.ForeColor = ColorTranslator.FromHtml("#" + str2);
							button2.Dock = DockStyle.Fill;
							button2.AutoSize = false;
							button2.FlatStyle = FlatStyle.Popup;
							Control control = button2;
							Padding margin = new Padding(0, 0, 0, 0);
							control.Margin = margin;
							button2.Font = font;
							button2.Height = (int)Math.Round((double)(MyProject.Forms.Index.Height - M_Settings.Bottom_Panel_Height) / (double)M_Settings.rows);
							button2.Width = (int)Math.Round((double)(MyProject.Forms.Index.Width - M_Settings.Right_Panel_Width) / (double)M_Settings.columns);
							button2.Text = text4;
							object instance = NewLateBinding.LateGet(NewLateBinding.LateGet(MyProject.Forms.POS_Window.Main_Panel.Controls, null, "Item", new object[]
							{
								RuntimeHelpers.GetObjectValue(TLP_Name)
							}, null, null, null), null, "Controls", new object[0], null, null, null);
							Type type = null;
							string memberName = "Add";
							object[] array3 = new object[]
							{
								button,
								text3,
								0
							};
							object[] arguments = array3;
							string[] argumentNames = null;
							Type[] typeArguments = null;
							bool[] array4 = new bool[]
							{
								true,
								true,
								false
							};
							NewLateBinding.LateCall(instance, type, memberName, arguments, argumentNames, typeArguments, array4, true);
							if (array4[0])
							{
								button = (Button)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(Button));
							}
							if (array4[1])
							{
								text3 = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[1]), typeof(string));
							}
							button.Click += M_TLP_Foods.FoodButtonClick;
						}
					}
				}
			}
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x0004087C File Offset: 0x0003EA7C
		private static void FoodButtonClick(object sender, EventArgs e)
		{
			MyProject.Forms.POS_Window.CompletePanel.BringToFront();
			M_Settings.SelectedFood = Conversions.ToString(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null));
			M_Settings.SelectedFoodPrice = Conversions.ToDecimal(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null));
			bool flag = Convert.ToDouble(M_Settings.SelectedFoodPrice) == Conversions.ToDouble("0.01");
			if (flag)
			{
				M_Settings.SelectedFoodPrice = Conversions.ToDecimal("0");
			}
			M_Settings.SelectedOptionTLP = M_Settings.SelectedCategory + M_Settings.SelectedSize + "Options";
			flag = (Operators.CompareString(M_Settings.SelectedCategory.ToLower(), "meal", false) == 0);
			if (flag)
			{
				Meal.MealSelected();
			}
			else
			{
				try
				{
					offers.CheckOfferExistForThisFood(M_Settings.SelectedFoodPrice);
					flag = (decimal.Compare(offers.OfferDiscount, 0m) > 0 & Operators.CompareString(offers.OfferName, "", false) != 0);
					if (flag)
					{
						offers.AddOfferToShoppingCart();
					}
					M_Shopping_Cart.AddFoodToShoppingCart();
					MyProject.Forms.POS_Window.Main_Panel.Controls[M_Settings.SelectedOptionTLP].BringToFront();
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x000409DC File Offset: 0x0003EBDC
		private static void Count_Row_Column(object Folder)
		{
			int num = Directory.GetFiles(Conversions.ToString(Folder), "*.txt*").Count<string>();
			bool flag = num <= 12;
			if (flag)
			{
				M_Settings.rows = 5;
				M_Settings.columns = 3;
			}
			flag = (num > 12);
			if (flag)
			{
				M_Settings.rows = 6;
				M_Settings.columns = 4;
			}
			flag = (num > 20);
			if (flag)
			{
				M_Settings.rows = 6;
				M_Settings.columns = 6;
			}
			flag = (num > 30);
			if (flag)
			{
				M_Settings.rows = 7;
				M_Settings.columns = 7;
			}
			flag = (num > 42);
			checked
			{
				if (flag)
				{
					M_Settings.rows = (int)Math.Round(Math.Ceiling(Math.Sqrt((double)num)));
					M_Settings.columns = M_Settings.rows + 1;
				}
			}
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x00040A8C File Offset: 0x0003EC8C
		private static object Create_TLP(object name)
		{
			TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel2 = tableLayoutPanel;
			tableLayoutPanel2.Name = Conversions.ToString(name);
			tableLayoutPanel2.RowCount = M_Settings.rows;
			tableLayoutPanel2.ColumnCount = M_Settings.columns;
			tableLayoutPanel2.Dock = DockStyle.Fill;
			tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel2.AutoSize = true;
			Control control = tableLayoutPanel2;
			Padding margin = new Padding(0);
			control.Margin = margin;
			tableLayoutPanel2.BackColor = ColorTranslator.FromHtml(M_Settings.TLPs_bgColor);
			checked
			{
				tableLayoutPanel2.Height = (int)Math.Round((double)(MyProject.Forms.Index.Height - M_Settings.Bottom_Panel_Height) / (double)M_Settings.rows);
				tableLayoutPanel2.Width = (int)Math.Round((double)(MyProject.Forms.Index.Width - M_Settings.Right_Panel_Width) / (double)M_Settings.columns);
				MyProject.Forms.POS_Window.Main_Panel.Controls.Add(tableLayoutPanel);
				return tableLayoutPanel;
			}
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x00040B78 File Offset: 0x0003ED78
		public static object Convert_Food_Name_To_File_Name(object s)
		{
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				".",
				"_46_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"\"",
				"_34_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"/",
				"_47_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"\\",
				"_92_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"|",
				"_124_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				":",
				"_58_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"*",
				"_42_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"?",
				"_63_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"<",
				"_60_"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				">",
				"_62_"
			}, null, null, null));
			return s;
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x00040D6C File Offset: 0x0003EF6C
		public static object Convert_File_Name_To_Food_Name(object s)
		{
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_46_",
				"."
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_34_",
				"\""
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_47_",
				"/"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_92_",
				"\\"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_124_",
				"|"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_58_",
				":"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_42_",
				"*"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_63_",
				"?"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_60_",
				"<"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				"_62_",
				">"
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Replace", new object[]
			{
				".txt",
				""
			}, null, null, null));
			return s;
		}

		// Token: 0x040002F0 RID: 752
		private static string Category_Folder;

		// Token: 0x040002F1 RID: 753
		private static string Size_Folder;

		// Token: 0x040002F2 RID: 754
		private static string TLP_Name;
	}
}
