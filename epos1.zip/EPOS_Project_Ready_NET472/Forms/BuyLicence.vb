using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000011 RID: 17
	[DesignerGenerated]
	public class BuyLicence : Form
	{
		// Token: 0x060002AE RID: 686 RVA: 0x0001B32C File Offset: 0x0001952C
		[DebuggerNonUserCode]
		public BuyLicence()
		{
			base.Load += this.BuyLicence_Load;
			List<WeakReference> _ENCList = BuyLicence.__ENCList;
			lock (_ENCList)
			{
				BuyLicence.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x060002AF RID: 687 RVA: 0x0001B398 File Offset: 0x00019598
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x0001B3E8 File Offset: 0x000195E8
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Button1 = new Button();
			this.MsgLabel = new Label();
			this.BuyLicenceBTN = new Button();
			this.SuspendLayout();
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button1.BackColor = Color.Crimson;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 12f, FontStyle.Bold);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			Point location = new Point(23, 110);
			button.Location = location;
			Control button2 = this.Button1;
			Padding margin = new Padding(4);
			button2.Margin = margin;
			this.Button1.Name = "Button1";
			Control button3 = this.Button1;
			Size size = new Size(207, 60);
			button3.Size = size;
			this.Button1.TabIndex = 10;
			this.Button1.Text = "Exit";
			this.Button1.UseVisualStyleBackColor = false;
			this.MsgLabel.AutoSize = true;
			this.MsgLabel.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.MsgLabel.ForeColor = Color.Black;
			Control msgLabel = this.MsgLabel;
			location = new Point(29, 42);
			msgLabel.Location = location;
			Control msgLabel2 = this.MsgLabel;
			margin = new Padding(4, 0, 4, 0);
			msgLabel2.Margin = margin;
			this.MsgLabel.Name = "MsgLabel";
			Control msgLabel3 = this.MsgLabel;
			size = new Size(51, 32);
			msgLabel3.Size = size;
			this.MsgLabel.TabIndex = 51;
			this.MsgLabel.Text = "xxx";
			this.BuyLicenceBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.BuyLicenceBTN.BackColor = Color.LimeGreen;
			this.BuyLicenceBTN.FlatStyle = FlatStyle.Flat;
			this.BuyLicenceBTN.Font = new Font("Arial", 12f, FontStyle.Bold);
			this.BuyLicenceBTN.ForeColor = Color.White;
			Control buyLicenceBTN = this.BuyLicenceBTN;
			location = new Point(263, 110);
			buyLicenceBTN.Location = location;
			Control buyLicenceBTN2 = this.BuyLicenceBTN;
			margin = new Padding(4);
			buyLicenceBTN2.Margin = margin;
			this.BuyLicenceBTN.Name = "BuyLicenceBTN";
			Control buyLicenceBTN3 = this.BuyLicenceBTN;
			size = new Size(207, 60);
			buyLicenceBTN3.Size = size;
			this.BuyLicenceBTN.TabIndex = 52;
			this.BuyLicenceBTN.Text = "Buy Licence";
			this.BuyLicenceBTN.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(9f, 18f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Gold;
			size = new Size(483, 186);
			this.ClientSize = size;
			this.Controls.Add(this.BuyLicenceBTN);
			this.Controls.Add(this.MsgLabel);
			this.Controls.Add(this.Button1);
			this.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.FormBorderStyle = FormBorderStyle.None;
			margin = new Padding(4);
			this.Margin = margin;
			this.Name = "BuyLicence";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "BuyLicence";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x060002B1 RID: 689 RVA: 0x0001B784 File Offset: 0x00019984
		// (set) Token: 0x060002B2 RID: 690 RVA: 0x0001B79C File Offset: 0x0001999C
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x060002B3 RID: 691 RVA: 0x0001B7FC File Offset: 0x000199FC
		// (set) Token: 0x060002B4 RID: 692 RVA: 0x00002A2C File Offset: 0x00000C2C
		internal virtual Label MsgLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MsgLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._MsgLabel = value;
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x060002B5 RID: 693 RVA: 0x0001B814 File Offset: 0x00019A14
		// (set) Token: 0x060002B6 RID: 694 RVA: 0x0001B82C File Offset: 0x00019A2C
		internal virtual Button BuyLicenceBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BuyLicenceBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.BuyLicenceBTN_Click);
				bool flag = this._BuyLicenceBTN != null;
				if (flag)
				{
					this._BuyLicenceBTN.Click -= value2;
				}
				this._BuyLicenceBTN = value;
				flag = (this._BuyLicenceBTN != null);
				if (flag)
				{
					this._BuyLicenceBTN.Click += value2;
				}
			}
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x0001B88C File Offset: 0x00019A8C
		private void Button1_Click(object sender, EventArgs e)
		{
			bool flag = M_Settings.SoftwareExpiryDaysLeft <= 0;
			if (flag)
			{
				MyProject.Forms.Index.Close();
			}
			flag = (M_Settings.SoftwareExpiryDaysLeft > 0);
			if (flag)
			{
				MyProject.Forms.Index.Enabled = true;
				this.Close();
			}
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x0001B8E0 File Offset: 0x00019AE0
		private void BuyLicence_Load(object sender, EventArgs e)
		{
			string text = MySettingsProperty.Settings.SoftwareExpiryDate.ToString();
			text = text.Insert(6, "/");
			text = text.Insert(4, "/");
			string text2 = Conversions.ToString(NewLateBinding.LateGet(M_Settings.CurrentDate(), null, "Insert", new object[]
			{
				6,
				"/"
			}, null, null, null));
			text2 = text2.Insert(4, "/");
			DateTime dateTime = Conversions.ToDate("#" + text + " 10:00:00 AM#");
			DateTime dateTime2 = Conversions.ToDate("#" + text2 + " 10:00:00 AM#");
			M_Settings.SoftwareExpiryDaysLeft = (dateTime.Date - dateTime2.Date).Days;
			bool flag = M_Settings.SoftwareExpiryDaysLeft > 0;
			if (flag)
			{
				this.MsgLabel.Text = "The license will expire in " + M_Settings.SoftwareExpiryDaysLeft.ToString() + " days.";
			}
			flag = (M_Settings.SoftwareExpiryDaysLeft <= 0);
			if (flag)
			{
				this.MsgLabel.Text = "The software's license has expired.";
			}
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x0001BA04 File Offset: 0x00019C04
		private void BuyLicenceBTN_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.BuyLicenceBTN.Text, "Buy Licence", false) == 0;
			if (flag)
			{
				string text = "http://" + Online.SoftwareDomain;
				text += "/_All_Computers_Settings/buy_licence.php?action=abolfazlsedighigilani";
				text = text + "&folder=" + MySettingsProperty.Settings.ServerFolderName;
				Process.Start(text);
				Application.Exit();
			}
			flag = (Operators.CompareString(this.BuyLicenceBTN.Text, "Buy Licence", false) == 0 & Operators.CompareString(MySettingsProperty.Settings.BusinessName, "Softeware Demo Version", false) == 0);
			if (flag)
			{
				string text2 = "http://" + Online.SoftwareDomain;
				text2 += "/_All_Computers_Settings/buy_licence.php?action=abolfazlsedighigilani";
				text2 += "&folder=&type=tmycidnpcfnoffm";
				Process.Start(text2);
				MyProject.Forms.General_Settings.ResetToFactory();
				StreamWriter streamWriter = new StreamWriter("settings.txt", true);
				streamWriter.WriteLine(string.Concat(new string[]
				{
					"n",
					Environment.NewLine,
					"y",
					Environment.NewLine,
					"ARTECH AD102"
				}));
				streamWriter.Close();
				Application.Exit();
			}
		}

		// Token: 0x060002BA RID: 698 RVA: 0x0001BB48 File Offset: 0x00019D48
		public object CheckLicenseNo(object LN)
		{
			string result = "";
			ArrayList arrayList = new ArrayList();
			string businessTel = MySettingsProperty.Settings.BusinessTel;
			string text = MySettingsProperty.Settings.BusinessPostcode;
			string text2 = MySettingsProperty.Settings.BusinessName;
			text2 = text2.ToUpper();
			string value = Conversions.ToString(this.First2(businessTel));
			string value2 = Conversions.ToString(this.Last2(businessTel));
			string text3 = Conversions.ToString(this.First2(text2));
			string text4 = Conversions.ToString(this.Last2(text2));
			text = Regex.Replace(text, "[^\\d]", " ");
			string value3 = Conversions.ToString(this.First2(text));
			string value4 = Conversions.ToString(this.Last2(text));
			string text5 = text3.Substring(0, 1);
			string text6 = text3.Substring(1, 1);
			string text7 = text4.Substring(0, 1);
			string text8 = text4.Substring(1, 1);
			text5 = Conversions.ToString(this.LtoN(text5));
			text6 = Conversions.ToString(this.LtoN(text6));
			text7 = Conversions.ToString(this.LtoN(text7));
			text8 = Conversions.ToString(this.LtoN(text8));
			arrayList.Add(value);
			arrayList.Add(value2);
			arrayList.Add(text5);
			arrayList.Add(text6);
			arrayList.Add(text7);
			arrayList.Add(text8);
			arrayList.Add(value3);
			arrayList.Add(value4);
			string text9 = Conversions.ToString(LN);
			bool flag;
			try
			{
				foreach (object obj in arrayList)
				{
					object objectValue = RuntimeHelpers.GetObjectValue(obj);
					text9 = Strings.Replace(text9, Conversions.ToString(objectValue), "", 1, 1, CompareMethod.Binary);
				}
			}
			finally
			{
				IEnumerator enumerator;
				flag = (enumerator is IDisposable);
				if (flag)
				{
					(enumerator as IDisposable).Dispose();
				}
			}
			flag = (Operators.CompareString(text9, "", false) == 0);
			if (flag)
			{
				result = "LicenseOK";
			}
			return result;
		}

		// Token: 0x060002BB RID: 699 RVA: 0x0001BD4C File Offset: 0x00019F4C
		private object LtoN(object L)
		{
			bool flag = Operators.ConditionalCompareObjectEqual(L, "A", false);
			if (flag)
			{
				L = "50";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "B", false);
			if (flag)
			{
				L = "51";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "C", false);
			if (flag)
			{
				L = "52";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "D", false);
			if (flag)
			{
				L = "53";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "E", false);
			if (flag)
			{
				L = "54";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "F", false);
			if (flag)
			{
				L = "55";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "G", false);
			if (flag)
			{
				L = "56";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "H", false);
			if (flag)
			{
				L = "57";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "I", false);
			if (flag)
			{
				L = "58";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "J", false);
			if (flag)
			{
				L = "59";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "K", false);
			if (flag)
			{
				L = "60";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "L", false);
			if (flag)
			{
				L = "61";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "M", false);
			if (flag)
			{
				L = "62";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "N", false);
			if (flag)
			{
				L = "63";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "O", false);
			if (flag)
			{
				L = "64";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "P", false);
			if (flag)
			{
				L = "65";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "Q", false);
			if (flag)
			{
				L = "66";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "R", false);
			if (flag)
			{
				L = "67";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "S", false);
			if (flag)
			{
				L = "68";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "T", false);
			if (flag)
			{
				L = "69";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "U", false);
			if (flag)
			{
				L = "70";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "V", false);
			if (flag)
			{
				L = "71";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "W", false);
			if (flag)
			{
				L = "72";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "X", false);
			if (flag)
			{
				L = "73";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "Y", false);
			if (flag)
			{
				L = "74";
			}
			flag = Operators.ConditionalCompareObjectEqual(L, "Z", false);
			if (flag)
			{
				L = "75";
			}
			return L;
		}

		// Token: 0x060002BC RID: 700 RVA: 0x0001BFB8 File Offset: 0x0001A1B8
		private object First2(object s)
		{
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "replace", new object[]
			{
				" ",
				""
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Substring", new object[]
			{
				0,
				2
			}, null, null, null));
			return s;
		}

		// Token: 0x060002BD RID: 701 RVA: 0x0001C030 File Offset: 0x0001A230
		private object Last2(object s)
		{
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "replace", new object[]
			{
				" ",
				""
			}, null, null, null));
			s = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(s, null, "Substring", new object[]
			{
				Operators.SubtractObject(NewLateBinding.LateGet(s, null, "Length", new object[0], null, null, null), 2),
				2
			}, null, null, null));
			return s;
		}

		// Token: 0x04000138 RID: 312
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000139 RID: 313
		private IContainer components;

		// Token: 0x0400013A RID: 314
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x0400013B RID: 315
		[AccessedThroughProperty("MsgLabel")]
		private Label _MsgLabel;

		// Token: 0x0400013C RID: 316
		[AccessedThroughProperty("BuyLicenceBTN")]
		private Button _BuyLicenceBTN;
	}
}
