using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200001E RID: 30
	[DesignerGenerated]
	public class FreeFoodsOffer : Form
	{
		// Token: 0x060004F1 RID: 1265 RVA: 0x00029D50 File Offset: 0x00027F50
		public FreeFoodsOffer()
		{
			base.Load += this.FreeFoodsOffer_Load;
			List<WeakReference> _ENCList = FreeFoodsOffer.__ENCList;
			lock (_ENCList)
			{
				FreeFoodsOffer.__ENCList.Add(new WeakReference(this));
			}
			this.DiscountAmount = 0m;
			this.ServiceChargeAmount = 0m;
			this.NumberOfTotalOrders = 0;
			this.NumberOfDeliveryOrders = 0;
			this.NumberOfTakeCollOrders = 0;
			this.NumberOfDineInOrders = 0;
			this.NumberOfCancelledOrders = 0;
			this.DeliveryAmount = 0m;
			this.TakeCollAmount = 0m;
			this.DineInAmount = 0m;
			this.CancelAmount = 0m;
			this.SubTotalAmount = 0m;
			this.DeliveryChargeAmount = 0m;
			this.TotalAmount = 0m;
			this.DeliveryPaidAmount = 0m;
			this.DeliveryNotPaidAmount = 0m;
			this.TakeCollCashAmount = 0m;
			this.TakeCollPaidAmount = 0m;
			this.DineInCashAmount = 0m;
			this.DineInPaidAmount = 0m;
			this.CancelCashAmount = 0m;
			this.CancelPaidAmount = 0m;
			this.x = 0;
			this.y = 0;
			this.MyPrintFont = new Font(this.PrintFontType, 8f, FontStyle.Bold);
			this.DividerLine = "=======================================================";
			this.PrintFontType = "Century Gothic";
			this.StringLengthForPrint = default(SizeF);
			this.PrintWholeWidthArea = 275;
			this.ShopNameFontSize = 13;
			this.ShopNameLineSpace = 25;
			this.ShopAddressFontSize = 8;
			this.ShopAddressLineSpace = 12;
			this.ShopNumberFontSize = 15;
			this.PhoneNumberLineSpace = 25;
			this.WebsiteFontLine = 10;
			this.WebsiteLineSpace = Conversions.ToString(25);
			this.CalculationFontSize = 10;
			this.CalculationLineSpace = 17;
			this.InitializeComponent();
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x00029F50 File Offset: 0x00028150
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x00029FA0 File Offset: 0x000281A0
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.EndSessionNoBTN = new Button();
			this.EndSessionYesBTN = new Button();
			this.EndSessionLabel = new Label();
			this.ExitCancel = new Button();
			this.PrintDocument1 = new PrintDocument();
			this.PrintDocument2 = new PrintDocument();
			this.Label1 = new Label();
			this.Button1 = new Button();
			this.SuspendLayout();
			this.EndSessionNoBTN.BackColor = Color.FromArgb(0, 192, 0);
			this.EndSessionNoBTN.FlatAppearance.BorderColor = Color.White;
			this.EndSessionNoBTN.FlatAppearance.BorderSize = 2;
			this.EndSessionNoBTN.FlatAppearance.CheckedBackColor = Color.Silver;
			this.EndSessionNoBTN.FlatStyle = FlatStyle.Flat;
			this.EndSessionNoBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.EndSessionNoBTN.ForeColor = Color.White;
			Control endSessionNoBTN = this.EndSessionNoBTN;
			Point location = new Point(24, 260);
			endSessionNoBTN.Location = location;
			this.EndSessionNoBTN.Name = "EndSessionNoBTN";
			Control endSessionNoBTN2 = this.EndSessionNoBTN;
			Size size = new Size(383, 111);
			endSessionNoBTN2.Size = size;
			this.EndSessionNoBTN.TabIndex = 0;
			this.EndSessionNoBTN.Text = "ONLY Print today's sales report";
			this.EndSessionNoBTN.UseVisualStyleBackColor = false;
			this.EndSessionYesBTN.BackColor = Color.Crimson;
			this.EndSessionYesBTN.FlatAppearance.BorderColor = Color.White;
			this.EndSessionYesBTN.FlatAppearance.BorderSize = 2;
			this.EndSessionYesBTN.FlatAppearance.CheckedBackColor = Color.Silver;
			this.EndSessionYesBTN.FlatStyle = FlatStyle.Flat;
			this.EndSessionYesBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.EndSessionYesBTN.ForeColor = Color.White;
			Control endSessionYesBTN = this.EndSessionYesBTN;
			location = new Point(24, 118);
			endSessionYesBTN.Location = location;
			this.EndSessionYesBTN.Name = "EndSessionYesBTN";
			Control endSessionYesBTN2 = this.EndSessionYesBTN;
			size = new Size(530, 112);
			endSessionYesBTN2.Size = size;
			this.EndSessionYesBTN.TabIndex = 1;
			this.EndSessionYesBTN.Text = "Print today's sales + Archive orders";
			this.EndSessionYesBTN.UseVisualStyleBackColor = false;
			this.EndSessionLabel.AutoSize = true;
			this.EndSessionLabel.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.EndSessionLabel.ForeColor = Color.Black;
			Control endSessionLabel = this.EndSessionLabel;
			location = new Point(77, 29);
			endSessionLabel.Location = location;
			this.EndSessionLabel.Name = "EndSessionLabel";
			Control endSessionLabel2 = this.EndSessionLabel;
			size = new Size(420, 32);
			endSessionLabel2.Size = size;
			this.EndSessionLabel.TabIndex = 2;
			this.EndSessionLabel.Text = "End of today and Exit Software";
			this.ExitCancel.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.ExitCancel.BackColor = Color.Crimson;
			this.ExitCancel.FlatAppearance.BorderColor = Color.White;
			this.ExitCancel.FlatAppearance.BorderSize = 2;
			this.ExitCancel.FlatAppearance.CheckedBackColor = Color.Silver;
			this.ExitCancel.FlatStyle = FlatStyle.Flat;
			this.ExitCancel.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.ExitCancel.ForeColor = Color.White;
			Control exitCancel = this.ExitCancel;
			location = new Point(532, 7);
			exitCancel.Location = location;
			this.ExitCancel.Name = "ExitCancel";
			Control exitCancel2 = this.ExitCancel;
			size = new Size(40, 40);
			exitCancel2.Size = size;
			this.ExitCancel.TabIndex = 3;
			this.ExitCancel.Text = "X";
			this.ExitCancel.UseVisualStyleBackColor = false;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control label = this.Label1;
			location = new Point(45, 97);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(477, 18);
			label2.Size = size;
			this.Label1.TabIndex = 4;
			this.Label1.Text = "If you select this option, the system will close today and start a new day:";
			this.Button1.BackColor = Color.FromArgb(0, 192, 0);
			this.Button1.FlatAppearance.BorderColor = Color.White;
			this.Button1.FlatAppearance.BorderSize = 2;
			this.Button1.FlatAppearance.CheckedBackColor = Color.Silver;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(413, 260);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			size = new Size(141, 111);
			button2.Size = size;
			this.Button1.TabIndex = 5;
			this.Button1.Text = "Exit only";
			this.Button1.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Gold;
			size = new Size(579, 396);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.ExitCancel);
			this.Controls.Add(this.EndSessionLabel);
			this.Controls.Add(this.EndSessionYesBTN);
			this.Controls.Add(this.EndSessionNoBTN);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "FreeFoodsOffer";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "End_Session";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x060004F4 RID: 1268 RVA: 0x0002A654 File Offset: 0x00028854
		// (set) Token: 0x060004F5 RID: 1269 RVA: 0x0002A66C File Offset: 0x0002886C
		internal virtual Button EndSessionNoBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EndSessionNoBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._EndSessionNoBTN != null;
				if (flag)
				{
					this._EndSessionNoBTN.Click -= value2;
				}
				this._EndSessionNoBTN = value;
				flag = (this._EndSessionNoBTN != null);
				if (flag)
				{
					this._EndSessionNoBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x060004F6 RID: 1270 RVA: 0x0002A6CC File Offset: 0x000288CC
		// (set) Token: 0x060004F7 RID: 1271 RVA: 0x0002A6E4 File Offset: 0x000288E4
		internal virtual Button EndSessionYesBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EndSessionYesBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._EndSessionYesBTN != null;
				if (flag)
				{
					this._EndSessionYesBTN.Click -= value2;
				}
				this._EndSessionYesBTN = value;
				flag = (this._EndSessionYesBTN != null);
				if (flag)
				{
					this._EndSessionYesBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x060004F8 RID: 1272 RVA: 0x0002A744 File Offset: 0x00028944
		// (set) Token: 0x060004F9 RID: 1273 RVA: 0x00003A35 File Offset: 0x00001C35
		internal virtual Label EndSessionLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EndSessionLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._EndSessionLabel = value;
			}
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x060004FA RID: 1274 RVA: 0x0002A75C File Offset: 0x0002895C
		// (set) Token: 0x060004FB RID: 1275 RVA: 0x0002A774 File Offset: 0x00028974
		internal virtual Button ExitCancel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitCancel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ExitCancel_Click);
				bool flag = this._ExitCancel != null;
				if (flag)
				{
					this._ExitCancel.Click -= value2;
				}
				this._ExitCancel = value;
				flag = (this._ExitCancel != null);
				if (flag)
				{
					this._ExitCancel.Click += value2;
				}
			}
		}

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x060004FC RID: 1276 RVA: 0x0002A7D4 File Offset: 0x000289D4
		// (set) Token: 0x060004FD RID: 1277 RVA: 0x0002A7EC File Offset: 0x000289EC
		internal virtual PrintDocument PrintDocument1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PrintDocument1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				PrintPageEventHandler value2 = new PrintPageEventHandler(this.PrintDocument1_PrintPage);
				bool flag = this._PrintDocument1 != null;
				if (flag)
				{
					this._PrintDocument1.PrintPage -= value2;
				}
				this._PrintDocument1 = value;
				flag = (this._PrintDocument1 != null);
				if (flag)
				{
					this._PrintDocument1.PrintPage += value2;
				}
			}
		}

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x060004FE RID: 1278 RVA: 0x0002A84C File Offset: 0x00028A4C
		// (set) Token: 0x060004FF RID: 1279 RVA: 0x0002A864 File Offset: 0x00028A64
		internal virtual PrintDocument PrintDocument2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PrintDocument2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				PrintPageEventHandler value2 = new PrintPageEventHandler(this.PrintDocument2_PrintPage);
				bool flag = this._PrintDocument2 != null;
				if (flag)
				{
					this._PrintDocument2.PrintPage -= value2;
				}
				this._PrintDocument2 = value;
				flag = (this._PrintDocument2 != null);
				if (flag)
				{
					this._PrintDocument2.PrintPage += value2;
				}
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x06000500 RID: 1280 RVA: 0x0002A8C4 File Offset: 0x00028AC4
		// (set) Token: 0x06000501 RID: 1281 RVA: 0x00003A3F File Offset: 0x00001C3F
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x06000502 RID: 1282 RVA: 0x0002A8DC File Offset: 0x00028ADC
		// (set) Token: 0x06000503 RID: 1283 RVA: 0x0002A8F4 File Offset: 0x00028AF4
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click_1);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x0002A954 File Offset: 0x00028B54
		private void PrintDocument1_PrintPage(object sender, PrintPageEventArgs e)
		{
			int num = 0;
			num = Conversions.ToInteger(this.PrintHeader(e, num));
			this.PrintAllCalculations(e, num);
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x0002A988 File Offset: 0x00028B88
		public void CalculateEndSession(object FolderDay)
		{
			string[] array = File.ReadAllLines(Conversions.ToString(Operators.AddObject(Operators.AddObject(M_Settings.DataFolder + "\\order_history\\", FolderDay), "\\_TodayOrderList.txt")));
			foreach (string text in array)
			{
				string[] array3 = text.Split(new char[]
				{
					'|'
				});
				bool flag = array3.Count<string>() == 17;
				if (flag)
				{
					bool flag2 = Operators.CompareString(array3[3], "Cancelled", false) == 0;
					if (flag2)
					{
						checked
						{
							this.NumberOfCancelledOrders++;
						}
						this.CancelAmount = new decimal(Convert.ToDouble(this.CancelAmount) + Conversions.ToDouble(array3[15]));
						flag2 = (Operators.CompareString(array3[4], "Cash", false) == 0);
						if (flag2)
						{
							this.CancelCashAmount = new decimal(Convert.ToDouble(this.CancelCashAmount) + Conversions.ToDouble(array3[15]));
						}
						flag2 = (Operators.CompareString(array3[4], "NOT PAID", false) == 0);
						if (flag2)
						{
							this.CancelCashAmount = new decimal(Convert.ToDouble(this.CancelCashAmount) + Conversions.ToDouble(array3[15]));
						}
						flag2 = (Operators.CompareString(array3[4], "PAID", false) == 0);
						if (flag2)
						{
							this.CancelPaidAmount = new decimal(Convert.ToDouble(this.CancelPaidAmount) + Conversions.ToDouble(array3[15]));
						}
						flag2 = (Operators.CompareString(array3[4], "Credit/Debit Card", false) == 0);
						if (flag2)
						{
							this.CancelPaidAmount = new decimal(Convert.ToDouble(this.CancelPaidAmount) + Conversions.ToDouble(array3[15]));
						}
					}
					flag2 = (Operators.CompareString(array3[3], "Cancelled", false) != 0);
					if (flag2)
					{
						string left = array3[2];
						flag = (Operators.CompareString(left, "Delivery", false) == 0);
						if (flag)
						{
							checked
							{
								this.NumberOfTotalOrders++;
								this.NumberOfDeliveryOrders++;
							}
							this.DeliveryAmount = new decimal(Convert.ToDouble(this.DeliveryAmount) + Conversions.ToDouble(array3[15]));
							this.SubTotalAmount = new decimal(Convert.ToDouble(this.SubTotalAmount) + Conversions.ToDouble(array3[11]));
							this.DiscountAmount = new decimal(Convert.ToDouble(this.DiscountAmount) + Conversions.ToDouble(array3[12]));
							this.DeliveryChargeAmount = new decimal(Convert.ToDouble(this.DeliveryChargeAmount) + Conversions.ToDouble(array3[13]));
							this.ServiceChargeAmount = new decimal(Convert.ToDouble(this.ServiceChargeAmount) + Conversions.ToDouble(array3[14]));
							this.TotalAmount = new decimal(Convert.ToDouble(this.TotalAmount) + Conversions.ToDouble(array3[15]));
							flag2 = (Operators.CompareString(array3[4], "PAID", false) == 0);
							if (flag2)
							{
								this.DeliveryPaidAmount = new decimal(Convert.ToDouble(this.DeliveryPaidAmount) + Conversions.ToDouble(array3[15]));
							}
							flag2 = (Operators.CompareString(array3[4], "NOT PAID", false) == 0);
							if (flag2)
							{
								this.DeliveryNotPaidAmount = new decimal(Convert.ToDouble(this.DeliveryNotPaidAmount) + Conversions.ToDouble(array3[15]));
							}
						}
						else
						{
							flag2 = (Operators.CompareString(left, "Takeaway", false) == 0 || Operators.CompareString(left, "Collection", false) == 0);
							if (flag2)
							{
								checked
								{
									this.NumberOfTotalOrders++;
									this.NumberOfTakeCollOrders++;
								}
								this.TakeCollAmount = new decimal(Convert.ToDouble(this.TakeCollAmount) + Conversions.ToDouble(array3[15]));
								this.SubTotalAmount = new decimal(Convert.ToDouble(this.SubTotalAmount) + Conversions.ToDouble(array3[11]));
								this.DiscountAmount = new decimal(Convert.ToDouble(this.DiscountAmount) + Conversions.ToDouble(array3[12]));
								this.DeliveryChargeAmount = new decimal(Convert.ToDouble(this.DeliveryChargeAmount) + Conversions.ToDouble(array3[13]));
								this.ServiceChargeAmount = new decimal(Convert.ToDouble(this.ServiceChargeAmount) + Conversions.ToDouble(array3[14]));
								this.TotalAmount = new decimal(Convert.ToDouble(this.TotalAmount) + Conversions.ToDouble(array3[15]));
								flag2 = (Operators.CompareString(array3[4], "Cash", false) == 0);
								if (flag2)
								{
									this.TakeCollCashAmount = new decimal(Convert.ToDouble(this.TakeCollCashAmount) + Conversions.ToDouble(array3[15]));
								}
								flag2 = (Operators.CompareString(array3[4], "Cash", false) != 0);
								if (flag2)
								{
									this.TakeCollPaidAmount = new decimal(Convert.ToDouble(this.TakeCollPaidAmount) + Conversions.ToDouble(array3[15]));
								}
							}
							else
							{
								flag2 = (Operators.CompareString(left, "Dine In", false) == 0);
								if (flag2)
								{
									checked
									{
										this.NumberOfTotalOrders++;
										this.NumberOfDineInOrders++;
									}
									this.DineInAmount = new decimal(Convert.ToDouble(this.DineInAmount) + Conversions.ToDouble(array3[15]));
									this.SubTotalAmount = new decimal(Convert.ToDouble(this.SubTotalAmount) + Conversions.ToDouble(array3[11]));
									this.DiscountAmount = new decimal(Convert.ToDouble(this.DiscountAmount) + Conversions.ToDouble(array3[12]));
									this.ServiceChargeAmount = new decimal(Convert.ToDouble(this.ServiceChargeAmount) + Conversions.ToDouble(array3[14]));
									this.TotalAmount = new decimal(Convert.ToDouble(this.TotalAmount) + Conversions.ToDouble(array3[15]));
									flag2 = (Operators.CompareString(array3[4], "Cash", false) == 0);
									if (flag2)
									{
										this.DineInCashAmount = new decimal(Convert.ToDouble(this.DineInCashAmount) + Conversions.ToDouble(array3[15]));
									}
									flag2 = (Operators.CompareString(array3[4], "Cash", false) != 0);
									if (flag2)
									{
										this.DineInPaidAmount = new decimal(Convert.ToDouble(this.DineInPaidAmount) + Conversions.ToDouble(array3[15]));
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x0002AFA8 File Offset: 0x000291A8
		public void PrintAllCalculations(object e, object offset)
		{
			this.x = 0;
			object instance = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type = null;
			string memberName = "DrawString";
			object[] array = new object[]
			{
				"CANCELLED:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments = array;
			string[] argumentNames = null;
			Type[] typeArguments = null;
			bool[] array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance, type, memberName, arguments, argumentNames, typeArguments, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			object instance2 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type2 = null;
			string memberName2 = "DrawString";
			object[] array3 = new object[]
			{
				"No. of cancelled orders: " + this.NumberOfCancelledOrders.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments2 = array3;
			string[] argumentNames2 = null;
			Type[] typeArguments2 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance2, type2, memberName2, arguments2, argumentNames2, typeArguments2, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance3 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type3 = null;
			string memberName3 = "DrawString";
			array3 = new object[]
			{
				"Paid/Card: £" + this.CancelPaidAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments3 = array3;
			string[] argumentNames3 = null;
			Type[] typeArguments3 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance3, type3, memberName3, arguments3, argumentNames3, typeArguments3, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance4 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type4 = null;
			string memberName4 = "DrawString";
			array3 = new object[]
			{
				"Cash: £" + this.CancelCashAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments4 = array3;
			string[] argumentNames4 = null;
			Type[] typeArguments4 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance4, type4, memberName4, arguments4, argumentNames4, typeArguments4, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance5 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type5 = null;
			string memberName5 = "DrawString";
			array3 = new object[]
			{
				"Total: £" + this.CancelAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments5 = array3;
			string[] argumentNames5 = null;
			Type[] typeArguments5 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance5, type5, memberName5, arguments5, argumentNames5, typeArguments5, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance6 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type6 = null;
			string memberName6 = "DrawString";
			array3 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments6 = array3;
			string[] argumentNames6 = null;
			Type[] typeArguments6 = null;
			array2 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance6, type6, memberName6, arguments6, argumentNames6, typeArguments6, array2, true);
			if (array2[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
			}
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance7 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type7 = null;
			string memberName7 = "DrawString";
			array3 = new object[]
			{
				"DELIVERY:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments7 = array3;
			string[] argumentNames7 = null;
			Type[] typeArguments7 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance7, type7, memberName7, arguments7, argumentNames7, typeArguments7, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			object instance8 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type8 = null;
			string memberName8 = "DrawString";
			array3 = new object[]
			{
				"No. of Delivery orders: " + this.NumberOfDeliveryOrders.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments8 = array3;
			string[] argumentNames8 = null;
			Type[] typeArguments8 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance8, type8, memberName8, arguments8, argumentNames8, typeArguments8, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance9 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type9 = null;
			string memberName9 = "DrawString";
			array3 = new object[]
			{
				"PAID: £" + this.DeliveryPaidAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments9 = array3;
			string[] argumentNames9 = null;
			Type[] typeArguments9 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance9, type9, memberName9, arguments9, argumentNames9, typeArguments9, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance10 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type10 = null;
			string memberName10 = "DrawString";
			array3 = new object[]
			{
				"NOT PAID: £" + this.DeliveryNotPaidAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments10 = array3;
			string[] argumentNames10 = null;
			Type[] typeArguments10 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance10, type10, memberName10, arguments10, argumentNames10, typeArguments10, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance11 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type11 = null;
			string memberName11 = "DrawString";
			array3 = new object[]
			{
				"Total: £" + this.DeliveryAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments11 = array3;
			string[] argumentNames11 = null;
			Type[] typeArguments11 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance11, type11, memberName11, arguments11, argumentNames11, typeArguments11, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance12 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type12 = null;
			string memberName12 = "DrawString";
			array3 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments12 = array3;
			string[] argumentNames12 = null;
			Type[] typeArguments12 = null;
			array2 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance12, type12, memberName12, arguments12, argumentNames12, typeArguments12, array2, true);
			if (array2[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
			}
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance13 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type13 = null;
			string memberName13 = "DrawString";
			array3 = new object[]
			{
				"TAKEAWAY/COLLECTION:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments13 = array3;
			string[] argumentNames13 = null;
			Type[] typeArguments13 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance13, type13, memberName13, arguments13, argumentNames13, typeArguments13, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			object instance14 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type14 = null;
			string memberName14 = "DrawString";
			array3 = new object[]
			{
				"No. of Takeaway/Collection orders: " + this.NumberOfTakeCollOrders.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments14 = array3;
			string[] argumentNames14 = null;
			Type[] typeArguments14 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance14, type14, memberName14, arguments14, argumentNames14, typeArguments14, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance15 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type15 = null;
			string memberName15 = "DrawString";
			array3 = new object[]
			{
				"Card: £" + this.TakeCollPaidAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments15 = array3;
			string[] argumentNames15 = null;
			Type[] typeArguments15 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance15, type15, memberName15, arguments15, argumentNames15, typeArguments15, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance16 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type16 = null;
			string memberName16 = "DrawString";
			array3 = new object[]
			{
				"Cash: £" + this.TakeCollCashAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments16 = array3;
			string[] argumentNames16 = null;
			Type[] typeArguments16 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance16, type16, memberName16, arguments16, argumentNames16, typeArguments16, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance17 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type17 = null;
			string memberName17 = "DrawString";
			array3 = new object[]
			{
				"Total: £" + this.TakeCollAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments17 = array3;
			string[] argumentNames17 = null;
			Type[] typeArguments17 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance17, type17, memberName17, arguments17, argumentNames17, typeArguments17, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance18 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type18 = null;
			string memberName18 = "DrawString";
			array3 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments18 = array3;
			string[] argumentNames18 = null;
			Type[] typeArguments18 = null;
			array2 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance18, type18, memberName18, arguments18, argumentNames18, typeArguments18, array2, true);
			if (array2[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
			}
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance19 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type19 = null;
			string memberName19 = "DrawString";
			array3 = new object[]
			{
				"DINE IN:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments19 = array3;
			string[] argumentNames19 = null;
			Type[] typeArguments19 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance19, type19, memberName19, arguments19, argumentNames19, typeArguments19, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			object instance20 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type20 = null;
			string memberName20 = "DrawString";
			array3 = new object[]
			{
				"No. of Dine In orders: " + this.NumberOfDineInOrders.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments20 = array3;
			string[] argumentNames20 = null;
			Type[] typeArguments20 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance20, type20, memberName20, arguments20, argumentNames20, typeArguments20, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance21 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type21 = null;
			string memberName21 = "DrawString";
			array3 = new object[]
			{
				"Card: £" + this.DineInPaidAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments21 = array3;
			string[] argumentNames21 = null;
			Type[] typeArguments21 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance21, type21, memberName21, arguments21, argumentNames21, typeArguments21, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance22 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type22 = null;
			string memberName22 = "DrawString";
			array3 = new object[]
			{
				"Cash: £" + this.DineInCashAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments22 = array3;
			string[] argumentNames22 = null;
			Type[] typeArguments22 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance22, type22, memberName22, arguments22, argumentNames22, typeArguments22, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance23 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type23 = null;
			string memberName23 = "DrawString";
			array3 = new object[]
			{
				"Total: £" + this.DineInAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments23 = array3;
			string[] argumentNames23 = null;
			Type[] typeArguments23 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance23, type23, memberName23, arguments23, argumentNames23, typeArguments23, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance24 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type24 = null;
			string memberName24 = "DrawString";
			array3 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments24 = array3;
			string[] argumentNames24 = null;
			Type[] typeArguments24 = null;
			array2 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance24, type24, memberName24, arguments24, argumentNames24, typeArguments24, array2, true);
			if (array2[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
			}
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			decimal num = decimal.Add(decimal.Add(this.DeliveryNotPaidAmount, this.TakeCollCashAmount), this.DineInCashAmount);
			decimal num2 = decimal.Add(decimal.Add(this.DeliveryPaidAmount, this.TakeCollPaidAmount), this.DineInPaidAmount);
			object instance25 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type25 = null;
			string memberName25 = "DrawString";
			array3 = new object[]
			{
				"TODAY (" + this.DateToPrint + ") :",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments25 = array3;
			string[] argumentNames25 = null;
			Type[] typeArguments25 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance25, type25, memberName25, arguments25, argumentNames25, typeArguments25, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			object instance26 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type26 = null;
			string memberName26 = "DrawString";
			array3 = new object[]
			{
				"No. of all Orders: " + this.NumberOfTotalOrders.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments26 = array3;
			string[] argumentNames26 = null;
			Type[] typeArguments26 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance26, type26, memberName26, arguments26, argumentNames26, typeArguments26, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance27 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type27 = null;
			string memberName27 = "DrawString";
			array3 = new object[]
			{
				"Card: £" + num2.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments27 = array3;
			string[] argumentNames27 = null;
			Type[] typeArguments27 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance27, type27, memberName27, arguments27, argumentNames27, typeArguments27, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance28 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type28 = null;
			string memberName28 = "DrawString";
			array3 = new object[]
			{
				"Cash: £" + num.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments28 = array3;
			string[] argumentNames28 = null;
			Type[] typeArguments28 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance28, type28, memberName28, arguments28, argumentNames28, typeArguments28, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			object instance29 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type29 = null;
			string memberName29 = "DrawString";
			array3 = new object[]
			{
				"Today's Total: £" + this.TotalAmount.ToString(),
				new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments29 = array3;
			string[] argumentNames29 = null;
			Type[] typeArguments29 = null;
			array2 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance29, type29, memberName29, arguments29, argumentNames29, typeArguments29, array2, true);
			if (array2[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			this.NumberOfCancelledOrders = 0;
			this.CancelAmount = 0m;
			this.CancelCashAmount = 0m;
			this.CancelPaidAmount = 0m;
			this.NumberOfDeliveryOrders = 0;
			this.DeliveryAmount = 0m;
			this.DeliveryPaidAmount = 0m;
			this.DeliveryNotPaidAmount = 0m;
			this.NumberOfTakeCollOrders = 0;
			this.TakeCollCashAmount = 0m;
			this.TakeCollPaidAmount = 0m;
			this.TakeCollAmount = 0m;
			this.NumberOfDineInOrders = 0;
			this.DineInAmount = 0m;
			this.DineInCashAmount = 0m;
			this.DineInPaidAmount = 0m;
			this.SubTotalAmount = 0m;
			this.DeliveryChargeAmount = 0m;
			this.NumberOfTotalOrders = 0;
			this.TotalAmount = 0m;
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00003A49 File Offset: 0x00001C49
		private void Button2_Click(object sender, EventArgs e)
		{
			this.EndOfToday("Archive");
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x00002107 File Offset: 0x00000307
		private void Button1_Click_1(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x00003A59 File Offset: 0x00001C59
		private void Button1_Click(object sender, EventArgs e)
		{
			this.EndOfToday("");
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x0002CBBC File Offset: 0x0002ADBC
		private void EndOfToday(object Archive)
		{
			this.CalculateEndSession("_today");
			bool flag = Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0;
			if (flag)
			{
				this.PrintDocument1.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
			}
			int num = 1;
			int num2 = Conversions.ToInteger(MySettingsProperty.Settings.NumberOfPrint);
			int num3 = num;
			checked
			{
				for (;;)
				{
					int num4 = num3;
					int num5 = num2;
					if (num4 > num5)
					{
						break;
					}
					this.PrintDocument1.Print();
					num3++;
				}
				flag = Operators.ConditionalCompareObjectEqual(Archive, "Archive", false);
				if (flag)
				{
					OrderManagment.Archive_todayFlder();
					OrderManagment.Archive_todayFlderOnline();
				}
				CallerID.CallerIdFree(M_Settings.CallerIdType);
				Application.Exit();
			}
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x00003A69 File Offset: 0x00001C69
		private void ExitCancel_Click(object sender, EventArgs e)
		{
			this.Hide();
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x0002CC6C File Offset: 0x0002AE6C
		public object PrintHeader(object e, object offset)
		{
			Font font = new Font(this.PrintFontType, 8f, FontStyle.Regular);
			font = new Font(this.PrintFontType, (float)this.ShopNameFontSize, FontStyle.Regular);
			object instance = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type = null;
			string memberName = "MeasureString";
			object[] array = new object[]
			{
				M_Settings.ShopName,
				font
			};
			object[] arguments = array;
			string[] argumentNames = null;
			Type[] typeArguments = null;
			bool[] array2 = new bool[]
			{
				true,
				true
			};
			object obj = NewLateBinding.LateGet(instance, type, memberName, arguments, argumentNames, typeArguments, array2);
			if (array2[0])
			{
				M_Settings.ShopName = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(string));
			}
			if (array2[1])
			{
				font = (Font)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[1]), typeof(Font));
			}
			SizeF sizeF;
			this.StringLengthForPrint = ((obj != null) ? ((SizeF)obj) : sizeF);
			checked
			{
				this.x = (int)Math.Round((double)(unchecked((float)this.PrintWholeWidthArea - this.StringLengthForPrint.Width) / 2f));
				object instance2 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type2 = null;
				string memberName2 = "DrawString";
				object[] array3 = new object[]
				{
					M_Settings.ShopName,
					new Font(this.PrintFontType, (float)this.ShopNameFontSize, FontStyle.Bold),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments2 = array3;
				string[] argumentNames2 = null;
				Type[] typeArguments2 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance2, type2, memberName2, arguments2, argumentNames2, typeArguments2, array2, true);
				if (array2[0])
				{
					M_Settings.ShopName = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
				}
				font = new Font(this.PrintFontType, (float)this.ShopAddressFontSize, FontStyle.Regular);
				object instance3 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type3 = null;
				string memberName3 = "MeasureString";
				array3 = new object[]
				{
					M_Settings.ShopAddress,
					font
				};
				object[] arguments3 = array3;
				string[] argumentNames3 = null;
				Type[] typeArguments3 = null;
				array2 = new bool[]
				{
					true,
					true
				};
				object obj2 = NewLateBinding.LateGet(instance3, type3, memberName3, arguments3, argumentNames3, typeArguments3, array2);
				if (array2[0])
				{
					M_Settings.ShopAddress = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[1])
				{
					font = (Font)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[1]), typeof(Font));
				}
				this.StringLengthForPrint = ((obj2 != null) ? ((SizeF)obj2) : sizeF);
				this.x = (int)Math.Round((double)(unchecked((float)this.PrintWholeWidthArea - this.StringLengthForPrint.Width) / 2f));
				offset = Operators.AddObject(offset, this.ShopNameLineSpace);
				object instance4 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type4 = null;
				string memberName4 = "DrawString";
				array3 = new object[]
				{
					M_Settings.ShopAddress,
					new Font(this.PrintFontType, (float)this.ShopAddressFontSize, FontStyle.Regular),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments4 = array3;
				string[] argumentNames4 = null;
				Type[] typeArguments4 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance4, type4, memberName4, arguments4, argumentNames4, typeArguments4, array2, true);
				if (array2[0])
				{
					M_Settings.ShopAddress = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
				}
				font = new Font(this.PrintFontType, (float)this.ShopAddressFontSize, FontStyle.Regular);
				object instance5 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type5 = null;
				string memberName5 = "MeasureString";
				array3 = new object[]
				{
					M_Settings.ShopCity,
					font
				};
				object[] arguments5 = array3;
				string[] argumentNames5 = null;
				Type[] typeArguments5 = null;
				array2 = new bool[]
				{
					true,
					true
				};
				object obj3 = NewLateBinding.LateGet(instance5, type5, memberName5, arguments5, argumentNames5, typeArguments5, array2);
				if (array2[0])
				{
					M_Settings.ShopCity = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[1])
				{
					font = (Font)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[1]), typeof(Font));
				}
				this.StringLengthForPrint = ((obj3 != null) ? ((SizeF)obj3) : sizeF);
				this.x = (int)Math.Round((double)(unchecked((float)this.PrintWholeWidthArea - this.StringLengthForPrint.Width) / 2f));
				offset = Operators.AddObject(offset, this.ShopAddressLineSpace);
				object instance6 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type6 = null;
				string memberName6 = "DrawString";
				array3 = new object[]
				{
					M_Settings.ShopCity,
					new Font(this.PrintFontType, (float)this.ShopAddressFontSize, FontStyle.Regular),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments6 = array3;
				string[] argumentNames6 = null;
				Type[] typeArguments6 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance6, type6, memberName6, arguments6, argumentNames6, typeArguments6, array2, true);
				if (array2[0])
				{
					M_Settings.ShopCity = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
				}
				font = new Font(this.PrintFontType, (float)this.ShopAddressFontSize, FontStyle.Regular);
				object instance7 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type7 = null;
				string memberName7 = "MeasureString";
				array3 = new object[]
				{
					M_Settings.ShopPostCode,
					font
				};
				object[] arguments7 = array3;
				string[] argumentNames7 = null;
				Type[] typeArguments7 = null;
				array2 = new bool[]
				{
					true,
					true
				};
				object obj4 = NewLateBinding.LateGet(instance7, type7, memberName7, arguments7, argumentNames7, typeArguments7, array2);
				if (array2[0])
				{
					M_Settings.ShopPostCode = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[1])
				{
					font = (Font)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[1]), typeof(Font));
				}
				this.StringLengthForPrint = ((obj4 != null) ? ((SizeF)obj4) : sizeF);
				this.x = (int)Math.Round((double)(unchecked((float)this.PrintWholeWidthArea - this.StringLengthForPrint.Width) / 2f));
				offset = Operators.AddObject(offset, this.ShopAddressLineSpace);
				object instance8 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type8 = null;
				string memberName8 = "DrawString";
				array3 = new object[]
				{
					M_Settings.ShopPostCode,
					new Font(this.PrintFontType, (float)this.ShopAddressFontSize, FontStyle.Regular),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments8 = array3;
				string[] argumentNames8 = null;
				Type[] typeArguments8 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance8, type8, memberName8, arguments8, argumentNames8, typeArguments8, array2, true);
				if (array2[0])
				{
					M_Settings.ShopPostCode = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
				}
				font = new Font(this.PrintFontType, (float)this.ShopNumberFontSize, FontStyle.Bold);
				object instance9 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type9 = null;
				string memberName9 = "MeasureString";
				array3 = new object[]
				{
					M_Settings.ShopPhone,
					font
				};
				object[] arguments9 = array3;
				string[] argumentNames9 = null;
				Type[] typeArguments9 = null;
				array2 = new bool[]
				{
					true,
					true
				};
				object obj5 = NewLateBinding.LateGet(instance9, type9, memberName9, arguments9, argumentNames9, typeArguments9, array2);
				if (array2[0])
				{
					M_Settings.ShopPhone = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[1])
				{
					font = (Font)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[1]), typeof(Font));
				}
				this.StringLengthForPrint = ((obj5 != null) ? ((SizeF)obj5) : sizeF);
				this.x = (int)Math.Round((double)(unchecked((float)this.PrintWholeWidthArea - this.StringLengthForPrint.Width) / 2f));
				offset = Operators.AddObject(offset, this.ShopAddressLineSpace);
				object instance10 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type10 = null;
				string memberName10 = "DrawString";
				array3 = new object[]
				{
					M_Settings.ShopPhone,
					new Font(this.PrintFontType, (float)this.ShopNumberFontSize, FontStyle.Bold),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments10 = array3;
				string[] argumentNames10 = null;
				Type[] typeArguments10 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance10, type10, memberName10, arguments10, argumentNames10, typeArguments10, array2, true);
				if (array2[0])
				{
					M_Settings.ShopPhone = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
				}
				bool flag = Operators.CompareString(M_Settings.ShopWebsite, "", false) != 0;
				if (flag)
				{
					font = new Font(this.PrintFontType, (float)this.WebsiteFontLine, FontStyle.Regular);
					object instance11 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
					Type type11 = null;
					string memberName11 = "MeasureString";
					array3 = new object[]
					{
						M_Settings.ShopWebsite,
						font
					};
					object[] arguments11 = array3;
					string[] argumentNames11 = null;
					Type[] typeArguments11 = null;
					array2 = new bool[]
					{
						true,
						true
					};
					object obj6 = NewLateBinding.LateGet(instance11, type11, memberName11, arguments11, argumentNames11, typeArguments11, array2);
					if (array2[0])
					{
						M_Settings.ShopWebsite = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
					}
					if (array2[1])
					{
						font = (Font)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[1]), typeof(Font));
					}
					this.StringLengthForPrint = ((obj6 != null) ? ((SizeF)obj6) : sizeF);
					this.x = (int)Math.Round((double)(unchecked((float)this.PrintWholeWidthArea - this.StringLengthForPrint.Width) / 2f));
					offset = Operators.AddObject(offset, this.PhoneNumberLineSpace);
					object instance12 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
					Type type12 = null;
					string memberName12 = "DrawString";
					array3 = new object[]
					{
						M_Settings.ShopWebsite,
						new Font(this.PrintFontType, (float)this.WebsiteFontLine, FontStyle.Bold),
						Brushes.Black,
						this.x,
						Operators.AddObject(this.y, offset)
					};
					object[] arguments12 = array3;
					string[] argumentNames12 = null;
					Type[] typeArguments12 = null;
					array2 = new bool[]
					{
						true,
						false,
						false,
						true,
						false
					};
					NewLateBinding.LateCall(instance12, type12, memberName12, arguments12, argumentNames12, typeArguments12, array2, true);
					if (array2[0])
					{
						M_Settings.ShopWebsite = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
					}
					if (array2[3])
					{
						this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
					}
				}
				offset = Operators.AddObject(offset, this.WebsiteLineSpace);
				object instance13 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type13 = null;
				string memberName13 = "DrawString";
				array3 = new object[]
				{
					this.DividerLine,
					new Font(this.PrintFontType, 8f, FontStyle.Regular),
					Brushes.Black,
					0,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments13 = array3;
				string[] argumentNames13 = null;
				Type[] typeArguments13 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					false,
					false
				};
				NewLateBinding.LateCall(instance13, type13, memberName13, arguments13, argumentNames13, typeArguments13, array2, true);
				if (array2[0])
				{
					this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				font = new Font(this.PrintFontType, 12f, FontStyle.Regular);
				object instance14 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type14 = null;
				string memberName14 = "MeasureString";
				array3 = new object[]
				{
					this.DateToPrint,
					font
				};
				object[] arguments14 = array3;
				string[] argumentNames14 = null;
				Type[] typeArguments14 = null;
				array2 = new bool[]
				{
					true,
					true
				};
				object obj7 = NewLateBinding.LateGet(instance14, type14, memberName14, arguments14, argumentNames14, typeArguments14, array2);
				if (array2[0])
				{
					this.DateToPrint = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[1])
				{
					font = (Font)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[1]), typeof(Font));
				}
				this.StringLengthForPrint = ((obj7 != null) ? ((SizeF)obj7) : sizeF);
				this.x = (int)Math.Round((double)(unchecked((float)this.PrintWholeWidthArea - this.StringLengthForPrint.Width) / 2f));
				offset = Operators.AddObject(offset, 15);
				object instance15 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type15 = null;
				string memberName15 = "DrawString";
				array3 = new object[]
				{
					this.DateToPrint,
					new Font(this.PrintFontType, (float)this.WebsiteFontLine, FontStyle.Bold),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments15 = array3;
				string[] argumentNames15 = null;
				Type[] typeArguments15 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance15, type15, memberName15, arguments15, argumentNames15, typeArguments15, array2, true);
				if (array2[0])
				{
					this.DateToPrint = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				if (array2[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[3]), typeof(int));
				}
				offset = Operators.AddObject(offset, 20);
				object instance16 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type16 = null;
				string memberName16 = "DrawString";
				array3 = new object[]
				{
					this.DividerLine,
					new Font(this.PrintFontType, 8f, FontStyle.Regular),
					Brushes.Black,
					0,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments16 = array3;
				string[] argumentNames16 = null;
				Type[] typeArguments16 = null;
				array2 = new bool[]
				{
					true,
					false,
					false,
					false,
					false
				};
				NewLateBinding.LateCall(instance16, type16, memberName16, arguments16, argumentNames16, typeArguments16, array2, true);
				if (array2[0])
				{
					this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
				}
				offset = Operators.AddObject(offset, 20);
				return offset;
			}
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x0002DBD8 File Offset: 0x0002BDD8
		private void FreeFoodsOffer_Load(object sender, EventArgs e)
		{
			this.DateToPrint = DateTime.Today.ToString("yyyy'/'MM'/'dd");
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x0002DC00 File Offset: 0x0002BE00
		private void PrintDocument2_PrintPage(object sender, PrintPageEventArgs e)
		{
			int num = 0;
			num = Conversions.ToInteger(this.PrintHeader(e, num));
			this.PrintFullReport(e, num);
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x0002DC34 File Offset: 0x0002BE34
		private void PrintFullReport(object e, object offset)
		{
			string[] array = File.ReadAllLines(M_Settings.DataFolder + "\\order_history\\" + this.FolderDayFullReportPrint + "\\_TodayOrderList.txt");
			this.x = 0;
			string text = "";
			object instance = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type = null;
			string memberName = "DrawString";
			object[] array2 = new object[]
			{
				"CANCELLED:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments = array2;
			string[] argumentNames = null;
			Type[] typeArguments = null;
			bool[] array3 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance, type, memberName, arguments, argumentNames, typeArguments, array3, true);
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array2[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			bool flag2;
			object[] array6;
			foreach (string text2 in array)
			{
				string[] array5 = text2.Split(new char[]
				{
					'|'
				});
				bool flag = Operators.CompareString(array5[3], "Cancelled", false) == 0;
				if (flag)
				{
					flag2 = (Operators.CompareString(array5[4], "Credit/Debit Card", false) == 0);
					if (flag2)
					{
						array5[4] = "Card";
					}
					text = string.Concat(new string[]
					{
						array5[0],
						" - ",
						array5[1].Substring(8, 2),
						":",
						array5[1].Substring(10, 2),
						" - ",
						array5[4],
						" - £",
						array5[15]
					});
					object instance2 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
					Type type2 = null;
					string memberName2 = "DrawString";
					array6 = new object[]
					{
						text,
						new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
						Brushes.Black,
						this.x,
						Operators.AddObject(this.y, offset)
					};
					object[] arguments2 = array6;
					string[] argumentNames2 = null;
					Type[] typeArguments2 = null;
					array3 = new bool[]
					{
						true,
						false,
						false,
						true,
						false
					};
					NewLateBinding.LateCall(instance2, type2, memberName2, arguments2, argumentNames2, typeArguments2, array3, true);
					if (array3[0])
					{
						text = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
					}
					if (array3[3])
					{
						this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
					}
					offset = Operators.AddObject(offset, this.CalculationLineSpace);
				}
			}
			flag2 = (Operators.CompareString(text, "", false) == 0);
			if (flag2)
			{
				object instance3 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type3 = null;
				string memberName3 = "DrawString";
				array6 = new object[]
				{
					"No cancelled order.",
					new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments3 = array6;
				string[] argumentNames3 = null;
				Type[] typeArguments3 = null;
				array3 = new bool[]
				{
					false,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance3, type3, memberName3, arguments3, argumentNames3, typeArguments3, array3, true);
				if (array3[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
				}
				offset = Operators.AddObject(offset, this.CalculationLineSpace);
			}
			object instance4 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type4 = null;
			string memberName4 = "DrawString";
			array6 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments4 = array6;
			string[] argumentNames4 = null;
			Type[] typeArguments4 = null;
			array3 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance4, type4, memberName4, arguments4, argumentNames4, typeArguments4, array3, true);
			if (array3[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
			}
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			text = "";
			object instance5 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type5 = null;
			string memberName5 = "DrawString";
			array6 = new object[]
			{
				"DELIVERY:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments5 = array6;
			string[] argumentNames5 = null;
			Type[] typeArguments5 = null;
			array3 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance5, type5, memberName5, arguments5, argumentNames5, typeArguments5, array3, true);
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			foreach (string text3 in array)
			{
				string[] array8 = text3.Split(new char[]
				{
					'|'
				});
				flag2 = (Operators.CompareString(array8[2], "Delivery", false) == 0);
				if (flag2)
				{
					bool flag = Operators.CompareString(array8[4], "Credit/Debit Card", false) == 0;
					if (flag)
					{
						array8[4] = "Card";
					}
					flag2 = (Operators.CompareString(array8[5], "DriverName", false) == 0);
					if (flag2)
					{
						array8[5] = "xxxx";
					}
					text = string.Concat(new string[]
					{
						array8[0],
						" - ",
						array8[1].Substring(8, 2),
						":",
						array8[1].Substring(10, 2),
						" - ",
						array8[4],
						" - ",
						array8[5],
						" - £",
						array8[15]
					});
					object instance6 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
					Type type6 = null;
					string memberName6 = "DrawString";
					array6 = new object[]
					{
						text,
						new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
						Brushes.Black,
						this.x,
						Operators.AddObject(this.y, offset)
					};
					object[] arguments6 = array6;
					string[] argumentNames6 = null;
					Type[] typeArguments6 = null;
					array3 = new bool[]
					{
						true,
						false,
						false,
						true,
						false
					};
					NewLateBinding.LateCall(instance6, type6, memberName6, arguments6, argumentNames6, typeArguments6, array3, true);
					if (array3[0])
					{
						text = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
					}
					if (array3[3])
					{
						this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
					}
					offset = Operators.AddObject(offset, this.CalculationLineSpace);
				}
			}
			flag2 = (Operators.CompareString(text, "", false) == 0);
			if (flag2)
			{
				object instance7 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type7 = null;
				string memberName7 = "DrawString";
				array6 = new object[]
				{
					"No delivery order.",
					new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments7 = array6;
				string[] argumentNames7 = null;
				Type[] typeArguments7 = null;
				array3 = new bool[]
				{
					false,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance7, type7, memberName7, arguments7, argumentNames7, typeArguments7, array3, true);
				if (array3[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
				}
				offset = Operators.AddObject(offset, this.CalculationLineSpace);
			}
			object instance8 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type8 = null;
			string memberName8 = "DrawString";
			array6 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments8 = array6;
			string[] argumentNames8 = null;
			Type[] typeArguments8 = null;
			array3 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance8, type8, memberName8, arguments8, argumentNames8, typeArguments8, array3, true);
			if (array3[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
			}
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			text = "";
			object instance9 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type9 = null;
			string memberName9 = "DrawString";
			array6 = new object[]
			{
				"TAKEAWAY/COLLECTION:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments9 = array6;
			string[] argumentNames9 = null;
			Type[] typeArguments9 = null;
			array3 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance9, type9, memberName9, arguments9, argumentNames9, typeArguments9, array3, true);
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			foreach (string text4 in array)
			{
				string[] array10 = text4.Split(new char[]
				{
					'|'
				});
				flag2 = (Operators.CompareString(array10[2], "Takeaway", false) == 0 | Operators.CompareString(array10[3], "Collection", false) == 0);
				if (flag2)
				{
					bool flag = Operators.CompareString(array10[4], "Credit/Debit Card", false) == 0;
					if (flag)
					{
						array10[4] = "Card";
					}
					text = string.Concat(new string[]
					{
						array10[0],
						" - ",
						array10[1].Substring(8, 2),
						":",
						array10[1].Substring(10, 2),
						" - ",
						array10[4],
						" - £",
						array10[15]
					});
					object instance10 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
					Type type10 = null;
					string memberName10 = "DrawString";
					array6 = new object[]
					{
						text,
						new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
						Brushes.Black,
						this.x,
						Operators.AddObject(this.y, offset)
					};
					object[] arguments10 = array6;
					string[] argumentNames10 = null;
					Type[] typeArguments10 = null;
					array3 = new bool[]
					{
						true,
						false,
						false,
						true,
						false
					};
					NewLateBinding.LateCall(instance10, type10, memberName10, arguments10, argumentNames10, typeArguments10, array3, true);
					if (array3[0])
					{
						text = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
					}
					if (array3[3])
					{
						this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
					}
					offset = Operators.AddObject(offset, this.CalculationLineSpace);
				}
			}
			flag2 = (Operators.CompareString(text, "", false) == 0);
			if (flag2)
			{
				object instance11 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type11 = null;
				string memberName11 = "DrawString";
				array6 = new object[]
				{
					"No takeaway/collection order.",
					new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments11 = array6;
				string[] argumentNames11 = null;
				Type[] typeArguments11 = null;
				array3 = new bool[]
				{
					false,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance11, type11, memberName11, arguments11, argumentNames11, typeArguments11, array3, true);
				if (array3[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
				}
				offset = Operators.AddObject(offset, this.CalculationLineSpace);
			}
			object instance12 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type12 = null;
			string memberName12 = "DrawString";
			array6 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments12 = array6;
			string[] argumentNames12 = null;
			Type[] typeArguments12 = null;
			array3 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance12, type12, memberName12, arguments12, argumentNames12, typeArguments12, array3, true);
			if (array3[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
			}
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
			text = "";
			object instance13 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type13 = null;
			string memberName13 = "DrawString";
			array6 = new object[]
			{
				"DINE IN:",
				new Font(this.PrintFontType, 16f, FontStyle.Bold),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments13 = array6;
			string[] argumentNames13 = null;
			Type[] typeArguments13 = null;
			array3 = new bool[]
			{
				false,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance13, type13, memberName13, arguments13, argumentNames13, typeArguments13, array3, true);
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, 25);
			foreach (string text5 in array)
			{
				string[] array12 = text5.Split(new char[]
				{
					'|'
				});
				flag2 = (Operators.CompareString(array12[2], "Dine In", false) == 0);
				if (flag2)
				{
					bool flag = Operators.CompareString(array12[4], "Credit/Debit Card", false) == 0;
					if (flag)
					{
						array12[4] = "Card";
					}
					text = string.Concat(new string[]
					{
						array12[0],
						" - ",
						array12[1].Substring(8, 2),
						":",
						array12[1].Substring(10, 2),
						" - ",
						array12[4],
						" - £",
						array12[15]
					});
					object instance14 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
					Type type14 = null;
					string memberName14 = "DrawString";
					array6 = new object[]
					{
						text,
						new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
						Brushes.Black,
						this.x,
						Operators.AddObject(this.y, offset)
					};
					object[] arguments14 = array6;
					string[] argumentNames14 = null;
					Type[] typeArguments14 = null;
					array3 = new bool[]
					{
						true,
						false,
						false,
						true,
						false
					};
					NewLateBinding.LateCall(instance14, type14, memberName14, arguments14, argumentNames14, typeArguments14, array3, true);
					if (array3[0])
					{
						text = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
					}
					if (array3[3])
					{
						this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
					}
					offset = Operators.AddObject(offset, this.CalculationLineSpace);
				}
			}
			flag2 = (Operators.CompareString(text, "", false) == 0);
			if (flag2)
			{
				object instance15 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
				Type type15 = null;
				string memberName15 = "DrawString";
				array6 = new object[]
				{
					"No dine in order.",
					new Font(this.PrintFontType, (float)this.CalculationFontSize, FontStyle.Bold),
					Brushes.Black,
					this.x,
					Operators.AddObject(this.y, offset)
				};
				object[] arguments15 = array6;
				string[] argumentNames15 = null;
				Type[] typeArguments15 = null;
				array3 = new bool[]
				{
					false,
					false,
					false,
					true,
					false
				};
				NewLateBinding.LateCall(instance15, type15, memberName15, arguments15, argumentNames15, typeArguments15, array3, true);
				if (array3[3])
				{
					this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
				}
				offset = Operators.AddObject(offset, this.CalculationLineSpace);
			}
			object instance16 = NewLateBinding.LateGet(e, null, "Graphics", new object[0], null, null, null);
			Type type16 = null;
			string memberName16 = "DrawString";
			array6 = new object[]
			{
				this.DividerLine,
				new Font(this.PrintFontType, 8f, FontStyle.Regular),
				Brushes.Black,
				this.x,
				Operators.AddObject(this.y, offset)
			};
			object[] arguments16 = array6;
			string[] argumentNames16 = null;
			Type[] typeArguments16 = null;
			array3 = new bool[]
			{
				true,
				false,
				false,
				true,
				false
			};
			NewLateBinding.LateCall(instance16, type16, memberName16, arguments16, argumentNames16, typeArguments16, array3, true);
			if (array3[0])
			{
				this.DividerLine = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[0]), typeof(string));
			}
			if (array3[3])
			{
				this.x = (int)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array6[3]), typeof(int));
			}
			offset = Operators.AddObject(offset, this.CalculationLineSpace);
		}

		// Token: 0x040001ED RID: 493
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x040001EE RID: 494
		private IContainer components;

		// Token: 0x040001EF RID: 495
		[AccessedThroughProperty("EndSessionNoBTN")]
		private Button _EndSessionNoBTN;

		// Token: 0x040001F0 RID: 496
		[AccessedThroughProperty("EndSessionYesBTN")]
		private Button _EndSessionYesBTN;

		// Token: 0x040001F1 RID: 497
		[AccessedThroughProperty("EndSessionLabel")]
		private Label _EndSessionLabel;

		// Token: 0x040001F2 RID: 498
		[AccessedThroughProperty("ExitCancel")]
		private Button _ExitCancel;

		// Token: 0x040001F3 RID: 499
		[AccessedThroughProperty("PrintDocument1")]
		private PrintDocument _PrintDocument1;

		// Token: 0x040001F4 RID: 500
		[AccessedThroughProperty("PrintDocument2")]
		private PrintDocument _PrintDocument2;

		// Token: 0x040001F5 RID: 501
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x040001F6 RID: 502
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x040001F7 RID: 503
		public string DateToPrint;

		// Token: 0x040001F8 RID: 504
		public string FolderDayFullReportPrint;

		// Token: 0x040001F9 RID: 505
		private decimal DiscountAmount;

		// Token: 0x040001FA RID: 506
		private decimal ServiceChargeAmount;

		// Token: 0x040001FB RID: 507
		public int NumberOfTotalOrders;

		// Token: 0x040001FC RID: 508
		public int NumberOfDeliveryOrders;

		// Token: 0x040001FD RID: 509
		public int NumberOfTakeCollOrders;

		// Token: 0x040001FE RID: 510
		public int NumberOfDineInOrders;

		// Token: 0x040001FF RID: 511
		public int NumberOfCancelledOrders;

		// Token: 0x04000200 RID: 512
		public decimal DeliveryAmount;

		// Token: 0x04000201 RID: 513
		public decimal TakeCollAmount;

		// Token: 0x04000202 RID: 514
		public decimal DineInAmount;

		// Token: 0x04000203 RID: 515
		public decimal CancelAmount;

		// Token: 0x04000204 RID: 516
		public decimal SubTotalAmount;

		// Token: 0x04000205 RID: 517
		public decimal DeliveryChargeAmount;

		// Token: 0x04000206 RID: 518
		public decimal TotalAmount;

		// Token: 0x04000207 RID: 519
		public decimal DeliveryPaidAmount;

		// Token: 0x04000208 RID: 520
		public decimal DeliveryNotPaidAmount;

		// Token: 0x04000209 RID: 521
		public decimal TakeCollCashAmount;

		// Token: 0x0400020A RID: 522
		public decimal TakeCollPaidAmount;

		// Token: 0x0400020B RID: 523
		public decimal DineInCashAmount;

		// Token: 0x0400020C RID: 524
		public decimal DineInPaidAmount;

		// Token: 0x0400020D RID: 525
		public decimal CancelCashAmount;

		// Token: 0x0400020E RID: 526
		public decimal CancelPaidAmount;

		// Token: 0x0400020F RID: 527
		private int x;

		// Token: 0x04000210 RID: 528
		private int y;

		// Token: 0x04000211 RID: 529
		private object MyPrintFont;

		// Token: 0x04000212 RID: 530
		private string DividerLine;

		// Token: 0x04000213 RID: 531
		private string PrintFontType;

		// Token: 0x04000214 RID: 532
		private SizeF StringLengthForPrint;

		// Token: 0x04000215 RID: 533
		private int PrintWholeWidthArea;

		// Token: 0x04000216 RID: 534
		private int ShopNameFontSize;

		// Token: 0x04000217 RID: 535
		private int ShopNameLineSpace;

		// Token: 0x04000218 RID: 536
		private int ShopAddressFontSize;

		// Token: 0x04000219 RID: 537
		private int ShopAddressLineSpace;

		// Token: 0x0400021A RID: 538
		private int ShopNumberFontSize;

		// Token: 0x0400021B RID: 539
		private int PhoneNumberLineSpace;

		// Token: 0x0400021C RID: 540
		private int WebsiteFontLine;

		// Token: 0x0400021D RID: 541
		private string WebsiteLineSpace;

		// Token: 0x0400021E RID: 542
		private int CalculationFontSize;

		// Token: 0x0400021F RID: 543
		private int CalculationLineSpace;
	}
}
