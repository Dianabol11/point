using System;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000036 RID: 54
	[StandardModule]
	internal sealed class M_TLP_Sizes
	{
		// Token: 0x0600069A RID: 1690 RVA: 0x000417B4 File Offset: 0x0003F9B4
		public static void Create_Sizes_TLPs(object CategoryName, object Sizes)
		{
			bool flag = Operators.ConditionalCompareObjectNotEqual(Sizes, "no", false);
			checked
			{
				if (flag)
				{
					M_TLP_Sizes.Count_Row_Column(NewLateBinding.LateGet(Sizes, null, "Split", new object[]
					{
						new char[]
						{
							'&'
						}
					}, null, null, null).ToString().Count<char>());
					TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
					TableLayoutPanel tableLayoutPanel2 = tableLayoutPanel;
					tableLayoutPanel2.Name = Conversions.ToString(Operators.AddObject(CategoryName, "Size"));
					tableLayoutPanel2.RowCount = M_Settings.rows;
					tableLayoutPanel2.ColumnCount = M_Settings.columns;
					tableLayoutPanel2.Dock = DockStyle.Fill;
					tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
					tableLayoutPanel2.AutoSize = true;
					Control control = tableLayoutPanel2;
					Padding margin = new Padding(0);
					control.Margin = margin;
					tableLayoutPanel2.Height = (int)Math.Round((double)(MyProject.Forms.Index.Height - M_Settings.Bottom_Panel_Height) / (double)M_Settings.rows);
					tableLayoutPanel2.Width = (int)Math.Round((double)(MyProject.Forms.Index.Width - M_Settings.Right_Panel_Width) / (double)M_Settings.columns);
					tableLayoutPanel2.BackColor = ColorTranslator.FromHtml(M_Settings.TLPs_bgColor);
					MyProject.Forms.POS_Window.Main_Panel.Controls.Add(tableLayoutPanel);
					try
					{
						foreach (object obj in ((IEnumerable)NewLateBinding.LateGet(Sizes, null, "Split", new object[]
						{
							new char[]
							{
								'&'
							}
						}, null, null, null)))
						{
							object objectValue = RuntimeHelpers.GetObjectValue(obj);
							Button button = new Button();
							Button button2 = button;
							button2.Name = Conversions.ToString(objectValue);
							button2.BackColor = ColorTranslator.FromHtml("#" + M_Settings.Button_bgColor);
							button2.ForeColor = ColorTranslator.FromHtml("#" + M_Settings.Button_TextColor);
							button2.Dock = DockStyle.Fill;
							button2.AutoSize = false;
							button2.FlatStyle = FlatStyle.Popup;
							Control control2 = button2;
							margin = new Padding(0, 0, 0, 0);
							control2.Margin = margin;
							button2.Font = new Font("Arial", 16f, FontStyle.Regular);
							button2.Height = (int)Math.Round((double)(MyProject.Forms.Index.Height - M_Settings.Bottom_Panel_Height) / (double)M_Settings.rows);
							button2.Width = (int)Math.Round((double)(MyProject.Forms.Index.Width - M_Settings.Right_Panel_Width) / (double)M_Settings.columns);
							button2.Text = Conversions.ToString(objectValue);
							tableLayoutPanel.Controls.Add(button);
							button.Click += M_TLP_Sizes.SizeButtonClick;
						}
					}
					finally
					{
						IEnumerator enumerator;
						flag = (enumerator is IDisposable);
						if (flag)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
			}
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x00041AC4 File Offset: 0x0003FCC4
		private static void SizeButtonClick(object sender, EventArgs e)
		{
			M_Settings.SelectedSize = Conversions.ToString(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null));
			MyProject.Forms.POS_Window.Main_Panel.Controls[M_Settings.SelectedCategory + M_Settings.SelectedSize + "Foods"].BringToFront();
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00041B28 File Offset: 0x0003FD28
		private static void Count_Row_Column(object N)
		{
			bool flag = Operators.ConditionalCompareObjectLessEqual(N, 12, false);
			if (flag)
			{
				M_Settings.rows = 4;
				M_Settings.columns = 3;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 12, false);
			if (flag)
			{
				M_Settings.rows = 5;
				M_Settings.columns = 4;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 20, false);
			if (flag)
			{
				M_Settings.rows = 6;
				M_Settings.columns = 5;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 30, false);
			if (flag)
			{
				M_Settings.rows = 7;
				M_Settings.columns = 6;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 42, false);
			if (flag)
			{
				M_Settings.rows = checked((int)Math.Round(Math.Ceiling(Math.Sqrt(Conversions.ToDouble(N)))));
				M_Settings.columns = M_Settings.rows;
			}
		}
	}
}
