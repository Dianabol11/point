using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace POS
{
	// Token: 0x02000029 RID: 41
	[StandardModule]
	internal sealed class offers
	{
		// Token: 0x060005D7 RID: 1495 RVA: 0x000367AC File Offset: 0x000349AC
		public static void CheckOfferExistForThisFood(object SelectedFoodPrice)
		{
			bool flag = Operators.CompareString(offers.OFFER_B1G1F, "", false) != 0;
			bool flag2;
			if (flag)
			{
				flag2 = offers.OFFER_B1G1F.Contains(M_Settings.SelectedCategory);
				if (flag2)
				{
					offers.BIG1F(RuntimeHelpers.GetObjectValue(SelectedFoodPrice));
				}
			}
			flag2 = (Operators.CompareString(offers.OFFER_B1G1HALF, "", false) != 0);
			if (flag2)
			{
				flag = offers.OFFER_B1G1HALF.Contains(M_Settings.SelectedCategory);
				if (flag)
				{
					offers.B1G1HALF(RuntimeHelpers.GetObjectValue(SelectedFoodPrice));
				}
			}
			flag2 = (offers.OFFER_B1G1FPOUND.Count > 0);
			if (flag2)
			{
				try
				{
					foreach (object value in offers.OFFER_B1G1FPOUND)
					{
						string text = Conversions.ToString(value);
						flag = (text.Contains(M_Settings.SelectedCategory) & text.Contains(M_Settings.SelectedSize));
						if (flag)
						{
							offers.B1G1FPOUND(RuntimeHelpers.GetObjectValue(SelectedFoodPrice), text);
						}
					}
				}
				finally
				{
					IEnumerator enumerator;
					flag2 = (enumerator is IDisposable);
					if (flag2)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x000368C0 File Offset: 0x00034AC0
		public static void PERCENTOFF()
		{
			M_Calculates.OrderDiscount = 0m;
			bool flag = decimal.Compare(M_Calculates.OrderSubTotal, Conversions.ToDecimal(offers.OFFER_PERCENTOFF_PERCENT_MINIMUM_TOTAL)) >= 0;
			if (flag)
			{
				try
				{
					foreach (object obj in M_Settings.ShoppingCart.Items)
					{
						ListViewItem listViewItem = (ListViewItem)obj;
						string text = listViewItem.SubItems[1].Text;
						string text2 = listViewItem.SubItems[6].Text;
						flag = (Operators.CompareString(text2, "", false) == 0);
						if (flag)
						{
							text2 = "0";
						}
						flag = offers.OFFER_PERCENTOFF_PERCENT_CATEGORIES.Contains("#" + text + "#");
						if (flag)
						{
							M_Calculates.OrderDiscount = decimal.Add(M_Calculates.OrderDiscount, Math.Round(decimal.Divide(decimal.Multiply(Conversions.ToDecimal(text2), Conversions.ToDecimal(offers.OFFER_PERCENTOFF_PERCENT)), 100m), 2));
						}
					}
				}
				finally
				{
					IEnumerator enumerator;
					flag = (enumerator is IDisposable);
					if (flag)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x000369FC File Offset: 0x00034BFC
		public static void B1G1FPOUND(object SelectedFoodPrice, object ol)
		{
			bool flag = decimal.Compare(offers.SelectedFoodPriceOffer1, 0m) == 0;
			if (flag)
			{
				offers.SelectedFoodPriceOffer1 = Conversions.ToDecimal(SelectedFoodPrice);
				offers.SelectedFoodPriceOffer2 = 0m;
			}
			else
			{
				offers.SelectedFoodPriceOffer2 = Conversions.ToDecimal(SelectedFoodPrice);
				decimal num = Conversions.ToDecimal(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(ol, null, "Split", new object[]
				{
					new char[]
					{
						'#'
					}
				}, null, null, null), new object[]
				{
					0
				}, null));
				offers.OfferDiscount = decimal.Subtract(Math.Min(offers.SelectedFoodPriceOffer1, offers.SelectedFoodPriceOffer2), num);
				offers.OfferName = "Buy 1 Get 1 For £" + Conversions.ToString(num) + " " + M_Settings.SelectedCategory;
			}
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x00036ACC File Offset: 0x00034CCC
		public static void B1G1HALF(object SelectedFoodPrice)
		{
			bool flag = decimal.Compare(offers.SelectedFoodPriceOffer1, 0m) == 0;
			if (flag)
			{
				offers.SelectedFoodPriceOffer1 = Conversions.ToDecimal(SelectedFoodPrice);
				offers.SelectedFoodPriceOffer2 = 0m;
			}
			else
			{
				offers.SelectedFoodPriceOffer2 = Conversions.ToDecimal(SelectedFoodPrice);
				offers.OfferDiscount = Math.Round(decimal.Divide(Math.Min(offers.SelectedFoodPriceOffer1, offers.SelectedFoodPriceOffer2), 2m), 2);
				offers.OfferName = "Buy 1 Get 1 Half Price " + M_Settings.SelectedCategory;
			}
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x00036B54 File Offset: 0x00034D54
		public static void BIG1F(object SelectedFoodPrice)
		{
			bool flag = decimal.Compare(offers.SelectedFoodPriceOffer1, 0m) == 0;
			if (flag)
			{
				offers.SelectedFoodPriceOffer1 = Conversions.ToDecimal(SelectedFoodPrice);
				offers.SelectedFoodPriceOffer2 = 0m;
			}
			else
			{
				offers.SelectedFoodPriceOffer2 = Conversions.ToDecimal(SelectedFoodPrice);
				offers.OfferDiscount = Math.Min(offers.SelectedFoodPriceOffer1, offers.SelectedFoodPriceOffer2);
				offers.OfferName = "Buy 1 Get 1 Free " + M_Settings.SelectedCategory;
			}
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x00036BC8 File Offset: 0x00034DC8
		public static void AddOfferToShoppingCart()
		{
			try
			{
				int count = M_Settings.ShoppingCart.Items.Count;
				M_Settings.ShoppingCart.Items.Add(new ListViewItem("OFFER"));
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedCategory);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedSize);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(M_Settings.SelectedOptionTLP);
				M_Settings.ShoppingCart.Items[count].SubItems.Add("");
				M_Settings.ShoppingCart.Items[count].SubItems.Add(offers.OfferName);
				M_Settings.ShoppingCart.Items[count].SubItems.Add(Conversions.ToString(decimal.Multiply(offers.OfferDiscount, -1m)));
				M_Settings.ShoppingCart.Items[count].SubItems.Add(Conversions.ToString(decimal.Multiply(offers.OfferDiscount, -1m)));
				M_Settings.ShoppingCart.Items[count].Font = new Font(M_Settings.ShoppingCart.Font, FontStyle.Bold);
				M_Settings.ShoppingCart.TopItem = M_Settings.ShoppingCart.Items[checked(M_Settings.ShoppingCart.Items.Count - 1)];
				M_Calculates.CalculateSubTotal();
				offers.CleanOffer();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x00003E52 File Offset: 0x00002052
		public static void CleanOffer()
		{
			offers.SelectedFoodPriceOffer1 = 0m;
			offers.SelectedFoodPriceOffer2 = 0m;
			offers.OfferDiscount = 0m;
			offers.OfferName = "";
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x00036D90 File Offset: 0x00034F90
		public static void LoadOffers()
		{
			foreach (string text in File.ReadAllLines(M_Settings.MenuFolder + "\\_offers.txt"))
			{
				bool flag = Conversions.ToBoolean(Operators.NotObject(offers.CheckDaysOfWeek(text)));
				if (!flag)
				{
					flag = text.Contains("B1G1F#");
					if (flag)
					{
						offers.OFFER_B1G1F = text.Split(new char[]
						{
							'|'
						})[0].Replace("B1G1F#", "");
					}
					else
					{
						flag = text.Contains("B1G1HALF#");
						if (flag)
						{
							offers.OFFER_B1G1HALF = text.Split(new char[]
							{
								'|'
							})[0].Replace("B1G1HALF#", "");
						}
						else
						{
							flag = text.Contains("FREEDELIVERY");
							if (flag)
							{
								offers.OFFER_FREEDELIVERY_PRICE = text.Split(new char[]
								{
									'|'
								})[0].Replace("FREEDELIVERY", "");
							}
							else
							{
								flag = text.Contains("PERCENTOFF");
								if (flag)
								{
									offers.OFFER_PERCENTOFF_PERCENT = text.Split(new char[]
									{
										'#'
									})[0].Replace("PERCENTOFF", "");
									offers.OFFER_PERCENTOFF_PERCENT_CATEGORIES = text.Split(new char[]
									{
										'|'
									})[0] + "#";
									offers.OFFER_PERCENTOFF_PERCENT_MINIMUM_TOTAL = text.Split(new char[]
									{
										'|'
									})[2];
								}
								else
								{
									flag = text.Contains("FREEFOODS");
									if (flag)
									{
										offers.OFFER_FREEFOODS_PRICE = text.Split(new char[]
										{
											'#'
										})[0].Replace("FREEFOODS", "");
										offers.OFFER_FREEFOODS = text.Split(new char[]
										{
											'|'
										})[0].Replace("FREEFOODS" + offers.OFFER_FREEFOODS_PRICE + "#", "");
									}
									else
									{
										flag = text.Contains("B1G1FPOUND");
										if (flag)
										{
											offers.OFFER_B1G1FPOUND.Add(text.Split(new char[]
											{
												'|'
											})[0].Replace("B1G1FPOUND", ""));
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x00036FE4 File Offset: 0x000351E4
		private static object CheckDaysOfWeek(object OfferLine)
		{
			bool flag = false;
			Type type = null;
			string memberName = "Contains";
			object[] array = new object[]
			{
				offers.Today
			};
			object[] arguments = array;
			string[] argumentNames = null;
			Type[] typeArguments = null;
			bool[] array2 = new bool[]
			{
				true
			};
			object left = NewLateBinding.LateGet(OfferLine, type, memberName, arguments, argumentNames, typeArguments, array2);
			if (array2[0])
			{
				offers.Today = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array[0]), typeof(string));
			}
			object left2 = Operators.AndObject(left, Operators.CompareString(DateAndTime.TimeOfDay.ToString("HH"), offers.TimeOfDayToAcceptOffers, false) > 0);
			Type type2 = null;
			string memberName2 = "Contains";
			object[] array3 = new object[]
			{
				offers.Yesterday
			};
			object[] arguments2 = array3;
			string[] argumentNames2 = null;
			Type[] typeArguments2 = null;
			bool[] array4 = new bool[]
			{
				true
			};
			object left3 = NewLateBinding.LateGet(OfferLine, type2, memberName2, arguments2, argumentNames2, typeArguments2, array4);
			if (array4[0])
			{
				offers.Yesterday = (string)Conversions.ChangeType(RuntimeHelpers.GetObjectValue(array3[0]), typeof(string));
			}
			bool flag2 = Conversions.ToBoolean(Operators.OrObject(left2, Operators.AndObject(left3, Operators.CompareString(DateAndTime.TimeOfDay.ToString("HH"), offers.TimeOfDayToAcceptOffers, false) <= 0)));
			if (flag2)
			{
				flag = true;
			}
			return flag;
		}

		// Token: 0x0400026A RID: 618
		public static string OFFER_B1G1F;

		// Token: 0x0400026B RID: 619
		public static string OFFER_B1G1HALF;

		// Token: 0x0400026C RID: 620
		public static string OFFER_PERCENTOFF_PERCENT;

		// Token: 0x0400026D RID: 621
		public static string OFFER_PERCENTOFF_PERCENT_CATEGORIES;

		// Token: 0x0400026E RID: 622
		public static string OFFER_PERCENTOFF_PERCENT_MINIMUM_TOTAL;

		// Token: 0x0400026F RID: 623
		public static string OFFER_FREEDELIVERY_PRICE;

		// Token: 0x04000270 RID: 624
		public static string OFFER_FREEFOODS;

		// Token: 0x04000271 RID: 625
		public static string OFFER_FREEFOODS_PRICE;

		// Token: 0x04000272 RID: 626
		public static ArrayList OFFER_B1G1FPOUND = new ArrayList();

		// Token: 0x04000273 RID: 627
		public static string OfferName;

		// Token: 0x04000274 RID: 628
		public static decimal OfferDiscount;

		// Token: 0x04000275 RID: 629
		private static string TimeOfDayToAcceptOffers = "05";

		// Token: 0x04000276 RID: 630
		private static string Today = DateTime.Today.ToString("dddd");

		// Token: 0x04000277 RID: 631
		private static string Yesterday = DateTime.Today.AddDays(-1.0).ToString("dddd");

		// Token: 0x04000278 RID: 632
		private static decimal SelectedFoodPriceOffer1;

		// Token: 0x04000279 RID: 633
		private static decimal SelectedFoodPriceOffer2;
	}
}
