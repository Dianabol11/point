using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200001A RID: 26
	[DesignerGenerated]
	public class CalculateCustomerChange : Form
	{
		// Token: 0x06000426 RID: 1062 RVA: 0x000231D4 File Offset: 0x000213D4
		[DebuggerNonUserCode]
		public CalculateCustomerChange()
		{
			base.Load += this.CalculateCustomerChange_Load;
			List<WeakReference> _ENCList = CalculateCustomerChange.__ENCList;
			lock (_ENCList)
			{
				CalculateCustomerChange.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x00023240 File Offset: 0x00021440
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x00023290 File Offset: 0x00021490
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Button1 = new Button();
			this.TotalToBePaidTB = new TextBox();
			this.CashTB = new TextBox();
			this.PrintBTN = new Button();
			this.DeleteBTN = new Button();
			this.Button10 = new Button();
			this.Button9 = new Button();
			this.Button8 = new Button();
			this.Button7 = new Button();
			this.Button6 = new Button();
			this.Button5 = new Button();
			this.Button4 = new Button();
			this.Button3 = new Button();
			this.Button2 = new Button();
			this.Button12 = new Button();
			this.Label1 = new Label();
			this.ButtonDot = new Button();
			this.Button5Note = new Button();
			this.Button11 = new Button();
			this.Button20Note = new Button();
			this.Label2 = new Label();
			this.ChangeTB = new TextBox();
			this.Label3 = new Label();
			this.Button50Note = new Button();
			this.SuspendLayout();
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button1.BackColor = Color.FromArgb(178, 1, 1);
			this.Button1.FlatAppearance.BorderColor = Color.Gainsboro;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			Point location = new Point(608, 12);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			Size size = new Size(56, 46);
			button2.Size = size;
			this.Button1.TabIndex = 26;
			this.Button1.Text = "X";
			this.Button1.UseVisualStyleBackColor = false;
			this.TotalToBePaidTB.BackColor = Color.Gold;
			this.TotalToBePaidTB.BorderStyle = BorderStyle.FixedSingle;
			this.TotalToBePaidTB.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control totalToBePaidTB = this.TotalToBePaidTB;
			location = new Point(519, 102);
			totalToBePaidTB.Location = location;
			this.TotalToBePaidTB.Name = "TotalToBePaidTB";
			this.TotalToBePaidTB.ReadOnly = true;
			Control totalToBePaidTB2 = this.TotalToBePaidTB;
			size = new Size(145, 39);
			totalToBePaidTB2.Size = size;
			this.TotalToBePaidTB.TabIndex = 27;
			this.TotalToBePaidTB.TextAlign = HorizontalAlignment.Right;
			this.CashTB.BackColor = Color.Gold;
			this.CashTB.BorderStyle = BorderStyle.FixedSingle;
			this.CashTB.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control cashTB = this.CashTB;
			location = new Point(519, 147);
			cashTB.Location = location;
			this.CashTB.Name = "CashTB";
			this.CashTB.ReadOnly = true;
			Control cashTB2 = this.CashTB;
			size = new Size(145, 39);
			cashTB2.Size = size;
			this.CashTB.TabIndex = 67;
			this.CashTB.TextAlign = HorizontalAlignment.Right;
			this.PrintBTN.BackColor = Color.Lime;
			this.PrintBTN.FlatStyle = FlatStyle.Flat;
			this.PrintBTN.Font = new Font("Arial", 24f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.PrintBTN.ForeColor = Color.Black;
			Control printBTN = this.PrintBTN;
			location = new Point(393, 297);
			printBTN.Location = location;
			this.PrintBTN.Name = "PrintBTN";
			Control printBTN2 = this.PrintBTN;
			size = new Size(271, 80);
			printBTN2.Size = size;
			this.PrintBTN.TabIndex = 80;
			this.PrintBTN.Text = "Print";
			this.PrintBTN.UseVisualStyleBackColor = false;
			this.DeleteBTN.BackColor = Color.Crimson;
			this.DeleteBTN.FlatStyle = FlatStyle.Flat;
			this.DeleteBTN.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DeleteBTN.ForeColor = Color.White;
			Control deleteBTN = this.DeleteBTN;
			location = new Point(244, 297);
			deleteBTN.Location = location;
			this.DeleteBTN.Name = "DeleteBTN";
			Control deleteBTN2 = this.DeleteBTN;
			size = new Size(100, 80);
			deleteBTN2.Size = size;
			this.DeleteBTN.TabIndex = 79;
			this.DeleteBTN.Text = "Delete";
			this.DeleteBTN.UseVisualStyleBackColor = false;
			this.Button10.BackColor = Color.Gainsboro;
			this.Button10.FlatStyle = FlatStyle.Flat;
			this.Button10.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button3 = this.Button10;
			location = new Point(32, 297);
			button3.Location = location;
			this.Button10.Name = "Button10";
			Control button4 = this.Button10;
			size = new Size(100, 80);
			button4.Size = size;
			this.Button10.TabIndex = 78;
			this.Button10.Text = "0";
			this.Button10.UseVisualStyleBackColor = false;
			this.Button9.BackColor = Color.Gainsboro;
			this.Button9.FlatStyle = FlatStyle.Flat;
			this.Button9.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button5 = this.Button9;
			location = new Point(244, 211);
			button5.Location = location;
			this.Button9.Name = "Button9";
			Control button6 = this.Button9;
			size = new Size(100, 80);
			button6.Size = size;
			this.Button9.TabIndex = 77;
			this.Button9.Text = "9";
			this.Button9.UseVisualStyleBackColor = false;
			this.Button8.BackColor = Color.Gainsboro;
			this.Button8.FlatStyle = FlatStyle.Flat;
			this.Button8.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button7 = this.Button8;
			location = new Point(138, 211);
			button7.Location = location;
			this.Button8.Name = "Button8";
			Control button8 = this.Button8;
			size = new Size(100, 80);
			button8.Size = size;
			this.Button8.TabIndex = 76;
			this.Button8.Text = "8";
			this.Button8.UseVisualStyleBackColor = false;
			this.Button7.BackColor = Color.Gainsboro;
			this.Button7.FlatStyle = FlatStyle.Flat;
			this.Button7.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button9 = this.Button7;
			location = new Point(32, 211);
			button9.Location = location;
			this.Button7.Name = "Button7";
			Control button10 = this.Button7;
			size = new Size(100, 80);
			button10.Size = size;
			this.Button7.TabIndex = 75;
			this.Button7.Text = "7";
			this.Button7.UseVisualStyleBackColor = false;
			this.Button6.BackColor = Color.Gainsboro;
			this.Button6.FlatStyle = FlatStyle.Flat;
			this.Button6.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button11 = this.Button6;
			location = new Point(244, 125);
			button11.Location = location;
			this.Button6.Name = "Button6";
			Control button12 = this.Button6;
			size = new Size(100, 80);
			button12.Size = size;
			this.Button6.TabIndex = 74;
			this.Button6.Text = "6";
			this.Button6.UseVisualStyleBackColor = false;
			this.Button5.BackColor = Color.Gainsboro;
			this.Button5.FlatStyle = FlatStyle.Flat;
			this.Button5.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button13 = this.Button5;
			location = new Point(138, 125);
			button13.Location = location;
			this.Button5.Name = "Button5";
			Control button14 = this.Button5;
			size = new Size(100, 80);
			button14.Size = size;
			this.Button5.TabIndex = 73;
			this.Button5.Text = "5";
			this.Button5.UseVisualStyleBackColor = false;
			this.Button4.BackColor = Color.Gainsboro;
			this.Button4.FlatStyle = FlatStyle.Flat;
			this.Button4.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button15 = this.Button4;
			location = new Point(32, 125);
			button15.Location = location;
			this.Button4.Name = "Button4";
			Control button16 = this.Button4;
			size = new Size(100, 80);
			button16.Size = size;
			this.Button4.TabIndex = 72;
			this.Button4.Text = "4";
			this.Button4.UseVisualStyleBackColor = false;
			this.Button3.BackColor = Color.Gainsboro;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button17 = this.Button3;
			location = new Point(244, 39);
			button17.Location = location;
			this.Button3.Name = "Button3";
			Control button18 = this.Button3;
			size = new Size(100, 80);
			button18.Size = size;
			this.Button3.TabIndex = 71;
			this.Button3.Text = "3";
			this.Button3.UseVisualStyleBackColor = false;
			this.Button2.BackColor = Color.Gainsboro;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button19 = this.Button2;
			location = new Point(138, 39);
			button19.Location = location;
			this.Button2.Name = "Button2";
			Control button20 = this.Button2;
			size = new Size(100, 80);
			button20.Size = size;
			this.Button2.TabIndex = 70;
			this.Button2.Text = "2";
			this.Button2.UseVisualStyleBackColor = false;
			this.Button12.BackColor = Color.Gainsboro;
			this.Button12.FlatStyle = FlatStyle.Flat;
			this.Button12.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control button21 = this.Button12;
			location = new Point(32, 39);
			button21.Location = location;
			this.Button12.Name = "Button12";
			Control button22 = this.Button12;
			size = new Size(100, 80);
			button22.Size = size;
			this.Button12.TabIndex = 69;
			this.Button12.Text = "1";
			this.Button12.UseVisualStyleBackColor = false;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label = this.Label1;
			location = new Point(423, 105);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(90, 32);
			label2.Size = size;
			this.Label1.TabIndex = 68;
			this.Label1.Text = "Total:";
			this.ButtonDot.BackColor = Color.Gainsboro;
			this.ButtonDot.FlatStyle = FlatStyle.Flat;
			this.ButtonDot.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control buttonDot = this.ButtonDot;
			location = new Point(138, 297);
			buttonDot.Location = location;
			this.ButtonDot.Name = "ButtonDot";
			Control buttonDot2 = this.ButtonDot;
			size = new Size(100, 80);
			buttonDot2.Size = size;
			this.ButtonDot.TabIndex = 81;
			this.ButtonDot.Text = ".";
			this.ButtonDot.UseVisualStyleBackColor = false;
			this.Button5Note.BackColor = Color.LightSkyBlue;
			this.Button5Note.FlatStyle = FlatStyle.Flat;
			this.Button5Note.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button5Note.ForeColor = SystemColors.ControlText;
			Control button5Note = this.Button5Note;
			location = new Point(12, 400);
			button5Note.Location = location;
			this.Button5Note.Name = "Button5Note";
			Control button5Note2 = this.Button5Note;
			size = new Size(160, 80);
			button5Note2.Size = size;
			this.Button5Note.TabIndex = 82;
			this.Button5Note.Text = "£5";
			this.Button5Note.UseVisualStyleBackColor = false;
			this.Button11.BackColor = Color.LightSkyBlue;
			this.Button11.FlatStyle = FlatStyle.Flat;
			this.Button11.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button11.ForeColor = SystemColors.ControlText;
			Control button23 = this.Button11;
			location = new Point(178, 400);
			button23.Location = location;
			this.Button11.Name = "Button11";
			Control button24 = this.Button11;
			size = new Size(160, 80);
			button24.Size = size;
			this.Button11.TabIndex = 83;
			this.Button11.Text = "£10";
			this.Button11.UseVisualStyleBackColor = false;
			this.Button20Note.BackColor = Color.LightSkyBlue;
			this.Button20Note.FlatStyle = FlatStyle.Flat;
			this.Button20Note.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button20Note.ForeColor = SystemColors.ControlText;
			Control button20Note = this.Button20Note;
			location = new Point(344, 400);
			button20Note.Location = location;
			this.Button20Note.Name = "Button20Note";
			Control button20Note2 = this.Button20Note;
			size = new Size(160, 80);
			button20Note2.Size = size;
			this.Button20Note.TabIndex = 84;
			this.Button20Note.Text = "£20";
			this.Button20Note.UseVisualStyleBackColor = false;
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label3 = this.Label2;
			location = new Point(421, 150);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(92, 32);
			label4.Size = size;
			this.Label2.TabIndex = 85;
			this.Label2.Text = "Cash:";
			this.ChangeTB.BackColor = Color.Gold;
			this.ChangeTB.BorderStyle = BorderStyle.FixedSingle;
			this.ChangeTB.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control changeTB = this.ChangeTB;
			location = new Point(519, 193);
			changeTB.Location = location;
			this.ChangeTB.Name = "ChangeTB";
			this.ChangeTB.ReadOnly = true;
			Control changeTB2 = this.ChangeTB;
			size = new Size(145, 39);
			changeTB2.Size = size;
			this.ChangeTB.TabIndex = 86;
			this.ChangeTB.TextAlign = HorizontalAlignment.Right;
			this.Label3.AutoSize = true;
			this.Label3.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label5 = this.Label3;
			location = new Point(387, 195);
			label5.Location = location;
			this.Label3.Name = "Label3";
			Control label6 = this.Label3;
			size = new Size(126, 32);
			label6.Size = size;
			this.Label3.TabIndex = 87;
			this.Label3.Text = "Change:";
			this.Button50Note.BackColor = Color.LightSkyBlue;
			this.Button50Note.FlatStyle = FlatStyle.Flat;
			this.Button50Note.Font = new Font("Arial Narrow", 26.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button50Note.ForeColor = SystemColors.ControlText;
			Control button50Note = this.Button50Note;
			location = new Point(510, 400);
			button50Note.Location = location;
			this.Button50Note.Name = "Button50Note";
			Control button50Note2 = this.Button50Note;
			size = new Size(160, 80);
			button50Note2.Size = size;
			this.Button50Note.TabIndex = 88;
			this.Button50Note.Text = "£50";
			this.Button50Note.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Gold;
			size = new Size(684, 493);
			this.ClientSize = size;
			this.Controls.Add(this.Button50Note);
			this.Controls.Add(this.Label3);
			this.Controls.Add(this.ChangeTB);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.Button20Note);
			this.Controls.Add(this.Button11);
			this.Controls.Add(this.Button5Note);
			this.Controls.Add(this.ButtonDot);
			this.Controls.Add(this.PrintBTN);
			this.Controls.Add(this.DeleteBTN);
			this.Controls.Add(this.Button10);
			this.Controls.Add(this.Button9);
			this.Controls.Add(this.Button8);
			this.Controls.Add(this.Button7);
			this.Controls.Add(this.Button6);
			this.Controls.Add(this.Button5);
			this.Controls.Add(this.Button4);
			this.Controls.Add(this.Button3);
			this.Controls.Add(this.Button2);
			this.Controls.Add(this.Button12);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.CashTB);
			this.Controls.Add(this.TotalToBePaidTB);
			this.Controls.Add(this.Button1);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "CalculateCustomerChange";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "CalculateCustomerChange";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x06000429 RID: 1065 RVA: 0x000246C0 File Offset: 0x000228C0
		// (set) Token: 0x0600042A RID: 1066 RVA: 0x000246D8 File Offset: 0x000228D8
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x0600042B RID: 1067 RVA: 0x00024738 File Offset: 0x00022938
		// (set) Token: 0x0600042C RID: 1068 RVA: 0x000034D2 File Offset: 0x000016D2
		internal virtual TextBox TotalToBePaidTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalToBePaidTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalToBePaidTB = value;
			}
		}

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x0600042D RID: 1069 RVA: 0x00024750 File Offset: 0x00022950
		// (set) Token: 0x0600042E RID: 1070 RVA: 0x000034DC File Offset: 0x000016DC
		internal virtual TextBox CashTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CashTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._CashTB = value;
			}
		}

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x0600042F RID: 1071 RVA: 0x00024768 File Offset: 0x00022968
		// (set) Token: 0x06000430 RID: 1072 RVA: 0x00024780 File Offset: 0x00022980
		internal virtual Button PrintBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PrintBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.SelectTableBTN_Click);
				bool flag = this._PrintBTN != null;
				if (flag)
				{
					this._PrintBTN.Click -= value2;
				}
				this._PrintBTN = value;
				flag = (this._PrintBTN != null);
				if (flag)
				{
					this._PrintBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000431 RID: 1073 RVA: 0x000247E0 File Offset: 0x000229E0
		// (set) Token: 0x06000432 RID: 1074 RVA: 0x000247F8 File Offset: 0x000229F8
		internal virtual Button DeleteBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeleteBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DeleteBTN_Click);
				bool flag = this._DeleteBTN != null;
				if (flag)
				{
					this._DeleteBTN.Click -= value2;
				}
				this._DeleteBTN = value;
				flag = (this._DeleteBTN != null);
				if (flag)
				{
					this._DeleteBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000433 RID: 1075 RVA: 0x00024858 File Offset: 0x00022A58
		// (set) Token: 0x06000434 RID: 1076 RVA: 0x00024870 File Offset: 0x00022A70
		internal virtual Button Button10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button10_Click);
				bool flag = this._Button10 != null;
				if (flag)
				{
					this._Button10.Click -= value2;
				}
				this._Button10 = value;
				flag = (this._Button10 != null);
				if (flag)
				{
					this._Button10.Click += value2;
				}
			}
		}

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x06000435 RID: 1077 RVA: 0x000248D0 File Offset: 0x00022AD0
		// (set) Token: 0x06000436 RID: 1078 RVA: 0x000248E8 File Offset: 0x00022AE8
		internal virtual Button Button9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button9_Click);
				bool flag = this._Button9 != null;
				if (flag)
				{
					this._Button9.Click -= value2;
				}
				this._Button9 = value;
				flag = (this._Button9 != null);
				if (flag)
				{
					this._Button9.Click += value2;
				}
			}
		}

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06000437 RID: 1079 RVA: 0x00024948 File Offset: 0x00022B48
		// (set) Token: 0x06000438 RID: 1080 RVA: 0x00024960 File Offset: 0x00022B60
		internal virtual Button Button8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button8_Click);
				bool flag = this._Button8 != null;
				if (flag)
				{
					this._Button8.Click -= value2;
				}
				this._Button8 = value;
				flag = (this._Button8 != null);
				if (flag)
				{
					this._Button8.Click += value2;
				}
			}
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x06000439 RID: 1081 RVA: 0x000249C0 File Offset: 0x00022BC0
		// (set) Token: 0x0600043A RID: 1082 RVA: 0x000249D8 File Offset: 0x00022BD8
		internal virtual Button Button7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button7_Click);
				bool flag = this._Button7 != null;
				if (flag)
				{
					this._Button7.Click -= value2;
				}
				this._Button7 = value;
				flag = (this._Button7 != null);
				if (flag)
				{
					this._Button7.Click += value2;
				}
			}
		}

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x0600043B RID: 1083 RVA: 0x00024A38 File Offset: 0x00022C38
		// (set) Token: 0x0600043C RID: 1084 RVA: 0x00024A50 File Offset: 0x00022C50
		internal virtual Button Button6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button6_Click);
				bool flag = this._Button6 != null;
				if (flag)
				{
					this._Button6.Click -= value2;
				}
				this._Button6 = value;
				flag = (this._Button6 != null);
				if (flag)
				{
					this._Button6.Click += value2;
				}
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x0600043D RID: 1085 RVA: 0x00024AB0 File Offset: 0x00022CB0
		// (set) Token: 0x0600043E RID: 1086 RVA: 0x00024AC8 File Offset: 0x00022CC8
		internal virtual Button Button5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click);
				bool flag = this._Button5 != null;
				if (flag)
				{
					this._Button5.Click -= value2;
				}
				this._Button5 = value;
				flag = (this._Button5 != null);
				if (flag)
				{
					this._Button5.Click += value2;
				}
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x0600043F RID: 1087 RVA: 0x00024B28 File Offset: 0x00022D28
		// (set) Token: 0x06000440 RID: 1088 RVA: 0x00024B40 File Offset: 0x00022D40
		internal virtual Button Button4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				bool flag = this._Button4 != null;
				if (flag)
				{
					this._Button4.Click -= value2;
				}
				this._Button4 = value;
				flag = (this._Button4 != null);
				if (flag)
				{
					this._Button4.Click += value2;
				}
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x00024BA0 File Offset: 0x00022DA0
		// (set) Token: 0x06000442 RID: 1090 RVA: 0x00024BB8 File Offset: 0x00022DB8
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x06000443 RID: 1091 RVA: 0x00024C18 File Offset: 0x00022E18
		// (set) Token: 0x06000444 RID: 1092 RVA: 0x00024C30 File Offset: 0x00022E30
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000445 RID: 1093 RVA: 0x00024C90 File Offset: 0x00022E90
		// (set) Token: 0x06000446 RID: 1094 RVA: 0x00024CA8 File Offset: 0x00022EA8
		internal virtual Button Button12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button12_Click);
				bool flag = this._Button12 != null;
				if (flag)
				{
					this._Button12.Click -= value2;
				}
				this._Button12 = value;
				flag = (this._Button12 != null);
				if (flag)
				{
					this._Button12.Click += value2;
				}
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000447 RID: 1095 RVA: 0x00024D08 File Offset: 0x00022F08
		// (set) Token: 0x06000448 RID: 1096 RVA: 0x000034E6 File Offset: 0x000016E6
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000449 RID: 1097 RVA: 0x00024D20 File Offset: 0x00022F20
		// (set) Token: 0x0600044A RID: 1098 RVA: 0x00024D38 File Offset: 0x00022F38
		internal virtual Button ButtonDot
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ButtonDot;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ButtonDot_Click);
				bool flag = this._ButtonDot != null;
				if (flag)
				{
					this._ButtonDot.Click -= value2;
				}
				this._ButtonDot = value;
				flag = (this._ButtonDot != null);
				if (flag)
				{
					this._ButtonDot.Click += value2;
				}
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x0600044B RID: 1099 RVA: 0x00024D98 File Offset: 0x00022F98
		// (set) Token: 0x0600044C RID: 1100 RVA: 0x00024DB0 File Offset: 0x00022FB0
		internal virtual Button Button5Note
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5Note;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5Note_Click);
				bool flag = this._Button5Note != null;
				if (flag)
				{
					this._Button5Note.Click -= value2;
				}
				this._Button5Note = value;
				flag = (this._Button5Note != null);
				if (flag)
				{
					this._Button5Note.Click += value2;
				}
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x0600044D RID: 1101 RVA: 0x00024E10 File Offset: 0x00023010
		// (set) Token: 0x0600044E RID: 1102 RVA: 0x00024E28 File Offset: 0x00023028
		internal virtual Button Button11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button11_Click);
				bool flag = this._Button11 != null;
				if (flag)
				{
					this._Button11.Click -= value2;
				}
				this._Button11 = value;
				flag = (this._Button11 != null);
				if (flag)
				{
					this._Button11.Click += value2;
				}
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x0600044F RID: 1103 RVA: 0x00024E88 File Offset: 0x00023088
		// (set) Token: 0x06000450 RID: 1104 RVA: 0x00024EA0 File Offset: 0x000230A0
		internal virtual Button Button20Note
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button20Note;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button20Note_Click);
				bool flag = this._Button20Note != null;
				if (flag)
				{
					this._Button20Note.Click -= value2;
				}
				this._Button20Note = value;
				flag = (this._Button20Note != null);
				if (flag)
				{
					this._Button20Note.Click += value2;
				}
			}
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000451 RID: 1105 RVA: 0x00024F00 File Offset: 0x00023100
		// (set) Token: 0x06000452 RID: 1106 RVA: 0x000034F0 File Offset: 0x000016F0
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000453 RID: 1107 RVA: 0x00024F18 File Offset: 0x00023118
		// (set) Token: 0x06000454 RID: 1108 RVA: 0x000034FA File Offset: 0x000016FA
		internal virtual TextBox ChangeTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ChangeTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ChangeTB = value;
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000455 RID: 1109 RVA: 0x00024F30 File Offset: 0x00023130
		// (set) Token: 0x06000456 RID: 1110 RVA: 0x00003504 File Offset: 0x00001704
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000457 RID: 1111 RVA: 0x00024F48 File Offset: 0x00023148
		// (set) Token: 0x06000458 RID: 1112 RVA: 0x00024F60 File Offset: 0x00023160
		internal virtual Button Button50Note
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button50Note;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button50Note_Click);
				bool flag = this._Button50Note != null;
				if (flag)
				{
					this._Button50Note.Click -= value2;
				}
				this._Button50Note = value;
				flag = (this._Button50Note != null);
				if (flag)
				{
					this._Button50Note.Click += value2;
				}
			}
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00003422 File Offset: 0x00001622
		private void Button1_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0000350E File Offset: 0x0000170E
		private void CalculateCustomerChange_Load(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Show();
			this.TotalToBePaidTB.Text = Strings.Format(M_Calculates.OrderTotal, "0.00");
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x00003542 File Offset: 0x00001742
		private void SelectTableBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Close();
			this.Close();
			MyProject.Forms.POS_Window.PMButtonClick("Cash");
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x00024FC0 File Offset: 0x000231C0
		private void CalculateChange()
		{
			this.ChangeTB.Text = Strings.Format(decimal.Subtract(Conversions.ToDecimal(this.CashTB.Text), Conversions.ToDecimal(this.TotalToBePaidTB.Text)), "0.00");
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00003572 File Offset: 0x00001772
		private void DeleteBTN_Click(object sender, EventArgs e)
		{
			this.ChangeTB.Text = "";
			this.CashTB.Text = "";
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x00003598 File Offset: 0x00001798
		private void Button12_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "1";
			this.CalculateChange();
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x000035C4 File Offset: 0x000017C4
		private void Button2_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "2";
			this.CalculateChange();
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x000035F0 File Offset: 0x000017F0
		private void Button3_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "3";
			this.CalculateChange();
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0000361C File Offset: 0x0000181C
		private void Button4_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "4";
			this.CalculateChange();
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x00003648 File Offset: 0x00001848
		private void Button5_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "5";
			this.CalculateChange();
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x00003674 File Offset: 0x00001874
		private void Button6_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "6";
			this.CalculateChange();
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x000036A0 File Offset: 0x000018A0
		private void Button7_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "7";
			this.CalculateChange();
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x000036CC File Offset: 0x000018CC
		private void Button8_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "8";
			this.CalculateChange();
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x000036F8 File Offset: 0x000018F8
		private void Button9_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "9";
			this.CalculateChange();
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x00003724 File Offset: 0x00001924
		private void Button10_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + "0";
			this.CalculateChange();
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00003750 File Offset: 0x00001950
		private void ButtonDot_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = this.CashTB.Text + ".";
			this.CalculateChange();
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x0000377C File Offset: 0x0000197C
		private void Button5Note_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = "5";
			this.CalculateChange();
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00003798 File Offset: 0x00001998
		private void Button11_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = "10";
			this.CalculateChange();
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x000037B4 File Offset: 0x000019B4
		private void Button20Note_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = "20";
			this.CalculateChange();
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x000037D0 File Offset: 0x000019D0
		private void Button50Note_Click(object sender, EventArgs e)
		{
			this.CashTB.Text = "50";
			this.CalculateChange();
		}

		// Token: 0x0400018D RID: 397
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x0400018E RID: 398
		private IContainer components;

		// Token: 0x0400018F RID: 399
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000190 RID: 400
		[AccessedThroughProperty("TotalToBePaidTB")]
		private TextBox _TotalToBePaidTB;

		// Token: 0x04000191 RID: 401
		[AccessedThroughProperty("CashTB")]
		private TextBox _CashTB;

		// Token: 0x04000192 RID: 402
		[AccessedThroughProperty("PrintBTN")]
		private Button _PrintBTN;

		// Token: 0x04000193 RID: 403
		[AccessedThroughProperty("DeleteBTN")]
		private Button _DeleteBTN;

		// Token: 0x04000194 RID: 404
		[AccessedThroughProperty("Button10")]
		private Button _Button10;

		// Token: 0x04000195 RID: 405
		[AccessedThroughProperty("Button9")]
		private Button _Button9;

		// Token: 0x04000196 RID: 406
		[AccessedThroughProperty("Button8")]
		private Button _Button8;

		// Token: 0x04000197 RID: 407
		[AccessedThroughProperty("Button7")]
		private Button _Button7;

		// Token: 0x04000198 RID: 408
		[AccessedThroughProperty("Button6")]
		private Button _Button6;

		// Token: 0x04000199 RID: 409
		[AccessedThroughProperty("Button5")]
		private Button _Button5;

		// Token: 0x0400019A RID: 410
		[AccessedThroughProperty("Button4")]
		private Button _Button4;

		// Token: 0x0400019B RID: 411
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x0400019C RID: 412
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x0400019D RID: 413
		[AccessedThroughProperty("Button12")]
		private Button _Button12;

		// Token: 0x0400019E RID: 414
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x0400019F RID: 415
		[AccessedThroughProperty("ButtonDot")]
		private Button _ButtonDot;

		// Token: 0x040001A0 RID: 416
		[AccessedThroughProperty("Button5Note")]
		private Button _Button5Note;

		// Token: 0x040001A1 RID: 417
		[AccessedThroughProperty("Button11")]
		private Button _Button11;

		// Token: 0x040001A2 RID: 418
		[AccessedThroughProperty("Button20Note")]
		private Button _Button20Note;

		// Token: 0x040001A3 RID: 419
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x040001A4 RID: 420
		[AccessedThroughProperty("ChangeTB")]
		private TextBox _ChangeTB;

		// Token: 0x040001A5 RID: 421
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x040001A6 RID: 422
		[AccessedThroughProperty("Button50Note")]
		private Button _Button50Note;
	}
}
