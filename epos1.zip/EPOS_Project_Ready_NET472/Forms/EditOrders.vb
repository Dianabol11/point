using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200001D RID: 29
	[DesignerGenerated]
	public class EditOrders : Form
	{
		// Token: 0x060004B5 RID: 1205 RVA: 0x00027784 File Offset: 0x00025984
		public EditOrders()
		{
			base.Load += this.ActiveOrders_Load;
			List<WeakReference> _ENCList = EditOrders.__ENCList;
			lock (_ENCList)
			{
				EditOrders.__ENCList.Add(new WeakReference(this));
			}
			this.TLP_ActiveOrders = new TableLayoutPanel();
			this.InitializeComponent();
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x000277FC File Offset: 0x000259FC
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x0002784C File Offset: 0x00025A4C
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
			this.ActiveOrdersDGV = new DataGridView();
			this.C1 = new DataGridViewTextBoxColumn();
			this.C2 = new DataGridViewTextBoxColumn();
			this.C3 = new DataGridViewTextBoxColumn();
			this.C4 = new DataGridViewTextBoxColumn();
			this.C5 = new DataGridViewTextBoxColumn();
			this.C6 = new DataGridViewTextBoxColumn();
			this.C7 = new DataGridViewTextBoxColumn();
			this.C9 = new DataGridViewTextBoxColumn();
			this.C11 = new DataGridViewTextBoxColumn();
			this.C10 = new DataGridViewTextBoxColumn();
			this.DateTimeCol = new DataGridViewTextBoxColumn();
			this.Label1 = new Label();
			this.BottomPanel = new Panel();
			this.GoogleMapBTN = new Button();
			this.RePrintOrderBTN = new Button();
			this.EditOrderBTN = new Button();
			this.CancelOrderBTN = new Button();
			this.Button1 = new Button();
			this.EditOrderButtonsPanel = new Panel();
			this.Exit_Program = new Button();
			this.EditDeliveryAddressBTN = new Button();
			this.Button3 = new Button();
			((ISupportInitialize)this.ActiveOrdersDGV).BeginInit();
			this.BottomPanel.SuspendLayout();
			this.EditOrderButtonsPanel.SuspendLayout();
			this.SuspendLayout();
			this.ActiveOrdersDGV.AllowUserToAddRows = false;
			this.ActiveOrdersDGV.AllowUserToDeleteRows = false;
			this.ActiveOrdersDGV.AllowUserToResizeRows = false;
			this.ActiveOrdersDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			this.ActiveOrdersDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
			this.ActiveOrdersDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.ActiveOrdersDGV.Columns.AddRange(new DataGridViewColumn[]
			{
				this.C1,
				this.C2,
				this.C3,
				this.C4,
				this.C5,
				this.C6,
				this.C7,
				this.C9,
				this.C11,
				this.C10,
				this.DateTimeCol
			});
			this.ActiveOrdersDGV.Dock = DockStyle.Top;
			this.ActiveOrdersDGV.GridColor = Color.Gray;
			Control activeOrdersDGV = this.ActiveOrdersDGV;
			Point location = new Point(0, 0);
			activeOrdersDGV.Location = location;
			this.ActiveOrdersDGV.MultiSelect = false;
			this.ActiveOrdersDGV.Name = "ActiveOrdersDGV";
			this.ActiveOrdersDGV.ReadOnly = true;
			this.ActiveOrdersDGV.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
			this.ActiveOrdersDGV.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
			this.ActiveOrdersDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
			this.ActiveOrdersDGV.ShowCellErrors = false;
			this.ActiveOrdersDGV.ShowCellToolTips = false;
			this.ActiveOrdersDGV.ShowRowErrors = false;
			Control activeOrdersDGV2 = this.ActiveOrdersDGV;
			Size size = new Size(1042, 433);
			activeOrdersDGV2.Size = size;
			this.ActiveOrdersDGV.TabIndex = 29;
			dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C1.DefaultCellStyle = dataGridViewCellStyle;
			this.C1.FillWeight = 56.76831f;
			this.C1.HeaderText = "no";
			this.C1.Name = "C1";
			this.C1.ReadOnly = true;
			this.C1.Resizable = DataGridViewTriState.False;
			dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C2.DefaultCellStyle = dataGridViewCellStyle2;
			this.C2.FillWeight = 55.92848f;
			this.C2.HeaderText = "time";
			this.C2.Name = "C2";
			this.C2.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C3.DefaultCellStyle = dataGridViewCellStyle3;
			this.C3.FillWeight = 102.6321f;
			this.C3.HeaderText = "takeawaydelivery";
			this.C3.Name = "C3";
			this.C3.ReadOnly = true;
			dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C4.DefaultCellStyle = dataGridViewCellStyle4;
			this.C4.FillWeight = 96.05318f;
			this.C4.HeaderText = "cashcard";
			this.C4.Name = "C4";
			this.C4.ReadOnly = true;
			dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C5.DefaultCellStyle = dataGridViewCellStyle5;
			this.C5.FillWeight = 121.9256f;
			this.C5.HeaderText = "tel";
			this.C5.Name = "C5";
			this.C5.ReadOnly = true;
			this.C6.FillWeight = 152.2843f;
			this.C6.HeaderText = "address";
			this.C6.Name = "C6";
			this.C6.ReadOnly = true;
			dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C7.DefaultCellStyle = dataGridViewCellStyle6;
			this.C7.FillWeight = 112.407f;
			this.C7.HeaderText = "city";
			this.C7.Name = "C7";
			this.C7.ReadOnly = true;
			dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C9.DefaultCellStyle = dataGridViewCellStyle7;
			this.C9.FillWeight = 90.73148f;
			this.C9.HeaderText = "postcode";
			this.C9.Name = "C9";
			this.C9.ReadOnly = true;
			dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C11.DefaultCellStyle = dataGridViewCellStyle8;
			this.C11.FillWeight = 124.4961f;
			this.C11.HeaderText = "driver";
			this.C11.Name = "C11";
			this.C11.ReadOnly = true;
			dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleCenter;
			this.C10.DefaultCellStyle = dataGridViewCellStyle9;
			this.C10.FillWeight = 86.77339f;
			this.C10.HeaderText = "total";
			this.C10.Name = "C10";
			this.C10.ReadOnly = true;
			this.DateTimeCol.HeaderText = "DateTimeCol";
			this.DateTimeCol.Name = "DateTimeCol";
			this.DateTimeCol.ReadOnly = true;
			this.DateTimeCol.Visible = false;
			this.Label1.AutoSize = true;
			this.Label1.BackColor = Color.DarkGray;
			this.Label1.Font = new Font("Arial", 27.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.WhiteSmoke;
			Control label = this.Label1;
			location = new Point(239, 42);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(305, 42);
			label2.Size = size;
			this.Label1.TabIndex = 30;
			this.Label1.Text = "There is no order.";
			this.Label1.Visible = false;
			this.BottomPanel.BackColor = Color.SteelBlue;
			this.BottomPanel.Controls.Add(this.GoogleMapBTN);
			this.BottomPanel.Controls.Add(this.RePrintOrderBTN);
			this.BottomPanel.Controls.Add(this.EditOrderBTN);
			this.BottomPanel.Controls.Add(this.CancelOrderBTN);
			this.BottomPanel.Controls.Add(this.Button1);
			this.BottomPanel.Dock = DockStyle.Bottom;
			Control bottomPanel = this.BottomPanel;
			location = new Point(0, 439);
			bottomPanel.Location = location;
			this.BottomPanel.Name = "BottomPanel";
			Control bottomPanel2 = this.BottomPanel;
			size = new Size(1042, 97);
			bottomPanel2.Size = size;
			this.BottomPanel.TabIndex = 31;
			this.GoogleMapBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.GoogleMapBTN.BackColor = Color.LightSkyBlue;
			this.GoogleMapBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.GoogleMapBTN.FlatStyle = FlatStyle.Flat;
			this.GoogleMapBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.GoogleMapBTN.ForeColor = Color.Black;
			Control googleMapBTN = this.GoogleMapBTN;
			location = new Point(576, 23);
			googleMapBTN.Location = location;
			this.GoogleMapBTN.Name = "GoogleMapBTN";
			Control googleMapBTN2 = this.GoogleMapBTN;
			size = new Size(182, 56);
			googleMapBTN2.Size = size;
			this.GoogleMapBTN.TabIndex = 35;
			this.GoogleMapBTN.Text = "Google Map";
			this.GoogleMapBTN.UseVisualStyleBackColor = false;
			this.GoogleMapBTN.Visible = false;
			this.RePrintOrderBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.RePrintOrderBTN.BackColor = Color.MediumPurple;
			this.RePrintOrderBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.RePrintOrderBTN.FlatStyle = FlatStyle.Flat;
			this.RePrintOrderBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.RePrintOrderBTN.ForeColor = Color.Black;
			Control rePrintOrderBTN = this.RePrintOrderBTN;
			location = new Point(12, 23);
			rePrintOrderBTN.Location = location;
			this.RePrintOrderBTN.Name = "RePrintOrderBTN";
			Control rePrintOrderBTN2 = this.RePrintOrderBTN;
			size = new Size(182, 56);
			rePrintOrderBTN2.Size = size;
			this.RePrintOrderBTN.TabIndex = 34;
			this.RePrintOrderBTN.Text = "Print Order";
			this.RePrintOrderBTN.UseVisualStyleBackColor = false;
			this.RePrintOrderBTN.Visible = false;
			this.EditOrderBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.EditOrderBTN.BackColor = Color.LimeGreen;
			this.EditOrderBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.EditOrderBTN.FlatStyle = FlatStyle.Flat;
			this.EditOrderBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.EditOrderBTN.ForeColor = Color.Black;
			Control editOrderBTN = this.EditOrderBTN;
			location = new Point(200, 23);
			editOrderBTN.Location = location;
			this.EditOrderBTN.Name = "EditOrderBTN";
			Control editOrderBTN2 = this.EditOrderBTN;
			size = new Size(182, 56);
			editOrderBTN2.Size = size;
			this.EditOrderBTN.TabIndex = 33;
			this.EditOrderBTN.Text = "Edit order";
			this.EditOrderBTN.UseVisualStyleBackColor = false;
			this.EditOrderBTN.Visible = false;
			this.CancelOrderBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.CancelOrderBTN.BackColor = Color.Orange;
			this.CancelOrderBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.CancelOrderBTN.FlatStyle = FlatStyle.Flat;
			this.CancelOrderBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.CancelOrderBTN.ForeColor = Color.Black;
			Control cancelOrderBTN = this.CancelOrderBTN;
			location = new Point(388, 23);
			cancelOrderBTN.Location = location;
			this.CancelOrderBTN.Name = "CancelOrderBTN";
			Control cancelOrderBTN2 = this.CancelOrderBTN;
			size = new Size(182, 56);
			cancelOrderBTN2.Size = size;
			this.CancelOrderBTN.TabIndex = 32;
			this.CancelOrderBTN.Text = "Cancel order";
			this.CancelOrderBTN.UseVisualStyleBackColor = false;
			this.CancelOrderBTN.Visible = false;
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.Button1.BackColor = Color.FromArgb(178, 1, 1);
			this.Button1.FlatAppearance.BorderColor = Color.Gainsboro;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 20.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(902, 23);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			size = new Size(128, 56);
			button2.Size = size;
			this.Button1.TabIndex = 31;
			this.Button1.Text = "Exit";
			this.Button1.UseVisualStyleBackColor = false;
			this.EditOrderButtonsPanel.BackColor = Color.Gold;
			this.EditOrderButtonsPanel.Controls.Add(this.Exit_Program);
			this.EditOrderButtonsPanel.Controls.Add(this.EditDeliveryAddressBTN);
			this.EditOrderButtonsPanel.Controls.Add(this.Button3);
			Control editOrderButtonsPanel = this.EditOrderButtonsPanel;
			location = new Point(160, 87);
			editOrderButtonsPanel.Location = location;
			this.EditOrderButtonsPanel.Name = "EditOrderButtonsPanel";
			Control editOrderButtonsPanel2 = this.EditOrderButtonsPanel;
			size = new Size(500, 300);
			editOrderButtonsPanel2.Size = size;
			this.EditOrderButtonsPanel.TabIndex = 32;
			this.EditOrderButtonsPanel.Visible = false;
			this.Exit_Program.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.Exit_Program.BackColor = Color.Crimson;
			this.Exit_Program.FlatStyle = FlatStyle.Popup;
			this.Exit_Program.Font = new Font("Arial Black", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Exit_Program.ForeColor = SystemColors.Window;
			Control exit_Program = this.Exit_Program;
			location = new Point(443, 14);
			exit_Program.Location = location;
			this.Exit_Program.Name = "Exit_Program";
			Control exit_Program2 = this.Exit_Program;
			size = new Size(40, 40);
			exit_Program2.Size = size;
			this.Exit_Program.TabIndex = 36;
			this.Exit_Program.Text = "X";
			this.Exit_Program.UseVisualStyleBackColor = false;
			this.EditDeliveryAddressBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.EditDeliveryAddressBTN.BackColor = Color.LightSkyBlue;
			this.EditDeliveryAddressBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.EditDeliveryAddressBTN.FlatStyle = FlatStyle.Flat;
			this.EditDeliveryAddressBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.EditDeliveryAddressBTN.ForeColor = Color.Black;
			Control editDeliveryAddressBTN = this.EditDeliveryAddressBTN;
			location = new Point(29, 184);
			editDeliveryAddressBTN.Location = location;
			this.EditDeliveryAddressBTN.Name = "EditDeliveryAddressBTN";
			Control editDeliveryAddressBTN2 = this.EditDeliveryAddressBTN;
			size = new Size(444, 86);
			editDeliveryAddressBTN2.Size = size;
			this.EditDeliveryAddressBTN.TabIndex = 35;
			this.EditDeliveryAddressBTN.Text = "Edit delivery address and order";
			this.EditDeliveryAddressBTN.UseVisualStyleBackColor = false;
			this.Button3.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button3.BackColor = Color.Lime;
			this.Button3.FlatAppearance.BorderColor = Color.Gainsboro;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button3.ForeColor = Color.Black;
			Control button3 = this.Button3;
			location = new Point(29, 77);
			button3.Location = location;
			this.Button3.Name = "Button3";
			Control button4 = this.Button3;
			size = new Size(444, 86);
			button4.Size = size;
			this.Button3.TabIndex = 34;
			this.Button3.Text = "Edit order only";
			this.Button3.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(1042, 536);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.EditOrderButtonsPanel);
			this.Controls.Add(this.BottomPanel);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.ActiveOrdersDGV);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "EditOrders";
			this.Text = "ActiveOrders";
			this.WindowState = FormWindowState.Maximized;
			((ISupportInitialize)this.ActiveOrdersDGV).EndInit();
			this.BottomPanel.ResumeLayout(false);
			this.EditOrderButtonsPanel.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x060004B8 RID: 1208 RVA: 0x000289E0 File Offset: 0x00026BE0
		// (set) Token: 0x060004B9 RID: 1209 RVA: 0x000289F8 File Offset: 0x00026BF8
		internal virtual DataGridView ActiveOrdersDGV
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ActiveOrdersDGV;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				DataGridViewCellEventHandler value2 = new DataGridViewCellEventHandler(this.ActiveOrdersDGV_CellClick);
				bool flag = this._ActiveOrdersDGV != null;
				if (flag)
				{
					this._ActiveOrdersDGV.CellClick -= value2;
				}
				this._ActiveOrdersDGV = value;
				flag = (this._ActiveOrdersDGV != null);
				if (flag)
				{
					this._ActiveOrdersDGV.CellClick += value2;
				}
			}
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x060004BA RID: 1210 RVA: 0x00028A58 File Offset: 0x00026C58
		// (set) Token: 0x060004BB RID: 1211 RVA: 0x00003952 File Offset: 0x00001B52
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x060004BC RID: 1212 RVA: 0x00028A70 File Offset: 0x00026C70
		// (set) Token: 0x060004BD RID: 1213 RVA: 0x0000395C File Offset: 0x00001B5C
		internal virtual Panel BottomPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BottomPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BottomPanel = value;
			}
		}

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x060004BE RID: 1214 RVA: 0x00028A88 File Offset: 0x00026C88
		// (set) Token: 0x060004BF RID: 1215 RVA: 0x00028AA0 File Offset: 0x00026CA0
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x060004C0 RID: 1216 RVA: 0x00028B00 File Offset: 0x00026D00
		// (set) Token: 0x060004C1 RID: 1217 RVA: 0x00028B18 File Offset: 0x00026D18
		internal virtual Button CancelOrderBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CancelOrderBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._CancelOrderBTN != null;
				if (flag)
				{
					this._CancelOrderBTN.Click -= value2;
				}
				this._CancelOrderBTN = value;
				flag = (this._CancelOrderBTN != null);
				if (flag)
				{
					this._CancelOrderBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x060004C2 RID: 1218 RVA: 0x00028B78 File Offset: 0x00026D78
		// (set) Token: 0x060004C3 RID: 1219 RVA: 0x00003966 File Offset: 0x00001B66
		internal virtual DataGridViewTextBoxColumn C1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C1 = value;
			}
		}

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x060004C4 RID: 1220 RVA: 0x00028B90 File Offset: 0x00026D90
		// (set) Token: 0x060004C5 RID: 1221 RVA: 0x00003970 File Offset: 0x00001B70
		internal virtual DataGridViewTextBoxColumn C2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C2 = value;
			}
		}

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x060004C6 RID: 1222 RVA: 0x00028BA8 File Offset: 0x00026DA8
		// (set) Token: 0x060004C7 RID: 1223 RVA: 0x0000397A File Offset: 0x00001B7A
		internal virtual DataGridViewTextBoxColumn C3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C3 = value;
			}
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x060004C8 RID: 1224 RVA: 0x00028BC0 File Offset: 0x00026DC0
		// (set) Token: 0x060004C9 RID: 1225 RVA: 0x00003984 File Offset: 0x00001B84
		internal virtual DataGridViewTextBoxColumn C4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C4 = value;
			}
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x060004CA RID: 1226 RVA: 0x00028BD8 File Offset: 0x00026DD8
		// (set) Token: 0x060004CB RID: 1227 RVA: 0x0000398E File Offset: 0x00001B8E
		internal virtual DataGridViewTextBoxColumn C5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C5 = value;
			}
		}

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x060004CC RID: 1228 RVA: 0x00028BF0 File Offset: 0x00026DF0
		// (set) Token: 0x060004CD RID: 1229 RVA: 0x00003998 File Offset: 0x00001B98
		internal virtual DataGridViewTextBoxColumn C6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C6 = value;
			}
		}

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x00028C08 File Offset: 0x00026E08
		// (set) Token: 0x060004CF RID: 1231 RVA: 0x000039A2 File Offset: 0x00001BA2
		internal virtual DataGridViewTextBoxColumn C7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C7 = value;
			}
		}

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x060004D0 RID: 1232 RVA: 0x00028C20 File Offset: 0x00026E20
		// (set) Token: 0x060004D1 RID: 1233 RVA: 0x000039AC File Offset: 0x00001BAC
		internal virtual DataGridViewTextBoxColumn C9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C9 = value;
			}
		}

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x060004D2 RID: 1234 RVA: 0x00028C38 File Offset: 0x00026E38
		// (set) Token: 0x060004D3 RID: 1235 RVA: 0x000039B6 File Offset: 0x00001BB6
		internal virtual DataGridViewTextBoxColumn C11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C11 = value;
			}
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x00028C50 File Offset: 0x00026E50
		// (set) Token: 0x060004D5 RID: 1237 RVA: 0x000039C0 File Offset: 0x00001BC0
		internal virtual DataGridViewTextBoxColumn C10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._C10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._C10 = value;
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x060004D6 RID: 1238 RVA: 0x00028C68 File Offset: 0x00026E68
		// (set) Token: 0x060004D7 RID: 1239 RVA: 0x000039CA File Offset: 0x00001BCA
		internal virtual DataGridViewTextBoxColumn DateTimeCol
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DateTimeCol;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DateTimeCol = value;
			}
		}

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x060004D8 RID: 1240 RVA: 0x00028C80 File Offset: 0x00026E80
		// (set) Token: 0x060004D9 RID: 1241 RVA: 0x00028C98 File Offset: 0x00026E98
		internal virtual Button RePrintOrderBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._RePrintOrderBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.RePrintOrderBTN_Click);
				bool flag = this._RePrintOrderBTN != null;
				if (flag)
				{
					this._RePrintOrderBTN.Click -= value2;
				}
				this._RePrintOrderBTN = value;
				flag = (this._RePrintOrderBTN != null);
				if (flag)
				{
					this._RePrintOrderBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x060004DA RID: 1242 RVA: 0x00028CF8 File Offset: 0x00026EF8
		// (set) Token: 0x060004DB RID: 1243 RVA: 0x00028D10 File Offset: 0x00026F10
		internal virtual Button GoogleMapBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GoogleMapBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.GoogleMapBTN_Click);
				bool flag = this._GoogleMapBTN != null;
				if (flag)
				{
					this._GoogleMapBTN.Click -= value2;
				}
				this._GoogleMapBTN = value;
				flag = (this._GoogleMapBTN != null);
				if (flag)
				{
					this._GoogleMapBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x060004DC RID: 1244 RVA: 0x00028D70 File Offset: 0x00026F70
		// (set) Token: 0x060004DD RID: 1245 RVA: 0x00028D88 File Offset: 0x00026F88
		internal virtual Button EditOrderBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EditOrderBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.EditOrderBTN_Click);
				bool flag = this._EditOrderBTN != null;
				if (flag)
				{
					this._EditOrderBTN.Click -= value2;
				}
				this._EditOrderBTN = value;
				flag = (this._EditOrderBTN != null);
				if (flag)
				{
					this._EditOrderBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x060004DE RID: 1246 RVA: 0x00028DE8 File Offset: 0x00026FE8
		// (set) Token: 0x060004DF RID: 1247 RVA: 0x000039D4 File Offset: 0x00001BD4
		internal virtual Panel EditOrderButtonsPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EditOrderButtonsPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._EditOrderButtonsPanel = value;
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x060004E0 RID: 1248 RVA: 0x00028E00 File Offset: 0x00027000
		// (set) Token: 0x060004E1 RID: 1249 RVA: 0x00028E18 File Offset: 0x00027018
		internal virtual Button EditDeliveryAddressBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._EditDeliveryAddressBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				bool flag = this._EditDeliveryAddressBTN != null;
				if (flag)
				{
					this._EditDeliveryAddressBTN.Click -= value2;
				}
				this._EditDeliveryAddressBTN = value;
				flag = (this._EditDeliveryAddressBTN != null);
				if (flag)
				{
					this._EditDeliveryAddressBTN.Click += value2;
				}
			}
		}

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x060004E2 RID: 1250 RVA: 0x00028E78 File Offset: 0x00027078
		// (set) Token: 0x060004E3 RID: 1251 RVA: 0x00028E90 File Offset: 0x00027090
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x060004E4 RID: 1252 RVA: 0x00028EF0 File Offset: 0x000270F0
		// (set) Token: 0x060004E5 RID: 1253 RVA: 0x00028F08 File Offset: 0x00027108
		internal virtual Button Exit_Program
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Exit_Program;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Exit_Program_Click);
				bool flag = this._Exit_Program != null;
				if (flag)
				{
					this._Exit_Program.Click -= value2;
				}
				this._Exit_Program = value;
				flag = (this._Exit_Program != null);
				if (flag)
				{
					this._Exit_Program.Click += value2;
				}
			}
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x00028F68 File Offset: 0x00027168
		private void ActiveOrders_Load(object sender, EventArgs e)
		{
			bool flag = !File.Exists(M_Settings.DataFolder + "\\order_history\\_today\\_TodayOrderList.txt");
			checked
			{
				if (flag)
				{
					this.ActiveOrdersDGV.Hide();
				}
				else
				{
					this.ActiveOrdersDGV.Show();
					Font font = this.ActiveOrdersDGV.DefaultCellStyle.Font;
					DataGridView activeOrdersDGV = this.ActiveOrdersDGV;
					activeOrdersDGV.ReadOnly = true;
					activeOrdersDGV.MultiSelect = false;
					activeOrdersDGV.ColumnHeadersVisible = false;
					activeOrdersDGV.RowTemplate.Height = 55;
					activeOrdersDGV.DefaultCellStyle.Font = new Font("Arial", 14f, FontStyle.Bold);
					activeOrdersDGV.Height = M_Settings.ScreenHeight - 60;
					activeOrdersDGV.Width = M_Settings.ScreenWidth;
					activeOrdersDGV.ColumnHeadersVisible = false;
					activeOrdersDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
					activeOrdersDGV.RowHeadersVisible = false;
					this.ActiveOrdersArray = File.ReadAllLines(M_Settings.DataFolder + "\\order_history\\_today\\_TodayOrderList.txt");
					flag = (this.ActiveOrdersArray.Count<string>() > 0);
					if (flag)
					{
						this.Label1.Hide();
					}
					else
					{
						this.Label1.Show();
					}
					int num = -1;
					foreach (string text in this.ActiveOrdersArray)
					{
						num++;
						flag = (text.Length > 10);
						if (flag)
						{
							string text2 = text.Split(new char[]
							{
								'|'
							})[1].Substring(8, 2) + ":" + text.Split(new char[]
							{
								'|'
							})[1].Substring(10, 2);
							string text3 = text.Split(new char[]
							{
								'|'
							})[5];
							flag = (Operators.CompareString(text3, "DriverName", false) == 0);
							if (flag)
							{
								text3 = "-";
							}
							this.ActiveOrdersDGV.Rows.Add(new object[]
							{
								text.Split(new char[]
								{
									'|'
								})[0],
								text2,
								text.Split(new char[]
								{
									'|'
								})[2],
								text.Split(new char[]
								{
									'|'
								})[4],
								text.Split(new char[]
								{
									'|'
								})[7],
								text.Split(new char[]
								{
									'|'
								})[8],
								text.Split(new char[]
								{
									'|'
								})[9],
								text.Split(new char[]
								{
									'|'
								})[10],
								text3,
								"£" + text.Split(new char[]
								{
									'|'
								})[15],
								text.Split(new char[]
								{
									'|'
								})[1]
							});
							flag = ((text.Contains("Cancelled") | text.Contains("Complete")) & Operators.CompareString(MySettingsProperty.Settings.SafeMode, "y", false) == 0);
							if (flag)
							{
								this.ActiveOrdersDGV.Rows[num].DefaultCellStyle.ForeColor = Color.DarkGray;
								this.ActiveOrdersDGV.Rows[num].DefaultCellStyle.Font = new Font("Arial", 14f, FontStyle.Strikeout);
							}
							flag = (Operators.CompareString(M_Settings.OrderToDriverStatus, "yes", false) == 0 & Operators.CompareString(text3, "-", false) != 0 & Operators.CompareString(MySettingsProperty.Settings.SafeMode, "y", false) == 0);
							if (flag)
							{
								this.ActiveOrdersDGV.Rows[num].DefaultCellStyle.ForeColor = Color.DarkGray;
								this.ActiveOrdersDGV.Rows[num].DefaultCellStyle.Font = new Font("Arial", 14f, FontStyle.Strikeout);
							}
						}
					}
					flag = (this.ActiveOrdersDGV.Rows.Count > 0);
					if (flag)
					{
						this.ActiveOrdersDGV.CurrentCell = this.ActiveOrdersDGV.Rows[this.ActiveOrdersDGV.Rows.Count - 1].Cells[this.ActiveOrdersDGV.CurrentCell.ColumnIndex];
					}
					this.ActiveOrdersDGV.ClearSelection();
				}
			}
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x00029424 File Offset: 0x00027624
		private void ActiveOrdersDGV_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			this.CurrentSelectedIndex = Conversions.ToString(this.ActiveOrdersDGV.CurrentRow.Index);
			M_Settings.OrderNoToEdit = this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[0].Value.ToString();
			M_Settings.OrderType = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[2].Value);
			M_Settings.PaymentType = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[3].Value);
			M_Settings.CustomerTel = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[4].Value);
			M_Settings.CustomerAddress = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[5].Value);
			M_Settings.CustomerCity = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[6].Value);
			M_Settings.CustomerPostCode = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[7].Value);
			M_Settings.DriverName = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[8].Value);
			OrderManagment.EditOrderOldDateTime = Conversions.ToString(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[10].Value);
			OrderManagment.EditOrderOldDTotal = Conversions.ToDecimal(NewLateBinding.LateGet(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[9].Value, null, "Replace", new object[]
			{
				"£",
				""
			}, null, null, null));
			this.RePrintOrderBTN.Show();
			bool flag = M_Settings.PaymentType.Contains("Table") | Operators.CompareString(M_Settings.OrderToDriverStatus, "yes", false) == 0 | this.ActiveOrdersDGV.Rows[e.RowIndex].DefaultCellStyle.ForeColor == Color.DarkGray;
			bool flag2;
			if (flag)
			{
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.ActiveEditOrders, "y", false) == 0);
				if (flag2)
				{
					this.EditOrderBTN.Hide();
				}
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.ActiveEditOrders, "y", false) == 0);
				if (flag2)
				{
					this.CancelOrderBTN.Hide();
				}
			}
			else
			{
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.ActiveEditOrders, "y", false) == 0);
				if (flag2)
				{
					this.EditOrderBTN.Show();
				}
				flag2 = (Operators.CompareString(MySettingsProperty.Settings.ActiveEditOrders, "y", false) == 0);
				if (flag2)
				{
					this.CancelOrderBTN.Show();
				}
			}
			flag2 = (Operators.CompareString(M_Settings.OrderType, "Delivery", false) == 0);
			if (flag2)
			{
				this.GoogleMapBTN.Show();
			}
			else
			{
				this.GoogleMapBTN.Hide();
			}
			flag2 = Conversions.ToBoolean(Operators.AndObject(Operators.AndObject(this.ActiveOrdersDGV.Rows[e.RowIndex].DefaultCellStyle.ForeColor != Color.DarkGray, Operators.CompareObjectEqual(this.ActiveOrdersDGV.Rows[e.RowIndex].Cells[2].Value, "Delivery", false)), Operators.CompareString(M_Settings.OrderToDriverStatus, "yes", false) == 0));
			if (flag2)
			{
				MyProject.Forms.Form_Glass.Show();
				M_Settings.OrderToDriverStatus = this.CurrentSelectedIndex;
				MyProject.Forms.AssignOrderToDriver.Show();
			}
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x00029844 File Offset: 0x00027A44
		private void Button1_Click(object sender, EventArgs e)
		{
			M_Settings.OrderNoToEdit = "";
			M_Settings.OrderType = "";
			M_Settings.PaymentType = "";
			M_Settings.CustomerTel = "";
			M_Settings.CustomerAddress = "";
			M_Settings.CustomerCity = "";
			M_Settings.CustomerPostCode = "";
			OrderManagment.EditOrderOldDateTime = "";
			OrderManagment.EditOrderOldDTotal = 0m;
			this.Close();
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x000298BC File Offset: 0x00027ABC
		private void EditOrderBTN_Click(object sender, EventArgs e)
		{
			checked
			{
				int x = (int)Math.Round(unchecked((double)this.ActiveOrdersDGV.Width / 2.0 - (double)this.EditOrderButtonsPanel.Width / 2.0));
				int y = (int)Math.Round(unchecked((double)this.ActiveOrdersDGV.Height / 2.0 - (double)this.EditOrderButtonsPanel.Height / 2.0));
				Control editOrderButtonsPanel = this.EditOrderButtonsPanel;
				Point location = new Point(x, y);
				editOrderButtonsPanel.Location = location;
				this.EditOrderButtonsPanel.Visible = true;
				bool flag = Operators.CompareString(M_Settings.OrderType, "Dine In", false) == 0;
				if (flag)
				{
					this.EditDeliveryAddressBTN.Enabled = false;
				}
				else
				{
					this.EditDeliveryAddressBTN.Enabled = true;
				}
				flag = (Operators.CompareString(M_Settings.OrderType, "Takeaway", false) == 0);
				if (flag)
				{
					this.EditDeliveryAddressBTN.Text = "Change Takeaway to Delivery order";
				}
				flag = (Operators.CompareString(M_Settings.OrderType, "Delivery", false) == 0);
				if (flag)
				{
					this.EditDeliveryAddressBTN.Text = "Edit delivery address and order";
				}
			}
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x000299E0 File Offset: 0x00027BE0
		private void Button2_Click(object sender, EventArgs e)
		{
			this.OrderCancelled = "yes";
			bool flag = Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0;
			if (flag)
			{
				MyProject.Forms.Printing_Setup.PrintReceipt.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
			}
			MyProject.Forms.Printing_Setup.PrintReceipt.Print();
			this.ActiveOrdersArray[Conversions.ToInteger(this.CurrentSelectedIndex)] = this.ActiveOrdersArray[Conversions.ToInteger(this.CurrentSelectedIndex)].Replace("in progress", "Cancelled");
			File.WriteAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt", this.ActiveOrdersArray);
			Online.postdata(MySettingsProperty.Settings.SoftwareWebsite, "cancel_order.php", "cencel_order", MySettingsProperty.Settings.ServerFolderName, "_today" + MySettingsProperty.Settings.ComputerNo, this.CurrentSelectedIndex, M_Settings.OrderNoToEdit, "");
			this.OrderCancelled = "no";
			this.Close();
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x00029AFC File Offset: 0x00027CFC
		private void RePrintOrderBTN_Click(object sender, EventArgs e)
		{
			M_Shopping_Cart.BringUpExistingOrderIntoShoppingCart(M_Settings.OrderNoToEdit, 0);
			bool flag = Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0;
			if (flag)
			{
				MyProject.Forms.Printing_Setup.PrintReceipt.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
			}
			int num = 1;
			int num2 = Conversions.ToInteger(MySettingsProperty.Settings.NumberOfPrint);
			int num3 = num;
			checked
			{
				for (;;)
				{
					int num4 = num3;
					int num5 = num2;
					if (num4 > num5)
					{
						break;
					}
					MyProject.Forms.Printing_Setup.PrintReceipt.Print();
					num3++;
				}
				MyProject.Forms.POS_Window.ExitPOS();
				this.Close();
			}
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x00029BAC File Offset: 0x00027DAC
		private void GoogleMapBTN_Click(object sender, EventArgs e)
		{
			try
			{
				string text = string.Concat(new string[]
				{
					M_Settings.CustomerAddress,
					" ",
					M_Settings.CustomerCity,
					" ",
					M_Settings.CustomerPostCode
				});
				string text2 = string.Concat(new string[]
				{
					MySettingsProperty.Settings.BusinessAddress,
					" ",
					MySettingsProperty.Settings.BusinessCity,
					" ",
					MySettingsProperty.Settings.BusinessPostcode
				});
				text = text.Replace(" ", "+");
				text2 = text2.Replace(" ", "+");
				string fileName = "https://www.google.com/maps?saddr=" + text2 + "&daddr=" + text;
				Process.Start(fileName);
			}
			catch (Exception ex)
			{
			}
			this.Close();
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x00029CB4 File Offset: 0x00027EB4
		private void Button4_Click(object sender, EventArgs e)
		{
			M_Settings.OrderType = "Delivery";
			this.EditOrderButtonsPanel.Visible = false;
			this.Close();
			MyProject.Forms.Incoming_Calls.ShowOrderBTN.Visible = true;
			MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text = M_Settings.CustomerTel;
			Customers.FindCustomer(MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text);
			M_Settings.ShowForm(MyProject.Forms.Incoming_Calls);
			M_Settings.OrderNoToEditAddress = M_Settings.OrderNoToEdit;
			M_Settings.OrderNoToEdit = "";
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x000039DE File Offset: 0x00001BDE
		private void Button3_Click(object sender, EventArgs e)
		{
			this.EditOrderButtonsPanel.Visible = false;
			this.Close();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
			M_Shopping_Cart.BringUpExistingOrderIntoShoppingCart(M_Settings.OrderNoToEdit, 0);
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x00003A17 File Offset: 0x00001C17
		private void Exit_Program_Click(object sender, EventArgs e)
		{
			this.EditOrderButtonsPanel.Visible = false;
		}

		// Token: 0x040001D0 RID: 464
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x040001D1 RID: 465
		private IContainer components;

		// Token: 0x040001D2 RID: 466
		[AccessedThroughProperty("ActiveOrdersDGV")]
		private DataGridView _ActiveOrdersDGV;

		// Token: 0x040001D3 RID: 467
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x040001D4 RID: 468
		[AccessedThroughProperty("BottomPanel")]
		private Panel _BottomPanel;

		// Token: 0x040001D5 RID: 469
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x040001D6 RID: 470
		[AccessedThroughProperty("CancelOrderBTN")]
		private Button _CancelOrderBTN;

		// Token: 0x040001D7 RID: 471
		[AccessedThroughProperty("C1")]
		private DataGridViewTextBoxColumn _C1;

		// Token: 0x040001D8 RID: 472
		[AccessedThroughProperty("C2")]
		private DataGridViewTextBoxColumn _C2;

		// Token: 0x040001D9 RID: 473
		[AccessedThroughProperty("C3")]
		private DataGridViewTextBoxColumn _C3;

		// Token: 0x040001DA RID: 474
		[AccessedThroughProperty("C4")]
		private DataGridViewTextBoxColumn _C4;

		// Token: 0x040001DB RID: 475
		[AccessedThroughProperty("C5")]
		private DataGridViewTextBoxColumn _C5;

		// Token: 0x040001DC RID: 476
		[AccessedThroughProperty("C6")]
		private DataGridViewTextBoxColumn _C6;

		// Token: 0x040001DD RID: 477
		[AccessedThroughProperty("C7")]
		private DataGridViewTextBoxColumn _C7;

		// Token: 0x040001DE RID: 478
		[AccessedThroughProperty("C9")]
		private DataGridViewTextBoxColumn _C9;

		// Token: 0x040001DF RID: 479
		[AccessedThroughProperty("C11")]
		private DataGridViewTextBoxColumn _C11;

		// Token: 0x040001E0 RID: 480
		[AccessedThroughProperty("C10")]
		private DataGridViewTextBoxColumn _C10;

		// Token: 0x040001E1 RID: 481
		[AccessedThroughProperty("DateTimeCol")]
		private DataGridViewTextBoxColumn _DateTimeCol;

		// Token: 0x040001E2 RID: 482
		[AccessedThroughProperty("RePrintOrderBTN")]
		private Button _RePrintOrderBTN;

		// Token: 0x040001E3 RID: 483
		[AccessedThroughProperty("GoogleMapBTN")]
		private Button _GoogleMapBTN;

		// Token: 0x040001E4 RID: 484
		[AccessedThroughProperty("EditOrderBTN")]
		private Button _EditOrderBTN;

		// Token: 0x040001E5 RID: 485
		[AccessedThroughProperty("EditOrderButtonsPanel")]
		private Panel _EditOrderButtonsPanel;

		// Token: 0x040001E6 RID: 486
		[AccessedThroughProperty("EditDeliveryAddressBTN")]
		private Button _EditDeliveryAddressBTN;

		// Token: 0x040001E7 RID: 487
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x040001E8 RID: 488
		[AccessedThroughProperty("Exit_Program")]
		private Button _Exit_Program;

		// Token: 0x040001E9 RID: 489
		private object TLP_ActiveOrders;

		// Token: 0x040001EA RID: 490
		public string[] ActiveOrdersArray;

		// Token: 0x040001EB RID: 491
		private string CurrentSelectedIndex;

		// Token: 0x040001EC RID: 492
		public string OrderCancelled;
	}
}
