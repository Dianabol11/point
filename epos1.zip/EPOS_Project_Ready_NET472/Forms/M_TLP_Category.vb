using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000033 RID: 51
	[StandardModule]
	internal sealed class M_TLP_Category
	{
		// Token: 0x0600068A RID: 1674 RVA: 0x0003FDE8 File Offset: 0x0003DFE8
		public static void Create_Category_TLPs()
		{
			foreach (string text in File.ReadAllLines(M_Settings.MenuFolder + "\\_Categories.txt"))
			{
				bool flag = Operators.CompareString(text, "", false) != 0;
				if (flag)
				{
					M_Settings.Category_ArrayList.Add(text);
				}
			}
			TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel2 = tableLayoutPanel;
			tableLayoutPanel2.RowCount = Conversions.ToInteger(MySettingsProperty.Settings.CategoryRows);
			checked
			{
				tableLayoutPanel2.ColumnCount = (int)Math.Round(Math.Ceiling((double)M_Settings.Category_ArrayList.Count / Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows)));
				tableLayoutPanel2.Dock = DockStyle.Fill;
				tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
				tableLayoutPanel2.AutoSize = true;
				Control control = tableLayoutPanel2;
				Padding margin = new Padding(0);
				control.Margin = margin;
				tableLayoutPanel2.BackColor = Color.SteelBlue;
				MyProject.Forms.POS_Window.Bottom_Panel.Controls.Add(tableLayoutPanel);
				int num = 16;
				try
				{
					foreach (object obj in M_Settings.Category_ArrayList)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						string[] array2 = (string[])NewLateBinding.LateGet(objectValue, null, "Split", new object[]
						{
							new char[]
							{
								'|'
							}
						}, null, null, null);
						decimal value = new decimal((double)MyProject.Forms.Index.Width / (double)tableLayoutPanel.ColumnCount);
						Font font = new Font("Arial", 16f, FontStyle.Regular);
						font = (Font)M_Settings.GetFontFitIntoButton(array2[0], Convert.ToInt32(value), font);
						num = (int)Math.Round((double)Math.Min((float)num, font.Size));
					}
				}
				finally
				{
					IEnumerator enumerator;
					bool flag = enumerator is IDisposable;
					if (flag)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				try
				{
					foreach (object obj2 in M_Settings.Category_ArrayList)
					{
						object objectValue2 = RuntimeHelpers.GetObjectValue(obj2);
						string[] array3 = (string[])NewLateBinding.LateGet(objectValue2, null, "Split", new object[]
						{
							new char[]
							{
								'|'
							}
						}, null, null, null);
						decimal value2 = new decimal((double)MyProject.Forms.Index.Width / (double)tableLayoutPanel.ColumnCount);
						Font font2 = new Font("Arial", (float)num, FontStyle.Regular);
						Button button = new Button();
						Button button2 = button;
						button2.Name = array3[0];
						button2.BackColor = ColorTranslator.FromHtml("#275078");
						button2.ForeColor = ColorTranslator.FromHtml("#" + M_Settings.Button_TextColor);
						button2.Dock = DockStyle.Fill;
						button2.FlatStyle = FlatStyle.Popup;
						Control control2 = button2;
						margin = new Padding(0, 0, 0, 0);
						control2.Margin = margin;
						button2.Font = font2;
						button2.Height = (int)Math.Round((double)MyProject.Forms.POS_Window.Bottom_Panel.Height / Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows));
						button2.Width = Convert.ToInt32(value2);
						button2.Text = array3[0];
						tableLayoutPanel.Controls.Add(button);
						button.Click += M_TLP_Category.CategoryButtonClick;
					}
				}
				finally
				{
					IEnumerator enumerator2;
					bool flag = enumerator2 is IDisposable;
					if (flag)
					{
						(enumerator2 as IDisposable).Dispose();
					}
				}
			}
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x000401C0 File Offset: 0x0003E3C0
		private static void CategoryButtonClick(object sender, EventArgs e)
		{
			MyProject.Forms.POS_Window.CompletePanel.BringToFront();
			M_Settings.SelectedCategory = "";
			M_Settings.SelectedSize = "";
			M_Settings.SelectedFood = "";
			M_Settings.SelectedFoodPrice = 0m;
			M_Settings.SelectedOption = "";
			M_Settings.SelectedOptionPrice = 0m;
			M_Settings.SelectedCategory = Conversions.ToString(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null));
			M_Shopping_Cart.DeFocuseShoppingCartItem();
			M_Settings.BeforeOptionTXT = "    ";
			try
			{
				MyProject.Forms.POS_Window.Main_Panel.Controls[M_Settings.SelectedCategory + "Size"].BringToFront();
			}
			catch (Exception ex)
			{
				MyProject.Forms.POS_Window.Main_Panel.Controls[M_Settings.SelectedCategory + "Foods"].BringToFront();
			}
		}
	}
}
