using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200001B RID: 27
	[DesignerGenerated]
	public class CustomerReCall : Form
	{
		// Token: 0x0600046E RID: 1134 RVA: 0x00025010 File Offset: 0x00023210
		[DebuggerNonUserCode]
		public CustomerReCall()
		{
			List<WeakReference> _ENCList = CustomerReCall.__ENCList;
			lock (_ENCList)
			{
				CustomerReCall.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x00025068 File Offset: 0x00023268
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x000250B8 File Offset: 0x000232B8
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Label1 = new Label();
			this.Label2 = new Label();
			this.Label3 = new Label();
			this.Label4 = new Label();
			this.Label5 = new Label();
			this.Label6 = new Label();
			this.Label7 = new Label();
			this.Button1 = new Button();
			this.Button2 = new Button();
			this.Button3 = new Button();
			this.Button4 = new Button();
			this.Label9 = new Label();
			this.LeftPanel = new Panel();
			this.BottomPanel = new Panel();
			this.RightPanel = new Panel();
			this.Button5 = new Button();
			this.ReCallOrderTextBox = new TextBox();
			this.LeftPanel.SuspendLayout();
			this.BottomPanel.SuspendLayout();
			this.RightPanel.SuspendLayout();
			this.SuspendLayout();
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Century Gothic", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.PaleTurquoise;
			Control label = this.Label1;
			Point location = new Point(80, 21);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			Size size = new Size(242, 32);
			label2.Size = size;
			this.Label1.TabIndex = 0;
			this.Label1.Text = "Customer Details:";
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Century Gothic", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label2.ForeColor = Color.PaleTurquoise;
			Control label3 = this.Label2;
			location = new Point(147, 112);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(79, 25);
			label4.Size = size;
			this.Label2.TabIndex = 1;
			this.Label2.Text = "Label2";
			this.Label3.AutoSize = true;
			this.Label3.Font = new Font("Century Gothic", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label3.ForeColor = Color.PaleTurquoise;
			Control label5 = this.Label3;
			location = new Point(147, 148);
			label5.Location = location;
			this.Label3.Name = "Label3";
			Control label6 = this.Label3;
			size = new Size(79, 25);
			label6.Size = size;
			this.Label3.TabIndex = 2;
			this.Label3.Text = "Label3";
			this.Label4.AutoSize = true;
			this.Label4.Font = new Font("Century Gothic", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label4.ForeColor = Color.PaleTurquoise;
			Control label7 = this.Label4;
			location = new Point(147, 184);
			label7.Location = location;
			this.Label4.Name = "Label4";
			Control label8 = this.Label4;
			size = new Size(79, 25);
			label8.Size = size;
			this.Label4.TabIndex = 3;
			this.Label4.Text = "Label4";
			this.Label5.AutoSize = true;
			this.Label5.Font = new Font("Century Gothic", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label5.ForeColor = Color.PaleTurquoise;
			Control label9 = this.Label5;
			location = new Point(147, 219);
			label9.Location = location;
			this.Label5.Name = "Label5";
			Control label10 = this.Label5;
			size = new Size(79, 25);
			label10.Size = size;
			this.Label5.TabIndex = 4;
			this.Label5.Text = "Label5";
			this.Label6.AutoSize = true;
			this.Label6.Font = new Font("Century Gothic", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label6.ForeColor = Color.PaleTurquoise;
			Control label11 = this.Label6;
			location = new Point(82, 294);
			label11.Location = location;
			this.Label6.Name = "Label6";
			Control label12 = this.Label6;
			size = new Size(83, 25);
			label12.Size = size;
			this.Label6.TabIndex = 5;
			this.Label6.Text = "Driver: ";
			this.Label7.AutoSize = true;
			this.Label7.Font = new Font("Century Gothic", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label7.ForeColor = Color.PaleTurquoise;
			Control label13 = this.Label7;
			location = new Point(82, 349);
			label13.Location = location;
			this.Label7.Name = "Label7";
			Control label14 = this.Label7;
			size = new Size(130, 25);
			label14.Size = size;
			this.Label7.TabIndex = 6;
			this.Label7.Text = "Order Time:";
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button1.BackColor = Color.Crimson;
			this.Button1.Font = new Font("Century Gothic", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(21, 21);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			size = new Size(201, 53);
			button2.Size = size;
			this.Button1.TabIndex = 8;
			this.Button1.Text = "Cancel this order";
			this.Button1.UseVisualStyleBackColor = false;
			this.Button2.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button2.BackColor = Color.LimeGreen;
			this.Button2.Font = new Font("Century Gothic", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control button3 = this.Button2;
			location = new Point(435, 21);
			button3.Location = location;
			this.Button2.Name = "Button2";
			Control button4 = this.Button2;
			size = new Size(201, 53);
			button4.Size = size;
			this.Button2.TabIndex = 9;
			this.Button2.Text = "New Delivery order";
			this.Button2.UseVisualStyleBackColor = false;
			this.Button3.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button3.BackColor = Color.Orange;
			this.Button3.Font = new Font("Century Gothic", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control button5 = this.Button3;
			location = new Point(228, 21);
			button5.Location = location;
			this.Button3.Name = "Button3";
			Control button6 = this.Button3;
			size = new Size(201, 53);
			button6.Size = size;
			this.Button3.TabIndex = 10;
			this.Button3.Text = "Edit this order";
			this.Button3.UseVisualStyleBackColor = false;
			this.Button4.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.Button4.BackColor = Color.Crimson;
			this.Button4.Font = new Font("Century Gothic", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button4.ForeColor = Color.White;
			Control button7 = this.Button4;
			location = new Point(900, 21);
			button7.Location = location;
			this.Button4.Name = "Button4";
			Control button8 = this.Button4;
			size = new Size(201, 53);
			button8.Size = size;
			this.Button4.TabIndex = 11;
			this.Button4.Text = "Exit";
			this.Button4.UseVisualStyleBackColor = false;
			this.Label9.AutoSize = true;
			this.Label9.Font = new Font("Century Gothic", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label9.ForeColor = Color.PaleTurquoise;
			Control label15 = this.Label9;
			location = new Point(84, 67);
			label15.Location = location;
			this.Label9.Name = "Label9";
			Control label16 = this.Label9;
			size = new Size(75, 19);
			label16.Size = size;
			this.Label9.TabIndex = 12;
			this.Label9.Text = "OrderNo";
			this.LeftPanel.BackColor = Color.DodgerBlue;
			this.LeftPanel.Controls.Add(this.Label1);
			this.LeftPanel.Controls.Add(this.Label9);
			this.LeftPanel.Controls.Add(this.Label2);
			this.LeftPanel.Controls.Add(this.Label3);
			this.LeftPanel.Controls.Add(this.Label4);
			this.LeftPanel.Controls.Add(this.Label5);
			this.LeftPanel.Controls.Add(this.Label6);
			this.LeftPanel.Controls.Add(this.Label7);
			this.LeftPanel.Dock = DockStyle.Left;
			Control leftPanel = this.LeftPanel;
			location = new Point(0, 0);
			leftPanel.Location = location;
			this.LeftPanel.Name = "LeftPanel";
			Control leftPanel2 = this.LeftPanel;
			size = new Size(513, 391);
			leftPanel2.Size = size;
			this.LeftPanel.TabIndex = 13;
			this.BottomPanel.Controls.Add(this.Button5);
			this.BottomPanel.Controls.Add(this.Button1);
			this.BottomPanel.Controls.Add(this.Button2);
			this.BottomPanel.Controls.Add(this.Button4);
			this.BottomPanel.Controls.Add(this.Button3);
			this.BottomPanel.Dock = DockStyle.Bottom;
			Control bottomPanel = this.BottomPanel;
			location = new Point(0, 391);
			bottomPanel.Location = location;
			this.BottomPanel.Name = "BottomPanel";
			Control bottomPanel2 = this.BottomPanel;
			size = new Size(1113, 100);
			bottomPanel2.Size = size;
			this.BottomPanel.TabIndex = 14;
			this.RightPanel.BackColor = Color.CornflowerBlue;
			this.RightPanel.Controls.Add(this.ReCallOrderTextBox);
			this.RightPanel.Dock = DockStyle.Right;
			Control rightPanel = this.RightPanel;
			location = new Point(550, 0);
			rightPanel.Location = location;
			this.RightPanel.Name = "RightPanel";
			Control rightPanel2 = this.RightPanel;
			size = new Size(563, 391);
			rightPanel2.Size = size;
			this.RightPanel.TabIndex = 15;
			this.Button5.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button5.BackColor = Color.LimeGreen;
			this.Button5.Font = new Font("Century Gothic", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control button9 = this.Button5;
			location = new Point(642, 21);
			button9.Location = location;
			this.Button5.Name = "Button5";
			Control button10 = this.Button5;
			size = new Size(201, 53);
			button10.Size = size;
			this.Button5.TabIndex = 12;
			this.Button5.Text = "New Collection order";
			this.Button5.UseVisualStyleBackColor = false;
			this.ReCallOrderTextBox.BackColor = Color.CornflowerBlue;
			this.ReCallOrderTextBox.Dock = DockStyle.Fill;
			this.ReCallOrderTextBox.Font = new Font("Century Gothic", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ReCallOrderTextBox.ForeColor = SystemColors.ButtonHighlight;
			Control reCallOrderTextBox = this.ReCallOrderTextBox;
			location = new Point(0, 0);
			reCallOrderTextBox.Location = location;
			this.ReCallOrderTextBox.Multiline = true;
			this.ReCallOrderTextBox.Name = "ReCallOrderTextBox";
			this.ReCallOrderTextBox.ReadOnly = true;
			this.ReCallOrderTextBox.ScrollBars = ScrollBars.Both;
			Control reCallOrderTextBox2 = this.ReCallOrderTextBox;
			size = new Size(563, 391);
			reCallOrderTextBox2.Size = size;
			this.ReCallOrderTextBox.TabIndex = 8;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.SteelBlue;
			size = new Size(1113, 491);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.RightPanel);
			this.Controls.Add(this.LeftPanel);
			this.Controls.Add(this.BottomPanel);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "CustomerReCall";
			this.ShowIcon = false;
			this.ShowInTaskbar = false;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "CustomerReCall";
			this.WindowState = FormWindowState.Maximized;
			this.LeftPanel.ResumeLayout(false);
			this.LeftPanel.PerformLayout();
			this.BottomPanel.ResumeLayout(false);
			this.RightPanel.ResumeLayout(false);
			this.RightPanel.PerformLayout();
			this.ResumeLayout(false);
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x06000471 RID: 1137 RVA: 0x00025EC0 File Offset: 0x000240C0
		// (set) Token: 0x06000472 RID: 1138 RVA: 0x000037F9 File Offset: 0x000019F9
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x06000473 RID: 1139 RVA: 0x00025ED8 File Offset: 0x000240D8
		// (set) Token: 0x06000474 RID: 1140 RVA: 0x00003803 File Offset: 0x00001A03
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x06000475 RID: 1141 RVA: 0x00025EF0 File Offset: 0x000240F0
		// (set) Token: 0x06000476 RID: 1142 RVA: 0x0000380D File Offset: 0x00001A0D
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x06000477 RID: 1143 RVA: 0x00025F08 File Offset: 0x00024108
		// (set) Token: 0x06000478 RID: 1144 RVA: 0x00003817 File Offset: 0x00001A17
		internal virtual Label Label4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label4 = value;
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x06000479 RID: 1145 RVA: 0x00025F20 File Offset: 0x00024120
		// (set) Token: 0x0600047A RID: 1146 RVA: 0x00003821 File Offset: 0x00001A21
		internal virtual Label Label5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label5 = value;
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x0600047B RID: 1147 RVA: 0x00025F38 File Offset: 0x00024138
		// (set) Token: 0x0600047C RID: 1148 RVA: 0x0000382B File Offset: 0x00001A2B
		internal virtual Label Label6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label6 = value;
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x0600047D RID: 1149 RVA: 0x00025F50 File Offset: 0x00024150
		// (set) Token: 0x0600047E RID: 1150 RVA: 0x00003835 File Offset: 0x00001A35
		internal virtual Label Label7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label7 = value;
			}
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x0600047F RID: 1151 RVA: 0x00025F68 File Offset: 0x00024168
		// (set) Token: 0x06000480 RID: 1152 RVA: 0x00025F80 File Offset: 0x00024180
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x06000481 RID: 1153 RVA: 0x00025FE0 File Offset: 0x000241E0
		// (set) Token: 0x06000482 RID: 1154 RVA: 0x00025FF8 File Offset: 0x000241F8
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x06000483 RID: 1155 RVA: 0x00026058 File Offset: 0x00024258
		// (set) Token: 0x06000484 RID: 1156 RVA: 0x00026070 File Offset: 0x00024270
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x06000485 RID: 1157 RVA: 0x000260D0 File Offset: 0x000242D0
		// (set) Token: 0x06000486 RID: 1158 RVA: 0x000260E8 File Offset: 0x000242E8
		internal virtual Button Button4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				bool flag = this._Button4 != null;
				if (flag)
				{
					this._Button4.Click -= value2;
				}
				this._Button4 = value;
				flag = (this._Button4 != null);
				if (flag)
				{
					this._Button4.Click += value2;
				}
			}
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x06000487 RID: 1159 RVA: 0x00026148 File Offset: 0x00024348
		// (set) Token: 0x06000488 RID: 1160 RVA: 0x0000383F File Offset: 0x00001A3F
		internal virtual Label Label9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label9 = value;
			}
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x06000489 RID: 1161 RVA: 0x00026160 File Offset: 0x00024360
		// (set) Token: 0x0600048A RID: 1162 RVA: 0x00003849 File Offset: 0x00001A49
		internal virtual Panel LeftPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LeftPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._LeftPanel = value;
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x0600048B RID: 1163 RVA: 0x00026178 File Offset: 0x00024378
		// (set) Token: 0x0600048C RID: 1164 RVA: 0x00003853 File Offset: 0x00001A53
		internal virtual Panel BottomPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BottomPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BottomPanel = value;
			}
		}

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x0600048D RID: 1165 RVA: 0x00026190 File Offset: 0x00024390
		// (set) Token: 0x0600048E RID: 1166 RVA: 0x0000385D File Offset: 0x00001A5D
		internal virtual Panel RightPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._RightPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._RightPanel = value;
			}
		}

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x0600048F RID: 1167 RVA: 0x000261A8 File Offset: 0x000243A8
		// (set) Token: 0x06000490 RID: 1168 RVA: 0x000261C0 File Offset: 0x000243C0
		internal virtual Button Button5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click);
				bool flag = this._Button5 != null;
				if (flag)
				{
					this._Button5.Click -= value2;
				}
				this._Button5 = value;
				flag = (this._Button5 != null);
				if (flag)
				{
					this._Button5.Click += value2;
				}
			}
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x06000491 RID: 1169 RVA: 0x00026220 File Offset: 0x00024420
		// (set) Token: 0x06000492 RID: 1170 RVA: 0x00003867 File Offset: 0x00001A67
		internal virtual TextBox ReCallOrderTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ReCallOrderTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ReCallOrderTextBox = value;
			}
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x00026238 File Offset: 0x00024438
		public void CustomerReCallTodayOrderListData(object order)
		{
			this.OrderNoRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				0
			}, null));
			this.OrderDateTimeRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				1
			}, null));
			this.OrderTypeRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				2
			}, null));
			this.OrderStatusRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				3
			}, null));
			this.PaymentTypeRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				4
			}, null));
			this.DriverNameRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				5
			}, null));
			this.OrderTakenFromRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				6
			}, null));
			this.CustomerTelRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				7
			}, null));
			this.CustomerAddressRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				8
			}, null));
			this.CustomerCityRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				9
			}, null));
			this.CustomerPostCodeRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				10
			}, null));
			this.OrderTotalRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				15
			}, null));
			this.OrderCommentRC = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(order, null, "Split", new object[]
			{
				"|"
			}, null, null, null), new object[]
			{
				16
			}, null));
			this.Label9.Text = string.Concat(new string[]
			{
				"No: ",
				this.OrderNoRC,
				" - ",
				this.OrderTypeRC,
				" - ",
				this.OrderStatusRC
			});
			this.Label2.Text = "Tel: " + this.CustomerTelRC;
			this.Label3.Text = this.CustomerAddressRC;
			this.Label4.Text = this.CustomerCityRC;
			this.Label5.Text = this.CustomerPostCodeRC;
			this.Label6.Text = "Payment type: " + this.PaymentTypeRC;
			this.Label7.Text = "Order Time: " + this.OrderDateTimeRC.Substring(8, 2) + ":" + this.OrderDateTimeRC.Substring(10, 2);
			this.ShowOrderIntoRightPanel();
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x0000221E File Offset: 0x0000041E
		private void Button4_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x000266B0 File Offset: 0x000248B0
		private void Button2_Click(object sender, EventArgs e)
		{
			M_Settings.OrderType = "Delivery";
			M_Settings.CustomerTel = this.CustomerTelRC;
			M_Settings.CustomerAddress = this.CustomerAddressRC;
			M_Settings.CustomerCity = this.CustomerCityRC;
			M_Settings.CustomerPostCode = this.CustomerPostCodeRC;
			M_Settings.OrderComment = this.OrderCommentRC;
			this.Hide();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x00026718 File Offset: 0x00024918
		private void Button5_Click(object sender, EventArgs e)
		{
			M_Settings.OrderType = "Collection";
			M_Settings.CustomerTel = this.CustomerTelRC;
			M_Settings.CustomerAddress = this.CustomerAddressRC;
			M_Settings.CustomerCity = this.CustomerCityRC;
			M_Settings.CustomerPostCode = this.CustomerPostCodeRC;
			M_Settings.OrderComment = this.OrderCommentRC;
			this.Hide();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x00026780 File Offset: 0x00024980
		private void Button1_Click(object sender, EventArgs e)
		{
			MyProject.Forms.EditOrders.OrderCancelled = "yes";
			bool flag = Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0;
			if (flag)
			{
				MyProject.Forms.Printing_Setup.PrintReceipt.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
			}
			MyProject.Forms.Printing_Setup.PrintReceipt.Print();
			string[] array = File.ReadAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt");
			checked
			{
				array[(int)Math.Round(unchecked(Conversions.ToDouble(this.OrderNoRC) - 1.0))] = array[(int)Math.Round(unchecked(Conversions.ToDouble(this.OrderNoRC) - 1.0))].Replace("in progress", "Cancelled");
				File.WriteAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\_TodayOrderList.txt", array);
			}
			Online.postdata(MySettingsProperty.Settings.SoftwareWebsite, "cancel_order.php", "cencel_order", MySettingsProperty.Settings.ServerFolderName, "_today" + MySettingsProperty.Settings.ComputerNo, Conversions.ToString(Conversions.ToDouble(this.OrderNoRC) - 1.0), M_Settings.OrderNoToEdit, "");
			MyProject.Forms.EditOrders.OrderCancelled = "no";
			this.Close();
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x000268E8 File Offset: 0x00024AE8
		private void ShowOrderIntoRightPanel()
		{
			string[] array = File.ReadAllLines(M_Settings.DataFolder + "\\Order_History\\_today\\" + this.OrderNoRC + ".txt");
			this.ReCallOrderTextBox.Text = "";
			TextBox reCallOrderTextBox;
			foreach (string text in array)
			{
				bool flag = Operators.CompareString(text.Split(new char[]
				{
					'|'
				})[0], "Food", false) == 0 | Operators.CompareString(text.Split(new char[]
				{
					'|'
				})[0], "Option", false) == 0;
				if (flag)
				{
					string text2 = text.Split(new char[]
					{
						'|'
					})[4];
					string text3 = text.Split(new char[]
					{
						'|'
					})[5];
					string text4 = text.Split(new char[]
					{
						'|'
					})[6];
					flag = (Operators.CompareString(text2, "", false) != 0);
					if (flag)
					{
						text2 += "x ";
					}
					flag = (Operators.CompareString(text4, "", false) == 0);
					if (flag)
					{
						text4 = "0";
					}
					flag = (decimal.Compare(Conversions.ToDecimal(text4), 0m) == 0);
					if (flag)
					{
						text4 = "";
					}
					else
					{
						text4 = " £" + text4;
					}
					reCallOrderTextBox = this.ReCallOrderTextBox;
					reCallOrderTextBox.Text = string.Concat(new string[]
					{
						reCallOrderTextBox.Text,
						text2,
						text3,
						text4,
						Environment.NewLine
					});
				}
			}
			reCallOrderTextBox = this.ReCallOrderTextBox;
			reCallOrderTextBox.Text = reCallOrderTextBox.Text + "================================" + Environment.NewLine;
			reCallOrderTextBox = this.ReCallOrderTextBox;
			reCallOrderTextBox.Text = reCallOrderTextBox.Text + "Sub Total: " + array.Last<string>().Split(new char[]
			{
				'|'
			})[0] + Environment.NewLine;
			reCallOrderTextBox = this.ReCallOrderTextBox;
			reCallOrderTextBox.Text = reCallOrderTextBox.Text + "Discount: " + array.Last<string>().Split(new char[]
			{
				'|'
			})[1] + Environment.NewLine;
			reCallOrderTextBox = this.ReCallOrderTextBox;
			reCallOrderTextBox.Text = reCallOrderTextBox.Text + "Delivery Charge: " + array.Last<string>().Split(new char[]
			{
				'|'
			})[2] + Environment.NewLine;
			reCallOrderTextBox = this.ReCallOrderTextBox;
			reCallOrderTextBox.Text = reCallOrderTextBox.Text + "Service Charge: " + array.Last<string>().Split(new char[]
			{
				'|'
			})[3] + Environment.NewLine;
			reCallOrderTextBox = this.ReCallOrderTextBox;
			reCallOrderTextBox.Text = reCallOrderTextBox.Text + "Total: " + array.Last<string>().Split(new char[]
			{
				'|'
			})[4];
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x00026C20 File Offset: 0x00024E20
		private void Button3_Click(object sender, EventArgs e)
		{
			M_Settings.OrderType = this.OrderTypeRC;
			M_Settings.CustomerTel = this.CustomerTelRC;
			M_Settings.CustomerAddress = this.CustomerAddressRC;
			M_Settings.CustomerCity = this.CustomerCityRC;
			M_Settings.CustomerPostCode = this.CustomerPostCodeRC;
			M_Settings.OrderComment = this.OrderCommentRC;
			this.Hide();
			M_Settings.ShowForm(MyProject.Forms.POS_Window);
			M_Shopping_Cart.BringUpExistingOrderIntoShoppingCart(this.OrderNoRC, 0);
		}

		// Token: 0x040001A7 RID: 423
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x040001A8 RID: 424
		private IContainer components;

		// Token: 0x040001A9 RID: 425
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x040001AA RID: 426
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x040001AB RID: 427
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x040001AC RID: 428
		[AccessedThroughProperty("Label4")]
		private Label _Label4;

		// Token: 0x040001AD RID: 429
		[AccessedThroughProperty("Label5")]
		private Label _Label5;

		// Token: 0x040001AE RID: 430
		[AccessedThroughProperty("Label6")]
		private Label _Label6;

		// Token: 0x040001AF RID: 431
		[AccessedThroughProperty("Label7")]
		private Label _Label7;

		// Token: 0x040001B0 RID: 432
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x040001B1 RID: 433
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x040001B2 RID: 434
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x040001B3 RID: 435
		[AccessedThroughProperty("Button4")]
		private Button _Button4;

		// Token: 0x040001B4 RID: 436
		[AccessedThroughProperty("Label9")]
		private Label _Label9;

		// Token: 0x040001B5 RID: 437
		[AccessedThroughProperty("LeftPanel")]
		private Panel _LeftPanel;

		// Token: 0x040001B6 RID: 438
		[AccessedThroughProperty("BottomPanel")]
		private Panel _BottomPanel;

		// Token: 0x040001B7 RID: 439
		[AccessedThroughProperty("RightPanel")]
		private Panel _RightPanel;

		// Token: 0x040001B8 RID: 440
		[AccessedThroughProperty("Button5")]
		private Button _Button5;

		// Token: 0x040001B9 RID: 441
		[AccessedThroughProperty("ReCallOrderTextBox")]
		private TextBox _ReCallOrderTextBox;

		// Token: 0x040001BA RID: 442
		private string OrderNoRC;

		// Token: 0x040001BB RID: 443
		private string OrderDateTimeRC;

		// Token: 0x040001BC RID: 444
		private string OrderTypeRC;

		// Token: 0x040001BD RID: 445
		private string OrderStatusRC;

		// Token: 0x040001BE RID: 446
		private string PaymentTypeRC;

		// Token: 0x040001BF RID: 447
		private string DriverNameRC;

		// Token: 0x040001C0 RID: 448
		private string OrderTakenFromRC;

		// Token: 0x040001C1 RID: 449
		private string CustomerTelRC;

		// Token: 0x040001C2 RID: 450
		private string CustomerAddressRC;

		// Token: 0x040001C3 RID: 451
		private string CustomerCityRC;

		// Token: 0x040001C4 RID: 452
		private string CustomerPostCodeRC;

		// Token: 0x040001C5 RID: 453
		private string OrderTotalRC;

		// Token: 0x040001C6 RID: 454
		private string OrderCommentRC;
	}
}
