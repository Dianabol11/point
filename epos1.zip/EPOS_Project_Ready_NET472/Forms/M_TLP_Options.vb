using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000035 RID: 53
	[StandardModule]
	internal sealed class M_TLP_Options
	{
		// Token: 0x06000693 RID: 1683 RVA: 0x00040F90 File Offset: 0x0003F190
		public static void Create_cooking_options_TLP()
		{
			ArrayList arrayList = new ArrayList();
			try
			{
				foreach (string value in File.ReadAllLines("menu\\Cooking_Options.txt"))
				{
					arrayList.Add(value);
				}
				M_TLP_Options.Count_Row_Column(arrayList.Count);
				M_TLP_Options.Create_TLP("Cooking", arrayList);
				arrayList.Clear();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x0004101C File Offset: 0x0003F21C
		public static void Create_Options_TLPs()
		{
			M_TLP_Options.Create_cooking_options_TLP();
			DirectoryInfo directoryInfo = new DirectoryInfo(M_Settings.MenuFolder);
			FileInfo[] files = directoryInfo.GetFiles("_Options.txt", SearchOption.AllDirectories);
			foreach (FileInfo fileInfo in files)
			{
				ArrayList arrayList = new ArrayList();
				string text = Strings.Replace(Strings.Replace(fileInfo.DirectoryName, M_Settings.MenuFolder + "\\", "", 1, -1, CompareMethod.Binary), "\\", "", 1, -1, CompareMethod.Binary);
				text = Conversions.ToString(M_TLP_Foods.Convert_File_Name_To_Food_Name(text));
				try
				{
					foreach (string value in File.ReadAllLines(fileInfo.DirectoryName.ToString() + "\\_Options.txt"))
					{
						arrayList.Add(value);
					}
					M_TLP_Options.Count_Row_Column(arrayList.Count);
				}
				catch (Exception ex)
				{
				}
				M_TLP_Options.Create_TLP(text, arrayList);
				arrayList.Clear();
			}
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x00041148 File Offset: 0x0003F348
		private static void Create_TLP(object name, object OptionsArrayList)
		{
			TableLayoutPanel tableLayoutPanel = new TableLayoutPanel();
			TableLayoutPanel tableLayoutPanel2 = tableLayoutPanel;
			tableLayoutPanel2.Name = Conversions.ToString(Operators.AddObject(name, "Options"));
			tableLayoutPanel2.RowCount = M_Settings.rows;
			tableLayoutPanel2.ColumnCount = M_Settings.columns;
			tableLayoutPanel2.Dock = DockStyle.Fill;
			tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
			tableLayoutPanel2.AutoSize = true;
			Control control = tableLayoutPanel2;
			Padding margin = new Padding(0);
			control.Margin = margin;
			checked
			{
				tableLayoutPanel2.Height = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Height / (double)M_Settings.rows);
				tableLayoutPanel2.Width = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Width / (double)M_Settings.columns);
				tableLayoutPanel2.BackColor = ColorTranslator.FromHtml(M_Settings.TLPs_bgColor);
				MyProject.Forms.POS_Window.Main_Panel.Controls.Add(tableLayoutPanel);
				Button button = new Button();
				Button button2 = button;
				button2.Name = "FREE";
				button2.BackColor = ColorTranslator.FromHtml("#DC143C");
				button2.ForeColor = ColorTranslator.FromHtml("#FFFFFF");
				button2.Dock = DockStyle.Fill;
				button2.AutoSize = false;
				button2.FlatStyle = FlatStyle.Popup;
				Control control2 = button2;
				margin = new Padding(0, 0, 0, 0);
				control2.Margin = margin;
				button2.Font = new Font("Arial", 16f, FontStyle.Regular);
				button2.Width = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Width / (double)M_Settings.columns);
				button2.Height = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Height / (double)M_Settings.rows);
				button2.Text = "FREE";
				tableLayoutPanel.Controls.Add(button);
				button.Click += M_TLP_Options.FREEOptionButtonClick;
				Button button3 = new Button();
				Button button4 = button3;
				button4.Name = "NO";
				button4.BackColor = ColorTranslator.FromHtml("#DC143C");
				button4.ForeColor = ColorTranslator.FromHtml("#FFFFFF");
				button4.Dock = DockStyle.Fill;
				button4.AutoSize = false;
				button4.FlatStyle = FlatStyle.Popup;
				Control control3 = button4;
				margin = new Padding(0, 0, 0, 0);
				control3.Margin = margin;
				button4.Font = new Font("Arial", 16f, FontStyle.Regular);
				button4.Width = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Width / (double)M_Settings.columns);
				button4.Height = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Height / (double)M_Settings.rows);
				button4.Text = "NO";
				tableLayoutPanel.Controls.Add(button3);
				button3.Click += M_TLP_Options.NoOptionButtonClick;
				try
				{
					foreach (object obj in ((IEnumerable)OptionsArrayList))
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						string[] array = (string[])NewLateBinding.LateGet(objectValue, null, "Split", new object[]
						{
							new char[]
							{
								'&'
							}
						}, null, null, null);
						int num = 16;
						string text = array[0];
						decimal value = new decimal((double)(MyProject.Forms.Index.Width - M_Settings.Right_Panel_Width) / (double)M_Settings.columns);
						Font font = new Font("Arial", 16f, FontStyle.Regular);
						font = (Font)M_Settings.GetFontFitIntoButton(array[0], Convert.ToInt32(value), font);
						num = (int)Math.Round((double)Math.Min((float)num, font.Size));
						Button button5 = new Button();
						Button button6 = button5;
						button6.Name = array[1];
						button6.BackColor = ColorTranslator.FromHtml("#" + array[2]);
						button6.ForeColor = ColorTranslator.FromHtml("#" + M_Settings.Button_TextColor);
						button6.Dock = DockStyle.Fill;
						button6.AutoSize = false;
						button6.FlatStyle = FlatStyle.Popup;
						Control control4 = button6;
						margin = new Padding(0, 0, 0, 0);
						control4.Margin = margin;
						button6.Font = font;
						button6.Width = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Width / (double)M_Settings.columns);
						button6.Height = (int)Math.Round((double)MyProject.Forms.POS_Window.Main_Panel.Height / (double)M_Settings.rows);
						button6.Text = array[0];
						tableLayoutPanel.Controls.Add(button5);
						button5.Click += M_TLP_Options.OptionButtonClick;
					}
				}
				finally
				{
					IEnumerator enumerator;
					bool flag = enumerator is IDisposable;
					if (flag)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
			}
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x00041678 File Offset: 0x0003F878
		private static void OptionButtonClick(object sender, EventArgs e)
		{
			MyProject.Forms.POS_Window.CompletePanel.BringToFront();
			M_Settings.SelectedOption = Conversions.ToString(NewLateBinding.LateGet(sender, null, "text", new object[0], null, null, null));
			M_Settings.SelectedOptionPrice = Conversions.ToDecimal(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null));
			M_Shopping_Cart.AddOptionsToShoppingCart();
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x00004099 File Offset: 0x00002299
		private static void NoOptionButtonClick(object sender, EventArgs e)
		{
			M_Settings.BeforeOptionTXT = "   NO ";
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x000040A7 File Offset: 0x000022A7
		private static void FREEOptionButtonClick(object sender, EventArgs e)
		{
			M_Settings.BeforeOptionTXT = "   FREE ";
		}

		// Token: 0x06000699 RID: 1689 RVA: 0x000416E0 File Offset: 0x0003F8E0
		private static void Count_Row_Column(object N)
		{
			N = Operators.AddObject(N, 2);
			bool flag = Operators.ConditionalCompareObjectLessEqual(N, 12, false);
			if (flag)
			{
				M_Settings.rows = 4;
				M_Settings.columns = 3;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 12, false);
			if (flag)
			{
				M_Settings.rows = 5;
				M_Settings.columns = 4;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 20, false);
			if (flag)
			{
				M_Settings.rows = 7;
				M_Settings.columns = 5;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 30, false);
			if (flag)
			{
				M_Settings.rows = 8;
				M_Settings.columns = 6;
			}
			flag = Operators.ConditionalCompareObjectGreater(N, 42, false);
			checked
			{
				if (flag)
				{
					M_Settings.rows = (int)Math.Round(Math.Ceiling(Math.Sqrt(Conversions.ToDouble(N))));
					M_Settings.columns = M_Settings.rows + 2;
				}
			}
		}
	}
}
