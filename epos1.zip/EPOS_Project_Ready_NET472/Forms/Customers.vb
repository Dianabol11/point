using System;
using System.Collections;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000026 RID: 38
	[StandardModule]
	internal sealed class Customers
	{
		// Token: 0x060005C6 RID: 1478 RVA: 0x00034C80 File Offset: 0x00032E80
		public static void FindCustomer(object TextToSearch)
		{
			try
			{
				Customers.CustomerArrayIndex = -1;
				MyProject.Forms.Incoming_Calls.StreetNameTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.CustomerCityTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.PostCodeTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.CustomerNoteTextBox.Text = "";
				MyProject.Forms.Incoming_Calls.ClearCustomerSearchComboBox();
				bool flag;
				foreach (string text in Customers.AllCustomersArray)
				{
					flag = text.ToUpper().Contains(TextToSearch.ToString().ToUpper());
					if (flag)
					{
						string text2 = string.Concat(new string[]
						{
							text.Split(new char[]
							{
								'|'
							})[1],
							", ",
							text.Split(new char[]
							{
								'|'
							})[2],
							", ",
							text.Split(new char[]
							{
								'|'
							})[3]
						});
						Customers.CustomerMultiAddresses.Add(text2);
						Customers.CustomerMultiAddressesAllInfo.Add(text);
						MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Items.Add(text2);
						flag = (Customers.CustomerMultiAddresses.Count > 8);
						if (flag)
						{
							break;
						}
					}
				}
				flag = (MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Items.Count > 1);
				if (flag)
				{
					MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.DroppedDown = true;
				}
				flag = (MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Items.Count == 1);
				if (flag)
				{
					MyProject.Forms.Incoming_Calls.CustomerPhoneNumberTextBox.Text = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[0], null, "Split", new object[]
					{
						"|"
					}, null, null, null), new object[]
					{
						0
					}, null));
					MyProject.Forms.Incoming_Calls.StreetNameTextBox.Text = Strings.Trim(Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[0], null, "Split", new object[]
					{
						"|"
					}, null, null, null), new object[]
					{
						1
					}, null)));
					MyProject.Forms.Incoming_Calls.CustomerCityTextBox.Text = Strings.Trim(Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[0], null, "Split", new object[]
					{
						"|"
					}, null, null, null), new object[]
					{
						2
					}, null)));
					MyProject.Forms.Incoming_Calls.PostCodeTextBox.Text = Strings.Trim(Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[0], null, "Split", new object[]
					{
						"|"
					}, null, null, null), new object[]
					{
						3
					}, null)));
					M_Settings.CustomerNumberOfOrders = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[0], null, "Split", new object[]
					{
						"|"
					}, null, null, null), new object[]
					{
						5
					}, null));
					M_Settings.CustomerLastCallDate = Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[0], null, "Split", new object[]
					{
						"|"
					}, null, null, null), new object[]
					{
						6
					}, null));
					MyProject.Forms.Incoming_Calls.CustomerNoteTextBox.Text = Strings.Trim(Conversions.ToString(NewLateBinding.LateIndexGet(NewLateBinding.LateGet(Customers.CustomerMultiAddressesAllInfo[0], null, "Split", new object[]
					{
						"|"
					}, null, null, null), new object[]
					{
						7
					}, null)));
					Customers.CustomerArrayIndex = Array.IndexOf(Customers.AllCustomersArray, RuntimeHelpers.GetObjectValue(Customers.CustomerMultiAddressesAllInfo[0]));
					MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Items.Clear();
					MyProject.Forms.Incoming_Calls.NumberOfOrdersLBL.Text = "Number of previous orders: " + M_Settings.CustomerNumberOfOrders.ToString();
				}
				MyProject.Forms.Incoming_Calls.CustomerSearchComboBox.Text = "";
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005C7 RID: 1479 RVA: 0x000351D8 File Offset: 0x000333D8
		public static void AddCustomerInto_Customers_txt_File()
		{
			checked
			{
				try
				{
					bool flag = M_Settings.CustomerTel.Length > 0;
					if (flag)
					{
						string text = M_Settings.CustomerTel + "|";
						text = text + M_Settings.CustomerAddress + "|";
						text = text + M_Settings.CustomerCity + "|";
						text = text + M_Settings.CustomerPostCode + "|";
						text = text + M_Settings.CustomerType + "|";
						text += "1|";
						text = Conversions.ToString(Operators.AddObject(text, Operators.AddObject(M_Settings.CurrentDate(), "|")));
						text += M_Settings.CustomerNote;
						Array.Resize<string>(ref Customers.AllCustomersArray, Customers.AllCustomersArray.Count<string>() + 1);
						Customers.AllCustomersArray[Customers.AllCustomersArray.Count<string>() - 1] = text;
						File.WriteAllLines(M_Settings.DataFolder + "\\_Customers.txt", Customers.AllCustomersArray);
						flag = Operators.ConditionalCompareObjectEqual(Online.checkinternet(), "HOHA_PING_IS_OK", false);
						if (flag)
						{
							Online.AddCustomerServer(text);
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x060005C8 RID: 1480 RVA: 0x00035308 File Offset: 0x00033508
		public static void UpdateCustomerAt_Customers_txt_File(object indx)
		{
			try
			{
				string text = M_Settings.CustomerTel + "|";
				text = text + M_Settings.CustomerAddress + "|";
				text = text + M_Settings.CustomerCity + "|";
				text = text + M_Settings.CustomerPostCode + "|";
				text = text + M_Settings.CustomerType + "|";
				text = text + (checked(Conversions.ToInteger(M_Settings.CustomerNumberOfOrders) + 1)).ToString() + "|";
				text = Conversions.ToString(Operators.AddObject(text, Operators.AddObject(M_Settings.CurrentDate(), "|")));
				text += M_Settings.CustomerNote;
				Customers.AllCustomersArray[Conversions.ToInteger(indx)] = text;
				File.WriteAllLines(M_Settings.DataFolder + "\\_Customers.txt", Customers.AllCustomersArray);
				bool flag = Operators.ConditionalCompareObjectEqual(Online.checkinternet(), "HOHA_PING_IS_OK", false);
				if (flag)
				{
					Online.UpdateCustomerServer(text, RuntimeHelpers.GetObjectValue(indx));
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0400025C RID: 604
		public static string[] AllCustomersArray;

		// Token: 0x0400025D RID: 605
		public static int CustomerArrayIndex;

		// Token: 0x0400025E RID: 606
		public static ArrayList CustomerMultiAddresses = new ArrayList();

		// Token: 0x0400025F RID: 607
		public static ArrayList CustomerMultiAddressesAllInfo = new ArrayList();
	}
}
