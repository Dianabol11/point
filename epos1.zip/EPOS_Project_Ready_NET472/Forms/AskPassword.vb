using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace POS
{
	// Token: 0x0200000C RID: 12
	[DesignerGenerated]
	public class AskPassword : Form
	{
		// Token: 0x06000080 RID: 128 RVA: 0x000062FC File Offset: 0x000044FC
		[DebuggerNonUserCode]
		public AskPassword()
		{
			List<WeakReference> _ENCList = AskPassword.__ENCList;
			lock (_ENCList)
			{
				AskPassword.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00006354 File Offset: 0x00004554
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000082 RID: 130 RVA: 0x000063A4 File Offset: 0x000045A4
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.SuspendLayout();
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			Size clientSize = new Size(405, 139);
			this.ClientSize = clientSize;
			this.Name = "AskPassword";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "AskPassword";
			this.TopMost = true;
			this.ResumeLayout(false);
		}

		// Token: 0x04000034 RID: 52
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000035 RID: 53
		private IContainer components;
	}
}
