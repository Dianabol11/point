using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace POS
{
	// Token: 0x0200000D RID: 13
	[DesignerGenerated]
	public class Edit_Customers : Form
	{
		// Token: 0x06000084 RID: 132 RVA: 0x00006428 File Offset: 0x00004628
		[DebuggerNonUserCode]
		public Edit_Customers()
		{
			base.Load += this.Edit_Customers_Load;
			List<WeakReference> _ENCList = Edit_Customers.__ENCList;
			lock (_ENCList)
			{
				Edit_Customers.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00006494 File Offset: 0x00004694
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000086 RID: 134 RVA: 0x000064E4 File Offset: 0x000046E4
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.CustomersEditDGV = new DataGridView();
			this.MobileColumn = new DataGridViewTextBoxColumn();
			this.Address = new DataGridViewTextBoxColumn();
			this.City = new DataGridViewTextBoxColumn();
			this.Postcode = new DataGridViewTextBoxColumn();
			this.Empty = new DataGridViewTextBoxColumn();
			this.Orders = new DataGridViewTextBoxColumn();
			this.LastOrder = new DataGridViewTextBoxColumn();
			this.Note = new DataGridViewTextBoxColumn();
			this.LeftPanel = new Panel();
			this.BottomPanel = new Panel();
			this.RightPanel = new Panel();
			this.Button2 = new Button();
			this.Label3 = new Label();
			this.Label2 = new Label();
			this.Label1 = new Label();
			this.TextBox1 = new TextBox();
			this.PasteBTN = new Button();
			this.Button1 = new Button();
			this.Button3 = new Button();
			((ISupportInitialize)this.CustomersEditDGV).BeginInit();
			this.LeftPanel.SuspendLayout();
			this.RightPanel.SuspendLayout();
			this.SuspendLayout();
			this.CustomersEditDGV.AllowUserToAddRows = false;
			this.CustomersEditDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			this.CustomersEditDGV.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
			this.CustomersEditDGV.BorderStyle = BorderStyle.None;
			this.CustomersEditDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.CustomersEditDGV.Columns.AddRange(new DataGridViewColumn[]
			{
				this.MobileColumn,
				this.Address,
				this.City,
				this.Postcode,
				this.Empty,
				this.Orders,
				this.LastOrder,
				this.Note
			});
			this.CustomersEditDGV.Dock = DockStyle.Fill;
			this.CustomersEditDGV.EditMode = DataGridViewEditMode.EditProgrammatically;
			Control customersEditDGV = this.CustomersEditDGV;
			Point location = new Point(0, 0);
			customersEditDGV.Location = location;
			Control customersEditDGV2 = this.CustomersEditDGV;
			Padding margin = new Padding(5, 6, 5, 6);
			customersEditDGV2.Margin = margin;
			this.CustomersEditDGV.MultiSelect = false;
			this.CustomersEditDGV.Name = "CustomersEditDGV";
			this.CustomersEditDGV.RowHeadersVisible = false;
			this.CustomersEditDGV.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
			this.CustomersEditDGV.ScrollBars = ScrollBars.Vertical;
			this.CustomersEditDGV.SelectionMode = DataGridViewSelectionMode.CellSelect;
			Control customersEditDGV3 = this.CustomersEditDGV;
			Size size = new Size(614, 443);
			customersEditDGV3.Size = size;
			this.CustomersEditDGV.TabIndex = 0;
			this.MobileColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			this.MobileColumn.HeaderText = "Tel/Mobile";
			this.MobileColumn.Name = "MobileColumn";
			this.Address.HeaderText = "Address";
			this.Address.Name = "Address";
			this.City.HeaderText = "City";
			this.City.Name = "City";
			this.Postcode.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
			this.Postcode.HeaderText = "Postcode";
			this.Postcode.Name = "Postcode";
			this.Empty.HeaderText = "EmptyColumn";
			this.Empty.Name = "Empty";
			this.Empty.Visible = false;
			this.Orders.HeaderText = "OrdersColumn";
			this.Orders.Name = "Orders";
			this.Orders.Visible = false;
			this.LastOrder.HeaderText = "LastOrderColumn";
			this.LastOrder.Name = "LastOrder";
			this.LastOrder.Visible = false;
			this.Note.HeaderText = "NoteColumn";
			this.Note.Name = "Note";
			this.Note.Visible = false;
			this.LeftPanel.Controls.Add(this.CustomersEditDGV);
			this.LeftPanel.Dock = DockStyle.Fill;
			Control leftPanel = this.LeftPanel;
			location = new Point(0, 0);
			leftPanel.Location = location;
			this.LeftPanel.Name = "LeftPanel";
			Control leftPanel2 = this.LeftPanel;
			size = new Size(614, 443);
			leftPanel2.Size = size;
			this.LeftPanel.TabIndex = 1;
			this.BottomPanel.Dock = DockStyle.Bottom;
			Control bottomPanel = this.BottomPanel;
			location = new Point(0, 443);
			bottomPanel.Location = location;
			this.BottomPanel.Name = "BottomPanel";
			Control bottomPanel2 = this.BottomPanel;
			size = new Size(841, 258);
			bottomPanel2.Size = size;
			this.BottomPanel.TabIndex = 2;
			this.RightPanel.BackColor = Color.Gold;
			this.RightPanel.Controls.Add(this.Button3);
			this.RightPanel.Controls.Add(this.Button2);
			this.RightPanel.Controls.Add(this.Label3);
			this.RightPanel.Controls.Add(this.Label2);
			this.RightPanel.Controls.Add(this.Label1);
			this.RightPanel.Controls.Add(this.TextBox1);
			this.RightPanel.Controls.Add(this.PasteBTN);
			this.RightPanel.Controls.Add(this.Button1);
			this.RightPanel.Dock = DockStyle.Right;
			Control rightPanel = this.RightPanel;
			location = new Point(614, 0);
			rightPanel.Location = location;
			this.RightPanel.Name = "RightPanel";
			Control rightPanel2 = this.RightPanel;
			size = new Size(227, 443);
			rightPanel2.Size = size;
			this.RightPanel.TabIndex = 0;
			this.Button2.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.Button2.BackColor = Color.LimeGreen;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.ForeColor = Color.White;
			Control button = this.Button2;
			location = new Point(11, 332);
			button.Location = location;
			this.Button2.Name = "Button2";
			Control button2 = this.Button2;
			size = new Size(207, 48);
			button2.Size = size;
			this.Button2.TabIndex = 6;
			this.Button2.Text = "Save and Exit";
			this.Button2.UseVisualStyleBackColor = false;
			this.Label3.AutoSize = true;
			Control label = this.Label3;
			location = new Point(36, 146);
			label.Location = location;
			this.Label3.Name = "Label3";
			Control label2 = this.Label3;
			size = new Size(146, 25);
			label2.Size = size;
			this.Label3.TabIndex = 4;
			this.Label3.Text = "3- Click on Paste";
			this.Label2.AutoSize = true;
			Control label3 = this.Label2;
			location = new Point(36, 121);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(146, 25);
			label4.Size = size;
			this.Label2.TabIndex = 3;
			this.Label2.Text = "2- Enter new text\r\n";
			this.Label1.AutoSize = true;
			Control label5 = this.Label1;
			location = new Point(36, 96);
			label5.Location = location;
			this.Label1.Name = "Label1";
			Control label6 = this.Label1;
			size = new Size(129, 25);
			label6.Size = size;
			this.Label1.TabIndex = 2;
			this.Label1.Text = "1- Select a cell";
			Control textBox = this.TextBox1;
			location = new Point(8, 174);
			textBox.Location = location;
			this.TextBox1.Name = "TextBox1";
			Control textBox2 = this.TextBox1;
			size = new Size(207, 32);
			textBox2.Size = size;
			this.TextBox1.TabIndex = 0;
			this.PasteBTN.BackColor = Color.Orange;
			this.PasteBTN.FlatStyle = FlatStyle.Flat;
			this.PasteBTN.ForeColor = Color.White;
			Control pasteBTN = this.PasteBTN;
			location = new Point(57, 212);
			pasteBTN.Location = location;
			this.PasteBTN.Name = "PasteBTN";
			Control pasteBTN2 = this.PasteBTN;
			size = new Size(125, 44);
			pasteBTN2.Size = size;
			this.PasteBTN.TabIndex = 1;
			this.PasteBTN.Text = "Paste";
			this.PasteBTN.UseVisualStyleBackColor = false;
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.Button1.BackColor = Color.Crimson;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.ForeColor = Color.White;
			Control button3 = this.Button1;
			location = new Point(11, 386);
			button3.Location = location;
			this.Button1.Name = "Button1";
			Control button4 = this.Button1;
			size = new Size(207, 48);
			button4.Size = size;
			this.Button1.TabIndex = 0;
			this.Button1.Text = "Cancel";
			this.Button1.UseVisualStyleBackColor = false;
			this.Button3.BackColor = Color.DarkOrange;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.ForeColor = Color.White;
			Control button5 = this.Button3;
			location = new Point(23, 12);
			button5.Location = location;
			this.Button3.Name = "Button3";
			Control button6 = this.Button3;
			size = new Size(183, 44);
			button6.Size = size;
			this.Button3.TabIndex = 7;
			this.Button3.Text = "Delete Customer";
			this.Button3.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(10f, 25f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(841, 701);
			this.ClientSize = size;
			this.Controls.Add(this.LeftPanel);
			this.Controls.Add(this.RightPanel);
			this.Controls.Add(this.BottomPanel);
			this.Font = new Font("Arial Narrow", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.FormBorderStyle = FormBorderStyle.None;
			margin = new Padding(5, 6, 5, 6);
			this.Margin = margin;
			this.Name = "Edit_Customers";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Edit_Customers";
			this.TopMost = true;
			this.WindowState = FormWindowState.Maximized;
			((ISupportInitialize)this.CustomersEditDGV).EndInit();
			this.LeftPanel.ResumeLayout(false);
			this.RightPanel.ResumeLayout(false);
			this.RightPanel.PerformLayout();
			this.ResumeLayout(false);
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000087 RID: 135 RVA: 0x0000704C File Offset: 0x0000524C
		// (set) Token: 0x06000088 RID: 136 RVA: 0x00007064 File Offset: 0x00005264
		internal virtual DataGridView CustomersEditDGV
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CustomersEditDGV;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				DataGridViewCellEventHandler value2 = new DataGridViewCellEventHandler(this.CustomersEditDGV_CellClick);
				bool flag = this._CustomersEditDGV != null;
				if (flag)
				{
					this._CustomersEditDGV.CellClick -= value2;
				}
				this._CustomersEditDGV = value;
				flag = (this._CustomersEditDGV != null);
				if (flag)
				{
					this._CustomersEditDGV.CellClick += value2;
				}
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000089 RID: 137 RVA: 0x000070C4 File Offset: 0x000052C4
		// (set) Token: 0x0600008A RID: 138 RVA: 0x00002142 File Offset: 0x00000342
		internal virtual Panel LeftPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LeftPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._LeftPanel = value;
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x0600008B RID: 139 RVA: 0x000070DC File Offset: 0x000052DC
		// (set) Token: 0x0600008C RID: 140 RVA: 0x000070F4 File Offset: 0x000052F4
		internal virtual Panel BottomPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BottomPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				PaintEventHandler value2 = new PaintEventHandler(this.Panel2_Paint);
				bool flag = this._BottomPanel != null;
				if (flag)
				{
					this._BottomPanel.Paint -= value2;
				}
				this._BottomPanel = value;
				flag = (this._BottomPanel != null);
				if (flag)
				{
					this._BottomPanel.Paint += value2;
				}
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x0600008D RID: 141 RVA: 0x00007154 File Offset: 0x00005354
		// (set) Token: 0x0600008E RID: 142 RVA: 0x0000214C File Offset: 0x0000034C
		internal virtual Panel RightPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._RightPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._RightPanel = value;
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x0600008F RID: 143 RVA: 0x0000716C File Offset: 0x0000536C
		// (set) Token: 0x06000090 RID: 144 RVA: 0x00007184 File Offset: 0x00005384
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000091 RID: 145 RVA: 0x000071E4 File Offset: 0x000053E4
		// (set) Token: 0x06000092 RID: 146 RVA: 0x00002156 File Offset: 0x00000356
		internal virtual TextBox TextBox1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TextBox1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TextBox1 = value;
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000093 RID: 147 RVA: 0x000071FC File Offset: 0x000053FC
		// (set) Token: 0x06000094 RID: 148 RVA: 0x00007214 File Offset: 0x00005414
		internal virtual Button PasteBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PasteBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.SaveBTN_Click);
				bool flag = this._PasteBTN != null;
				if (flag)
				{
					this._PasteBTN.Click -= value2;
				}
				this._PasteBTN = value;
				flag = (this._PasteBTN != null);
				if (flag)
				{
					this._PasteBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x06000095 RID: 149 RVA: 0x00007274 File Offset: 0x00005474
		// (set) Token: 0x06000096 RID: 150 RVA: 0x00002160 File Offset: 0x00000360
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x06000097 RID: 151 RVA: 0x0000728C File Offset: 0x0000548C
		// (set) Token: 0x06000098 RID: 152 RVA: 0x0000216A File Offset: 0x0000036A
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x06000099 RID: 153 RVA: 0x000072A4 File Offset: 0x000054A4
		// (set) Token: 0x0600009A RID: 154 RVA: 0x00002174 File Offset: 0x00000374
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x0600009B RID: 155 RVA: 0x000072BC File Offset: 0x000054BC
		// (set) Token: 0x0600009C RID: 156 RVA: 0x000072D4 File Offset: 0x000054D4
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x0600009D RID: 157 RVA: 0x00007334 File Offset: 0x00005534
		// (set) Token: 0x0600009E RID: 158 RVA: 0x0000217E File Offset: 0x0000037E
		internal virtual DataGridViewTextBoxColumn MobileColumn
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MobileColumn;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._MobileColumn = value;
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600009F RID: 159 RVA: 0x0000734C File Offset: 0x0000554C
		// (set) Token: 0x060000A0 RID: 160 RVA: 0x00002188 File Offset: 0x00000388
		internal virtual DataGridViewTextBoxColumn Address
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Address;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Address = value;
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060000A1 RID: 161 RVA: 0x00007364 File Offset: 0x00005564
		// (set) Token: 0x060000A2 RID: 162 RVA: 0x00002192 File Offset: 0x00000392
		internal virtual DataGridViewTextBoxColumn City
		{
			[DebuggerNonUserCode]
			get
			{
				return this._City;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._City = value;
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060000A3 RID: 163 RVA: 0x0000737C File Offset: 0x0000557C
		// (set) Token: 0x060000A4 RID: 164 RVA: 0x0000219C File Offset: 0x0000039C
		internal virtual DataGridViewTextBoxColumn Postcode
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Postcode;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Postcode = value;
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x00007394 File Offset: 0x00005594
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x000021A6 File Offset: 0x000003A6
		internal virtual DataGridViewTextBoxColumn Empty
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Empty;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Empty = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x000073AC File Offset: 0x000055AC
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x000021B0 File Offset: 0x000003B0
		internal virtual DataGridViewTextBoxColumn Orders
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Orders;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Orders = value;
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x000073C4 File Offset: 0x000055C4
		// (set) Token: 0x060000AA RID: 170 RVA: 0x000021BA File Offset: 0x000003BA
		internal virtual DataGridViewTextBoxColumn LastOrder
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LastOrder;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._LastOrder = value;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x060000AB RID: 171 RVA: 0x000073DC File Offset: 0x000055DC
		// (set) Token: 0x060000AC RID: 172 RVA: 0x000021C4 File Offset: 0x000003C4
		internal virtual DataGridViewTextBoxColumn Note
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Note;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Note = value;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x060000AD RID: 173 RVA: 0x000073F4 File Offset: 0x000055F4
		// (set) Token: 0x060000AE RID: 174 RVA: 0x0000740C File Offset: 0x0000560C
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x0000746C File Offset: 0x0000566C
		private void Edit_Customers_Load(object sender, EventArgs e)
		{
			foreach (string text in Customers.AllCustomersArray)
			{
				string[] array = text.Split(new char[]
				{
					'|'
				});
				this.CustomersEditDGV.Rows.Add(new object[]
				{
					array[0],
					array[1],
					array[2],
					array[3],
					array[4],
					array[5],
					array[6],
					array[7]
				});
			}
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00007510 File Offset: 0x00005710
		private void Button2_Click(object sender, EventArgs e)
		{
			try
			{
				try
				{
					foreach (object obj in ((IEnumerable)this.CustomersEditDGV.Rows))
					{
						DataGridViewRow dataGridViewRow = (DataGridViewRow)obj;
						string text = Conversions.ToString(dataGridViewRow.Cells[0].Value);
						string text2 = Conversions.ToString(dataGridViewRow.Cells[1].Value);
						string text3 = Conversions.ToString(dataGridViewRow.Cells[2].Value);
						string text4 = Conversions.ToString(dataGridViewRow.Cells[3].Value);
						string text5 = Conversions.ToString(dataGridViewRow.Cells[5].Value);
						string text6 = Conversions.ToString(dataGridViewRow.Cells[6].Value);
						string text7 = Conversions.ToString(dataGridViewRow.Cells[7].Value);
						string text8 = string.Concat(new string[]
						{
							text,
							"|",
							text2,
							"|",
							text3,
							"|",
							text4,
							"||",
							text5,
							"|",
							text6,
							"|",
							text7
						});
						Customers.AllCustomersArray[dataGridViewRow.Index] = text8;
					}
				}
				finally
				{
					IEnumerator enumerator;
					bool flag = enumerator is IDisposable;
					if (flag)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				FileSystem.Rename("data/_Customers.txt", Conversions.ToString(Operators.AddObject(Operators.AddObject(Operators.AddObject("data/_Customers", M_Settings.CurrentDate()), M_Settings.CurrentTime()), ".txt")));
				File.WriteAllLines("data/_Customers.txt", Customers.AllCustomersArray);
				this.Close();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x000021CE File Offset: 0x000003CE
		private void CustomersEditDGV_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			M_Settings.FocusedTextBoxForKeyboardTyping = this.TextBox1;
			this.TextBox1.Text = "";
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x000021EE File Offset: 0x000003EE
		private void Panel2_Paint(object sender, PaintEventArgs e)
		{
			Keyboard.MyKeyboard(this.BottomPanel, this.BottomPanel.Width, this.BottomPanel.Height);
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0000221E File Offset: 0x0000041E
		private void Button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00002229 File Offset: 0x00000429
		private void SaveBTN_Click(object sender, EventArgs e)
		{
			this.CustomersEditDGV.CurrentCell.Value = this.TextBox1.Text;
			this.TextBox1.Text = "";
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x0000225A File Offset: 0x0000045A
		private void Button3_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x04000036 RID: 54
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000037 RID: 55
		private IContainer components;

		// Token: 0x04000038 RID: 56
		[AccessedThroughProperty("CustomersEditDGV")]
		private DataGridView _CustomersEditDGV;

		// Token: 0x04000039 RID: 57
		[AccessedThroughProperty("LeftPanel")]
		private Panel _LeftPanel;

		// Token: 0x0400003A RID: 58
		[AccessedThroughProperty("BottomPanel")]
		private Panel _BottomPanel;

		// Token: 0x0400003B RID: 59
		[AccessedThroughProperty("RightPanel")]
		private Panel _RightPanel;

		// Token: 0x0400003C RID: 60
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x0400003D RID: 61
		[AccessedThroughProperty("TextBox1")]
		private TextBox _TextBox1;

		// Token: 0x0400003E RID: 62
		[AccessedThroughProperty("PasteBTN")]
		private Button _PasteBTN;

		// Token: 0x0400003F RID: 63
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x04000040 RID: 64
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000041 RID: 65
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x04000042 RID: 66
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x04000043 RID: 67
		[AccessedThroughProperty("MobileColumn")]
		private DataGridViewTextBoxColumn _MobileColumn;

		// Token: 0x04000044 RID: 68
		[AccessedThroughProperty("Address")]
		private DataGridViewTextBoxColumn _Address;

		// Token: 0x04000045 RID: 69
		[AccessedThroughProperty("City")]
		private DataGridViewTextBoxColumn _City;

		// Token: 0x04000046 RID: 70
		[AccessedThroughProperty("Postcode")]
		private DataGridViewTextBoxColumn _Postcode;

		// Token: 0x04000047 RID: 71
		[AccessedThroughProperty("Empty")]
		private DataGridViewTextBoxColumn _Empty;

		// Token: 0x04000048 RID: 72
		[AccessedThroughProperty("Orders")]
		private DataGridViewTextBoxColumn _Orders;

		// Token: 0x04000049 RID: 73
		[AccessedThroughProperty("LastOrder")]
		private DataGridViewTextBoxColumn _LastOrder;

		// Token: 0x0400004A RID: 74
		[AccessedThroughProperty("Note")]
		private DataGridViewTextBoxColumn _Note;

		// Token: 0x0400004B RID: 75
		[AccessedThroughProperty("Button3")]
		private Button _Button3;
	}
}
