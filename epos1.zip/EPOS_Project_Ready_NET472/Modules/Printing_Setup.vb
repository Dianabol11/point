using System;
using Microsoft.VisualBasic.CompilerServices;

namespace POS
{
	// Token: 0x0200002D RID: 45
	[StandardModule]
	internal sealed class Prints
	{
	}
}
