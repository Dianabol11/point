using System;
using System.Collections;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000023 RID: 35
	[StandardModule]
	internal sealed class M_Calculates
	{
		// Token: 0x060005B3 RID: 1459 RVA: 0x000342DC File Offset: 0x000324DC
		public static void xCalculateTotal(object qty, object price)
		{
			M_Calculates.OrderTotal = Conversions.ToDecimal(Operators.AddObject(M_Calculates.OrderTotal, NewLateBinding.LateGet(null, typeof(Math), "Round", new object[]
			{
				Operators.MultiplyObject(qty, price),
				2
			}, null, null, null)));
			MyProject.Forms.POS_Window.TotalTextBox.Text = Conversions.ToString(M_Calculates.OrderTotal);
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x00034358 File Offset: 0x00032558
		public static void CalculateSubTotal()
		{
			try
			{
				M_Settings.AutoCompleteTime = Conversions.ToString(Operators.AddObject(M_Settings.CurrentDate(), M_Settings.CurrentTime()));
				M_Settings.AutoCompleteActive = "yes";
				M_Calculates.OrderSubTotal = 0m;
				bool flag;
				try
				{
					foreach (object obj in M_Settings.ShoppingCart.Items)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(obj);
						flag = Operators.ConditionalCompareObjectNotEqual(NewLateBinding.LateGet(NewLateBinding.LateGet(objectValue, null, "SubItems", new object[]
						{
							6
						}, null, null, null), null, "Text", new object[0], null, null, null), "", false);
						if (flag)
						{
							M_Calculates.OrderSubTotal = decimal.Add(M_Calculates.OrderSubTotal, Conversions.ToDecimal(NewLateBinding.LateGet(NewLateBinding.LateGet(objectValue, null, "SubItems", new object[]
							{
								6
							}, null, null, null), null, "Text", new object[0], null, null, null)));
						}
						MyProject.Forms.POS_Window.SubTotalTextBox.Text = Strings.Format(M_Calculates.OrderSubTotal, "0.00");
					}
				}
				finally
				{
					IEnumerator enumerator;
					flag = (enumerator is IDisposable);
					if (flag)
					{
						(enumerator as IDisposable).Dispose();
					}
				}
				flag = (M_Settings.ShoppingCart.Items.Count == 0);
				if (flag)
				{
					MyProject.Forms.POS_Window.SubTotalTextBox.Text = "0.00";
				}
				flag = (decimal.Compare(M_Calculates.OrderSubTotal, 0m) > 0);
				if (flag)
				{
					MyProject.Forms.POS_Window.DiscountBTN.Enabled = true;
					MyProject.Forms.POS_Window.CompleteBTN.Enabled = true;
					MyProject.Forms.POS_Window.CommentBTN.Enabled = true;
				}
				else
				{
					MyProject.Forms.POS_Window.DiscountBTN.Enabled = false;
					MyProject.Forms.POS_Window.CompleteBTN.Enabled = false;
					MyProject.Forms.POS_Window.CommentBTN.Enabled = false;
				}
			}
			catch (Exception ex)
			{
			}
			M_Calculates.CalculateDiscount();
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x000345C8 File Offset: 0x000327C8
		public static void CalculateDiscount()
		{
			bool flag = Operators.CompareString(offers.OFFER_PERCENTOFF_PERCENT, "", false) != 0;
			if (flag)
			{
				offers.PERCENTOFF();
			}
			MyProject.Forms.POS_Window.DiscountTextBox.Text = Strings.Format(M_Calculates.OrderDiscount, "0.00");
			M_Calculates.CalculateDelivery();
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x00034628 File Offset: 0x00032828
		public static void CalculateDelivery()
		{
			bool flag = Operators.CompareString(offers.OFFER_FREEDELIVERY_PRICE, "", false) != 0 & decimal.Compare(decimal.Subtract(M_Calculates.OrderSubTotal, M_Calculates.OrderDiscount), Conversions.ToDecimal(offers.OFFER_FREEDELIVERY_PRICE)) >= 0;
			if (flag)
			{
				M_Calculates.OrderDelivery = 0m;
			}
			flag = (Operators.CompareString(M_Settings.OrderType, "Delivery", false) != 0);
			if (flag)
			{
				M_Calculates.OrderDelivery = 0m;
			}
			MyProject.Forms.POS_Window.DeliveryChargeTextBox.Text = Strings.Format(M_Calculates.OrderDelivery, "0.00");
			M_Calculates.CalculateServiceCharge();
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x00003DD5 File Offset: 0x00001FD5
		private static void CalculateServiceCharge()
		{
			MyProject.Forms.POS_Window.ServiceChargeTextBox.Text = Strings.Format(M_Calculates.OrderServiceCharge, "0.00");
			M_Calculates.CalculateTotal();
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x000346D8 File Offset: 0x000328D8
		private static void CalculateTotal()
		{
			M_Calculates.OrderTotal = decimal.Add(decimal.Add(decimal.Subtract(M_Calculates.OrderSubTotal, M_Calculates.OrderDiscount), M_Calculates.OrderDelivery), M_Calculates.OrderServiceCharge);
			MyProject.Forms.POS_Window.TotalTextBox.Text = Strings.Format(M_Calculates.OrderTotal, "0.00");
		}

		// Token: 0x04000256 RID: 598
		public static decimal OrderSubTotal;

		// Token: 0x04000257 RID: 599
		public static decimal OrderDiscount;

		// Token: 0x04000258 RID: 600
		public static decimal OrderDelivery;

		// Token: 0x04000259 RID: 601
		public static decimal OrderServiceCharge;

		// Token: 0x0400025A RID: 602
		public static decimal OrderTotal;
	}
}
