using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000010 RID: 16
	[DesignerGenerated]
	public class RePrintSaleReport : Form
	{
		// Token: 0x06000254 RID: 596 RVA: 0x00018660 File Offset: 0x00016860
		[DebuggerNonUserCode]
		public RePrintSaleReport()
		{
			base.Load += this.RePrintSaleReport_Load;
			List<WeakReference> _ENCList = RePrintSaleReport.__ENCList;
			lock (_ENCList)
			{
				RePrintSaleReport.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000255 RID: 597 RVA: 0x000186CC File Offset: 0x000168CC
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0001871C File Offset: 0x0001691C
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Button1 = new Button();
			this.Button2 = new Button();
			this.Label11 = new Label();
			this.Label12 = new Label();
			this.Label13 = new Label();
			this.Label14 = new Label();
			this.Label15 = new Label();
			this.NoOfCancelledTextBox = new TextBox();
			this.PaidCancelledTextBox = new TextBox();
			this.CashCancelledTextBox = new TextBox();
			this.TotalCancelledTextBox = new TextBox();
			this.TotalDeliveryTextBox = new TextBox();
			this.CashDeliveryTextBox = new TextBox();
			this.PaidDeliveryTextBox = new TextBox();
			this.NoOfDeliveryTextBox = new TextBox();
			this.Label1 = new Label();
			this.TotalTakeawayCollectionTextBox = new TextBox();
			this.CashTakeawayCollectionTextBox = new TextBox();
			this.PaidTakeawayCollectionTextBox = new TextBox();
			this.NoOfTakeawayCollectionTextBox = new TextBox();
			this.Label2 = new Label();
			this.TotalDineInTextBox = new TextBox();
			this.CashDineInTextBox = new TextBox();
			this.PaidDineInTextBox = new TextBox();
			this.NoOfDineInTextBox = new TextBox();
			this.Label3 = new Label();
			this.TotalTotalTextBox = new TextBox();
			this.CashTotalTextBox = new TextBox();
			this.NoOfTotalTextBox = new TextBox();
			this.Label4 = new Label();
			this.Button3 = new Button();
			this.PaidTotalTextBox = new TextBox();
			this.DateLabel = new Label();
			this.SuspendLayout();
			this.Button1.Anchor = AnchorStyles.Bottom;
			this.Button1.BackColor = Color.Orange;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			Point location = new Point(569, 301);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			Size size = new Size(221, 67);
			button2.Size = size;
			this.Button1.TabIndex = 11;
			this.Button1.Text = "Print + Delete";
			this.Button1.UseVisualStyleBackColor = false;
			this.Button2.Anchor = AnchorStyles.Bottom;
			this.Button2.BackColor = Color.FromArgb(192, 0, 0);
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button2.ForeColor = Color.White;
			Control button3 = this.Button2;
			location = new Point(744, 8);
			button3.Location = location;
			this.Button2.Name = "Button2";
			Control button4 = this.Button2;
			size = new Size(46, 40);
			button4.Size = size;
			this.Button2.TabIndex = 12;
			this.Button2.Text = "x";
			this.Button2.UseVisualStyleBackColor = false;
			this.Label11.AutoSize = true;
			this.Label11.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label11.ForeColor = Color.SteelBlue;
			Control label = this.Label11;
			location = new Point(114, 203);
			label.Location = location;
			this.Label11.Name = "Label11";
			Control label2 = this.Label11;
			size = new Size(95, 22);
			label2.Size = size;
			this.Label11.TabIndex = 13;
			this.Label11.Text = "Cancelled";
			this.Label12.AutoSize = true;
			this.Label12.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label12.ForeColor = Color.SteelBlue;
			Control label3 = this.Label12;
			location = new Point(211, 19);
			label3.Location = location;
			this.Label12.Name = "Label12";
			Control label4 = this.Label12;
			size = new Size(69, 22);
			label4.Size = size;
			this.Label12.TabIndex = 14;
			this.Label12.Text = "Orders";
			this.Label13.AutoSize = true;
			this.Label13.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label13.ForeColor = Color.SteelBlue;
			Control label5 = this.Label13;
			location = new Point(335, 19);
			label5.Location = location;
			this.Label13.Name = "Label13";
			Control label6 = this.Label13;
			size = new Size(104, 22);
			label6.Size = size;
			this.Label13.TabIndex = 15;
			this.Label13.Text = "Paid / Card";
			this.Label14.AutoSize = true;
			this.Label14.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label14.ForeColor = Color.SteelBlue;
			Control label7 = this.Label14;
			location = new Point(465, 19);
			label7.Location = location;
			this.Label14.Name = "Label14";
			Control label8 = this.Label14;
			size = new Size(54, 22);
			label8.Size = size;
			this.Label14.TabIndex = 16;
			this.Label14.Text = "Cash";
			this.Label15.AutoSize = true;
			this.Label15.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label15.ForeColor = Color.SteelBlue;
			Control label9 = this.Label15;
			location = new Point(568, 19);
			label9.Location = location;
			this.Label15.Name = "Label15";
			Control label10 = this.Label15;
			size = new Size(50, 22);
			label10.Size = size;
			this.Label15.TabIndex = 17;
			this.Label15.Text = "Total";
			this.NoOfCancelledTextBox.BackColor = SystemColors.Control;
			this.NoOfCancelledTextBox.BorderStyle = BorderStyle.None;
			this.NoOfCancelledTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control noOfCancelledTextBox = this.NoOfCancelledTextBox;
			location = new Point(215, 200);
			noOfCancelledTextBox.Location = location;
			this.NoOfCancelledTextBox.Name = "NoOfCancelledTextBox";
			Control noOfCancelledTextBox2 = this.NoOfCancelledTextBox;
			size = new Size(66, 22);
			noOfCancelledTextBox2.Size = size;
			this.NoOfCancelledTextBox.TabIndex = 18;
			this.NoOfCancelledTextBox.TextAlign = HorizontalAlignment.Center;
			this.PaidCancelledTextBox.BackColor = SystemColors.Control;
			this.PaidCancelledTextBox.BorderStyle = BorderStyle.None;
			this.PaidCancelledTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control paidCancelledTextBox = this.PaidCancelledTextBox;
			location = new Point(339, 200);
			paidCancelledTextBox.Location = location;
			this.PaidCancelledTextBox.Name = "PaidCancelledTextBox";
			Control paidCancelledTextBox2 = this.PaidCancelledTextBox;
			size = new Size(100, 22);
			paidCancelledTextBox2.Size = size;
			this.PaidCancelledTextBox.TabIndex = 19;
			this.PaidCancelledTextBox.TextAlign = HorizontalAlignment.Center;
			this.CashCancelledTextBox.BackColor = SystemColors.Control;
			this.CashCancelledTextBox.BorderStyle = BorderStyle.None;
			this.CashCancelledTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control cashCancelledTextBox = this.CashCancelledTextBox;
			location = new Point(445, 200);
			cashCancelledTextBox.Location = location;
			this.CashCancelledTextBox.Name = "CashCancelledTextBox";
			Control cashCancelledTextBox2 = this.CashCancelledTextBox;
			size = new Size(100, 22);
			cashCancelledTextBox2.Size = size;
			this.CashCancelledTextBox.TabIndex = 20;
			this.CashCancelledTextBox.TextAlign = HorizontalAlignment.Center;
			this.TotalCancelledTextBox.BackColor = SystemColors.Control;
			this.TotalCancelledTextBox.BorderStyle = BorderStyle.None;
			this.TotalCancelledTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control totalCancelledTextBox = this.TotalCancelledTextBox;
			location = new Point(551, 203);
			totalCancelledTextBox.Location = location;
			this.TotalCancelledTextBox.Name = "TotalCancelledTextBox";
			this.TotalCancelledTextBox.ReadOnly = true;
			Control totalCancelledTextBox2 = this.TotalCancelledTextBox;
			size = new Size(96, 22);
			totalCancelledTextBox2.Size = size;
			this.TotalCancelledTextBox.TabIndex = 21;
			this.TotalCancelledTextBox.TextAlign = HorizontalAlignment.Center;
			this.TotalDeliveryTextBox.BackColor = SystemColors.Control;
			this.TotalDeliveryTextBox.BorderStyle = BorderStyle.None;
			this.TotalDeliveryTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control totalDeliveryTextBox = this.TotalDeliveryTextBox;
			location = new Point(551, 68);
			totalDeliveryTextBox.Location = location;
			this.TotalDeliveryTextBox.Name = "TotalDeliveryTextBox";
			this.TotalDeliveryTextBox.ReadOnly = true;
			Control totalDeliveryTextBox2 = this.TotalDeliveryTextBox;
			size = new Size(96, 22);
			totalDeliveryTextBox2.Size = size;
			this.TotalDeliveryTextBox.TabIndex = 26;
			this.TotalDeliveryTextBox.TextAlign = HorizontalAlignment.Center;
			this.CashDeliveryTextBox.BackColor = SystemColors.Control;
			this.CashDeliveryTextBox.BorderStyle = BorderStyle.None;
			this.CashDeliveryTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control cashDeliveryTextBox = this.CashDeliveryTextBox;
			location = new Point(445, 68);
			cashDeliveryTextBox.Location = location;
			this.CashDeliveryTextBox.Name = "CashDeliveryTextBox";
			Control cashDeliveryTextBox2 = this.CashDeliveryTextBox;
			size = new Size(100, 22);
			cashDeliveryTextBox2.Size = size;
			this.CashDeliveryTextBox.TabIndex = 25;
			this.CashDeliveryTextBox.TextAlign = HorizontalAlignment.Center;
			this.PaidDeliveryTextBox.BackColor = SystemColors.Control;
			this.PaidDeliveryTextBox.BorderStyle = BorderStyle.None;
			this.PaidDeliveryTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control paidDeliveryTextBox = this.PaidDeliveryTextBox;
			location = new Point(339, 68);
			paidDeliveryTextBox.Location = location;
			this.PaidDeliveryTextBox.Name = "PaidDeliveryTextBox";
			Control paidDeliveryTextBox2 = this.PaidDeliveryTextBox;
			size = new Size(100, 22);
			paidDeliveryTextBox2.Size = size;
			this.PaidDeliveryTextBox.TabIndex = 24;
			this.PaidDeliveryTextBox.TextAlign = HorizontalAlignment.Center;
			this.NoOfDeliveryTextBox.BackColor = SystemColors.Control;
			this.NoOfDeliveryTextBox.BorderStyle = BorderStyle.None;
			this.NoOfDeliveryTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control noOfDeliveryTextBox = this.NoOfDeliveryTextBox;
			location = new Point(215, 68);
			noOfDeliveryTextBox.Location = location;
			this.NoOfDeliveryTextBox.Name = "NoOfDeliveryTextBox";
			Control noOfDeliveryTextBox2 = this.NoOfDeliveryTextBox;
			size = new Size(66, 22);
			noOfDeliveryTextBox2.Size = size;
			this.NoOfDeliveryTextBox.TabIndex = 23;
			this.NoOfDeliveryTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.SteelBlue;
			Control label11 = this.Label1;
			location = new Point(131, 68);
			label11.Location = location;
			this.Label1.Name = "Label1";
			Control label12 = this.Label1;
			size = new Size(78, 22);
			label12.Size = size;
			this.Label1.TabIndex = 22;
			this.Label1.Text = "Delivery";
			this.TotalTakeawayCollectionTextBox.BackColor = SystemColors.Control;
			this.TotalTakeawayCollectionTextBox.BorderStyle = BorderStyle.None;
			this.TotalTakeawayCollectionTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control totalTakeawayCollectionTextBox = this.TotalTakeawayCollectionTextBox;
			location = new Point(551, 113);
			totalTakeawayCollectionTextBox.Location = location;
			this.TotalTakeawayCollectionTextBox.Name = "TotalTakeawayCollectionTextBox";
			this.TotalTakeawayCollectionTextBox.ReadOnly = true;
			Control totalTakeawayCollectionTextBox2 = this.TotalTakeawayCollectionTextBox;
			size = new Size(96, 22);
			totalTakeawayCollectionTextBox2.Size = size;
			this.TotalTakeawayCollectionTextBox.TabIndex = 31;
			this.TotalTakeawayCollectionTextBox.TextAlign = HorizontalAlignment.Center;
			this.CashTakeawayCollectionTextBox.BackColor = SystemColors.Control;
			this.CashTakeawayCollectionTextBox.BorderStyle = BorderStyle.None;
			this.CashTakeawayCollectionTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control cashTakeawayCollectionTextBox = this.CashTakeawayCollectionTextBox;
			location = new Point(445, 113);
			cashTakeawayCollectionTextBox.Location = location;
			this.CashTakeawayCollectionTextBox.Name = "CashTakeawayCollectionTextBox";
			Control cashTakeawayCollectionTextBox2 = this.CashTakeawayCollectionTextBox;
			size = new Size(100, 22);
			cashTakeawayCollectionTextBox2.Size = size;
			this.CashTakeawayCollectionTextBox.TabIndex = 30;
			this.CashTakeawayCollectionTextBox.TextAlign = HorizontalAlignment.Center;
			this.PaidTakeawayCollectionTextBox.BackColor = SystemColors.Control;
			this.PaidTakeawayCollectionTextBox.BorderStyle = BorderStyle.None;
			this.PaidTakeawayCollectionTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control paidTakeawayCollectionTextBox = this.PaidTakeawayCollectionTextBox;
			location = new Point(339, 113);
			paidTakeawayCollectionTextBox.Location = location;
			this.PaidTakeawayCollectionTextBox.Name = "PaidTakeawayCollectionTextBox";
			Control paidTakeawayCollectionTextBox2 = this.PaidTakeawayCollectionTextBox;
			size = new Size(100, 22);
			paidTakeawayCollectionTextBox2.Size = size;
			this.PaidTakeawayCollectionTextBox.TabIndex = 29;
			this.PaidTakeawayCollectionTextBox.TextAlign = HorizontalAlignment.Center;
			this.NoOfTakeawayCollectionTextBox.BackColor = SystemColors.Control;
			this.NoOfTakeawayCollectionTextBox.BorderStyle = BorderStyle.None;
			this.NoOfTakeawayCollectionTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control noOfTakeawayCollectionTextBox = this.NoOfTakeawayCollectionTextBox;
			location = new Point(215, 113);
			noOfTakeawayCollectionTextBox.Location = location;
			this.NoOfTakeawayCollectionTextBox.Name = "NoOfTakeawayCollectionTextBox";
			Control noOfTakeawayCollectionTextBox2 = this.NoOfTakeawayCollectionTextBox;
			size = new Size(66, 22);
			noOfTakeawayCollectionTextBox2.Size = size;
			this.NoOfTakeawayCollectionTextBox.TabIndex = 28;
			this.NoOfTakeawayCollectionTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label2.ForeColor = Color.SteelBlue;
			Control label13 = this.Label2;
			location = new Point(18, 113);
			label13.Location = location;
			this.Label2.Name = "Label2";
			Control label14 = this.Label2;
			size = new Size(191, 22);
			label14.Size = size;
			this.Label2.TabIndex = 27;
			this.Label2.Text = "Takeaway / Collection";
			this.TotalDineInTextBox.BackColor = SystemColors.Control;
			this.TotalDineInTextBox.BorderStyle = BorderStyle.None;
			this.TotalDineInTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control totalDineInTextBox = this.TotalDineInTextBox;
			location = new Point(551, 158);
			totalDineInTextBox.Location = location;
			this.TotalDineInTextBox.Name = "TotalDineInTextBox";
			this.TotalDineInTextBox.ReadOnly = true;
			Control totalDineInTextBox2 = this.TotalDineInTextBox;
			size = new Size(96, 22);
			totalDineInTextBox2.Size = size;
			this.TotalDineInTextBox.TabIndex = 36;
			this.TotalDineInTextBox.TextAlign = HorizontalAlignment.Center;
			this.CashDineInTextBox.BackColor = SystemColors.Control;
			this.CashDineInTextBox.BorderStyle = BorderStyle.None;
			this.CashDineInTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control cashDineInTextBox = this.CashDineInTextBox;
			location = new Point(445, 158);
			cashDineInTextBox.Location = location;
			this.CashDineInTextBox.Name = "CashDineInTextBox";
			Control cashDineInTextBox2 = this.CashDineInTextBox;
			size = new Size(100, 22);
			cashDineInTextBox2.Size = size;
			this.CashDineInTextBox.TabIndex = 35;
			this.CashDineInTextBox.TextAlign = HorizontalAlignment.Center;
			this.PaidDineInTextBox.BackColor = SystemColors.Control;
			this.PaidDineInTextBox.BorderStyle = BorderStyle.None;
			this.PaidDineInTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control paidDineInTextBox = this.PaidDineInTextBox;
			location = new Point(339, 158);
			paidDineInTextBox.Location = location;
			this.PaidDineInTextBox.Name = "PaidDineInTextBox";
			Control paidDineInTextBox2 = this.PaidDineInTextBox;
			size = new Size(100, 22);
			paidDineInTextBox2.Size = size;
			this.PaidDineInTextBox.TabIndex = 34;
			this.PaidDineInTextBox.TextAlign = HorizontalAlignment.Center;
			this.NoOfDineInTextBox.BackColor = SystemColors.Control;
			this.NoOfDineInTextBox.BorderStyle = BorderStyle.None;
			this.NoOfDineInTextBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control noOfDineInTextBox = this.NoOfDineInTextBox;
			location = new Point(215, 158);
			noOfDineInTextBox.Location = location;
			this.NoOfDineInTextBox.Name = "NoOfDineInTextBox";
			Control noOfDineInTextBox2 = this.NoOfDineInTextBox;
			size = new Size(66, 22);
			noOfDineInTextBox2.Size = size;
			this.NoOfDineInTextBox.TabIndex = 33;
			this.NoOfDineInTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label3.AutoSize = true;
			this.Label3.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label3.ForeColor = Color.SteelBlue;
			Control label15 = this.Label3;
			location = new Point(139, 158);
			label15.Location = location;
			this.Label3.Name = "Label3";
			Control label16 = this.Label3;
			size = new Size(70, 22);
			label16.Size = size;
			this.Label3.TabIndex = 32;
			this.Label3.Text = "Dine In";
			this.TotalTotalTextBox.BackColor = SystemColors.Control;
			this.TotalTotalTextBox.BorderStyle = BorderStyle.None;
			this.TotalTotalTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control totalTotalTextBox = this.TotalTotalTextBox;
			location = new Point(551, 247);
			totalTotalTextBox.Location = location;
			this.TotalTotalTextBox.Name = "TotalTotalTextBox";
			this.TotalTotalTextBox.ReadOnly = true;
			Control totalTotalTextBox2 = this.TotalTotalTextBox;
			size = new Size(96, 22);
			totalTotalTextBox2.Size = size;
			this.TotalTotalTextBox.TabIndex = 41;
			this.TotalTotalTextBox.TextAlign = HorizontalAlignment.Center;
			this.CashTotalTextBox.BackColor = SystemColors.Control;
			this.CashTotalTextBox.BorderStyle = BorderStyle.None;
			this.CashTotalTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control cashTotalTextBox = this.CashTotalTextBox;
			location = new Point(445, 247);
			cashTotalTextBox.Location = location;
			this.CashTotalTextBox.Name = "CashTotalTextBox";
			this.CashTotalTextBox.ReadOnly = true;
			Control cashTotalTextBox2 = this.CashTotalTextBox;
			size = new Size(100, 22);
			cashTotalTextBox2.Size = size;
			this.CashTotalTextBox.TabIndex = 40;
			this.CashTotalTextBox.TextAlign = HorizontalAlignment.Center;
			this.NoOfTotalTextBox.BackColor = SystemColors.Control;
			this.NoOfTotalTextBox.BorderStyle = BorderStyle.None;
			this.NoOfTotalTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control noOfTotalTextBox = this.NoOfTotalTextBox;
			location = new Point(215, 247);
			noOfTotalTextBox.Location = location;
			this.NoOfTotalTextBox.Name = "NoOfTotalTextBox";
			this.NoOfTotalTextBox.ReadOnly = true;
			Control noOfTotalTextBox2 = this.NoOfTotalTextBox;
			size = new Size(66, 22);
			noOfTotalTextBox2.Size = size;
			this.NoOfTotalTextBox.TabIndex = 38;
			this.NoOfTotalTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label4.AutoSize = true;
			this.Label4.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label4.ForeColor = Color.SteelBlue;
			Control label17 = this.Label4;
			location = new Point(148, 247);
			label17.Location = location;
			this.Label4.Name = "Label4";
			Control label18 = this.Label4;
			size = new Size(61, 22);
			label18.Size = size;
			this.Label4.TabIndex = 37;
			this.Label4.Text = "Today";
			this.Button3.Anchor = AnchorStyles.Bottom;
			this.Button3.BackColor = Color.Crimson;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button3.ForeColor = Color.White;
			Control button5 = this.Button3;
			location = new Point(12, 301);
			button5.Location = location;
			this.Button3.Name = "Button3";
			Control button6 = this.Button3;
			size = new Size(221, 67);
			button6.Size = size;
			this.Button3.TabIndex = 42;
			this.Button3.Text = "Delete only";
			this.Button3.UseVisualStyleBackColor = false;
			this.PaidTotalTextBox.BackColor = SystemColors.Control;
			this.PaidTotalTextBox.BorderStyle = BorderStyle.None;
			this.PaidTotalTextBox.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control paidTotalTextBox = this.PaidTotalTextBox;
			location = new Point(339, 247);
			paidTotalTextBox.Location = location;
			this.PaidTotalTextBox.Name = "PaidTotalTextBox";
			this.PaidTotalTextBox.ReadOnly = true;
			Control paidTotalTextBox2 = this.PaidTotalTextBox;
			size = new Size(100, 22);
			paidTotalTextBox2.Size = size;
			this.PaidTotalTextBox.TabIndex = 45;
			this.PaidTotalTextBox.TextAlign = HorizontalAlignment.Center;
			this.DateLabel.AutoSize = true;
			this.DateLabel.Font = new Font("Arial", 15.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DateLabel.ForeColor = Color.Crimson;
			Control dateLabel = this.DateLabel;
			location = new Point(18, 19);
			dateLabel.Location = location;
			this.DateLabel.Name = "DateLabel";
			Control dateLabel2 = this.DateLabel;
			size = new Size(55, 24);
			dateLabel2.Size = size;
			this.DateLabel.TabIndex = 46;
			this.DateLabel.Text = "Date";
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = SystemColors.Control;
			size = new Size(799, 380);
			this.ClientSize = size;
			this.Controls.Add(this.DateLabel);
			this.Controls.Add(this.PaidTotalTextBox);
			this.Controls.Add(this.Button3);
			this.Controls.Add(this.TotalTotalTextBox);
			this.Controls.Add(this.CashTotalTextBox);
			this.Controls.Add(this.NoOfTotalTextBox);
			this.Controls.Add(this.Label4);
			this.Controls.Add(this.TotalDineInTextBox);
			this.Controls.Add(this.CashDineInTextBox);
			this.Controls.Add(this.PaidDineInTextBox);
			this.Controls.Add(this.NoOfDineInTextBox);
			this.Controls.Add(this.Label3);
			this.Controls.Add(this.TotalTakeawayCollectionTextBox);
			this.Controls.Add(this.CashTakeawayCollectionTextBox);
			this.Controls.Add(this.PaidTakeawayCollectionTextBox);
			this.Controls.Add(this.NoOfTakeawayCollectionTextBox);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.TotalDeliveryTextBox);
			this.Controls.Add(this.CashDeliveryTextBox);
			this.Controls.Add(this.PaidDeliveryTextBox);
			this.Controls.Add(this.NoOfDeliveryTextBox);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.TotalCancelledTextBox);
			this.Controls.Add(this.CashCancelledTextBox);
			this.Controls.Add(this.PaidCancelledTextBox);
			this.Controls.Add(this.NoOfCancelledTextBox);
			this.Controls.Add(this.Label15);
			this.Controls.Add(this.Label14);
			this.Controls.Add(this.Label13);
			this.Controls.Add(this.Label12);
			this.Controls.Add(this.Label11);
			this.Controls.Add(this.Button2);
			this.Controls.Add(this.Button1);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "RePrintSaleReport";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "CreateSelfSaleReport";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000257 RID: 599 RVA: 0x0001A128 File Offset: 0x00018328
		// (set) Token: 0x06000258 RID: 600 RVA: 0x0001A140 File Offset: 0x00018340
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x06000259 RID: 601 RVA: 0x0001A1A0 File Offset: 0x000183A0
		// (set) Token: 0x0600025A RID: 602 RVA: 0x0001A1B8 File Offset: 0x000183B8
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x0600025B RID: 603 RVA: 0x0001A218 File Offset: 0x00018418
		// (set) Token: 0x0600025C RID: 604 RVA: 0x00002915 File Offset: 0x00000B15
		internal virtual Label Label11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label11 = value;
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x0600025D RID: 605 RVA: 0x0001A230 File Offset: 0x00018430
		// (set) Token: 0x0600025E RID: 606 RVA: 0x0000291F File Offset: 0x00000B1F
		internal virtual Label Label12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label12 = value;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600025F RID: 607 RVA: 0x0001A248 File Offset: 0x00018448
		// (set) Token: 0x06000260 RID: 608 RVA: 0x00002929 File Offset: 0x00000B29
		internal virtual Label Label13
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label13;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label13 = value;
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000261 RID: 609 RVA: 0x0001A260 File Offset: 0x00018460
		// (set) Token: 0x06000262 RID: 610 RVA: 0x00002933 File Offset: 0x00000B33
		internal virtual Label Label14
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label14;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label14 = value;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000263 RID: 611 RVA: 0x0001A278 File Offset: 0x00018478
		// (set) Token: 0x06000264 RID: 612 RVA: 0x0000293D File Offset: 0x00000B3D
		internal virtual Label Label15
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label15;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label15 = value;
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000265 RID: 613 RVA: 0x0001A290 File Offset: 0x00018490
		// (set) Token: 0x06000266 RID: 614 RVA: 0x0001A2A8 File Offset: 0x000184A8
		internal virtual TextBox NoOfCancelledTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfCancelledTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NoOfCancelledTextBox_TextChanged);
				bool flag = this._NoOfCancelledTextBox != null;
				if (flag)
				{
					this._NoOfCancelledTextBox.TextChanged -= value2;
				}
				this._NoOfCancelledTextBox = value;
				flag = (this._NoOfCancelledTextBox != null);
				if (flag)
				{
					this._NoOfCancelledTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000267 RID: 615 RVA: 0x0001A308 File Offset: 0x00018508
		// (set) Token: 0x06000268 RID: 616 RVA: 0x0001A320 File Offset: 0x00018520
		internal virtual TextBox PaidCancelledTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PaidCancelledTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PaidCancelledTextBox_TextChanged);
				bool flag = this._PaidCancelledTextBox != null;
				if (flag)
				{
					this._PaidCancelledTextBox.TextChanged -= value2;
				}
				this._PaidCancelledTextBox = value;
				flag = (this._PaidCancelledTextBox != null);
				if (flag)
				{
					this._PaidCancelledTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x06000269 RID: 617 RVA: 0x0001A380 File Offset: 0x00018580
		// (set) Token: 0x0600026A RID: 618 RVA: 0x0001A398 File Offset: 0x00018598
		internal virtual TextBox CashCancelledTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CashCancelledTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CashCancelledTextBox_TextChanged);
				bool flag = this._CashCancelledTextBox != null;
				if (flag)
				{
					this._CashCancelledTextBox.TextChanged -= value2;
				}
				this._CashCancelledTextBox = value;
				flag = (this._CashCancelledTextBox != null);
				if (flag)
				{
					this._CashCancelledTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x0600026B RID: 619 RVA: 0x0001A3F8 File Offset: 0x000185F8
		// (set) Token: 0x0600026C RID: 620 RVA: 0x00002947 File Offset: 0x00000B47
		internal virtual TextBox TotalCancelledTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalCancelledTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalCancelledTextBox = value;
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600026D RID: 621 RVA: 0x0001A410 File Offset: 0x00018610
		// (set) Token: 0x0600026E RID: 622 RVA: 0x00002951 File Offset: 0x00000B51
		internal virtual TextBox TotalDeliveryTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalDeliveryTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalDeliveryTextBox = value;
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x0600026F RID: 623 RVA: 0x0001A428 File Offset: 0x00018628
		// (set) Token: 0x06000270 RID: 624 RVA: 0x0001A440 File Offset: 0x00018640
		internal virtual TextBox CashDeliveryTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CashDeliveryTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CashDeliveryTextBox_TextChanged);
				bool flag = this._CashDeliveryTextBox != null;
				if (flag)
				{
					this._CashDeliveryTextBox.TextChanged -= value2;
				}
				this._CashDeliveryTextBox = value;
				flag = (this._CashDeliveryTextBox != null);
				if (flag)
				{
					this._CashDeliveryTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000271 RID: 625 RVA: 0x0001A4A0 File Offset: 0x000186A0
		// (set) Token: 0x06000272 RID: 626 RVA: 0x0001A4B8 File Offset: 0x000186B8
		internal virtual TextBox PaidDeliveryTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PaidDeliveryTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PaidDeliveryTextBox_TextChanged);
				bool flag = this._PaidDeliveryTextBox != null;
				if (flag)
				{
					this._PaidDeliveryTextBox.TextChanged -= value2;
				}
				this._PaidDeliveryTextBox = value;
				flag = (this._PaidDeliveryTextBox != null);
				if (flag)
				{
					this._PaidDeliveryTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000273 RID: 627 RVA: 0x0001A518 File Offset: 0x00018718
		// (set) Token: 0x06000274 RID: 628 RVA: 0x0001A530 File Offset: 0x00018730
		internal virtual TextBox NoOfDeliveryTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfDeliveryTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NoOfDeliveryTextBox_TextChanged);
				bool flag = this._NoOfDeliveryTextBox != null;
				if (flag)
				{
					this._NoOfDeliveryTextBox.TextChanged -= value2;
				}
				this._NoOfDeliveryTextBox = value;
				flag = (this._NoOfDeliveryTextBox != null);
				if (flag)
				{
					this._NoOfDeliveryTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000275 RID: 629 RVA: 0x0001A590 File Offset: 0x00018790
		// (set) Token: 0x06000276 RID: 630 RVA: 0x0000295B File Offset: 0x00000B5B
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000277 RID: 631 RVA: 0x0001A5A8 File Offset: 0x000187A8
		// (set) Token: 0x06000278 RID: 632 RVA: 0x00002965 File Offset: 0x00000B65
		internal virtual TextBox TotalTakeawayCollectionTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalTakeawayCollectionTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalTakeawayCollectionTextBox = value;
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000279 RID: 633 RVA: 0x0001A5C0 File Offset: 0x000187C0
		// (set) Token: 0x0600027A RID: 634 RVA: 0x0001A5D8 File Offset: 0x000187D8
		internal virtual TextBox CashTakeawayCollectionTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CashTakeawayCollectionTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CashTakeawayCollectionTextBox_TextChanged);
				bool flag = this._CashTakeawayCollectionTextBox != null;
				if (flag)
				{
					this._CashTakeawayCollectionTextBox.TextChanged -= value2;
				}
				this._CashTakeawayCollectionTextBox = value;
				flag = (this._CashTakeawayCollectionTextBox != null);
				if (flag)
				{
					this._CashTakeawayCollectionTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x0600027B RID: 635 RVA: 0x0001A638 File Offset: 0x00018838
		// (set) Token: 0x0600027C RID: 636 RVA: 0x0001A650 File Offset: 0x00018850
		internal virtual TextBox PaidTakeawayCollectionTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PaidTakeawayCollectionTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PaidTakeawayCollectionTextBox_TextChanged);
				bool flag = this._PaidTakeawayCollectionTextBox != null;
				if (flag)
				{
					this._PaidTakeawayCollectionTextBox.TextChanged -= value2;
				}
				this._PaidTakeawayCollectionTextBox = value;
				flag = (this._PaidTakeawayCollectionTextBox != null);
				if (flag)
				{
					this._PaidTakeawayCollectionTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600027D RID: 637 RVA: 0x0001A6B0 File Offset: 0x000188B0
		// (set) Token: 0x0600027E RID: 638 RVA: 0x0001A6C8 File Offset: 0x000188C8
		internal virtual TextBox NoOfTakeawayCollectionTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfTakeawayCollectionTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NoOfTakeawayCollectionTextBox_TextChanged);
				bool flag = this._NoOfTakeawayCollectionTextBox != null;
				if (flag)
				{
					this._NoOfTakeawayCollectionTextBox.TextChanged -= value2;
				}
				this._NoOfTakeawayCollectionTextBox = value;
				flag = (this._NoOfTakeawayCollectionTextBox != null);
				if (flag)
				{
					this._NoOfTakeawayCollectionTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600027F RID: 639 RVA: 0x0001A728 File Offset: 0x00018928
		// (set) Token: 0x06000280 RID: 640 RVA: 0x0000296F File Offset: 0x00000B6F
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000281 RID: 641 RVA: 0x0001A740 File Offset: 0x00018940
		// (set) Token: 0x06000282 RID: 642 RVA: 0x00002979 File Offset: 0x00000B79
		internal virtual TextBox TotalDineInTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalDineInTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalDineInTextBox = value;
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000283 RID: 643 RVA: 0x0001A758 File Offset: 0x00018958
		// (set) Token: 0x06000284 RID: 644 RVA: 0x0001A770 File Offset: 0x00018970
		internal virtual TextBox CashDineInTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CashDineInTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CashDineInTextBox_TextChanged);
				bool flag = this._CashDineInTextBox != null;
				if (flag)
				{
					this._CashDineInTextBox.TextChanged -= value2;
				}
				this._CashDineInTextBox = value;
				flag = (this._CashDineInTextBox != null);
				if (flag)
				{
					this._CashDineInTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000285 RID: 645 RVA: 0x0001A7D0 File Offset: 0x000189D0
		// (set) Token: 0x06000286 RID: 646 RVA: 0x0001A7E8 File Offset: 0x000189E8
		internal virtual TextBox PaidDineInTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PaidDineInTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PaidDineInTextBox_TextChanged);
				bool flag = this._PaidDineInTextBox != null;
				if (flag)
				{
					this._PaidDineInTextBox.TextChanged -= value2;
				}
				this._PaidDineInTextBox = value;
				flag = (this._PaidDineInTextBox != null);
				if (flag)
				{
					this._PaidDineInTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000287 RID: 647 RVA: 0x0001A848 File Offset: 0x00018A48
		// (set) Token: 0x06000288 RID: 648 RVA: 0x0001A860 File Offset: 0x00018A60
		internal virtual TextBox NoOfDineInTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfDineInTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NoOfDineInTextBox_TextChanged);
				bool flag = this._NoOfDineInTextBox != null;
				if (flag)
				{
					this._NoOfDineInTextBox.TextChanged -= value2;
				}
				this._NoOfDineInTextBox = value;
				flag = (this._NoOfDineInTextBox != null);
				if (flag)
				{
					this._NoOfDineInTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06000289 RID: 649 RVA: 0x0001A8C0 File Offset: 0x00018AC0
		// (set) Token: 0x0600028A RID: 650 RVA: 0x00002983 File Offset: 0x00000B83
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x0600028B RID: 651 RVA: 0x0001A8D8 File Offset: 0x00018AD8
		// (set) Token: 0x0600028C RID: 652 RVA: 0x0000298D File Offset: 0x00000B8D
		internal virtual TextBox TotalTotalTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TotalTotalTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TotalTotalTextBox = value;
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600028D RID: 653 RVA: 0x0001A8F0 File Offset: 0x00018AF0
		// (set) Token: 0x0600028E RID: 654 RVA: 0x00002997 File Offset: 0x00000B97
		internal virtual TextBox CashTotalTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CashTotalTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._CashTotalTextBox = value;
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x0600028F RID: 655 RVA: 0x0001A908 File Offset: 0x00018B08
		// (set) Token: 0x06000290 RID: 656 RVA: 0x000029A1 File Offset: 0x00000BA1
		internal virtual TextBox NoOfTotalTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NoOfTotalTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._NoOfTotalTextBox = value;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000291 RID: 657 RVA: 0x0001A920 File Offset: 0x00018B20
		// (set) Token: 0x06000292 RID: 658 RVA: 0x000029AB File Offset: 0x00000BAB
		internal virtual Label Label4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label4 = value;
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06000293 RID: 659 RVA: 0x0001A938 File Offset: 0x00018B38
		// (set) Token: 0x06000294 RID: 660 RVA: 0x0001A950 File Offset: 0x00018B50
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000295 RID: 661 RVA: 0x0001A9B0 File Offset: 0x00018BB0
		// (set) Token: 0x06000296 RID: 662 RVA: 0x000029B5 File Offset: 0x00000BB5
		internal virtual TextBox PaidTotalTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PaidTotalTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PaidTotalTextBox = value;
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000297 RID: 663 RVA: 0x0001A9C8 File Offset: 0x00018BC8
		// (set) Token: 0x06000298 RID: 664 RVA: 0x000029BF File Offset: 0x00000BBF
		internal virtual Label DateLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DateLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DateLabel = value;
			}
		}

		// Token: 0x06000299 RID: 665 RVA: 0x000029C9 File Offset: 0x00000BC9
		private void Button2_Click(object sender, EventArgs e)
		{
			this.ClearAllVariables();
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x0600029A RID: 666 RVA: 0x0001A9E0 File Offset: 0x00018BE0
		private void RePrintSaleReport_Load(object sender, EventArgs e)
		{
			string text = MyProject.Forms.General_Settings.OrderHistoryListBox.SelectedItem.ToString();
			this.DateLabel.Text = text.Split(new char[]
			{
				' '
			})[0];
			text = text.Replace(" ", "");
			text = text.Replace("/", "");
			text = text.Replace("-", "");
			text = text.Replace(":", "");
			text = MySettingsProperty.Settings.ComputerNo + "_" + text;
			this.SelectedFolderDayDate = text;
			this.SelectedFolderDay = "data\\order_history\\" + text;
			MyProject.Forms.FreeFoodsOffer.CalculateEndSession(text);
			this.NoOfDeliveryTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.NumberOfDeliveryOrders);
			this.NoOfTakeawayCollectionTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.NumberOfTakeCollOrders);
			this.NoOfDineInTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.NumberOfDineInOrders);
			this.NoOfCancelledTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.NumberOfCancelledOrders);
			this.NoOfTotalTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.NumberOfTotalOrders);
			this.PaidDeliveryTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.DeliveryPaidAmount);
			this.PaidTakeawayCollectionTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.TakeCollPaidAmount);
			this.PaidDineInTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.DineInPaidAmount);
			this.PaidCancelledTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.CancelPaidAmount);
			this.CashDeliveryTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.DeliveryNotPaidAmount);
			this.CashTakeawayCollectionTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.TakeCollCashAmount);
			this.CashDineInTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.DineInCashAmount);
			this.CashCancelledTextBox.Text = Conversions.ToString(MyProject.Forms.FreeFoodsOffer.CancelCashAmount);
			this.CalculateTotal();
		}

		// Token: 0x0600029B RID: 667 RVA: 0x0001AC54 File Offset: 0x00018E54
		public void ReadSelectedDaySaleData()
		{
			string text = MyProject.Forms.General_Settings.OrderHistoryListBox.SelectedItem.ToString();
			MessageBox.Show(text);
		}

		// Token: 0x0600029C RID: 668 RVA: 0x0001AC84 File Offset: 0x00018E84
		private void CalculateTotal()
		{
			try
			{
				this.TotalDeliveryTextBox.Text = Conversions.ToString(decimal.Add(Conversions.ToDecimal(this.PaidDeliveryTextBox.Text), Conversions.ToDecimal(this.CashDeliveryTextBox.Text)));
				this.TotalTakeawayCollectionTextBox.Text = Conversions.ToString(decimal.Add(Conversions.ToDecimal(this.PaidTakeawayCollectionTextBox.Text), Conversions.ToDecimal(this.CashTakeawayCollectionTextBox.Text)));
				this.TotalDineInTextBox.Text = Conversions.ToString(decimal.Add(Conversions.ToDecimal(this.PaidDineInTextBox.Text), Conversions.ToDecimal(this.CashDineInTextBox.Text)));
				this.TotalCancelledTextBox.Text = Conversions.ToString(decimal.Add(Conversions.ToDecimal(this.PaidCancelledTextBox.Text), Conversions.ToDecimal(this.CashCancelledTextBox.Text)));
				this.NoOfTotalTextBox.Text = Conversions.ToString(checked(Conversions.ToInteger(this.NoOfDeliveryTextBox.Text) + Conversions.ToInteger(this.NoOfTakeawayCollectionTextBox.Text) + Conversions.ToInteger(this.NoOfDineInTextBox.Text)));
				this.PaidTotalTextBox.Text = Conversions.ToString(decimal.Add(decimal.Add(Conversions.ToDecimal(this.PaidDeliveryTextBox.Text), Conversions.ToDecimal(this.PaidTakeawayCollectionTextBox.Text)), Conversions.ToDecimal(this.PaidDineInTextBox.Text)));
				this.CashTotalTextBox.Text = Conversions.ToString(decimal.Add(decimal.Add(Conversions.ToDecimal(this.CashDeliveryTextBox.Text), Conversions.ToDecimal(this.CashTakeawayCollectionTextBox.Text)), Conversions.ToDecimal(this.CashDineInTextBox.Text)));
				this.TotalTotalTextBox.Text = Conversions.ToString(decimal.Add(decimal.Add(Conversions.ToDecimal(this.TotalDeliveryTextBox.Text), Conversions.ToDecimal(this.TotalTakeawayCollectionTextBox.Text)), Conversions.ToDecimal(this.TotalDineInTextBox.Text)));
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600029D RID: 669 RVA: 0x000029EB File Offset: 0x00000BEB
		private void NoOfDeliveryTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x0600029E RID: 670 RVA: 0x000029EB File Offset: 0x00000BEB
		private void NoOfTakeawayCollectionTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x0600029F RID: 671 RVA: 0x000029EB File Offset: 0x00000BEB
		private void NoOfDineInTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x000029EB File Offset: 0x00000BEB
		private void NoOfCancelledTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x000029EB File Offset: 0x00000BEB
		private void PaidDeliveryTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x000029EB File Offset: 0x00000BEB
		private void PaidTakeawayCollectionTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x000029EB File Offset: 0x00000BEB
		private void PaidDineInTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x000029EB File Offset: 0x00000BEB
		private void PaidCancelledTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x000029EB File Offset: 0x00000BEB
		private void CashDeliveryTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A6 RID: 678 RVA: 0x000029EB File Offset: 0x00000BEB
		private void CashTakeawayCollectionTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A7 RID: 679 RVA: 0x000029EB File Offset: 0x00000BEB
		private void CashDineInTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A8 RID: 680 RVA: 0x000029EB File Offset: 0x00000BEB
		private void CashCancelledTextBox_TextChanged(object sender, EventArgs e)
		{
			this.CalculateTotal();
		}

		// Token: 0x060002A9 RID: 681 RVA: 0x000029F6 File Offset: 0x00000BF6
		private void Button3_Click(object sender, EventArgs e)
		{
			this.DeleteSelectedDayData();
			this.ClearAllVariables();
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x060002AA RID: 682 RVA: 0x0001AEC0 File Offset: 0x000190C0
		private void Button1_Click(object sender, EventArgs e)
		{
			MyProject.Forms.FreeFoodsOffer.NumberOfCancelledOrders = Conversions.ToInteger(this.NoOfCancelledTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.CancelAmount = Conversions.ToDecimal(this.TotalCancelledTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.CancelCashAmount = Conversions.ToDecimal(this.CashCancelledTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.CancelPaidAmount = Conversions.ToDecimal(this.PaidCancelledTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.NumberOfDeliveryOrders = Conversions.ToInteger(this.NoOfDeliveryTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.DeliveryAmount = Conversions.ToDecimal(this.TotalDeliveryTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.DeliveryPaidAmount = Conversions.ToDecimal(this.PaidDeliveryTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.DeliveryNotPaidAmount = Conversions.ToDecimal(this.CashDeliveryTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.NumberOfTakeCollOrders = Conversions.ToInteger(this.NoOfTakeawayCollectionTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.TakeCollCashAmount = Conversions.ToDecimal(this.CashTakeawayCollectionTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.TakeCollPaidAmount = Conversions.ToDecimal(this.PaidTakeawayCollectionTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.TakeCollAmount = Conversions.ToDecimal(this.TotalTakeawayCollectionTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.NumberOfDineInOrders = Conversions.ToInteger(this.NoOfDineInTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.DineInAmount = Conversions.ToDecimal(this.TotalDineInTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.DineInCashAmount = Conversions.ToDecimal(this.CashDineInTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.DineInPaidAmount = Conversions.ToDecimal(this.PaidDineInTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.NumberOfTotalOrders = Conversions.ToInteger(this.NoOfTotalTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.TotalAmount = Conversions.ToDecimal(this.TotalTotalTextBox.Text);
			MyProject.Forms.FreeFoodsOffer.PrintDocument1.Print();
			this.DeleteSelectedDayData();
			this.ClearAllVariables();
			MyProject.Forms.Form_Glass.Close();
			this.Close();
		}

		// Token: 0x060002AB RID: 683 RVA: 0x0001B138 File Offset: 0x00019338
		private void DeleteSelectedDayData()
		{
			foreach (string path in Directory.GetFiles(this.SelectedFolderDay))
			{
				File.Delete(path);
			}
			File.SetAttributes(this.SelectedFolderDay, FileAttributes.Normal);
			Directory.Delete(this.SelectedFolderDay);
			MyProject.Forms.General_Settings.OrderHistoryListBox.Items.Clear();
			MyProject.Forms.General_Settings.ReadOrderHistory();
			MyProject.Forms.General_Settings.OrderHistoryListBox.Refresh();
		}

		// Token: 0x060002AC RID: 684 RVA: 0x0001B1D0 File Offset: 0x000193D0
		private void ClearAllVariables()
		{
			MyProject.Forms.FreeFoodsOffer.NumberOfDeliveryOrders = 0;
			MyProject.Forms.FreeFoodsOffer.NumberOfTakeCollOrders = 0;
			MyProject.Forms.FreeFoodsOffer.NumberOfDineInOrders = 0;
			MyProject.Forms.FreeFoodsOffer.NumberOfCancelledOrders = 0;
			MyProject.Forms.FreeFoodsOffer.NumberOfTotalOrders = 0;
			MyProject.Forms.FreeFoodsOffer.DeliveryPaidAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.TakeCollPaidAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.DineInPaidAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.CancelPaidAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.DeliveryNotPaidAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.TakeCollCashAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.DineInCashAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.CancelCashAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.DeliveryAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.TakeCollAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.DineInAmount = 0m;
			MyProject.Forms.FreeFoodsOffer.CancelAmount = 0m;
		}

		// Token: 0x04000113 RID: 275
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000114 RID: 276
		private IContainer components;

		// Token: 0x04000115 RID: 277
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000116 RID: 278
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x04000117 RID: 279
		[AccessedThroughProperty("Label11")]
		private Label _Label11;

		// Token: 0x04000118 RID: 280
		[AccessedThroughProperty("Label12")]
		private Label _Label12;

		// Token: 0x04000119 RID: 281
		[AccessedThroughProperty("Label13")]
		private Label _Label13;

		// Token: 0x0400011A RID: 282
		[AccessedThroughProperty("Label14")]
		private Label _Label14;

		// Token: 0x0400011B RID: 283
		[AccessedThroughProperty("Label15")]
		private Label _Label15;

		// Token: 0x0400011C RID: 284
		[AccessedThroughProperty("NoOfCancelledTextBox")]
		private TextBox _NoOfCancelledTextBox;

		// Token: 0x0400011D RID: 285
		[AccessedThroughProperty("PaidCancelledTextBox")]
		private TextBox _PaidCancelledTextBox;

		// Token: 0x0400011E RID: 286
		[AccessedThroughProperty("CashCancelledTextBox")]
		private TextBox _CashCancelledTextBox;

		// Token: 0x0400011F RID: 287
		[AccessedThroughProperty("TotalCancelledTextBox")]
		private TextBox _TotalCancelledTextBox;

		// Token: 0x04000120 RID: 288
		[AccessedThroughProperty("TotalDeliveryTextBox")]
		private TextBox _TotalDeliveryTextBox;

		// Token: 0x04000121 RID: 289
		[AccessedThroughProperty("CashDeliveryTextBox")]
		private TextBox _CashDeliveryTextBox;

		// Token: 0x04000122 RID: 290
		[AccessedThroughProperty("PaidDeliveryTextBox")]
		private TextBox _PaidDeliveryTextBox;

		// Token: 0x04000123 RID: 291
		[AccessedThroughProperty("NoOfDeliveryTextBox")]
		private TextBox _NoOfDeliveryTextBox;

		// Token: 0x04000124 RID: 292
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000125 RID: 293
		[AccessedThroughProperty("TotalTakeawayCollectionTextBox")]
		private TextBox _TotalTakeawayCollectionTextBox;

		// Token: 0x04000126 RID: 294
		[AccessedThroughProperty("CashTakeawayCollectionTextBox")]
		private TextBox _CashTakeawayCollectionTextBox;

		// Token: 0x04000127 RID: 295
		[AccessedThroughProperty("PaidTakeawayCollectionTextBox")]
		private TextBox _PaidTakeawayCollectionTextBox;

		// Token: 0x04000128 RID: 296
		[AccessedThroughProperty("NoOfTakeawayCollectionTextBox")]
		private TextBox _NoOfTakeawayCollectionTextBox;

		// Token: 0x04000129 RID: 297
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x0400012A RID: 298
		[AccessedThroughProperty("TotalDineInTextBox")]
		private TextBox _TotalDineInTextBox;

		// Token: 0x0400012B RID: 299
		[AccessedThroughProperty("CashDineInTextBox")]
		private TextBox _CashDineInTextBox;

		// Token: 0x0400012C RID: 300
		[AccessedThroughProperty("PaidDineInTextBox")]
		private TextBox _PaidDineInTextBox;

		// Token: 0x0400012D RID: 301
		[AccessedThroughProperty("NoOfDineInTextBox")]
		private TextBox _NoOfDineInTextBox;

		// Token: 0x0400012E RID: 302
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x0400012F RID: 303
		[AccessedThroughProperty("TotalTotalTextBox")]
		private TextBox _TotalTotalTextBox;

		// Token: 0x04000130 RID: 304
		[AccessedThroughProperty("CashTotalTextBox")]
		private TextBox _CashTotalTextBox;

		// Token: 0x04000131 RID: 305
		[AccessedThroughProperty("NoOfTotalTextBox")]
		private TextBox _NoOfTotalTextBox;

		// Token: 0x04000132 RID: 306
		[AccessedThroughProperty("Label4")]
		private Label _Label4;

		// Token: 0x04000133 RID: 307
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x04000134 RID: 308
		[AccessedThroughProperty("PaidTotalTextBox")]
		private TextBox _PaidTotalTextBox;

		// Token: 0x04000135 RID: 309
		[AccessedThroughProperty("DateLabel")]
		private Label _DateLabel;

		// Token: 0x04000136 RID: 310
		private string SelectedFolderDay;

		// Token: 0x04000137 RID: 311
		private string SelectedFolderDayDate;
	}
}
