using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200002A RID: 42
	[StandardModule]
	internal sealed class Online
	{
		// Token: 0x060005E1 RID: 1505 RVA: 0x00037120 File Offset: 0x00035320
		public static void AddActivityOnServer()
		{
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
			bool flag = Operators.CompareString(MySettingsProperty.Settings.BusinessName, "Softeware Demo Version", false) != 0;
			if (flag)
			{
				Online.postdata(Online.SoftwareDomain, "add_shop_activity_on_server.php", "", MySettingsProperty.Settings.ServerFolderName, "", "", "", "");
			}
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x00037198 File Offset: 0x00035398
		public static void AutoMenuDownload()
		{
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
			string left = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "partners/" + MySettingsProperty.Settings.ServerFolderName + "/menu/_auto_download_menu.txt", "", "", "", "", "", ""));
			bool flag = Operators.CompareString(left, "y", false) == 0;
			if (flag)
			{
				MyProject.Forms.General_Settings.DownloadMenu();
			}
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
		}

		// Token: 0x060005E3 RID: 1507 RVA: 0x00037228 File Offset: 0x00035428
		public static object checkinternet()
		{
			string result = "";
			bool isAvailable = MyProject.Computer.Network.IsAvailable;
			if (isAvailable)
			{
				MyProject.Forms.Index.WifiON.Show();
				MyProject.Forms.Index.WifiOnOff.Show();
				result = "HOHA_PING_IS_OK";
				M_Settings.SoftwareOnlineStatus = "online";
			}
			else
			{
				MyProject.Forms.Index.WifiON.Hide();
				MyProject.Forms.Index.WifiOnOff.Hide();
				M_Settings.SoftwareOnlineStatus = "offline";
			}
			return result;
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x000372C8 File Offset: 0x000354C8
		public static void CheckWebsiteConnection()
		{
			string left = "";
			try
			{
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
				left = Conversions.ToString(Online.postdata(M_Settings.ShopWebsite, "/order-me/VBnetConnectionTest.php", "", "", "", "", "", ""));
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
			}
			catch (Exception ex)
			{
			}
			bool flag = Operators.CompareString(left, "WebsiteOK", false) == 0;
			if (flag)
			{
				MyProject.Forms.Index.WebON.Show();
				MyProject.Forms.Index.WebOnOff.Show();
			}
			else
			{
				MyProject.Forms.Index.WebON.Hide();
				MyProject.Forms.Index.WebOnOff.Hide();
			}
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x000373B4 File Offset: 0x000355B4
		public static object postdata(string domain, string folder_file, string url_action, string v1, string v2, string v3, string v4, string v5)
		{
			object result;
			try
			{
				bool flag = Operators.CompareString(MySettingsProperty.Settings.SoftwareType, "ONLINE MODE", false) == 0 | Operators.CompareString(M_Settings.GetNecessaryDataFromServerInOfflineMode, "yes", false) == 0;
				if (flag)
				{
					WebRequest webRequest = WebRequest.Create(string.Concat(new string[]
					{
						"http://",
						domain,
						"/",
						folder_file,
						"?action=",
						url_action,
						"&v1=",
						v1,
						"&v2=",
						v2,
						"&v3=",
						v3,
						"&v4=",
						v4,
						"&v5=",
						v5
					}));
					WebResponse response = webRequest.GetResponse();
					StreamReader streamReader = new StreamReader(response.GetResponseStream());
					string text = streamReader.ReadToEnd();
					result = text;
				}
				else
				{
					string text2 = "";
					result = text2;
				}
			}
			catch (Exception ex)
			{
				string text3 = "";
				result = text3;
			}
			return result;
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x0003750C File Offset: 0x0003570C
		public static void GetSoftwareCompanyDetailsFromServer()
		{
			try
			{
				bool flag = Operators.ConditionalCompareObjectEqual(Online.checkinternet(), "HOHA_PING_IS_OK", false);
				if (flag)
				{
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
					MySettingsProperty.Settings.SoftwareCompany = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "_All_Computers_Settings/Software_Company_Details.php", "SoftwareCompany", "", "", "", "", ""));
					MySettingsProperty.Settings.SoftwareAddress = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "_All_Computers_Settings/Software_Company_Details.php", "SoftwareAddress", "", "", "", "", ""));
					MySettingsProperty.Settings.SoftwareTel = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "_All_Computers_Settings/Software_Company_Details.php", "SoftwareTel", "", "", "", "", ""));
					MySettingsProperty.Settings.LockSoftwareNumber = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "_All_Computers_Settings/All_Computers_Software_Settings.php", "LockSoftwareNumber", "", "", "", "", ""));
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
					MySettingsProperty.Settings.Save();
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x00037678 File Offset: 0x00035878
		public static void UploadFile(object UploadFilePath, object UploadFileName, object SaveFilePath)
		{
			try
			{
				NewLateBinding.LateCall(new WebClient
				{
					Credentials = new NetworkCredential(MySettingsProperty.Settings.FTPusername, MySettingsProperty.Settings.FTPpassword)
				}, null, "UploadFile", new object[]
				{
					Operators.AddObject(Operators.AddObject(Operators.AddObject("ftp://" + Online.SoftwareDomain + "/", SaveFilePath), "/"), UploadFileName),
					Operators.AddObject(Operators.AddObject(UploadFilePath, "\\"), UploadFileName)
				}, null, null, null, true);
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x00037734 File Offset: 0x00035934
		public static void DownloadFile(object DownloadFilePath, object DownloadFileName, object SaveFilePath)
		{
			try
			{
				NewLateBinding.LateCall(new WebClient
				{
					Credentials = new NetworkCredential(MySettingsProperty.Settings.FTPusername, MySettingsProperty.Settings.FTPpassword)
				}, null, "DownloadFile", new object[]
				{
					Operators.AddObject(Operators.AddObject(Operators.AddObject("http://" + Online.SoftwareDomain + "/", DownloadFilePath), "/"), DownloadFileName),
					Operators.AddObject(Operators.AddObject(SaveFilePath, "\\"), DownloadFileName)
				}, null, null, null, true);
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x000377F0 File Offset: 0x000359F0
		public static void DownloadManyFiles(object NumberOfFiles, object Files, object HostFolder, object SaveFolder)
		{
			checked
			{
				try
				{
					bool flag = Operators.ConditionalCompareObjectEqual(NumberOfFiles, 0, false);
					int num;
					if (flag)
					{
						num = 0;
					}
					flag = Operators.ConditionalCompareObjectGreater(NumberOfFiles, 0, false);
					if (flag)
					{
						num = Conversions.ToInteger(NewLateBinding.LateGet(null, typeof(Math), "Floor", new object[]
						{
							Operators.DivideObject(100, NumberOfFiles)
						}, null, null, null));
					}
					try
					{
						foreach (object obj in ((IEnumerable)Files))
						{
							object objectValue = RuntimeHelpers.GetObjectValue(obj);
							Online.DownloadFile(RuntimeHelpers.GetObjectValue(HostFolder), RuntimeHelpers.GetObjectValue(objectValue), RuntimeHelpers.GetObjectValue(SaveFolder));
							flag = (MyProject.Forms.General_Settings.UploadDownloadProgressBar.Value + num > 100);
							if (flag)
							{
								MyProject.Forms.General_Settings.UploadDownloadProgressBar.Value = 100;
							}
							else
							{
								ProgressBar uploadDownloadProgressBar = MyProject.Forms.General_Settings.UploadDownloadProgressBar;
								uploadDownloadProgressBar.Value += num;
							}
						}
					}
					finally
					{
						IEnumerator enumerator;
						flag = (enumerator is IDisposable);
						if (flag)
						{
							(enumerator as IDisposable).Dispose();
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x00037970 File Offset: 0x00035B70
		public static void AddCustomerServer(object c)
		{
			try
			{
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
				Online.postdata(Online.SoftwareDomain, "customer_add_update.php", "add_customer", Conversions.ToString(c), MySettingsProperty.Settings.ServerFolderName, "", "", "");
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x000379EC File Offset: 0x00035BEC
		public static void UpdateCustomerServer(object c, object indx)
		{
			try
			{
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
				Online.postdata(Online.SoftwareDomain, "customer_add_update.php", "update_customer", Conversions.ToString(c), MySettingsProperty.Settings.ServerFolderName, Conversions.ToString(indx), "", "");
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005EC RID: 1516 RVA: 0x00037A68 File Offset: 0x00035C68
		public static object CASHandCARRY()
		{
			string text = "";
			try
			{
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
				text = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "/cash_and_carry/index.php", "", MySettingsProperty.Settings.BusinessName, MySettingsProperty.Settings.BusinessTel, MySettingsProperty.Settings.BusinessAddress, MySettingsProperty.Settings.BusinessCity, MySettingsProperty.Settings.BusinessPostcode));
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
			}
			catch (Exception ex)
			{
			}
			bool flag = Operators.CompareString(text, "NoCash&Carry", false) == 0;
			if (flag)
			{
				MyProject.Forms.Index.CashCarryBTN.Visible = false;
			}
			flag = (Operators.CompareString(text, "NoCash&Carry", false) != 0);
			if (flag)
			{
				MyProject.Forms.Index.CashCarryBTN.Visible = true;
			}
			return text;
		}

		// Token: 0x060005ED RID: 1517 RVA: 0x00037B5C File Offset: 0x00035D5C
		public static void CheckIfSoftwareNewVersionIsAvailable()
		{
			try
			{
				WebRequest webRequest = WebRequest.Create("http://" + MySettingsProperty.Settings.SoftwareWebsite + "/_software_update_files/list_of_update_files.php");
				WebResponse response = webRequest.GetResponse();
				StreamReader streamReader = new StreamReader(response.GetResponseStream());
				Array instance = streamReader.ReadToEnd().Split(new char[]
				{
					'|'
				});
				string left = Strings.Trim(File.ReadAllText("version.dat"));
				string right = Strings.Trim(Conversions.ToString(NewLateBinding.LateIndexGet(instance, new object[]
				{
					0
				}, null)));
				bool flag = Operators.CompareString(left, right, false) < 0;
				if (flag)
				{
					Online.DownloadFile("_software_update_files", "update.exe", MyProject.Application.Info.DirectoryPath);
					MessageBox.Show("Software new version is available." + Environment.NewLine + "Login to Control Panel > Advanced > Update Software.");
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060005EE RID: 1518 RVA: 0x00037C64 File Offset: 0x00035E64
		public static void CheckBusinessInfoWithServer()
		{
			try
			{
				string left = File.ReadAllText("data\\admin\\BusinessInfo.txt");
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
				M_Settings.BusinessDetailsOnServer = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "partners/" + MySettingsProperty.Settings.ServerFolderName + "/data/admin/BusinessInfo.txt", "", "", "", "", "", ""));
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
				bool flag = !M_Settings.BusinessDetailsOnServer.Contains("LockSoftware") & Operators.CompareString(MySettingsProperty.Settings.LockSoftware, "yes", false) == 0;
				if (flag)
				{
					MySettingsProperty.Settings.LockSoftware = null;
				}
				flag = M_Settings.BusinessDetailsOnServer.Contains("LockSoftware");
				if (flag)
				{
					MySettingsProperty.Settings.LockSoftware = "yes";
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
					Online.postdata(Online.SoftwareDomain, "admin/partner_lock_software.php", "software_locked_just_now", MySettingsProperty.Settings.ServerFolderName, "", "", "", "");
					M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
				}
				flag = (Operators.CompareString(M_Settings.BusinessDetailsOnServer, "", false) == 0 & !MyProject.Forms.Index.CheckBusinessDetailsOnServerTimer.Enabled);
				if (flag)
				{
					MyProject.Forms.Index.CheckBusinessDetailsOnServerTimer.Start();
					flag = (Operators.CompareString(MySettingsProperty.Settings.BusinessName, "", false) != 0);
					if (flag)
					{
						StreamWriter streamWriter = new StreamWriter("data/admin/BusinessInfo.txt");
						streamWriter.Write(string.Concat(new string[]
						{
							MySettingsProperty.Settings.BusinessName,
							"|",
							MySettingsProperty.Settings.BusinessTel,
							"|",
							MySettingsProperty.Settings.BusinessAddress,
							"|",
							MySettingsProperty.Settings.BusinessCity,
							"|",
							MySettingsProperty.Settings.BusinessPostcode,
							"|",
							MySettingsProperty.Settings.BusinessTel,
							"|",
							MySettingsProperty.Settings.WebsiteURL,
							"|",
							MySettingsProperty.Settings.SoftwareExpiryDate,
							"|",
							MySettingsProperty.Settings.SoftwareExpiryDate
						}));
						streamWriter.Close();
					}
				}
				else
				{
					flag = (Operators.CompareString(M_Settings.BusinessDetailsOnServer, "", false) != 0 & MyProject.Forms.Index.CheckBusinessDetailsOnServerTimer.Enabled);
					if (flag)
					{
						MyProject.Forms.Index.CheckBusinessDetailsOnServerTimer.Stop();
					}
					flag = (Operators.CompareString(left, M_Settings.BusinessDetailsOnServer, false) != 0 & Operators.CompareString(M_Settings.BusinessDetailsOnServer, "", false) != 0);
					if (flag)
					{
						File.WriteAllText("data\\admin\\BusinessInfo.txt", M_Settings.BusinessDetailsOnServer);
						string[] array = File.ReadAllText("data\\admin\\BusinessInfo.txt").Split(new char[]
						{
							'|'
						});
						flag = (array[7].Length == 8);
						if (flag)
						{
							MySettingsProperty.Settings.SoftwareExpiryDate = array[7];
							MySettingsProperty.Settings.LicenseNo = "";
							MySettingsProperty.Settings.Save();
						}
						flag = (array[7].Length > 8);
						if (flag)
						{
							MySettingsProperty.Settings.LicenseNo = array[7];
							MySettingsProperty.Settings.SoftwareExpiryDate = "";
							MySettingsProperty.Settings.Save();
						}
						flag = (array[8].Length == 8);
						if (flag)
						{
							MySettingsProperty.Settings.SoftwareOnlineExpiryDate = array[8];
							MySettingsProperty.Settings.LicenseOnlineNo = "";
							MySettingsProperty.Settings.Save();
						}
						flag = (array[8].Length > 8);
						if (flag)
						{
							MySettingsProperty.Settings.LicenseOnlineNo = array[8];
							MySettingsProperty.Settings.SoftwareOnlineExpiryDate = "";
							MySettingsProperty.Settings.Save();
						}
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0400027A RID: 634
		public static string SoftwareDomain = MySettingsProperty.Settings.SoftwareWebsite;
	}
}
