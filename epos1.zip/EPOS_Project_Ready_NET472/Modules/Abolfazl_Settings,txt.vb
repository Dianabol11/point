using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200000A RID: 10
	[DesignerGenerated]
	public class Abolfazl_Settings : Form
	{
		// Token: 0x06000061 RID: 97 RVA: 0x000055E8 File Offset: 0x000037E8
		public Abolfazl_Settings()
		{
			List<WeakReference> _ENCList = Abolfazl_Settings.__ENCList;
			lock (_ENCList)
			{
				Abolfazl_Settings.__ENCList.Add(new WeakReference(this));
			}
			this.SoftwareType = "n";
			this.PostCodeFinder = "n";
			this.CallerId = "n";
			this.InitializeComponent();
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00005660 File Offset: 0x00003860
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000063 RID: 99 RVA: 0x000056B0 File Offset: 0x000038B0
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.OnlineModeCheckBox = new CheckBox();
			this.Label7 = new Label();
			this.CallerIdComboBox = new ComboBox();
			this.PostcodeFinderCheckBox = new CheckBox();
			this.Button1 = new Button();
			this.Button2 = new Button();
			this.Label1 = new Label();
			this.WhiteLabelTextBox = new TextBox();
			this.SuspendLayout();
			this.OnlineModeCheckBox.AutoSize = true;
			this.OnlineModeCheckBox.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control onlineModeCheckBox = this.OnlineModeCheckBox;
			Point location = new Point(21, 14);
			onlineModeCheckBox.Location = location;
			this.OnlineModeCheckBox.Name = "OnlineModeCheckBox";
			Control onlineModeCheckBox2 = this.OnlineModeCheckBox;
			Size size = new Size(123, 23);
			onlineModeCheckBox2.Size = size;
			this.OnlineModeCheckBox.TabIndex = 12;
			this.OnlineModeCheckBox.Text = "Online Mode";
			this.OnlineModeCheckBox.UseVisualStyleBackColor = true;
			this.Label7.AutoSize = true;
			this.Label7.Font = new Font("Arial", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label = this.Label7;
			location = new Point(16, 103);
			label.Location = location;
			this.Label7.Name = "Label7";
			Control label2 = this.Label7;
			size = new Size(69, 18);
			label2.Size = size;
			this.Label7.TabIndex = 11;
			this.Label7.Text = "Caller ID";
			this.CallerIdComboBox.FormattingEnabled = true;
			this.CallerIdComboBox.Items.AddRange(new object[]
			{
				"",
				"ARTECH AD102"
			});
			Control callerIdComboBox = this.CallerIdComboBox;
			location = new Point(95, 100);
			callerIdComboBox.Location = location;
			this.CallerIdComboBox.Name = "CallerIdComboBox";
			Control callerIdComboBox2 = this.CallerIdComboBox;
			size = new Size(166, 21);
			callerIdComboBox2.Size = size;
			this.CallerIdComboBox.TabIndex = 10;
			this.PostcodeFinderCheckBox.AutoSize = true;
			this.PostcodeFinderCheckBox.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control postcodeFinderCheckBox = this.PostcodeFinderCheckBox;
			location = new Point(21, 56);
			postcodeFinderCheckBox.Location = location;
			this.PostcodeFinderCheckBox.Name = "PostcodeFinderCheckBox";
			Control postcodeFinderCheckBox2 = this.PostcodeFinderCheckBox;
			size = new Size(154, 23);
			postcodeFinderCheckBox2.Size = size;
			this.PostcodeFinderCheckBox.TabIndex = 13;
			this.PostcodeFinderCheckBox.Text = "Postcode Finder";
			this.PostcodeFinderCheckBox.UseVisualStyleBackColor = true;
			this.Button1.Anchor = AnchorStyles.Bottom;
			this.Button1.BackColor = Color.FromArgb(0, 192, 0);
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(164, 191);
			button.Location = location;
			this.Button1.Name = "Button1";
			Control button2 = this.Button1;
			size = new Size(105, 39);
			button2.Size = size;
			this.Button1.TabIndex = 14;
			this.Button1.Text = "Finish";
			this.Button1.UseVisualStyleBackColor = false;
			this.Button2.Anchor = AnchorStyles.Bottom;
			this.Button2.BackColor = Color.Red;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button2.ForeColor = Color.White;
			Control button3 = this.Button2;
			location = new Point(12, 191);
			button3.Location = location;
			this.Button2.Name = "Button2";
			Control button4 = this.Button2;
			size = new Size(105, 39);
			button4.Size = size;
			this.Button2.TabIndex = 15;
			this.Button2.Text = "Exit";
			this.Button2.UseVisualStyleBackColor = false;
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 11.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label3 = this.Label1;
			location = new Point(16, 143);
			label3.Location = location;
			this.Label1.Name = "Label1";
			Control label4 = this.Label1;
			size = new Size(91, 18);
			label4.Size = size;
			this.Label1.TabIndex = 16;
			this.Label1.Text = "White Label";
			Control whiteLabelTextBox = this.WhiteLabelTextBox;
			location = new Point(113, 143);
			whiteLabelTextBox.Location = location;
			this.WhiteLabelTextBox.Name = "WhiteLabelTextBox";
			Control whiteLabelTextBox2 = this.WhiteLabelTextBox;
			size = new Size(148, 20);
			whiteLabelTextBox2.Size = size;
			this.WhiteLabelTextBox.TabIndex = 17;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(281, 242);
			this.ClientSize = size;
			this.Controls.Add(this.WhiteLabelTextBox);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.Button2);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.PostcodeFinderCheckBox);
			this.Controls.Add(this.OnlineModeCheckBox);
			this.Controls.Add(this.Label7);
			this.Controls.Add(this.CallerIdComboBox);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "Abolfazl_Settings";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Abolfazl_Settings";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000064 RID: 100 RVA: 0x00005D0C File Offset: 0x00003F0C
		// (set) Token: 0x06000065 RID: 101 RVA: 0x00005D24 File Offset: 0x00003F24
		internal virtual CheckBox OnlineModeCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OnlineModeCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.OnlineModeCheckBox_CheckedChanged);
				bool flag = this._OnlineModeCheckBox != null;
				if (flag)
				{
					this._OnlineModeCheckBox.CheckedChanged -= value2;
				}
				this._OnlineModeCheckBox = value;
				flag = (this._OnlineModeCheckBox != null);
				if (flag)
				{
					this._OnlineModeCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000066 RID: 102 RVA: 0x00005D84 File Offset: 0x00003F84
		// (set) Token: 0x06000067 RID: 103 RVA: 0x000020E9 File Offset: 0x000002E9
		internal virtual Label Label7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label7 = value;
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000068 RID: 104 RVA: 0x00005D9C File Offset: 0x00003F9C
		// (set) Token: 0x06000069 RID: 105 RVA: 0x00005DB4 File Offset: 0x00003FB4
		internal virtual ComboBox CallerIdComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CallerIdComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CallerIdComboBox_SelectedIndexChanged);
				bool flag = this._CallerIdComboBox != null;
				if (flag)
				{
					this._CallerIdComboBox.SelectedIndexChanged -= value2;
				}
				this._CallerIdComboBox = value;
				flag = (this._CallerIdComboBox != null);
				if (flag)
				{
					this._CallerIdComboBox.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x0600006A RID: 106 RVA: 0x00005E14 File Offset: 0x00004014
		// (set) Token: 0x0600006B RID: 107 RVA: 0x00005E2C File Offset: 0x0000402C
		internal virtual CheckBox PostcodeFinderCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PostcodeFinderCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CheckBox1_CheckedChanged);
				bool flag = this._PostcodeFinderCheckBox != null;
				if (flag)
				{
					this._PostcodeFinderCheckBox.CheckedChanged -= value2;
				}
				this._PostcodeFinderCheckBox = value;
				flag = (this._PostcodeFinderCheckBox != null);
				if (flag)
				{
					this._PostcodeFinderCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x0600006C RID: 108 RVA: 0x00005E8C File Offset: 0x0000408C
		// (set) Token: 0x0600006D RID: 109 RVA: 0x00005EA4 File Offset: 0x000040A4
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x0600006E RID: 110 RVA: 0x00005F04 File Offset: 0x00004104
		// (set) Token: 0x0600006F RID: 111 RVA: 0x00005F1C File Offset: 0x0000411C
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x06000070 RID: 112 RVA: 0x00005F7C File Offset: 0x0000417C
		// (set) Token: 0x06000071 RID: 113 RVA: 0x000020F3 File Offset: 0x000002F3
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000072 RID: 114 RVA: 0x00005F94 File Offset: 0x00004194
		// (set) Token: 0x06000073 RID: 115 RVA: 0x000020FD File Offset: 0x000002FD
		internal virtual TextBox WhiteLabelTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._WhiteLabelTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._WhiteLabelTextBox = value;
			}
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00005FAC File Offset: 0x000041AC
		private void OnlineModeCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool @checked = this.OnlineModeCheckBox.Checked;
			if (@checked)
			{
				this.SoftwareType = "y";
			}
			else
			{
				this.SoftwareType = "n";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00005FF0 File Offset: 0x000041F0
		private void CheckBox1_CheckedChanged(object sender, EventArgs e)
		{
			bool @checked = this.PostcodeFinderCheckBox.Checked;
			if (@checked)
			{
				this.PostCodeFinder = "y";
			}
			else
			{
				this.PostCodeFinder = "n";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00006034 File Offset: 0x00004234
		private void CallerIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool flag = Operators.ConditionalCompareObjectEqual(this.CallerIdComboBox.SelectedItem, "", false);
			if (flag)
			{
				this.CallerId = "n";
			}
			flag = Operators.ConditionalCompareObjectEqual(this.CallerIdComboBox.SelectedItem, "ARTECH AD102", false);
			if (flag)
			{
				this.CallerId = "ARTECH AD102";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000077 RID: 119 RVA: 0x0000609C File Offset: 0x0000429C
		private void Button1_Click(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.WhiteLable = this.WhiteLabelTextBox.Text;
			MySettingsProperty.Settings.Save();
			FileSystem.Rename("abolfazl_settings.txt", "settings.txt");
			StreamWriter streamWriter = new StreamWriter("settings.txt");
			streamWriter.Write(string.Concat(new string[]
			{
				this.SoftwareType,
				Environment.NewLine,
				this.PostCodeFinder,
				Environment.NewLine,
				this.CallerId
			}));
			streamWriter.Close();
			Application.Exit();
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00002107 File Offset: 0x00000307
		private void Button2_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x04000024 RID: 36
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000025 RID: 37
		private IContainer components;

		// Token: 0x04000026 RID: 38
		[AccessedThroughProperty("OnlineModeCheckBox")]
		private CheckBox _OnlineModeCheckBox;

		// Token: 0x04000027 RID: 39
		[AccessedThroughProperty("Label7")]
		private Label _Label7;

		// Token: 0x04000028 RID: 40
		[AccessedThroughProperty("CallerIdComboBox")]
		private ComboBox _CallerIdComboBox;

		// Token: 0x04000029 RID: 41
		[AccessedThroughProperty("PostcodeFinderCheckBox")]
		private CheckBox _PostcodeFinderCheckBox;

		// Token: 0x0400002A RID: 42
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x0400002B RID: 43
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x0400002C RID: 44
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x0400002D RID: 45
		[AccessedThroughProperty("WhiteLabelTextBox")]
		private TextBox _WhiteLabelTextBox;

		// Token: 0x0400002E RID: 46
		private string SoftwareType;

		// Token: 0x0400002F RID: 47
		private string PostCodeFinder;

		// Token: 0x04000030 RID: 48
		private string CallerId;
	}
}
