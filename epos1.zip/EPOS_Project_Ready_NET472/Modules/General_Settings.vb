using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.FileIO;
using POS.My;

namespace POS
{
	// Token: 0x0200000E RID: 14
	[DesignerGenerated]
	public class General_Settings : Form
	{
		// Token: 0x060000B7 RID: 183 RVA: 0x00007748 File Offset: 0x00005948
		[DebuggerNonUserCode]
		public General_Settings()
		{
			base.Load += this.General_Settings_Load;
			List<WeakReference> _ENCList = General_Settings.__ENCList;
			lock (_ENCList)
			{
				General_Settings.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x000077B4 File Offset: 0x000059B4
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00007804 File Offset: 0x00005A04
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.ExitBTN = new Button();
			this.AdvancedTP = new TabControl();
			this.GeneralTB = new TabPage();
			this.SafeModeCheckBox = new CheckBox();
			this.Categories2RowsCheckBox = new CheckBox();
			this.TableManagementCheckBox = new CheckBox();
			this.SupplierCheckBox = new CheckBox();
			this.ShopOwnerGroupBox = new GroupBox();
			this.Label20 = new Label();
			this.Label21 = new Label();
			this.BusinessEmailTextBox = new TextBox();
			this.ShopOwnerMobileTextBox = new TextBox();
			this.Button4 = new Button();
			this.PostcodeFinderCheckBox1 = new CheckBox();
			this.OrderHistoryGroupBox = new GroupBox();
			this.OrderHistorySummaryPrintBTN = new Button();
			this.OrderHistoryDeleteBTN = new Button();
			this.OrderHistoryFullPrintBTN = new Button();
			this.OrderHistoryListBox = new ListBox();
			this.DriversAccessCheckBox = new CheckBox();
			this.ActiveEditOrdersCheckBox = new CheckBox();
			this.RemoveItemsInShoppingCartCheckBox = new CheckBox();
			this.FlashDriverGroupBox = new GroupBox();
			this.USBBackupBTN = new Button();
			this.USBRestoreBTN = new Button();
			this.DownloadBackupGroupBox = new GroupBox();
			this.AllPostCodesTextBox = new TextBox();
			this.DownloadBackupCustomersRB = new RadioButton();
			this.DownloadBackupMenuRB = new RadioButton();
			this.DownloadPostcodesRB = new RadioButton();
			this.DownloadBackupBTN = new Button();
			this.NewPasswordGroupBox = new GroupBox();
			this.NewPassUserComboBox = new ComboBox();
			this.Label12 = new Label();
			this.Label11 = new Label();
			this.Label10 = new Label();
			this.NewPassConfirmfTextBox = new TextBox();
			this.NewPassTextBox = new TextBox();
			this.NewPasswordSaveBTN = new Button();
			this.BusinessInfoGroupBox = new GroupBox();
			this.Label6 = new Label();
			this.BPhoneTextBox = new TextBox();
			this.BNameTextBox = new TextBox();
			this.Label5 = new Label();
			this.BPostcodeTextBox = new TextBox();
			this.Label2 = new Label();
			this.Label1 = new Label();
			this.BCityTextBox = new TextBox();
			this.Label3 = new Label();
			this.Label4 = new Label();
			this.BAddressTextBox = new TextBox();
			this.DriversTB = new TabPage();
			this.KeyboardDriver = new Panel();
			this.GroupBox7 = new GroupBox();
			this.DriversDeleteComboBox = new ComboBox();
			this.Button3 = new Button();
			this.GroupBox6 = new GroupBox();
			this.Label9 = new Label();
			this.Button2 = new Button();
			this.Label8 = new Label();
			this.AddDriverMobileTextBox = new TextBox();
			this.AddDriverNameTextBox = new TextBox();
			this.GroupBox5 = new GroupBox();
			this.DriversListBox = new ListBox();
			this.TabPage1 = new TabPage();
			this.Button11 = new Button();
			this.ExportCustomersTXT = new Button();
			this.ExportCustomersCSV = new Button();
			this.Button10 = new Button();
			this.MenuBTN = new Button();
			this.GroupBox3 = new GroupBox();
			this.Label34 = new Label();
			this.Button9 = new Button();
			this.ReceiptAdvertTB = new TextBox();
			this.GroupBox2 = new GroupBox();
			this.fppc9dc = new TextBox();
			this.fppc8dc = new TextBox();
			this.fppc7dc = new TextBox();
			this.fppc9 = new TextBox();
			this.fppc8 = new TextBox();
			this.fppc7 = new TextBox();
			this.OtherDeliveryChargeTextBox = new TextBox();
			this.Label33 = new Label();
			this.Label32 = new Label();
			this.fppc6dc = new TextBox();
			this.fppc5dc = new TextBox();
			this.fppc4dc = new TextBox();
			this.fppc3dc = new TextBox();
			this.fppc2dc = new TextBox();
			this.fppc1dc = new TextBox();
			this.fppc6 = new TextBox();
			this.fppc5 = new TextBox();
			this.fppc4 = new TextBox();
			this.fppc3 = new TextBox();
			this.fppc2 = new TextBox();
			this.fppc1 = new TextBox();
			this.Button6 = new Button();
			this.DeliveryChargeLBL = new Label();
			this.GroupBox1 = new GroupBox();
			this.Label30 = new Label();
			this.CallerIdComboBox1 = new ComboBox();
			this.AutoCompleteLBL = new Label();
			this.CallerIDLBL = new Label();
			this.AutoCompleteOrderTextBox = new TextBox();
			this.PrinterGroupBox = new GroupBox();
			this.Label31 = new Label();
			this.Label29 = new Label();
			this.Printer2ComboBox = new ComboBox();
			this.Label28 = new Label();
			this.Printer1ComboBox = new ComboBox();
			this.CommentFontSieTextBox = new TextBox();
			this.Label26 = new Label();
			this.Label25 = new Label();
			this.PrintersComboBox = new ComboBox();
			this.Button8 = new Button();
			this.Button7 = new Button();
			this.NumberOfPrintLabel = new Label();
			this.OrderFontSizeTextBox = new TextBox();
			this.NumberOfPrintTextBox = new TextBox();
			this.Label16 = new Label();
			this.Label17 = new Label();
			this.OrderLineSpaceTextBox = new TextBox();
			this.MyPrinterFontType = new ComboBox();
			this.Label24 = new Label();
			this.Label18 = new Label();
			this.FoodLeftAtTextBox = new TextBox();
			this.SecondLinesSpaceTextBox = new TextBox();
			this.Label19 = new Label();
			this.Label22 = new Label();
			this.PriceLeftAtTextBox = new TextBox();
			this.FoodMaxLenTextBox = new TextBox();
			this.Label23 = new Label();
			this.UpdateBTN = new Button();
			this.ResetToFactoryBTM = new Button();
			this.AbolfazlTB = new TabPage();
			this.Button5 = new Button();
			this.PostcodeFinderCheckBox = new CheckBox();
			this.OnlineModeCheckBox = new CheckBox();
			this.Button1 = new Button();
			this.GroupBox8 = new GroupBox();
			this.FTPpingBTN = new Button();
			this.SoftwareDomainTextBox = new TextBox();
			this.Label15 = new Label();
			this.FTPPasswordTextBox = new TextBox();
			this.FTPUsernameTextBox = new TextBox();
			this.Label14 = new Label();
			this.Label13 = new Label();
			this.FTPsaveBTN = new Button();
			this.Label7 = new Label();
			this.CallerIdComboBox = new ComboBox();
			this.SaveExitPanel = new Panel();
			this.UploadDownloadProgressBar = new ProgressBar();
			this.AdminPanel = new Panel();
			this.LoginPanel = new Panel();
			this.KeyboardPanel = new Panel();
			this.GroupBox4 = new GroupBox();
			this.UserNameComboBox = new ComboBox();
			this.CancelBTN = new Button();
			this.PasswordTextBox = new TextBox();
			this.LoginBTN = new Button();
			this.FolderBrowserDialogCustomersExport = new FolderBrowserDialog();
			this.AdvancedTP.SuspendLayout();
			this.GeneralTB.SuspendLayout();
			this.ShopOwnerGroupBox.SuspendLayout();
			this.OrderHistoryGroupBox.SuspendLayout();
			this.FlashDriverGroupBox.SuspendLayout();
			this.DownloadBackupGroupBox.SuspendLayout();
			this.NewPasswordGroupBox.SuspendLayout();
			this.BusinessInfoGroupBox.SuspendLayout();
			this.DriversTB.SuspendLayout();
			this.GroupBox7.SuspendLayout();
			this.GroupBox6.SuspendLayout();
			this.GroupBox5.SuspendLayout();
			this.TabPage1.SuspendLayout();
			this.GroupBox3.SuspendLayout();
			this.GroupBox2.SuspendLayout();
			this.GroupBox1.SuspendLayout();
			this.PrinterGroupBox.SuspendLayout();
			this.AbolfazlTB.SuspendLayout();
			this.GroupBox8.SuspendLayout();
			this.SaveExitPanel.SuspendLayout();
			this.AdminPanel.SuspendLayout();
			this.LoginPanel.SuspendLayout();
			this.GroupBox4.SuspendLayout();
			this.SuspendLayout();
			this.ExitBTN.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right);
			this.ExitBTN.BackColor = Color.Crimson;
			this.ExitBTN.FlatStyle = FlatStyle.Popup;
			this.ExitBTN.Font = new Font("Arial", 15.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.ExitBTN.ForeColor = SystemColors.Window;
			Control exitBTN = this.ExitBTN;
			Point point = new Point(1141, 8);
			exitBTN.Location = point;
			this.ExitBTN.Name = "ExitBTN";
			Control exitBTN2 = this.ExitBTN;
			Size size = new Size(148, 43);
			exitBTN2.Size = size;
			this.ExitBTN.TabIndex = 3;
			this.ExitBTN.Text = "Exit";
			this.ExitBTN.UseVisualStyleBackColor = false;
			this.AdvancedTP.Controls.Add(this.GeneralTB);
			this.AdvancedTP.Controls.Add(this.DriversTB);
			this.AdvancedTP.Controls.Add(this.TabPage1);
			this.AdvancedTP.Controls.Add(this.AbolfazlTB);
			this.AdvancedTP.Dock = DockStyle.Fill;
			this.AdvancedTP.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control advancedTP = this.AdvancedTP;
			point = new Point(0, 0);
			advancedTP.Location = point;
			this.AdvancedTP.Multiline = true;
			this.AdvancedTP.Name = "AdvancedTP";
			TabControl advancedTP2 = this.AdvancedTP;
			point = new Point(15, 15);
			advancedTP2.Padding = point;
			this.AdvancedTP.SelectedIndex = 0;
			Control advancedTP3 = this.AdvancedTP;
			size = new Size(1300, 677);
			advancedTP3.Size = size;
			this.AdvancedTP.TabIndex = 19;
			this.GeneralTB.Controls.Add(this.SafeModeCheckBox);
			this.GeneralTB.Controls.Add(this.Categories2RowsCheckBox);
			this.GeneralTB.Controls.Add(this.TableManagementCheckBox);
			this.GeneralTB.Controls.Add(this.SupplierCheckBox);
			this.GeneralTB.Controls.Add(this.ShopOwnerGroupBox);
			this.GeneralTB.Controls.Add(this.PostcodeFinderCheckBox1);
			this.GeneralTB.Controls.Add(this.OrderHistoryGroupBox);
			this.GeneralTB.Controls.Add(this.DriversAccessCheckBox);
			this.GeneralTB.Controls.Add(this.ActiveEditOrdersCheckBox);
			this.GeneralTB.Controls.Add(this.RemoveItemsInShoppingCartCheckBox);
			this.GeneralTB.Controls.Add(this.FlashDriverGroupBox);
			this.GeneralTB.Controls.Add(this.DownloadBackupGroupBox);
			this.GeneralTB.Controls.Add(this.NewPasswordGroupBox);
			this.GeneralTB.Controls.Add(this.BusinessInfoGroupBox);
			TabPage generalTB = this.GeneralTB;
			point = new Point(4, 49);
			generalTB.Location = point;
			this.GeneralTB.Name = "GeneralTB";
			Control generalTB2 = this.GeneralTB;
			Padding padding = new Padding(3);
			generalTB2.Padding = padding;
			Control generalTB3 = this.GeneralTB;
			size = new Size(1292, 624);
			generalTB3.Size = size;
			this.GeneralTB.TabIndex = 0;
			this.GeneralTB.Text = "General";
			this.GeneralTB.UseVisualStyleBackColor = true;
			this.SafeModeCheckBox.AutoSize = true;
			this.SafeModeCheckBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control safeModeCheckBox = this.SafeModeCheckBox;
			point = new Point(21, 548);
			safeModeCheckBox.Location = point;
			this.SafeModeCheckBox.Name = "SafeModeCheckBox";
			Control safeModeCheckBox2 = this.SafeModeCheckBox;
			size = new Size(104, 22);
			safeModeCheckBox2.Size = size;
			this.SafeModeCheckBox.TabIndex = 54;
			this.SafeModeCheckBox.Text = "Safe Mode";
			this.SafeModeCheckBox.UseVisualStyleBackColor = true;
			this.Categories2RowsCheckBox.AutoSize = true;
			this.Categories2RowsCheckBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control categories2RowsCheckBox = this.Categories2RowsCheckBox;
			point = new Point(182, 522);
			categories2RowsCheckBox.Location = point;
			this.Categories2RowsCheckBox.Name = "Categories2RowsCheckBox";
			Control categories2RowsCheckBox2 = this.Categories2RowsCheckBox;
			size = new Size(177, 22);
			categories2RowsCheckBox2.Size = size;
			this.Categories2RowsCheckBox.TabIndex = 52;
			this.Categories2RowsCheckBox.Text = "Categories in 2 Rows";
			this.Categories2RowsCheckBox.UseVisualStyleBackColor = true;
			this.TableManagementCheckBox.AutoSize = true;
			this.TableManagementCheckBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control tableManagementCheckBox = this.TableManagementCheckBox;
			point = new Point(182, 494);
			tableManagementCheckBox.Location = point;
			this.TableManagementCheckBox.Name = "TableManagementCheckBox";
			Control tableManagementCheckBox2 = this.TableManagementCheckBox;
			size = new Size(159, 22);
			tableManagementCheckBox2.Size = size;
			this.TableManagementCheckBox.TabIndex = 51;
			this.TableManagementCheckBox.Text = "Table Management";
			this.TableManagementCheckBox.UseVisualStyleBackColor = true;
			this.TableManagementCheckBox.Visible = false;
			this.SupplierCheckBox.AutoSize = true;
			this.SupplierCheckBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control supplierCheckBox = this.SupplierCheckBox;
			point = new Point(182, 550);
			supplierCheckBox.Location = point;
			this.SupplierCheckBox.Name = "SupplierCheckBox";
			Control supplierCheckBox2 = this.SupplierCheckBox;
			size = new Size(128, 22);
			supplierCheckBox2.Size = size;
			this.SupplierCheckBox.TabIndex = 50;
			this.SupplierCheckBox.Text = "Show Supplier";
			this.SupplierCheckBox.UseVisualStyleBackColor = true;
			this.ShopOwnerGroupBox.Controls.Add(this.Label20);
			this.ShopOwnerGroupBox.Controls.Add(this.Label21);
			this.ShopOwnerGroupBox.Controls.Add(this.BusinessEmailTextBox);
			this.ShopOwnerGroupBox.Controls.Add(this.ShopOwnerMobileTextBox);
			this.ShopOwnerGroupBox.Controls.Add(this.Button4);
			this.ShopOwnerGroupBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ShopOwnerGroupBox.ForeColor = Color.Crimson;
			Control shopOwnerGroupBox = this.ShopOwnerGroupBox;
			point = new Point(335, 249);
			shopOwnerGroupBox.Location = point;
			this.ShopOwnerGroupBox.Name = "ShopOwnerGroupBox";
			Control shopOwnerGroupBox2 = this.ShopOwnerGroupBox;
			size = new Size(277, 210);
			shopOwnerGroupBox2.Size = size;
			this.ShopOwnerGroupBox.TabIndex = 31;
			this.ShopOwnerGroupBox.TabStop = false;
			this.ShopOwnerGroupBox.Text = "Shop Owner";
			this.ShopOwnerGroupBox.Visible = false;
			this.Label20.AutoSize = true;
			this.Label20.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label20.ForeColor = Color.Black;
			Control label = this.Label20;
			point = new Point(13, 96);
			label.Location = point;
			this.Label20.Name = "Label20";
			Control label2 = this.Label20;
			size = new Size(48, 18);
			label2.Size = size;
			this.Label20.TabIndex = 27;
			this.Label20.Text = "Email";
			this.Label21.AutoSize = true;
			this.Label21.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label21.ForeColor = Color.Black;
			Control label3 = this.Label21;
			point = new Point(8, 40);
			label3.Location = point;
			this.Label21.Name = "Label21";
			Control label4 = this.Label21;
			size = new Size(53, 18);
			label4.Size = size;
			this.Label21.TabIndex = 22;
			this.Label21.Text = "Phone";
			Control businessEmailTextBox = this.BusinessEmailTextBox;
			point = new Point(67, 90);
			businessEmailTextBox.Location = point;
			this.BusinessEmailTextBox.Name = "BusinessEmailTextBox";
			Control businessEmailTextBox2 = this.BusinessEmailTextBox;
			size = new Size(204, 29);
			businessEmailTextBox2.Size = size;
			this.BusinessEmailTextBox.TabIndex = 26;
			Control shopOwnerMobileTextBox = this.ShopOwnerMobileTextBox;
			point = new Point(67, 34);
			shopOwnerMobileTextBox.Location = point;
			this.ShopOwnerMobileTextBox.Name = "ShopOwnerMobileTextBox";
			Control shopOwnerMobileTextBox2 = this.ShopOwnerMobileTextBox;
			size = new Size(204, 29);
			shopOwnerMobileTextBox2.Size = size;
			this.ShopOwnerMobileTextBox.TabIndex = 25;
			this.Button4.Anchor = AnchorStyles.None;
			this.Button4.BackColor = Color.SteelBlue;
			this.Button4.FlatStyle = FlatStyle.Flat;
			this.Button4.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button4.ForeColor = Color.White;
			Control button = this.Button4;
			point = new Point(134, 150);
			button.Location = point;
			this.Button4.Name = "Button4";
			Control button2 = this.Button4;
			size = new Size(137, 45);
			button2.Size = size;
			this.Button4.TabIndex = 24;
			this.Button4.Text = "Save";
			this.Button4.UseVisualStyleBackColor = false;
			this.PostcodeFinderCheckBox1.AutoSize = true;
			this.PostcodeFinderCheckBox1.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control postcodeFinderCheckBox = this.PostcodeFinderCheckBox1;
			point = new Point(21, 493);
			postcodeFinderCheckBox.Location = point;
			this.PostcodeFinderCheckBox1.Name = "PostcodeFinderCheckBox1";
			Control postcodeFinderCheckBox2 = this.PostcodeFinderCheckBox1;
			size = new Size(143, 22);
			postcodeFinderCheckBox2.Size = size;
			this.PostcodeFinderCheckBox1.TabIndex = 45;
			this.PostcodeFinderCheckBox1.Text = "Postcode Finder";
			this.PostcodeFinderCheckBox1.UseVisualStyleBackColor = true;
			this.PostcodeFinderCheckBox1.Visible = false;
			this.OrderHistoryGroupBox.Controls.Add(this.OrderHistorySummaryPrintBTN);
			this.OrderHistoryGroupBox.Controls.Add(this.OrderHistoryDeleteBTN);
			this.OrderHistoryGroupBox.Controls.Add(this.OrderHistoryFullPrintBTN);
			this.OrderHistoryGroupBox.Controls.Add(this.OrderHistoryListBox);
			this.OrderHistoryGroupBox.Font = new Font("Arial", 14.25f);
			this.OrderHistoryGroupBox.ForeColor = Color.Crimson;
			Control orderHistoryGroupBox = this.OrderHistoryGroupBox;
			point = new Point(618, 13);
			orderHistoryGroupBox.Location = point;
			this.OrderHistoryGroupBox.Name = "OrderHistoryGroupBox";
			Control orderHistoryGroupBox2 = this.OrderHistoryGroupBox;
			size = new Size(239, 582);
			orderHistoryGroupBox2.Size = size;
			this.OrderHistoryGroupBox.TabIndex = 43;
			this.OrderHistoryGroupBox.TabStop = false;
			this.OrderHistoryGroupBox.Text = "Order History";
			this.OrderHistorySummaryPrintBTN.Anchor = AnchorStyles.Bottom;
			this.OrderHistorySummaryPrintBTN.BackColor = Color.SteelBlue;
			this.OrderHistorySummaryPrintBTN.Enabled = false;
			this.OrderHistorySummaryPrintBTN.FlatStyle = FlatStyle.Flat;
			this.OrderHistorySummaryPrintBTN.Font = new Font("Arial Narrow", 14.25f);
			this.OrderHistorySummaryPrintBTN.ForeColor = Color.White;
			Control orderHistorySummaryPrintBTN = this.OrderHistorySummaryPrintBTN;
			point = new Point(6, 473);
			orderHistorySummaryPrintBTN.Location = point;
			this.OrderHistorySummaryPrintBTN.Name = "OrderHistorySummaryPrintBTN";
			Control orderHistorySummaryPrintBTN2 = this.OrderHistorySummaryPrintBTN;
			size = new Size(227, 48);
			orderHistorySummaryPrintBTN2.Size = size;
			this.OrderHistorySummaryPrintBTN.TabIndex = 44;
			this.OrderHistorySummaryPrintBTN.Text = "Print Summary Report";
			this.OrderHistorySummaryPrintBTN.UseVisualStyleBackColor = false;
			this.OrderHistoryDeleteBTN.Anchor = AnchorStyles.Bottom;
			this.OrderHistoryDeleteBTN.BackColor = Color.Crimson;
			this.OrderHistoryDeleteBTN.Enabled = false;
			this.OrderHistoryDeleteBTN.FlatStyle = FlatStyle.Flat;
			this.OrderHistoryDeleteBTN.Font = new Font("Arial Narrow", 14.25f);
			this.OrderHistoryDeleteBTN.ForeColor = Color.White;
			Control orderHistoryDeleteBTN = this.OrderHistoryDeleteBTN;
			point = new Point(6, 419);
			orderHistoryDeleteBTN.Location = point;
			this.OrderHistoryDeleteBTN.Name = "OrderHistoryDeleteBTN";
			Control orderHistoryDeleteBTN2 = this.OrderHistoryDeleteBTN;
			size = new Size(227, 48);
			orderHistoryDeleteBTN2.Size = size;
			this.OrderHistoryDeleteBTN.TabIndex = 43;
			this.OrderHistoryDeleteBTN.Text = "Delete";
			this.OrderHistoryDeleteBTN.UseVisualStyleBackColor = false;
			this.OrderHistoryDeleteBTN.Visible = false;
			this.OrderHistoryFullPrintBTN.Anchor = AnchorStyles.Bottom;
			this.OrderHistoryFullPrintBTN.BackColor = Color.SteelBlue;
			this.OrderHistoryFullPrintBTN.Enabled = false;
			this.OrderHistoryFullPrintBTN.FlatStyle = FlatStyle.Flat;
			this.OrderHistoryFullPrintBTN.Font = new Font("Arial Narrow", 14.25f);
			this.OrderHistoryFullPrintBTN.ForeColor = Color.White;
			Control orderHistoryFullPrintBTN = this.OrderHistoryFullPrintBTN;
			point = new Point(6, 527);
			orderHistoryFullPrintBTN.Location = point;
			this.OrderHistoryFullPrintBTN.Name = "OrderHistoryFullPrintBTN";
			Control orderHistoryFullPrintBTN2 = this.OrderHistoryFullPrintBTN;
			size = new Size(227, 48);
			orderHistoryFullPrintBTN2.Size = size;
			this.OrderHistoryFullPrintBTN.TabIndex = 31;
			this.OrderHistoryFullPrintBTN.Text = "Print Full Report";
			this.OrderHistoryFullPrintBTN.UseVisualStyleBackColor = false;
			this.OrderHistoryListBox.FormattingEnabled = true;
			this.OrderHistoryListBox.ItemHeight = 22;
			Control orderHistoryListBox = this.OrderHistoryListBox;
			point = new Point(8, 32);
			orderHistoryListBox.Location = point;
			this.OrderHistoryListBox.Name = "OrderHistoryListBox";
			this.OrderHistoryListBox.ScrollAlwaysVisible = true;
			Control orderHistoryListBox2 = this.OrderHistoryListBox;
			size = new Size(223, 378);
			orderHistoryListBox2.Size = size;
			this.OrderHistoryListBox.TabIndex = 42;
			this.DriversAccessCheckBox.AutoSize = true;
			this.DriversAccessCheckBox.Font = new Font("Arial", 12f);
			this.DriversAccessCheckBox.ForeColor = Color.Black;
			Control driversAccessCheckBox = this.DriversAccessCheckBox;
			point = new Point(21, 465);
			driversAccessCheckBox.Location = point;
			this.DriversAccessCheckBox.Name = "DriversAccessCheckBox";
			Control driversAccessCheckBox2 = this.DriversAccessCheckBox;
			size = new Size(133, 22);
			driversAccessCheckBox2.Size = size;
			this.DriversAccessCheckBox.TabIndex = 25;
			this.DriversAccessCheckBox.Text = "Access Drivers";
			this.DriversAccessCheckBox.UseVisualStyleBackColor = true;
			this.DriversAccessCheckBox.Visible = false;
			this.ActiveEditOrdersCheckBox.AutoSize = true;
			this.ActiveEditOrdersCheckBox.Font = new Font("Arial", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ActiveEditOrdersCheckBox.ForeColor = Color.Black;
			Control activeEditOrdersCheckBox = this.ActiveEditOrdersCheckBox;
			point = new Point(21, 521);
			activeEditOrdersCheckBox.Location = point;
			this.ActiveEditOrdersCheckBox.Name = "ActiveEditOrdersCheckBox";
			Control activeEditOrdersCheckBox2 = this.ActiveEditOrdersCheckBox;
			size = new Size(148, 21);
			activeEditOrdersCheckBox2.Size = size;
			this.ActiveEditOrdersCheckBox.TabIndex = 37;
			this.ActiveEditOrdersCheckBox.Text = "Edit Orders Button";
			this.ActiveEditOrdersCheckBox.UseVisualStyleBackColor = true;
			this.ActiveEditOrdersCheckBox.Visible = false;
			this.RemoveItemsInShoppingCartCheckBox.AutoSize = true;
			this.RemoveItemsInShoppingCartCheckBox.Font = new Font("Arial", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.RemoveItemsInShoppingCartCheckBox.ForeColor = Color.Black;
			Control removeItemsInShoppingCartCheckBox = this.RemoveItemsInShoppingCartCheckBox;
			point = new Point(182, 466);
			removeItemsInShoppingCartCheckBox.Location = point;
			this.RemoveItemsInShoppingCartCheckBox.Name = "RemoveItemsInShoppingCartCheckBox";
			Control removeItemsInShoppingCartCheckBox2 = this.RemoveItemsInShoppingCartCheckBox;
			size = new Size(203, 21);
			removeItemsInShoppingCartCheckBox2.Size = size;
			this.RemoveItemsInShoppingCartCheckBox.TabIndex = 26;
			this.RemoveItemsInShoppingCartCheckBox.Text = "Shopping Cart Edit Buttons";
			this.RemoveItemsInShoppingCartCheckBox.UseVisualStyleBackColor = true;
			this.RemoveItemsInShoppingCartCheckBox.Visible = false;
			this.FlashDriverGroupBox.Controls.Add(this.USBBackupBTN);
			this.FlashDriverGroupBox.Controls.Add(this.USBRestoreBTN);
			this.FlashDriverGroupBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.FlashDriverGroupBox.ForeColor = Color.Crimson;
			Control flashDriverGroupBox = this.FlashDriverGroupBox;
			point = new Point(863, 41);
			flashDriverGroupBox.Location = point;
			this.FlashDriverGroupBox.Name = "FlashDriverGroupBox";
			Control flashDriverGroupBox2 = this.FlashDriverGroupBox;
			size = new Size(130, 189);
			flashDriverGroupBox2.Size = size;
			this.FlashDriverGroupBox.TabIndex = 33;
			this.FlashDriverGroupBox.TabStop = false;
			this.FlashDriverGroupBox.Text = "Flash Drive";
			this.FlashDriverGroupBox.Visible = false;
			this.USBBackupBTN.BackColor = Color.Lime;
			this.USBBackupBTN.FlatStyle = FlatStyle.Flat;
			this.USBBackupBTN.ForeColor = Color.Black;
			Control usbbackupBTN = this.USBBackupBTN;
			point = new Point(6, 27);
			usbbackupBTN.Location = point;
			this.USBBackupBTN.Name = "USBBackupBTN";
			Control usbbackupBTN2 = this.USBBackupBTN;
			size = new Size(117, 75);
			usbbackupBTN2.Size = size;
			this.USBBackupBTN.TabIndex = 34;
			this.USBBackupBTN.Text = "Create backup";
			this.USBBackupBTN.UseVisualStyleBackColor = false;
			this.USBRestoreBTN.BackColor = Color.Yellow;
			this.USBRestoreBTN.FlatStyle = FlatStyle.Flat;
			this.USBRestoreBTN.ForeColor = Color.Black;
			Control usbrestoreBTN = this.USBRestoreBTN;
			point = new Point(6, 108);
			usbrestoreBTN.Location = point;
			this.USBRestoreBTN.Name = "USBRestoreBTN";
			Control usbrestoreBTN2 = this.USBRestoreBTN;
			size = new Size(117, 75);
			usbrestoreBTN2.Size = size;
			this.USBRestoreBTN.TabIndex = 35;
			this.USBRestoreBTN.Text = "Restore backup";
			this.USBRestoreBTN.UseVisualStyleBackColor = false;
			this.DownloadBackupGroupBox.Controls.Add(this.AllPostCodesTextBox);
			this.DownloadBackupGroupBox.Controls.Add(this.DownloadBackupCustomersRB);
			this.DownloadBackupGroupBox.Controls.Add(this.DownloadBackupMenuRB);
			this.DownloadBackupGroupBox.Controls.Add(this.DownloadPostcodesRB);
			this.DownloadBackupGroupBox.Controls.Add(this.DownloadBackupBTN);
			this.DownloadBackupGroupBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DownloadBackupGroupBox.ForeColor = Color.Crimson;
			Control downloadBackupGroupBox = this.DownloadBackupGroupBox;
			point = new Point(391, 13);
			downloadBackupGroupBox.Location = point;
			this.DownloadBackupGroupBox.Name = "DownloadBackupGroupBox";
			Control downloadBackupGroupBox2 = this.DownloadBackupGroupBox;
			size = new Size(221, 230);
			downloadBackupGroupBox2.Size = size;
			this.DownloadBackupGroupBox.TabIndex = 31;
			this.DownloadBackupGroupBox.TabStop = false;
			this.DownloadBackupGroupBox.Text = "Download Options";
			this.DownloadBackupGroupBox.Visible = false;
			this.AllPostCodesTextBox.BackColor = Color.WhiteSmoke;
			this.AllPostCodesTextBox.BorderStyle = BorderStyle.None;
			this.AllPostCodesTextBox.Font = new Font("Arial", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.AllPostCodesTextBox.ForeColor = Color.DarkOrange;
			Control allPostCodesTextBox = this.AllPostCodesTextBox;
			point = new Point(43, 103);
			allPostCodesTextBox.Location = point;
			this.AllPostCodesTextBox.Multiline = true;
			this.AllPostCodesTextBox.Name = "AllPostCodesTextBox";
			this.AllPostCodesTextBox.ReadOnly = true;
			Control allPostCodesTextBox2 = this.AllPostCodesTextBox;
			size = new Size(153, 59);
			allPostCodesTextBox2.Size = size;
			this.AllPostCodesTextBox.TabIndex = 28;
			this.DownloadBackupCustomersRB.AutoSize = true;
			this.DownloadBackupCustomersRB.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DownloadBackupCustomersRB.ForeColor = Color.Black;
			Control downloadBackupCustomersRB = this.DownloadBackupCustomersRB;
			point = new Point(20, 55);
			downloadBackupCustomersRB.Location = point;
			this.DownloadBackupCustomersRB.Name = "DownloadBackupCustomersRB";
			Control downloadBackupCustomersRB2 = this.DownloadBackupCustomersRB;
			size = new Size(176, 22);
			downloadBackupCustomersRB2.Size = size;
			this.DownloadBackupCustomersRB.TabIndex = 27;
			this.DownloadBackupCustomersRB.TabStop = true;
			this.DownloadBackupCustomersRB.Text = "Download Customers";
			this.DownloadBackupCustomersRB.UseVisualStyleBackColor = true;
			this.DownloadBackupMenuRB.AutoSize = true;
			this.DownloadBackupMenuRB.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DownloadBackupMenuRB.ForeColor = Color.Black;
			Control downloadBackupMenuRB = this.DownloadBackupMenuRB;
			point = new Point(20, 30);
			downloadBackupMenuRB.Location = point;
			this.DownloadBackupMenuRB.Name = "DownloadBackupMenuRB";
			Control downloadBackupMenuRB2 = this.DownloadBackupMenuRB;
			size = new Size(138, 22);
			downloadBackupMenuRB2.Size = size;
			this.DownloadBackupMenuRB.TabIndex = 26;
			this.DownloadBackupMenuRB.TabStop = true;
			this.DownloadBackupMenuRB.Text = "Download Menu";
			this.DownloadBackupMenuRB.UseVisualStyleBackColor = true;
			this.DownloadPostcodesRB.AutoSize = true;
			this.DownloadPostcodesRB.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DownloadPostcodesRB.ForeColor = Color.Black;
			Control downloadPostcodesRB = this.DownloadPostcodesRB;
			point = new Point(20, 80);
			downloadPostcodesRB.Location = point;
			this.DownloadPostcodesRB.Name = "DownloadPostcodesRB";
			Control downloadPostcodesRB2 = this.DownloadPostcodesRB;
			size = new Size(175, 22);
			downloadPostcodesRB2.Size = size;
			this.DownloadPostcodesRB.TabIndex = 25;
			this.DownloadPostcodesRB.TabStop = true;
			this.DownloadPostcodesRB.Text = "Download Postcodes";
			this.DownloadPostcodesRB.UseVisualStyleBackColor = true;
			this.DownloadBackupBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.DownloadBackupBTN.BackColor = Color.SteelBlue;
			this.DownloadBackupBTN.FlatStyle = FlatStyle.Flat;
			this.DownloadBackupBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DownloadBackupBTN.ForeColor = Color.White;
			Control downloadBackupBTN = this.DownloadBackupBTN;
			point = new Point(9, 183);
			downloadBackupBTN.Location = point;
			this.DownloadBackupBTN.Name = "DownloadBackupBTN";
			Control downloadBackupBTN2 = this.DownloadBackupBTN;
			size = new Size(204, 37);
			downloadBackupBTN2.Size = size;
			this.DownloadBackupBTN.TabIndex = 24;
			this.DownloadBackupBTN.Text = "Download Now";
			this.DownloadBackupBTN.UseVisualStyleBackColor = false;
			this.NewPasswordGroupBox.Controls.Add(this.NewPassUserComboBox);
			this.NewPasswordGroupBox.Controls.Add(this.Label12);
			this.NewPasswordGroupBox.Controls.Add(this.Label11);
			this.NewPasswordGroupBox.Controls.Add(this.Label10);
			this.NewPasswordGroupBox.Controls.Add(this.NewPassConfirmfTextBox);
			this.NewPasswordGroupBox.Controls.Add(this.NewPassTextBox);
			this.NewPasswordGroupBox.Controls.Add(this.NewPasswordSaveBTN);
			this.NewPasswordGroupBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.NewPasswordGroupBox.ForeColor = Color.Crimson;
			Control newPasswordGroupBox = this.NewPasswordGroupBox;
			point = new Point(21, 249);
			newPasswordGroupBox.Location = point;
			this.NewPasswordGroupBox.Name = "NewPasswordGroupBox";
			Control newPasswordGroupBox2 = this.NewPasswordGroupBox;
			size = new Size(308, 203);
			newPasswordGroupBox2.Size = size;
			this.NewPasswordGroupBox.TabIndex = 25;
			this.NewPasswordGroupBox.TabStop = false;
			this.NewPasswordGroupBox.Text = "Change Passwords";
			this.NewPassUserComboBox.FormattingEnabled = true;
			Control newPassUserComboBox = this.NewPassUserComboBox;
			point = new Point(99, 29);
			newPassUserComboBox.Location = point;
			this.NewPassUserComboBox.Name = "NewPassUserComboBox";
			Control newPassUserComboBox2 = this.NewPassUserComboBox;
			size = new Size(198, 30);
			newPassUserComboBox2.Size = size;
			this.NewPassUserComboBox.TabIndex = 30;
			this.Label12.AutoSize = true;
			this.Label12.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label12.ForeColor = Color.Black;
			Control label5 = this.Label12;
			point = new Point(10, 35);
			label5.Location = point;
			this.Label12.Name = "Label12";
			Control label6 = this.Label12;
			size = new Size(89, 18);
			label6.Size = size;
			this.Label12.TabIndex = 29;
			this.Label12.Text = "Select User";
			this.Label11.AutoSize = true;
			this.Label11.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label11.ForeColor = Color.Black;
			Control label7 = this.Label11;
			point = new Point(8, 122);
			label7.Location = point;
			this.Label11.Name = "Label11";
			Control label8 = this.Label11;
			size = new Size(172, 18);
			label8.Size = size;
			this.Label11.TabIndex = 27;
			this.Label11.Text = "Confirm New Password";
			this.Label10.AutoSize = true;
			this.Label10.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label10.ForeColor = Color.Black;
			Control label9 = this.Label10;
			point = new Point(10, 79);
			label9.Location = point;
			this.Label10.Name = "Label10";
			Control label10 = this.Label10;
			size = new Size(113, 18);
			label10.Size = size;
			this.Label10.TabIndex = 22;
			this.Label10.Text = "New Password";
			Control newPassConfirmfTextBox = this.NewPassConfirmfTextBox;
			point = new Point(186, 116);
			newPassConfirmfTextBox.Location = point;
			this.NewPassConfirmfTextBox.Name = "NewPassConfirmfTextBox";
			this.NewPassConfirmfTextBox.PasswordChar = '*';
			Control newPassConfirmfTextBox2 = this.NewPassConfirmfTextBox;
			size = new Size(111, 29);
			newPassConfirmfTextBox2.Size = size;
			this.NewPassConfirmfTextBox.TabIndex = 26;
			Control newPassTextBox = this.NewPassTextBox;
			point = new Point(186, 73);
			newPassTextBox.Location = point;
			this.NewPassTextBox.Name = "NewPassTextBox";
			this.NewPassTextBox.PasswordChar = '*';
			Control newPassTextBox2 = this.NewPassTextBox;
			size = new Size(111, 29);
			newPassTextBox2.Size = size;
			this.NewPassTextBox.TabIndex = 25;
			this.NewPasswordSaveBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.NewPasswordSaveBTN.BackColor = Color.SteelBlue;
			this.NewPasswordSaveBTN.FlatStyle = FlatStyle.Flat;
			this.NewPasswordSaveBTN.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.NewPasswordSaveBTN.ForeColor = Color.White;
			Control newPasswordSaveBTN = this.NewPasswordSaveBTN;
			point = new Point(13, 160);
			newPasswordSaveBTN.Location = point;
			this.NewPasswordSaveBTN.Name = "NewPasswordSaveBTN";
			Control newPasswordSaveBTN2 = this.NewPasswordSaveBTN;
			size = new Size(284, 37);
			newPasswordSaveBTN2.Size = size;
			this.NewPasswordSaveBTN.TabIndex = 24;
			this.NewPasswordSaveBTN.Text = "Save  New Password";
			this.NewPasswordSaveBTN.UseVisualStyleBackColor = false;
			this.BusinessInfoGroupBox.BackColor = Color.Transparent;
			this.BusinessInfoGroupBox.Controls.Add(this.Label6);
			this.BusinessInfoGroupBox.Controls.Add(this.BPhoneTextBox);
			this.BusinessInfoGroupBox.Controls.Add(this.BNameTextBox);
			this.BusinessInfoGroupBox.Controls.Add(this.Label5);
			this.BusinessInfoGroupBox.Controls.Add(this.BPostcodeTextBox);
			this.BusinessInfoGroupBox.Controls.Add(this.Label2);
			this.BusinessInfoGroupBox.Controls.Add(this.Label1);
			this.BusinessInfoGroupBox.Controls.Add(this.BCityTextBox);
			this.BusinessInfoGroupBox.Controls.Add(this.Label3);
			this.BusinessInfoGroupBox.Controls.Add(this.Label4);
			this.BusinessInfoGroupBox.Controls.Add(this.BAddressTextBox);
			this.BusinessInfoGroupBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.BusinessInfoGroupBox.ForeColor = Color.Crimson;
			Control businessInfoGroupBox = this.BusinessInfoGroupBox;
			point = new Point(21, 13);
			businessInfoGroupBox.Location = point;
			this.BusinessInfoGroupBox.Name = "BusinessInfoGroupBox";
			Control businessInfoGroupBox2 = this.BusinessInfoGroupBox;
			size = new Size(364, 230);
			businessInfoGroupBox2.Size = size;
			this.BusinessInfoGroupBox.TabIndex = 4;
			this.BusinessInfoGroupBox.TabStop = false;
			this.BusinessInfoGroupBox.Text = "Software Licence Registered to";
			this.BusinessInfoGroupBox.Visible = false;
			this.Label6.AutoSize = true;
			this.Label6.Font = new Font("Arial Narrow", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control label11 = this.Label6;
			point = new Point(27, 200);
			label11.Location = point;
			this.Label6.Name = "Label6";
			Control label12 = this.Label6;
			size = new Size(320, 20);
			label12.Size = size;
			this.Label6.TabIndex = 15;
			this.Label6.Text = "Software Registration Licence can NOT be changed.";
			this.BPhoneTextBox.BorderStyle = BorderStyle.None;
			this.BPhoneTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control bphoneTextBox = this.BPhoneTextBox;
			point = new Point(99, 164);
			bphoneTextBox.Location = point;
			this.BPhoneTextBox.Name = "BPhoneTextBox";
			Control bphoneTextBox2 = this.BPhoneTextBox;
			size = new Size(248, 19);
			bphoneTextBox2.Size = size;
			this.BPhoneTextBox.TabIndex = 14;
			this.BNameTextBox.BorderStyle = BorderStyle.None;
			this.BNameTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control bnameTextBox = this.BNameTextBox;
			point = new Point(99, 32);
			bnameTextBox.Location = point;
			this.BNameTextBox.Name = "BNameTextBox";
			Control bnameTextBox2 = this.BNameTextBox;
			size = new Size(248, 19);
			bnameTextBox2.Size = size;
			this.BNameTextBox.TabIndex = 6;
			this.Label5.AutoSize = true;
			this.Label5.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label5.ForeColor = Color.Black;
			Control label13 = this.Label5;
			point = new Point(10, 164);
			label13.Location = point;
			this.Label5.Name = "Label5";
			Control label14 = this.Label5;
			size = new Size(53, 18);
			label14.Size = size;
			this.Label5.TabIndex = 13;
			this.Label5.Text = "Phone";
			this.BPostcodeTextBox.BorderStyle = BorderStyle.None;
			this.BPostcodeTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control bpostcodeTextBox = this.BPostcodeTextBox;
			point = new Point(99, 130);
			bpostcodeTextBox.Location = point;
			this.BPostcodeTextBox.Name = "BPostcodeTextBox";
			Control bpostcodeTextBox2 = this.BPostcodeTextBox;
			size = new Size(248, 19);
			bpostcodeTextBox2.Size = size;
			this.BPostcodeTextBox.TabIndex = 12;
			this.Label2.AutoSize = true;
			this.Label2.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label2.ForeColor = Color.Black;
			Control label15 = this.Label2;
			point = new Point(10, 32);
			label15.Location = point;
			this.Label2.Name = "Label2";
			Control label16 = this.Label2;
			size = new Size(50, 18);
			label16.Size = size;
			this.Label2.TabIndex = 5;
			this.Label2.Text = "Name";
			this.Label1.AutoSize = true;
			this.Label1.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.Black;
			Control label17 = this.Label1;
			point = new Point(10, 65);
			label17.Location = point;
			this.Label1.Name = "Label1";
			Control label18 = this.Label1;
			size = new Size(67, 18);
			label18.Size = size;
			this.Label1.TabIndex = 7;
			this.Label1.Text = "Address";
			this.BCityTextBox.BorderStyle = BorderStyle.None;
			this.BCityTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control bcityTextBox = this.BCityTextBox;
			point = new Point(99, 98);
			bcityTextBox.Location = point;
			this.BCityTextBox.Name = "BCityTextBox";
			Control bcityTextBox2 = this.BCityTextBox;
			size = new Size(248, 19);
			bcityTextBox2.Size = size;
			this.BCityTextBox.TabIndex = 10;
			this.Label3.AutoSize = true;
			this.Label3.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label3.ForeColor = Color.Black;
			Control label19 = this.Label3;
			point = new Point(10, 98);
			label19.Location = point;
			this.Label3.Name = "Label3";
			Control label20 = this.Label3;
			size = new Size(35, 18);
			label20.Size = size;
			this.Label3.TabIndex = 9;
			this.Label3.Text = "City";
			this.Label4.AutoSize = true;
			this.Label4.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label4.ForeColor = Color.Black;
			Control label21 = this.Label4;
			point = new Point(10, 131);
			label21.Location = point;
			this.Label4.Name = "Label4";
			Control label22 = this.Label4;
			size = new Size(75, 18);
			label22.Size = size;
			this.Label4.TabIndex = 11;
			this.Label4.Text = "Postcode";
			this.BAddressTextBox.BorderStyle = BorderStyle.None;
			this.BAddressTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control baddressTextBox = this.BAddressTextBox;
			point = new Point(99, 65);
			baddressTextBox.Location = point;
			this.BAddressTextBox.Name = "BAddressTextBox";
			Control baddressTextBox2 = this.BAddressTextBox;
			size = new Size(248, 19);
			baddressTextBox2.Size = size;
			this.BAddressTextBox.TabIndex = 8;
			this.DriversTB.Controls.Add(this.KeyboardDriver);
			this.DriversTB.Controls.Add(this.GroupBox7);
			this.DriversTB.Controls.Add(this.GroupBox6);
			this.DriversTB.Controls.Add(this.GroupBox5);
			TabPage driversTB = this.DriversTB;
			point = new Point(4, 49);
			driversTB.Location = point;
			this.DriversTB.Name = "DriversTB";
			Control driversTB2 = this.DriversTB;
			padding = new Padding(3);
			driversTB2.Padding = padding;
			Control driversTB3 = this.DriversTB;
			size = new Size(1292, 624);
			driversTB3.Size = size;
			this.DriversTB.TabIndex = 2;
			this.DriversTB.Text = "Drivers";
			this.DriversTB.UseVisualStyleBackColor = true;
			this.KeyboardDriver.BackColor = Color.Gainsboro;
			this.KeyboardDriver.Dock = DockStyle.Bottom;
			this.KeyboardDriver.ForeColor = SystemColors.Info;
			Control keyboardDriver = this.KeyboardDriver;
			point = new Point(414, 203);
			keyboardDriver.Location = point;
			this.KeyboardDriver.Name = "KeyboardDriver";
			Control keyboardDriver2 = this.KeyboardDriver;
			size = new Size(875, 418);
			keyboardDriver2.Size = size;
			this.KeyboardDriver.TabIndex = 31;
			this.GroupBox7.Controls.Add(this.DriversDeleteComboBox);
			this.GroupBox7.Controls.Add(this.Button3);
			this.GroupBox7.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.GroupBox7.ForeColor = Color.Crimson;
			Control groupBox = this.GroupBox7;
			point = new Point(420, 99);
			groupBox.Location = point;
			this.GroupBox7.Name = "GroupBox7";
			Control groupBox2 = this.GroupBox7;
			size = new Size(532, 84);
			groupBox2.Size = size;
			this.GroupBox7.TabIndex = 30;
			this.GroupBox7.TabStop = false;
			this.GroupBox7.Text = "Delete Driver";
			this.DriversDeleteComboBox.AutoCompleteMode = AutoCompleteMode.Suggest;
			this.DriversDeleteComboBox.AutoCompleteSource = AutoCompleteSource.ListItems;
			this.DriversDeleteComboBox.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DriversDeleteComboBox.FormattingEnabled = true;
			Control driversDeleteComboBox = this.DriversDeleteComboBox;
			point = new Point(13, 30);
			driversDeleteComboBox.Location = point;
			this.DriversDeleteComboBox.Name = "DriversDeleteComboBox";
			Control driversDeleteComboBox2 = this.DriversDeleteComboBox;
			size = new Size(433, 37);
			driversDeleteComboBox2.Size = size;
			this.DriversDeleteComboBox.TabIndex = 27;
			this.Button3.BackColor = Color.Orange;
			this.Button3.FlatStyle = FlatStyle.Flat;
			this.Button3.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button3.ForeColor = Color.White;
			Control button3 = this.Button3;
			point = new Point(454, 17);
			button3.Location = point;
			this.Button3.Name = "Button3";
			Control button4 = this.Button3;
			size = new Size(70, 61);
			button4.Size = size;
			this.Button3.TabIndex = 26;
			this.Button3.Text = "Delete";
			this.Button3.UseVisualStyleBackColor = false;
			this.GroupBox6.Controls.Add(this.Label9);
			this.GroupBox6.Controls.Add(this.Button2);
			this.GroupBox6.Controls.Add(this.Label8);
			this.GroupBox6.Controls.Add(this.AddDriverMobileTextBox);
			this.GroupBox6.Controls.Add(this.AddDriverNameTextBox);
			this.GroupBox6.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.GroupBox6.ForeColor = Color.Crimson;
			Control groupBox3 = this.GroupBox6;
			point = new Point(420, 3);
			groupBox3.Location = point;
			this.GroupBox6.Name = "GroupBox6";
			Control groupBox4 = this.GroupBox6;
			size = new Size(532, 90);
			groupBox4.Size = size;
			this.GroupBox6.TabIndex = 29;
			this.GroupBox6.TabStop = false;
			this.GroupBox6.Text = "Add New Driver";
			this.Label9.AutoSize = true;
			this.Label9.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label9.ForeColor = Color.Black;
			Control label23 = this.Label9;
			point = new Point(225, 43);
			label23.Location = point;
			this.Label9.Name = "Label9";
			Control label24 = this.Label9;
			size = new Size(65, 19);
			label24.Size = size;
			this.Label9.TabIndex = 3;
			this.Label9.Text = "Mobile:";
			this.Button2.BackColor = Color.MediumSeaGreen;
			this.Button2.FlatStyle = FlatStyle.Flat;
			this.Button2.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Button2.ForeColor = Color.White;
			Control button5 = this.Button2;
			point = new Point(452, 22);
			button5.Location = point;
			this.Button2.Name = "Button2";
			Control button6 = this.Button2;
			size = new Size(72, 61);
			button6.Size = size;
			this.Button2.TabIndex = 24;
			this.Button2.Text = "Save";
			this.Button2.UseVisualStyleBackColor = false;
			this.Label8.AutoSize = true;
			this.Label8.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Label8.ForeColor = Color.Black;
			Control label25 = this.Label8;
			point = new Point(6, 43);
			label25.Location = point;
			this.Label8.Name = "Label8";
			Control label26 = this.Label8;
			size = new Size(59, 19);
			label26.Size = size;
			this.Label8.TabIndex = 2;
			this.Label8.Text = "Name:";
			this.AddDriverMobileTextBox.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control addDriverMobileTextBox = this.AddDriverMobileTextBox;
			point = new Point(290, 32);
			addDriverMobileTextBox.Location = point;
			this.AddDriverMobileTextBox.Name = "AddDriverMobileTextBox";
			Control addDriverMobileTextBox2 = this.AddDriverMobileTextBox;
			size = new Size(156, 35);
			addDriverMobileTextBox2.Size = size;
			this.AddDriverMobileTextBox.TabIndex = 1;
			this.AddDriverNameTextBox.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control addDriverNameTextBox = this.AddDriverNameTextBox;
			point = new Point(65, 32);
			addDriverNameTextBox.Location = point;
			this.AddDriverNameTextBox.Name = "AddDriverNameTextBox";
			Control addDriverNameTextBox2 = this.AddDriverNameTextBox;
			size = new Size(156, 35);
			addDriverNameTextBox2.Size = size;
			this.AddDriverNameTextBox.TabIndex = 0;
			this.GroupBox5.Controls.Add(this.DriversListBox);
			this.GroupBox5.Dock = DockStyle.Left;
			this.GroupBox5.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.GroupBox5.ForeColor = Color.Crimson;
			Control groupBox5 = this.GroupBox5;
			point = new Point(3, 3);
			groupBox5.Location = point;
			Control groupBox6 = this.GroupBox5;
			padding = new Padding(10);
			groupBox6.Margin = padding;
			this.GroupBox5.Name = "GroupBox5";
			Control groupBox7 = this.GroupBox5;
			padding = new Padding(20, 10, 20, 10);
			groupBox7.Padding = padding;
			Control groupBox8 = this.GroupBox5;
			size = new Size(411, 618);
			groupBox8.Size = size;
			this.GroupBox5.TabIndex = 26;
			this.GroupBox5.TabStop = false;
			this.GroupBox5.Text = "Drivers";
			this.DriversListBox.BorderStyle = BorderStyle.FixedSingle;
			this.DriversListBox.Dock = DockStyle.Fill;
			this.DriversListBox.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DriversListBox.FormattingEnabled = true;
			this.DriversListBox.ItemHeight = 32;
			Control driversListBox = this.DriversListBox;
			point = new Point(20, 32);
			driversListBox.Location = point;
			Control driversListBox2 = this.DriversListBox;
			padding = new Padding(10);
			driversListBox2.Margin = padding;
			this.DriversListBox.Name = "DriversListBox";
			this.DriversListBox.SelectionMode = SelectionMode.None;
			Control driversListBox3 = this.DriversListBox;
			size = new Size(371, 546);
			driversListBox3.Size = size;
			this.DriversListBox.TabIndex = 29;
			this.TabPage1.Controls.Add(this.Button11);
			this.TabPage1.Controls.Add(this.ExportCustomersTXT);
			this.TabPage1.Controls.Add(this.ExportCustomersCSV);
			this.TabPage1.Controls.Add(this.Button10);
			this.TabPage1.Controls.Add(this.MenuBTN);
			this.TabPage1.Controls.Add(this.GroupBox3);
			this.TabPage1.Controls.Add(this.GroupBox2);
			this.TabPage1.Controls.Add(this.GroupBox1);
			this.TabPage1.Controls.Add(this.PrinterGroupBox);
			this.TabPage1.Controls.Add(this.UpdateBTN);
			this.TabPage1.Controls.Add(this.ResetToFactoryBTM);
			TabPage tabPage = this.TabPage1;
			point = new Point(4, 49);
			tabPage.Location = point;
			this.TabPage1.Name = "TabPage1";
			Control tabPage2 = this.TabPage1;
			padding = new Padding(3);
			tabPage2.Padding = padding;
			Control tabPage3 = this.TabPage1;
			size = new Size(1292, 624);
			tabPage3.Size = size;
			this.TabPage1.TabIndex = 3;
			this.TabPage1.Text = "Advanced";
			this.TabPage1.UseVisualStyleBackColor = true;
			this.Button11.BackColor = Color.DarkOrchid;
			this.Button11.FlatAppearance.BorderColor = Color.Gainsboro;
			this.Button11.FlatStyle = FlatStyle.Flat;
			this.Button11.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold);
			this.Button11.ForeColor = Color.Snow;
			Control button7 = this.Button11;
			point = new Point(592, 535);
			button7.Location = point;
			this.Button11.Name = "Button11";
			Control button8 = this.Button11;
			size = new Size(322, 65);
			button8.Size = size;
			this.Button11.TabIndex = 63;
			this.Button11.Text = "Edit Customers";
			this.Button11.UseVisualStyleBackColor = false;
			this.ExportCustomersTXT.BackColor = Color.Orange;
			this.ExportCustomersTXT.FlatAppearance.BorderColor = Color.Gainsboro;
			this.ExportCustomersTXT.FlatStyle = FlatStyle.Flat;
			this.ExportCustomersTXT.Font = new Font("Arial Narrow", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.ExportCustomersTXT.ForeColor = Color.Snow;
			Control exportCustomersTXT = this.ExportCustomersTXT;
			point = new Point(756, 459);
			exportCustomersTXT.Location = point;
			this.ExportCustomersTXT.Name = "ExportCustomersTXT";
			Control exportCustomersTXT2 = this.ExportCustomersTXT;
			size = new Size(158, 70);
			exportCustomersTXT2.Size = size;
			this.ExportCustomersTXT.TabIndex = 62;
			this.ExportCustomersTXT.Text = "Export Customers\r\n .txt file";
			this.ExportCustomersTXT.UseVisualStyleBackColor = false;
			this.ExportCustomersCSV.BackColor = Color.Orange;
			this.ExportCustomersCSV.FlatAppearance.BorderColor = Color.Gainsboro;
			this.ExportCustomersCSV.FlatStyle = FlatStyle.Flat;
			this.ExportCustomersCSV.Font = new Font("Arial Narrow", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.ExportCustomersCSV.ForeColor = Color.Snow;
			Control exportCustomersCSV = this.ExportCustomersCSV;
			point = new Point(592, 459);
			exportCustomersCSV.Location = point;
			this.ExportCustomersCSV.Name = "ExportCustomersCSV";
			Control exportCustomersCSV2 = this.ExportCustomersCSV;
			size = new Size(158, 70);
			exportCustomersCSV2.Size = size;
			this.ExportCustomersCSV.TabIndex = 61;
			this.ExportCustomersCSV.Text = "Export Customers  .csv file";
			this.ExportCustomersCSV.UseVisualStyleBackColor = false;
			this.Button10.BackColor = Color.MediumSlateBlue;
			this.Button10.FlatStyle = FlatStyle.Flat;
			this.Button10.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold);
			this.Button10.ForeColor = Color.WhiteSmoke;
			Control button9 = this.Button10;
			point = new Point(592, 178);
			button9.Location = point;
			this.Button10.Name = "Button10";
			Control button10 = this.Button10;
			size = new Size(322, 67);
			button10.Size = size;
			this.Button10.TabIndex = 60;
			this.Button10.Text = "Uninstall Software";
			this.Button10.UseVisualStyleBackColor = false;
			this.MenuBTN.BackColor = Color.RoyalBlue;
			this.MenuBTN.FlatAppearance.BorderColor = Color.Gainsboro;
			this.MenuBTN.FlatStyle = FlatStyle.Flat;
			this.MenuBTN.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold);
			this.MenuBTN.ForeColor = Color.Snow;
			Control menuBTN = this.MenuBTN;
			point = new Point(592, 380);
			menuBTN.Location = point;
			this.MenuBTN.Name = "MenuBTN";
			Control menuBTN2 = this.MenuBTN;
			size = new Size(322, 73);
			menuBTN2.Size = size;
			this.MenuBTN.TabIndex = 59;
			this.MenuBTN.Text = "Enter / Update Menu";
			this.MenuBTN.UseVisualStyleBackColor = false;
			this.GroupBox3.Controls.Add(this.Label34);
			this.GroupBox3.Controls.Add(this.Button9);
			this.GroupBox3.Controls.Add(this.ReceiptAdvertTB);
			this.GroupBox3.ForeColor = Color.Crimson;
			Control groupBox9 = this.GroupBox3;
			point = new Point(592, 251);
			groupBox9.Location = point;
			this.GroupBox3.Name = "GroupBox3";
			Control groupBox10 = this.GroupBox3;
			size = new Size(322, 123);
			groupBox10.Size = size;
			this.GroupBox3.TabIndex = 58;
			this.GroupBox3.TabStop = false;
			this.GroupBox3.Text = "Receipt Advertisement";
			this.Label34.AutoSize = true;
			this.Label34.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label34.ForeColor = Color.Black;
			Control label27 = this.Label34;
			point = new Point(6, 26);
			label27.Location = point;
			this.Label34.Name = "Label34";
			Control label28 = this.Label34;
			size = new Size(281, 16);
			label28.Size = size;
			this.Label34.TabIndex = 93;
			this.Label34.Text = "This text will be printed at the bottom of receipt:";
			this.Label34.TextAlign = ContentAlignment.TopCenter;
			this.Button9.Anchor = AnchorStyles.Bottom;
			this.Button9.BackColor = Color.SteelBlue;
			this.Button9.FlatStyle = FlatStyle.Flat;
			this.Button9.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button9.ForeColor = Color.WhiteSmoke;
			Control button11 = this.Button9;
			point = new Point(106, 77);
			button11.Location = point;
			this.Button9.Name = "Button9";
			Control button12 = this.Button9;
			size = new Size(100, 38);
			button12.Size = size;
			this.Button9.TabIndex = 93;
			this.Button9.Text = "Save";
			this.Button9.UseVisualStyleBackColor = false;
			Control receiptAdvertTB = this.ReceiptAdvertTB;
			point = new Point(6, 49);
			receiptAdvertTB.Location = point;
			this.ReceiptAdvertTB.Name = "ReceiptAdvertTB";
			Control receiptAdvertTB2 = this.ReceiptAdvertTB;
			size = new Size(310, 22);
			receiptAdvertTB2.Size = size;
			this.ReceiptAdvertTB.TabIndex = 0;
			this.GroupBox2.Controls.Add(this.fppc9dc);
			this.GroupBox2.Controls.Add(this.fppc8dc);
			this.GroupBox2.Controls.Add(this.fppc7dc);
			this.GroupBox2.Controls.Add(this.fppc9);
			this.GroupBox2.Controls.Add(this.fppc8);
			this.GroupBox2.Controls.Add(this.fppc7);
			this.GroupBox2.Controls.Add(this.OtherDeliveryChargeTextBox);
			this.GroupBox2.Controls.Add(this.Label33);
			this.GroupBox2.Controls.Add(this.Label32);
			this.GroupBox2.Controls.Add(this.fppc6dc);
			this.GroupBox2.Controls.Add(this.fppc5dc);
			this.GroupBox2.Controls.Add(this.fppc4dc);
			this.GroupBox2.Controls.Add(this.fppc3dc);
			this.GroupBox2.Controls.Add(this.fppc2dc);
			this.GroupBox2.Controls.Add(this.fppc1dc);
			this.GroupBox2.Controls.Add(this.fppc6);
			this.GroupBox2.Controls.Add(this.fppc5);
			this.GroupBox2.Controls.Add(this.fppc4);
			this.GroupBox2.Controls.Add(this.fppc3);
			this.GroupBox2.Controls.Add(this.fppc2);
			this.GroupBox2.Controls.Add(this.fppc1);
			this.GroupBox2.Controls.Add(this.Button6);
			this.GroupBox2.Controls.Add(this.DeliveryChargeLBL);
			this.GroupBox2.ForeColor = Color.Crimson;
			Control groupBox11 = this.GroupBox2;
			point = new Point(326, 192);
			groupBox11.Location = point;
			this.GroupBox2.Name = "GroupBox2";
			Control groupBox12 = this.GroupBox2;
			size = new Size(260, 408);
			groupBox12.Size = size;
			this.GroupBox2.TabIndex = 57;
			this.GroupBox2.TabStop = false;
			this.GroupBox2.Text = "Delivery Charges";
			Control fppc9dc = this.fppc9dc;
			point = new Point(153, 286);
			fppc9dc.Location = point;
			this.fppc9dc.Name = "fppc9dc";
			Control fppc9dc2 = this.fppc9dc;
			size = new Size(76, 22);
			fppc9dc2.Size = size;
			this.fppc9dc.TabIndex = 92;
			Control fppc8dc = this.fppc8dc;
			point = new Point(153, 258);
			fppc8dc.Location = point;
			this.fppc8dc.Name = "fppc8dc";
			Control fppc8dc2 = this.fppc8dc;
			size = new Size(76, 22);
			fppc8dc2.Size = size;
			this.fppc8dc.TabIndex = 91;
			Control fppc7dc = this.fppc7dc;
			point = new Point(153, 230);
			fppc7dc.Location = point;
			this.fppc7dc.Name = "fppc7dc";
			Control fppc7dc2 = this.fppc7dc;
			size = new Size(76, 22);
			fppc7dc2.Size = size;
			this.fppc7dc.TabIndex = 90;
			this.fppc9.CharacterCasing = CharacterCasing.Upper;
			Control fppc = this.fppc9;
			point = new Point(22, 285);
			fppc.Location = point;
			this.fppc9.Name = "fppc9";
			Control fppc2 = this.fppc9;
			size = new Size(76, 22);
			fppc2.Size = size;
			this.fppc9.TabIndex = 89;
			this.fppc8.CharacterCasing = CharacterCasing.Upper;
			Control fppc3 = this.fppc8;
			point = new Point(22, 257);
			fppc3.Location = point;
			this.fppc8.Name = "fppc8";
			Control fppc4 = this.fppc8;
			size = new Size(76, 22);
			fppc4.Size = size;
			this.fppc8.TabIndex = 88;
			this.fppc7.CharacterCasing = CharacterCasing.Upper;
			Control fppc5 = this.fppc7;
			point = new Point(22, 229);
			fppc5.Location = point;
			this.fppc7.Name = "fppc7";
			Control fppc6 = this.fppc7;
			size = new Size(76, 22);
			fppc6.Size = size;
			this.fppc7.TabIndex = 87;
			Control otherDeliveryChargeTextBox = this.OtherDeliveryChargeTextBox;
			point = new Point(153, 314);
			otherDeliveryChargeTextBox.Location = point;
			this.OtherDeliveryChargeTextBox.Name = "OtherDeliveryChargeTextBox";
			Control otherDeliveryChargeTextBox2 = this.OtherDeliveryChargeTextBox;
			size = new Size(76, 22);
			otherDeliveryChargeTextBox2.Size = size;
			this.OtherDeliveryChargeTextBox.TabIndex = 86;
			this.Label33.AutoSize = true;
			this.Label33.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label33.ForeColor = Color.Black;
			Control label29 = this.Label33;
			point = new Point(161, 22);
			label29.Location = point;
			this.Label33.Name = "Label33";
			Control label30 = this.Label33;
			size = new Size(58, 32);
			label30.Size = size;
			this.Label33.TabIndex = 85;
			this.Label33.Text = "Delivery\r\nCharge";
			this.Label33.TextAlign = ContentAlignment.TopCenter;
			this.Label32.AutoSize = true;
			this.Label32.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label32.ForeColor = Color.Black;
			Control label31 = this.Label32;
			point = new Point(23, 23);
			label31.Location = point;
			this.Label32.Name = "Label32";
			Control label32 = this.Label32;
			size = new Size(74, 32);
			label32.Size = size;
			this.Label32.TabIndex = 84;
			this.Label32.Text = "First Part of\r\nPostcode";
			this.Label32.TextAlign = ContentAlignment.TopCenter;
			Control fppc6dc = this.fppc6dc;
			point = new Point(153, 202);
			fppc6dc.Location = point;
			this.fppc6dc.Name = "fppc6dc";
			Control fppc6dc2 = this.fppc6dc;
			size = new Size(76, 22);
			fppc6dc2.Size = size;
			this.fppc6dc.TabIndex = 83;
			Control fppc5dc = this.fppc5dc;
			point = new Point(153, 174);
			fppc5dc.Location = point;
			this.fppc5dc.Name = "fppc5dc";
			Control fppc5dc2 = this.fppc5dc;
			size = new Size(76, 22);
			fppc5dc2.Size = size;
			this.fppc5dc.TabIndex = 82;
			Control fppc4dc = this.fppc4dc;
			point = new Point(153, 146);
			fppc4dc.Location = point;
			this.fppc4dc.Name = "fppc4dc";
			Control fppc4dc2 = this.fppc4dc;
			size = new Size(76, 22);
			fppc4dc2.Size = size;
			this.fppc4dc.TabIndex = 81;
			Control fppc3dc = this.fppc3dc;
			point = new Point(153, 118);
			fppc3dc.Location = point;
			this.fppc3dc.Name = "fppc3dc";
			Control fppc3dc2 = this.fppc3dc;
			size = new Size(76, 22);
			fppc3dc2.Size = size;
			this.fppc3dc.TabIndex = 80;
			Control fppc2dc = this.fppc2dc;
			point = new Point(153, 90);
			fppc2dc.Location = point;
			this.fppc2dc.Name = "fppc2dc";
			Control fppc2dc2 = this.fppc2dc;
			size = new Size(76, 22);
			fppc2dc2.Size = size;
			this.fppc2dc.TabIndex = 79;
			Control fppc1dc = this.fppc1dc;
			point = new Point(153, 62);
			fppc1dc.Location = point;
			this.fppc1dc.Name = "fppc1dc";
			Control fppc1dc2 = this.fppc1dc;
			size = new Size(76, 22);
			fppc1dc2.Size = size;
			this.fppc1dc.TabIndex = 78;
			this.fppc6.CharacterCasing = CharacterCasing.Upper;
			Control fppc7 = this.fppc6;
			point = new Point(22, 201);
			fppc7.Location = point;
			this.fppc6.Name = "fppc6";
			Control fppc8 = this.fppc6;
			size = new Size(76, 22);
			fppc8.Size = size;
			this.fppc6.TabIndex = 77;
			this.fppc5.CharacterCasing = CharacterCasing.Upper;
			Control fppc9 = this.fppc5;
			point = new Point(22, 173);
			fppc9.Location = point;
			this.fppc5.Name = "fppc5";
			Control fppc10 = this.fppc5;
			size = new Size(76, 22);
			fppc10.Size = size;
			this.fppc5.TabIndex = 76;
			this.fppc4.CharacterCasing = CharacterCasing.Upper;
			Control fppc11 = this.fppc4;
			point = new Point(22, 145);
			fppc11.Location = point;
			this.fppc4.Name = "fppc4";
			Control fppc12 = this.fppc4;
			size = new Size(76, 22);
			fppc12.Size = size;
			this.fppc4.TabIndex = 75;
			this.fppc3.CharacterCasing = CharacterCasing.Upper;
			Control fppc13 = this.fppc3;
			point = new Point(22, 117);
			fppc13.Location = point;
			this.fppc3.Name = "fppc3";
			Control fppc14 = this.fppc3;
			size = new Size(76, 22);
			fppc14.Size = size;
			this.fppc3.TabIndex = 74;
			this.fppc2.CharacterCasing = CharacterCasing.Upper;
			Control fppc15 = this.fppc2;
			point = new Point(22, 89);
			fppc15.Location = point;
			this.fppc2.Name = "fppc2";
			Control fppc16 = this.fppc2;
			size = new Size(76, 22);
			fppc16.Size = size;
			this.fppc2.TabIndex = 73;
			this.fppc1.CharacterCasing = CharacterCasing.Upper;
			Control fppc17 = this.fppc1;
			point = new Point(22, 61);
			fppc17.Location = point;
			this.fppc1.Name = "fppc1";
			Control fppc18 = this.fppc1;
			size = new Size(76, 22);
			fppc18.Size = size;
			this.fppc1.TabIndex = 72;
			this.Button6.Anchor = AnchorStyles.Bottom;
			this.Button6.BackColor = Color.SteelBlue;
			this.Button6.FlatStyle = FlatStyle.Flat;
			this.Button6.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button6.ForeColor = Color.WhiteSmoke;
			Control button13 = this.Button6;
			point = new Point(63, 350);
			button13.Location = point;
			this.Button6.Name = "Button6";
			Control button14 = this.Button6;
			size = new Size(123, 52);
			button14.Size = size;
			this.Button6.TabIndex = 71;
			this.Button6.Text = "Save";
			this.Button6.UseVisualStyleBackColor = false;
			this.DeliveryChargeLBL.AutoSize = true;
			this.DeliveryChargeLBL.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.DeliveryChargeLBL.ForeColor = Color.Black;
			Control deliveryChargeLBL = this.DeliveryChargeLBL;
			point = new Point(18, 317);
			deliveryChargeLBL.Location = point;
			this.DeliveryChargeLBL.Name = "DeliveryChargeLBL";
			Control deliveryChargeLBL2 = this.DeliveryChargeLBL;
			size = new Size(108, 16);
			deliveryChargeLBL2.Size = size;
			this.DeliveryChargeLBL.TabIndex = 56;
			this.DeliveryChargeLBL.Text = "Other Postcodes";
			this.DeliveryChargeLBL.Visible = false;
			this.GroupBox1.Controls.Add(this.Label30);
			this.GroupBox1.Controls.Add(this.CallerIdComboBox1);
			this.GroupBox1.Controls.Add(this.AutoCompleteLBL);
			this.GroupBox1.Controls.Add(this.CallerIDLBL);
			this.GroupBox1.Controls.Add(this.AutoCompleteOrderTextBox);
			this.GroupBox1.ForeColor = Color.Crimson;
			Control groupBox13 = this.GroupBox1;
			point = new Point(326, 26);
			groupBox13.Location = point;
			this.GroupBox1.Name = "GroupBox1";
			Control groupBox14 = this.GroupBox1;
			size = new Size(260, 150);
			groupBox14.Size = size;
			this.GroupBox1.TabIndex = 56;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "Other Settings";
			this.Label30.AutoSize = true;
			this.Label30.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label30.ForeColor = Color.Black;
			Control label33 = this.Label30;
			point = new Point(217, 104);
			label33.Location = point;
			this.Label30.Name = "Label30";
			Control label34 = this.Label30;
			size = new Size(33, 18);
			label34.Size = size;
			this.Label30.TabIndex = 57;
			this.Label30.Text = "Min";
			this.Label30.Visible = false;
			this.CallerIdComboBox1.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.CallerIdComboBox1.FormattingEnabled = true;
			this.CallerIdComboBox1.Items.AddRange(new object[]
			{
				"",
				"ARTECH AD102"
			});
			Control callerIdComboBox = this.CallerIdComboBox1;
			point = new Point(93, 44);
			callerIdComboBox.Location = point;
			this.CallerIdComboBox1.Name = "CallerIdComboBox1";
			Control callerIdComboBox2 = this.CallerIdComboBox1;
			size = new Size(148, 26);
			callerIdComboBox2.Size = size;
			this.CallerIdComboBox1.TabIndex = 53;
			this.CallerIdComboBox1.Visible = false;
			this.AutoCompleteLBL.AutoSize = true;
			this.AutoCompleteLBL.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.AutoCompleteLBL.ForeColor = Color.Black;
			Control autoCompleteLBL = this.AutoCompleteLBL;
			point = new Point(19, 104);
			autoCompleteLBL.Location = point;
			this.AutoCompleteLBL.Name = "AutoCompleteLBL";
			Control autoCompleteLBL2 = this.AutoCompleteLBL;
			size = new Size(156, 18);
			autoCompleteLBL2.Size = size;
			this.AutoCompleteLBL.TabIndex = 51;
			this.AutoCompleteLBL.Text = "Auto Complete Order";
			this.AutoCompleteLBL.Visible = false;
			this.CallerIDLBL.AutoSize = true;
			this.CallerIDLBL.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.CallerIDLBL.ForeColor = Color.Black;
			Control callerIDLBL = this.CallerIDLBL;
			point = new Point(19, 47);
			callerIDLBL.Location = point;
			this.CallerIDLBL.Name = "CallerIDLBL";
			Control callerIDLBL2 = this.CallerIDLBL;
			size = new Size(68, 18);
			callerIDLBL2.Size = size;
			this.CallerIDLBL.TabIndex = 54;
			this.CallerIDLBL.Text = "Caller ID";
			this.CallerIDLBL.Visible = false;
			this.AutoCompleteOrderTextBox.Font = new Font("Arial", 14.25f);
			Control autoCompleteOrderTextBox = this.AutoCompleteOrderTextBox;
			point = new Point(180, 98);
			autoCompleteOrderTextBox.Location = point;
			this.AutoCompleteOrderTextBox.Name = "AutoCompleteOrderTextBox";
			Control autoCompleteOrderTextBox2 = this.AutoCompleteOrderTextBox;
			size = new Size(31, 29);
			autoCompleteOrderTextBox2.Size = size;
			this.AutoCompleteOrderTextBox.TabIndex = 52;
			this.AutoCompleteOrderTextBox.Visible = false;
			this.PrinterGroupBox.Controls.Add(this.Label31);
			this.PrinterGroupBox.Controls.Add(this.Label29);
			this.PrinterGroupBox.Controls.Add(this.Printer2ComboBox);
			this.PrinterGroupBox.Controls.Add(this.Label28);
			this.PrinterGroupBox.Controls.Add(this.Printer1ComboBox);
			this.PrinterGroupBox.Controls.Add(this.CommentFontSieTextBox);
			this.PrinterGroupBox.Controls.Add(this.Label26);
			this.PrinterGroupBox.Controls.Add(this.Label25);
			this.PrinterGroupBox.Controls.Add(this.PrintersComboBox);
			this.PrinterGroupBox.Controls.Add(this.Button8);
			this.PrinterGroupBox.Controls.Add(this.Button7);
			this.PrinterGroupBox.Controls.Add(this.NumberOfPrintLabel);
			this.PrinterGroupBox.Controls.Add(this.OrderFontSizeTextBox);
			this.PrinterGroupBox.Controls.Add(this.NumberOfPrintTextBox);
			this.PrinterGroupBox.Controls.Add(this.Label16);
			this.PrinterGroupBox.Controls.Add(this.Label17);
			this.PrinterGroupBox.Controls.Add(this.OrderLineSpaceTextBox);
			this.PrinterGroupBox.Controls.Add(this.MyPrinterFontType);
			this.PrinterGroupBox.Controls.Add(this.Label24);
			this.PrinterGroupBox.Controls.Add(this.Label18);
			this.PrinterGroupBox.Controls.Add(this.FoodLeftAtTextBox);
			this.PrinterGroupBox.Controls.Add(this.SecondLinesSpaceTextBox);
			this.PrinterGroupBox.Controls.Add(this.Label19);
			this.PrinterGroupBox.Controls.Add(this.Label22);
			this.PrinterGroupBox.Controls.Add(this.PriceLeftAtTextBox);
			this.PrinterGroupBox.Controls.Add(this.FoodMaxLenTextBox);
			this.PrinterGroupBox.Controls.Add(this.Label23);
			this.PrinterGroupBox.ForeColor = Color.Crimson;
			Control printerGroupBox = this.PrinterGroupBox;
			point = new Point(22, 26);
			printerGroupBox.Location = point;
			this.PrinterGroupBox.Name = "PrinterGroupBox";
			Control printerGroupBox2 = this.PrinterGroupBox;
			size = new Size(285, 574);
			printerGroupBox2.Size = size;
			this.PrinterGroupBox.TabIndex = 55;
			this.PrinterGroupBox.TabStop = false;
			this.PrinterGroupBox.Text = "Printer Settings";
			this.Label31.AutoSize = true;
			this.Label31.Font = new Font("Arial", 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label31.ForeColor = Color.RoyalBlue;
			Control label35 = this.Label31;
			point = new Point(128, 35);
			label35.Location = point;
			this.Label31.Name = "Label31";
			Control label36 = this.Label31;
			size = new Size(86, 16);
			label36.Size = size;
			this.Label31.TabIndex = 70;
			this.Label31.Text = "(Main Printer)";
			this.Label29.AutoSize = true;
			this.Label29.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label29.ForeColor = Color.Black;
			Control label37 = this.Label29;
			point = new Point(31, 146);
			label37.Location = point;
			this.Label29.Name = "Label29";
			Control label38 = this.Label29;
			size = new Size(67, 18);
			label38.Size = size;
			this.Label29.TabIndex = 69;
			this.Label29.Text = "Printer 2";
			this.Printer2ComboBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Printer2ComboBox.FormattingEnabled = true;
			Control printer2ComboBox = this.Printer2ComboBox;
			point = new Point(104, 140);
			printer2ComboBox.Location = point;
			this.Printer2ComboBox.Name = "Printer2ComboBox";
			Control printer2ComboBox2 = this.Printer2ComboBox;
			size = new Size(158, 30);
			printer2ComboBox2.Size = size;
			this.Printer2ComboBox.TabIndex = 68;
			this.Label28.AutoSize = true;
			this.Label28.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label28.ForeColor = Color.Black;
			Control label39 = this.Label28;
			point = new Point(31, 110);
			label39.Location = point;
			this.Label28.Name = "Label28";
			Control label40 = this.Label28;
			size = new Size(67, 18);
			label40.Size = size;
			this.Label28.TabIndex = 67;
			this.Label28.Text = "Printer 1";
			this.Printer1ComboBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Printer1ComboBox.FormattingEnabled = true;
			Control printer1ComboBox = this.Printer1ComboBox;
			point = new Point(104, 104);
			printer1ComboBox.Location = point;
			this.Printer1ComboBox.Name = "Printer1ComboBox";
			Control printer1ComboBox2 = this.Printer1ComboBox;
			size = new Size(158, 30);
			printer1ComboBox2.Size = size;
			this.Printer1ComboBox.TabIndex = 66;
			this.CommentFontSieTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control commentFontSieTextBox = this.CommentFontSieTextBox;
			point = new Point(203, 354);
			commentFontSieTextBox.Location = point;
			this.CommentFontSieTextBox.Name = "CommentFontSieTextBox";
			Control commentFontSieTextBox2 = this.CommentFontSieTextBox;
			size = new Size(35, 26);
			commentFontSieTextBox2.Size = size;
			this.CommentFontSieTextBox.TabIndex = 65;
			this.CommentFontSieTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label26.AutoSize = true;
			this.Label26.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label26.ForeColor = Color.Black;
			Control label41 = this.Label26;
			point = new Point(44, 357);
			label41.Location = point;
			this.Label26.Name = "Label26";
			Control label42 = this.Label26;
			size = new Size(146, 18);
			label42.Size = size;
			this.Label26.TabIndex = 64;
			this.Label26.Text = "Comment Font Size";
			this.Label25.AutoSize = true;
			this.Label25.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label25.ForeColor = Color.Black;
			Control label43 = this.Label25;
			point = new Point(6, 74);
			label43.Location = point;
			this.Label25.Name = "Label25";
			Control label44 = this.Label25;
			size = new Size(92, 18);
			label44.Size = size;
			this.Label25.TabIndex = 63;
			this.Label25.Text = "Main Printer";
			this.PrintersComboBox.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.PrintersComboBox.FormattingEnabled = true;
			Control printersComboBox = this.PrintersComboBox;
			point = new Point(104, 68);
			printersComboBox.Location = point;
			this.PrintersComboBox.Name = "PrintersComboBox";
			Control printersComboBox2 = this.PrintersComboBox;
			size = new Size(158, 30);
			printersComboBox2.Size = size;
			this.PrintersComboBox.TabIndex = 62;
			this.Button8.Anchor = AnchorStyles.Bottom;
			this.Button8.BackColor = Color.SteelBlue;
			this.Button8.FlatStyle = FlatStyle.Flat;
			this.Button8.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button8.ForeColor = Color.WhiteSmoke;
			Control button15 = this.Button8;
			point = new Point(156, 516);
			button15.Location = point;
			this.Button8.Name = "Button8";
			Control button16 = this.Button8;
			size = new Size(123, 52);
			button16.Size = size;
			this.Button8.TabIndex = 58;
			this.Button8.Text = "Save";
			this.Button8.UseVisualStyleBackColor = false;
			this.Button7.Anchor = AnchorStyles.Bottom;
			this.Button7.BackColor = Color.SteelBlue;
			this.Button7.FlatStyle = FlatStyle.Flat;
			this.Button7.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Button7.ForeColor = Color.WhiteSmoke;
			Control button17 = this.Button7;
			point = new Point(6, 516);
			button17.Location = point;
			this.Button7.Name = "Button7";
			Control button18 = this.Button7;
			size = new Size(141, 52);
			button18.Size = size;
			this.Button7.TabIndex = 59;
			this.Button7.Text = "Set to Default";
			this.Button7.UseVisualStyleBackColor = false;
			this.NumberOfPrintLabel.AutoSize = true;
			this.NumberOfPrintLabel.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.NumberOfPrintLabel.ForeColor = Color.Black;
			Control numberOfPrintLabel = this.NumberOfPrintLabel;
			point = new Point(6, 33);
			numberOfPrintLabel.Location = point;
			this.NumberOfPrintLabel.Name = "NumberOfPrintLabel";
			Control numberOfPrintLabel2 = this.NumberOfPrintLabel;
			size = new Size(124, 18);
			numberOfPrintLabel2.Size = size;
			this.NumberOfPrintLabel.TabIndex = 60;
			this.NumberOfPrintLabel.Text = "Number of Prints";
			this.OrderFontSizeTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control orderFontSizeTextBox = this.OrderFontSizeTextBox;
			point = new Point(203, 226);
			orderFontSizeTextBox.Location = point;
			this.OrderFontSizeTextBox.Name = "OrderFontSizeTextBox";
			Control orderFontSizeTextBox2 = this.OrderFontSizeTextBox;
			size = new Size(35, 26);
			orderFontSizeTextBox2.Size = size;
			this.OrderFontSizeTextBox.TabIndex = 28;
			this.OrderFontSizeTextBox.TextAlign = HorizontalAlignment.Center;
			this.NumberOfPrintTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control numberOfPrintTextBox = this.NumberOfPrintTextBox;
			point = new Point(227, 30);
			numberOfPrintTextBox.Location = point;
			this.NumberOfPrintTextBox.Name = "NumberOfPrintTextBox";
			Control numberOfPrintTextBox2 = this.NumberOfPrintTextBox;
			size = new Size(35, 26);
			numberOfPrintTextBox2.Size = size;
			this.NumberOfPrintTextBox.TabIndex = 61;
			this.NumberOfPrintTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label16.AutoSize = true;
			this.Label16.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label16.ForeColor = Color.Black;
			Control label45 = this.Label16;
			point = new Point(72, 229);
			label45.Location = point;
			this.Label16.Name = "Label16";
			Control label46 = this.Label16;
			size = new Size(118, 18);
			label46.Size = size;
			this.Label16.TabIndex = 27;
			this.Label16.Text = "Order Font Size";
			this.Label17.AutoSize = true;
			this.Label17.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label17.ForeColor = Color.Black;
			Control label47 = this.Label17;
			point = new Point(58, 389);
			label47.Location = point;
			this.Label17.Name = "Label17";
			Control label48 = this.Label17;
			size = new Size(132, 18);
			label48.Size = size;
			this.Label17.TabIndex = 29;
			this.Label17.Text = "Order Line Space";
			this.OrderLineSpaceTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control orderLineSpaceTextBox = this.OrderLineSpaceTextBox;
			point = new Point(203, 386);
			orderLineSpaceTextBox.Location = point;
			this.OrderLineSpaceTextBox.Name = "OrderLineSpaceTextBox";
			Control orderLineSpaceTextBox2 = this.OrderLineSpaceTextBox;
			size = new Size(35, 26);
			orderLineSpaceTextBox2.Size = size;
			this.OrderLineSpaceTextBox.TabIndex = 30;
			this.OrderLineSpaceTextBox.TextAlign = HorizontalAlignment.Center;
			this.MyPrinterFontType.Font = new Font("Arial", 14.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.MyPrinterFontType.ForeColor = Color.Black;
			this.MyPrinterFontType.FormattingEnabled = true;
			this.MyPrinterFontType.Items.AddRange(new object[]
			{
				"Arial",
				"Times New Roman",
				"Century Gothic",
				"Bahnschrift",
				"Book Antiqua",
				"Calisto MT",
				"Cambria",
				"Candara",
				"Franklin Gothic"
			});
			Control myPrinterFontType = this.MyPrinterFontType;
			point = new Point(95, 182);
			myPrinterFontType.Location = point;
			this.MyPrinterFontType.Name = "MyPrinterFontType";
			Control myPrinterFontType2 = this.MyPrinterFontType;
			size = new Size(167, 30);
			myPrinterFontType2.Size = size;
			this.MyPrinterFontType.TabIndex = 57;
			this.Label24.AutoSize = true;
			this.Label24.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label24.ForeColor = Color.Black;
			Control label49 = this.Label24;
			point = new Point(6, 188);
			label49.Location = point;
			this.Label24.Name = "Label24";
			Control label50 = this.Label24;
			size = new Size(83, 18);
			label50.Size = size;
			this.Label24.TabIndex = 56;
			this.Label24.Text = "Order Font";
			this.Label18.AutoSize = true;
			this.Label18.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label18.ForeColor = Color.Black;
			Control label51 = this.Label18;
			point = new Point(49, 261);
			label51.Location = point;
			this.Label18.Name = "Label18";
			Control label52 = this.Label18;
			size = new Size(141, 18);
			label52.Size = size;
			this.Label18.TabIndex = 31;
			this.Label18.Text = "Food Name Left @";
			this.FoodLeftAtTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control foodLeftAtTextBox = this.FoodLeftAtTextBox;
			point = new Point(203, 258);
			foodLeftAtTextBox.Location = point;
			this.FoodLeftAtTextBox.Name = "FoodLeftAtTextBox";
			Control foodLeftAtTextBox2 = this.FoodLeftAtTextBox;
			size = new Size(35, 26);
			foodLeftAtTextBox2.Size = size;
			this.FoodLeftAtTextBox.TabIndex = 32;
			this.FoodLeftAtTextBox.TextAlign = HorizontalAlignment.Center;
			this.SecondLinesSpaceTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control secondLinesSpaceTextBox = this.SecondLinesSpaceTextBox;
			point = new Point(203, 418);
			secondLinesSpaceTextBox.Location = point;
			this.SecondLinesSpaceTextBox.Name = "SecondLinesSpaceTextBox";
			Control secondLinesSpaceTextBox2 = this.SecondLinesSpaceTextBox;
			size = new Size(35, 26);
			secondLinesSpaceTextBox2.Size = size;
			this.SecondLinesSpaceTextBox.TabIndex = 38;
			this.SecondLinesSpaceTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label19.AutoSize = true;
			this.Label19.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label19.ForeColor = Color.Black;
			Control label53 = this.Label19;
			point = new Point(54, 293);
			label53.Location = point;
			this.Label19.Name = "Label19";
			Control label54 = this.Label19;
			size = new Size(136, 18);
			label54.Size = size;
			this.Label19.TabIndex = 33;
			this.Label19.Text = "Food Price Left @";
			this.Label22.AutoSize = true;
			this.Label22.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label22.ForeColor = Color.Black;
			Control label55 = this.Label22;
			point = new Point(31, 421);
			label55.Location = point;
			this.Label22.Name = "Label22";
			Control label56 = this.Label22;
			size = new Size(159, 18);
			label56.Size = size;
			this.Label22.TabIndex = 37;
			this.Label22.Text = "Food 2nd Line Space";
			this.PriceLeftAtTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control priceLeftAtTextBox = this.PriceLeftAtTextBox;
			point = new Point(203, 290);
			priceLeftAtTextBox.Location = point;
			this.PriceLeftAtTextBox.Name = "PriceLeftAtTextBox";
			Control priceLeftAtTextBox2 = this.PriceLeftAtTextBox;
			size = new Size(35, 26);
			priceLeftAtTextBox2.Size = size;
			this.PriceLeftAtTextBox.TabIndex = 34;
			this.PriceLeftAtTextBox.TextAlign = HorizontalAlignment.Center;
			this.FoodMaxLenTextBox.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			Control foodMaxLenTextBox = this.FoodMaxLenTextBox;
			point = new Point(203, 322);
			foodMaxLenTextBox.Location = point;
			this.FoodMaxLenTextBox.Name = "FoodMaxLenTextBox";
			Control foodMaxLenTextBox2 = this.FoodMaxLenTextBox;
			size = new Size(35, 26);
			foodMaxLenTextBox2.Size = size;
			this.FoodMaxLenTextBox.TabIndex = 36;
			this.FoodMaxLenTextBox.TextAlign = HorizontalAlignment.Center;
			this.Label23.AutoSize = true;
			this.Label23.Font = new Font("Arial", 12f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label23.ForeColor = Color.Black;
			Control label57 = this.Label23;
			point = new Point(57, 325);
			label57.Location = point;
			this.Label23.Name = "Label23";
			Control label58 = this.Label23;
			size = new Size(133, 18);
			label58.Size = size;
			this.Label23.TabIndex = 35;
			this.Label23.Text = "Food Max. Length";
			this.UpdateBTN.BackColor = Color.Orange;
			this.UpdateBTN.FlatStyle = FlatStyle.Flat;
			this.UpdateBTN.Font = new Font("Arial", 14.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.UpdateBTN.ForeColor = Color.White;
			Control updateBTN = this.UpdateBTN;
			point = new Point(592, 34);
			updateBTN.Location = point;
			this.UpdateBTN.Name = "UpdateBTN";
			Control updateBTN2 = this.UpdateBTN;
			size = new Size(322, 67);
			updateBTN2.Size = size;
			this.UpdateBTN.TabIndex = 50;
			this.UpdateBTN.Text = "Update Software";
			this.UpdateBTN.UseVisualStyleBackColor = false;
			this.UpdateBTN.Visible = false;
			this.ResetToFactoryBTM.BackColor = Color.Crimson;
			this.ResetToFactoryBTM.FlatStyle = FlatStyle.Flat;
			this.ResetToFactoryBTM.Font = new Font("Microsoft Sans Serif", 14.25f, FontStyle.Bold);
			this.ResetToFactoryBTM.ForeColor = Color.WhiteSmoke;
			Control resetToFactoryBTM = this.ResetToFactoryBTM;
			point = new Point(592, 105);
			resetToFactoryBTM.Location = point;
			this.ResetToFactoryBTM.Name = "ResetToFactoryBTM";
			Control resetToFactoryBTM2 = this.ResetToFactoryBTM;
			size = new Size(322, 67);
			resetToFactoryBTM2.Size = size;
			this.ResetToFactoryBTM.TabIndex = 9;
			this.ResetToFactoryBTM.Text = "Reset to Factory Setting";
			this.ResetToFactoryBTM.UseVisualStyleBackColor = false;
			this.AbolfazlTB.Controls.Add(this.Button5);
			this.AbolfazlTB.Controls.Add(this.PostcodeFinderCheckBox);
			this.AbolfazlTB.Controls.Add(this.OnlineModeCheckBox);
			this.AbolfazlTB.Controls.Add(this.Button1);
			this.AbolfazlTB.Controls.Add(this.GroupBox8);
			this.AbolfazlTB.Controls.Add(this.Label7);
			this.AbolfazlTB.Controls.Add(this.CallerIdComboBox);
			TabPage abolfazlTB = this.AbolfazlTB;
			point = new Point(4, 49);
			abolfazlTB.Location = point;
			this.AbolfazlTB.Name = "AbolfazlTB";
			Control abolfazlTB2 = this.AbolfazlTB;
			padding = new Padding(3);
			abolfazlTB2.Padding = padding;
			Control abolfazlTB3 = this.AbolfazlTB;
			size = new Size(1292, 624);
			abolfazlTB3.Size = size;
			this.AbolfazlTB.TabIndex = 1;
			this.AbolfazlTB.Text = "Abolfazl";
			this.AbolfazlTB.UseVisualStyleBackColor = true;
			Control button19 = this.Button5;
			point = new Point(545, 121);
			button19.Location = point;
			this.Button5.Name = "Button5";
			Control button20 = this.Button5;
			size = new Size(151, 55);
			button20.Size = size;
			this.Button5.TabIndex = 15;
			this.Button5.Text = "Button5";
			this.Button5.UseVisualStyleBackColor = true;
			this.PostcodeFinderCheckBox.AutoSize = true;
			this.PostcodeFinderCheckBox.Font = new Font("Arial", 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control postcodeFinderCheckBox3 = this.PostcodeFinderCheckBox;
			point = new Point(483, 27);
			postcodeFinderCheckBox3.Location = point;
			this.PostcodeFinderCheckBox.Name = "PostcodeFinderCheckBox";
			Control postcodeFinderCheckBox4 = this.PostcodeFinderCheckBox;
			size = new Size(154, 23);
			postcodeFinderCheckBox4.Size = size;
			this.PostcodeFinderCheckBox.TabIndex = 14;
			this.PostcodeFinderCheckBox.Text = "Postcode Finder";
			this.PostcodeFinderCheckBox.UseVisualStyleBackColor = true;
			this.OnlineModeCheckBox.AutoSize = true;
			this.OnlineModeCheckBox.Font = new Font("Arial", 12f, FontStyle.Bold);
			Control onlineModeCheckBox = this.OnlineModeCheckBox;
			point = new Point(335, 29);
			onlineModeCheckBox.Location = point;
			this.OnlineModeCheckBox.Name = "OnlineModeCheckBox";
			Control onlineModeCheckBox2 = this.OnlineModeCheckBox;
			size = new Size(123, 23);
			onlineModeCheckBox2.Size = size;
			this.OnlineModeCheckBox.TabIndex = 9;
			this.OnlineModeCheckBox.Text = "Online Mode";
			this.OnlineModeCheckBox.UseVisualStyleBackColor = true;
			Control button21 = this.Button1;
			point = new Point(31, 298);
			button21.Location = point;
			this.Button1.Name = "Button1";
			Control button22 = this.Button1;
			size = new Size(322, 73);
			button22.Size = size;
			this.Button1.TabIndex = 8;
			this.Button1.Text = "Reset to Factory Setting";
			this.Button1.UseVisualStyleBackColor = true;
			this.GroupBox8.Controls.Add(this.FTPpingBTN);
			this.GroupBox8.Controls.Add(this.SoftwareDomainTextBox);
			this.GroupBox8.Controls.Add(this.Label15);
			this.GroupBox8.Controls.Add(this.FTPPasswordTextBox);
			this.GroupBox8.Controls.Add(this.FTPUsernameTextBox);
			this.GroupBox8.Controls.Add(this.Label14);
			this.GroupBox8.Controls.Add(this.Label13);
			this.GroupBox8.Controls.Add(this.FTPsaveBTN);
			Control groupBox15 = this.GroupBox8;
			point = new Point(28, 86);
			groupBox15.Location = point;
			this.GroupBox8.Name = "GroupBox8";
			Control groupBox16 = this.GroupBox8;
			size = new Size(325, 190);
			groupBox16.Size = size;
			this.GroupBox8.TabIndex = 7;
			this.GroupBox8.TabStop = false;
			this.GroupBox8.Text = "FTP";
			this.FTPpingBTN.BackColor = Color.FromArgb(255, 128, 128);
			this.FTPpingBTN.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control ftppingBTN = this.FTPpingBTN;
			point = new Point(6, 138);
			ftppingBTN.Location = point;
			this.FTPpingBTN.Name = "FTPpingBTN";
			Control ftppingBTN2 = this.FTPpingBTN;
			size = new Size(114, 46);
			ftppingBTN2.Size = size;
			this.FTPpingBTN.TabIndex = 12;
			this.FTPpingBTN.Text = "Ping";
			this.FTPpingBTN.UseVisualStyleBackColor = false;
			this.SoftwareDomainTextBox.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control softwareDomainTextBox = this.SoftwareDomainTextBox;
			point = new Point(88, 40);
			softwareDomainTextBox.Location = point;
			this.SoftwareDomainTextBox.Name = "SoftwareDomainTextBox";
			Control softwareDomainTextBox2 = this.SoftwareDomainTextBox;
			size = new Size(171, 22);
			softwareDomainTextBox2.Size = size;
			this.SoftwareDomainTextBox.TabIndex = 11;
			this.Label15.AutoSize = true;
			this.Label15.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label59 = this.Label15;
			point = new Point(21, 43);
			label59.Location = point;
			this.Label15.Name = "Label15";
			Control label60 = this.Label15;
			size = new Size(57, 16);
			label60.Size = size;
			this.Label15.TabIndex = 10;
			this.Label15.Text = "Domain";
			this.FTPPasswordTextBox.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control ftppasswordTextBox = this.FTPPasswordTextBox;
			point = new Point(88, 98);
			ftppasswordTextBox.Location = point;
			this.FTPPasswordTextBox.Name = "FTPPasswordTextBox";
			this.FTPPasswordTextBox.PasswordChar = '*';
			Control ftppasswordTextBox2 = this.FTPPasswordTextBox;
			size = new Size(171, 22);
			ftppasswordTextBox2.Size = size;
			this.FTPPasswordTextBox.TabIndex = 9;
			this.FTPUsernameTextBox.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control ftpusernameTextBox = this.FTPUsernameTextBox;
			point = new Point(88, 68);
			ftpusernameTextBox.Location = point;
			this.FTPUsernameTextBox.Name = "FTPUsernameTextBox";
			Control ftpusernameTextBox2 = this.FTPUsernameTextBox;
			size = new Size(171, 22);
			ftpusernameTextBox2.Size = size;
			this.FTPUsernameTextBox.TabIndex = 8;
			this.Label14.AutoSize = true;
			this.Label14.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label61 = this.Label14;
			point = new Point(9, 101);
			label61.Location = point;
			this.Label14.Name = "Label14";
			Control label62 = this.Label14;
			size = new Size(69, 16);
			label62.Size = size;
			this.Label14.TabIndex = 7;
			this.Label14.Text = "Password";
			this.Label13.AutoSize = true;
			this.Label13.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control label63 = this.Label13;
			point = new Point(6, 71);
			label63.Location = point;
			this.Label13.Name = "Label13";
			Control label64 = this.Label13;
			size = new Size(72, 16);
			label64.Size = size;
			this.Label13.TabIndex = 6;
			this.Label13.Text = "Username";
			this.FTPsaveBTN.Font = new Font("Arial", 9.75f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control ftpsaveBTN = this.FTPsaveBTN;
			point = new Point(205, 138);
			ftpsaveBTN.Location = point;
			this.FTPsaveBTN.Name = "FTPsaveBTN";
			Control ftpsaveBTN2 = this.FTPsaveBTN;
			size = new Size(114, 46);
			ftpsaveBTN2.Size = size;
			this.FTPsaveBTN.TabIndex = 5;
			this.FTPsaveBTN.Text = "Save";
			this.FTPsaveBTN.UseVisualStyleBackColor = true;
			this.Label7.AutoSize = true;
			Control label65 = this.Label7;
			point = new Point(24, 25);
			label65.Location = point;
			this.Label7.Name = "Label7";
			Control label66 = this.Label7;
			size = new Size(59, 16);
			label66.Size = size;
			this.Label7.TabIndex = 4;
			this.Label7.Text = "Caller ID";
			this.CallerIdComboBox.FormattingEnabled = true;
			this.CallerIdComboBox.Items.AddRange(new object[]
			{
				"",
				"ARTECH AD102"
			});
			Control callerIdComboBox3 = this.CallerIdComboBox;
			point = new Point(116, 22);
			callerIdComboBox3.Location = point;
			this.CallerIdComboBox.Name = "CallerIdComboBox";
			Control callerIdComboBox4 = this.CallerIdComboBox;
			size = new Size(171, 24);
			callerIdComboBox4.Size = size;
			this.CallerIdComboBox.TabIndex = 3;
			this.SaveExitPanel.Controls.Add(this.ExitBTN);
			this.SaveExitPanel.Controls.Add(this.UploadDownloadProgressBar);
			this.SaveExitPanel.Dock = DockStyle.Bottom;
			Control saveExitPanel = this.SaveExitPanel;
			point = new Point(0, 677);
			saveExitPanel.Location = point;
			this.SaveExitPanel.Name = "SaveExitPanel";
			Control saveExitPanel2 = this.SaveExitPanel;
			size = new Size(1300, 63);
			saveExitPanel2.Size = size;
			this.SaveExitPanel.TabIndex = 20;
			this.UploadDownloadProgressBar.BackColor = Color.SteelBlue;
			this.UploadDownloadProgressBar.Dock = DockStyle.Fill;
			Control uploadDownloadProgressBar = this.UploadDownloadProgressBar;
			point = new Point(0, 0);
			uploadDownloadProgressBar.Location = point;
			this.UploadDownloadProgressBar.Name = "UploadDownloadProgressBar";
			Control uploadDownloadProgressBar2 = this.UploadDownloadProgressBar;
			size = new Size(1300, 63);
			uploadDownloadProgressBar2.Size = size;
			this.UploadDownloadProgressBar.Step = 1;
			this.UploadDownloadProgressBar.Style = ProgressBarStyle.Continuous;
			this.UploadDownloadProgressBar.TabIndex = 33;
			this.AdminPanel.Controls.Add(this.AdvancedTP);
			this.AdminPanel.Controls.Add(this.SaveExitPanel);
			this.AdminPanel.Dock = DockStyle.Fill;
			Control adminPanel = this.AdminPanel;
			point = new Point(0, 0);
			adminPanel.Location = point;
			this.AdminPanel.Name = "AdminPanel";
			Control adminPanel2 = this.AdminPanel;
			size = new Size(1300, 740);
			adminPanel2.Size = size;
			this.AdminPanel.TabIndex = 21;
			this.LoginPanel.BackColor = SystemColors.HotTrack;
			this.LoginPanel.Controls.Add(this.KeyboardPanel);
			this.LoginPanel.Controls.Add(this.GroupBox4);
			this.LoginPanel.Dock = DockStyle.Fill;
			Control loginPanel = this.LoginPanel;
			point = new Point(0, 0);
			loginPanel.Location = point;
			this.LoginPanel.Name = "LoginPanel";
			Control loginPanel2 = this.LoginPanel;
			size = new Size(1300, 740);
			loginPanel2.Size = size;
			this.LoginPanel.TabIndex = 5;
			this.KeyboardPanel.Dock = DockStyle.Bottom;
			Control keyboardPanel = this.KeyboardPanel;
			point = new Point(0, 440);
			keyboardPanel.Location = point;
			this.KeyboardPanel.Name = "KeyboardPanel";
			Control keyboardPanel2 = this.KeyboardPanel;
			size = new Size(1300, 300);
			keyboardPanel2.Size = size;
			this.KeyboardPanel.TabIndex = 26;
			this.GroupBox4.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.GroupBox4.Controls.Add(this.UserNameComboBox);
			this.GroupBox4.Controls.Add(this.CancelBTN);
			this.GroupBox4.Controls.Add(this.PasswordTextBox);
			this.GroupBox4.Controls.Add(this.LoginBTN);
			this.GroupBox4.FlatStyle = FlatStyle.Flat;
			this.GroupBox4.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.GroupBox4.ForeColor = SystemColors.ControlLightLight;
			Control groupBox17 = this.GroupBox4;
			point = new Point(132, 58);
			groupBox17.Location = point;
			this.GroupBox4.Name = "GroupBox4";
			Control groupBox18 = this.GroupBox4;
			size = new Size(964, 273);
			groupBox18.Size = size;
			this.GroupBox4.TabIndex = 25;
			this.GroupBox4.TabStop = false;
			this.GroupBox4.Text = "Control Panel";
			this.UserNameComboBox.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.UserNameComboBox.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.UserNameComboBox.FormattingEnabled = true;
			this.UserNameComboBox.Items.AddRange(new object[]
			{
				"STAFF",
				"ADMIN",
				"SHOP OWNER"
			});
			Control userNameComboBox = this.UserNameComboBox;
			point = new Point(41, 50);
			userNameComboBox.Location = point;
			this.UserNameComboBox.Name = "UserNameComboBox";
			Control userNameComboBox2 = this.UserNameComboBox;
			size = new Size(884, 40);
			userNameComboBox2.Size = size;
			this.UserNameComboBox.TabIndex = 0;
			this.CancelBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.CancelBTN.BackColor = Color.Crimson;
			this.CancelBTN.FlatStyle = FlatStyle.Popup;
			this.CancelBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.CancelBTN.ForeColor = Color.White;
			Control cancelBTN = this.CancelBTN;
			point = new Point(41, 179);
			cancelBTN.Location = point;
			this.CancelBTN.Name = "CancelBTN";
			Control cancelBTN2 = this.CancelBTN;
			size = new Size(216, 76);
			cancelBTN2.Size = size;
			this.CancelBTN.TabIndex = 24;
			this.CancelBTN.Text = "Exit";
			this.CancelBTN.UseVisualStyleBackColor = false;
			this.PasswordTextBox.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.PasswordTextBox.Font = new Font("Arial", 20.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			Control passwordTextBox = this.PasswordTextBox;
			point = new Point(41, 108);
			passwordTextBox.Location = point;
			this.PasswordTextBox.Name = "PasswordTextBox";
			this.PasswordTextBox.PasswordChar = '*';
			Control passwordTextBox2 = this.PasswordTextBox;
			size = new Size(884, 39);
			passwordTextBox2.Size = size;
			this.PasswordTextBox.TabIndex = 1;
			this.LoginBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.LoginBTN.BackColor = Color.FromArgb(0, 192, 0);
			this.LoginBTN.FlatStyle = FlatStyle.Popup;
			this.LoginBTN.Font = new Font("Arial", 18f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.LoginBTN.ForeColor = Color.White;
			Control loginBTN = this.LoginBTN;
			point = new Point(709, 179);
			loginBTN.Location = point;
			this.LoginBTN.Name = "LoginBTN";
			Control loginBTN2 = this.LoginBTN;
			size = new Size(216, 76);
			loginBTN2.Size = size;
			this.LoginBTN.TabIndex = 23;
			this.LoginBTN.Text = "Login";
			this.LoginBTN.UseVisualStyleBackColor = false;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(1300, 740);
			this.ClientSize = size;
			this.ControlBox = false;
			this.Controls.Add(this.AdminPanel);
			this.Controls.Add(this.LoginPanel);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "General_Settings";
			this.ShowIcon = false;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "General_Settings";
			this.WindowState = FormWindowState.Maximized;
			this.AdvancedTP.ResumeLayout(false);
			this.GeneralTB.ResumeLayout(false);
			this.GeneralTB.PerformLayout();
			this.ShopOwnerGroupBox.ResumeLayout(false);
			this.ShopOwnerGroupBox.PerformLayout();
			this.OrderHistoryGroupBox.ResumeLayout(false);
			this.FlashDriverGroupBox.ResumeLayout(false);
			this.DownloadBackupGroupBox.ResumeLayout(false);
			this.DownloadBackupGroupBox.PerformLayout();
			this.NewPasswordGroupBox.ResumeLayout(false);
			this.NewPasswordGroupBox.PerformLayout();
			this.BusinessInfoGroupBox.ResumeLayout(false);
			this.BusinessInfoGroupBox.PerformLayout();
			this.DriversTB.ResumeLayout(false);
			this.GroupBox7.ResumeLayout(false);
			this.GroupBox6.ResumeLayout(false);
			this.GroupBox6.PerformLayout();
			this.GroupBox5.ResumeLayout(false);
			this.TabPage1.ResumeLayout(false);
			this.GroupBox3.ResumeLayout(false);
			this.GroupBox3.PerformLayout();
			this.GroupBox2.ResumeLayout(false);
			this.GroupBox2.PerformLayout();
			this.GroupBox1.ResumeLayout(false);
			this.GroupBox1.PerformLayout();
			this.PrinterGroupBox.ResumeLayout(false);
			this.PrinterGroupBox.PerformLayout();
			this.AbolfazlTB.ResumeLayout(false);
			this.AbolfazlTB.PerformLayout();
			this.GroupBox8.ResumeLayout(false);
			this.GroupBox8.PerformLayout();
			this.SaveExitPanel.ResumeLayout(false);
			this.AdminPanel.ResumeLayout(false);
			this.LoginPanel.ResumeLayout(false);
			this.GroupBox4.ResumeLayout(false);
			this.GroupBox4.PerformLayout();
			this.ResumeLayout(false);
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x060000BA RID: 186 RVA: 0x0000EFA4 File Offset: 0x0000D1A4
		// (set) Token: 0x060000BB RID: 187 RVA: 0x0000EFBC File Offset: 0x0000D1BC
		internal virtual Button ExitBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExitBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				bool flag = this._ExitBTN != null;
				if (flag)
				{
					this._ExitBTN.Click -= value2;
				}
				this._ExitBTN = value;
				flag = (this._ExitBTN != null);
				if (flag)
				{
					this._ExitBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x060000BC RID: 188 RVA: 0x0000F01C File Offset: 0x0000D21C
		// (set) Token: 0x060000BD RID: 189 RVA: 0x0000226B File Offset: 0x0000046B
		internal virtual TabControl AdvancedTP
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AdvancedTP;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AdvancedTP = value;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x060000BE RID: 190 RVA: 0x0000F034 File Offset: 0x0000D234
		// (set) Token: 0x060000BF RID: 191 RVA: 0x00002275 File Offset: 0x00000475
		internal virtual TabPage GeneralTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GeneralTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GeneralTB = value;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x060000C0 RID: 192 RVA: 0x0000F04C File Offset: 0x0000D24C
		// (set) Token: 0x060000C1 RID: 193 RVA: 0x0000227F File Offset: 0x0000047F
		internal virtual TabPage AbolfazlTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AbolfazlTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AbolfazlTB = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x060000C2 RID: 194 RVA: 0x0000F064 File Offset: 0x0000D264
		// (set) Token: 0x060000C3 RID: 195 RVA: 0x00002289 File Offset: 0x00000489
		internal virtual Panel SaveExitPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SaveExitPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._SaveExitPanel = value;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x060000C4 RID: 196 RVA: 0x0000F07C File Offset: 0x0000D27C
		// (set) Token: 0x060000C5 RID: 197 RVA: 0x0000F094 File Offset: 0x0000D294
		internal virtual ComboBox CallerIdComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CallerIdComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ComboBox1_SelectedIndexChanged);
				bool flag = this._CallerIdComboBox != null;
				if (flag)
				{
					this._CallerIdComboBox.SelectedIndexChanged -= value2;
				}
				this._CallerIdComboBox = value;
				flag = (this._CallerIdComboBox != null);
				if (flag)
				{
					this._CallerIdComboBox.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x060000C6 RID: 198 RVA: 0x0000F0F4 File Offset: 0x0000D2F4
		// (set) Token: 0x060000C7 RID: 199 RVA: 0x00002293 File Offset: 0x00000493
		internal virtual Label Label7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label7 = value;
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x060000C8 RID: 200 RVA: 0x0000F10C File Offset: 0x0000D30C
		// (set) Token: 0x060000C9 RID: 201 RVA: 0x0000229D File Offset: 0x0000049D
		internal virtual GroupBox BusinessInfoGroupBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BusinessInfoGroupBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BusinessInfoGroupBox = value;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x060000CA RID: 202 RVA: 0x0000F124 File Offset: 0x0000D324
		// (set) Token: 0x060000CB RID: 203 RVA: 0x000022A7 File Offset: 0x000004A7
		internal virtual TextBox BPhoneTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BPhoneTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BPhoneTextBox = value;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x060000CC RID: 204 RVA: 0x0000F13C File Offset: 0x0000D33C
		// (set) Token: 0x060000CD RID: 205 RVA: 0x000022B1 File Offset: 0x000004B1
		internal virtual TextBox BNameTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BNameTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BNameTextBox = value;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060000CE RID: 206 RVA: 0x0000F154 File Offset: 0x0000D354
		// (set) Token: 0x060000CF RID: 207 RVA: 0x000022BB File Offset: 0x000004BB
		internal virtual Label Label5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label5 = value;
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x060000D0 RID: 208 RVA: 0x0000F16C File Offset: 0x0000D36C
		// (set) Token: 0x060000D1 RID: 209 RVA: 0x000022C5 File Offset: 0x000004C5
		internal virtual TextBox BPostcodeTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BPostcodeTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BPostcodeTextBox = value;
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x060000D2 RID: 210 RVA: 0x0000F184 File Offset: 0x0000D384
		// (set) Token: 0x060000D3 RID: 211 RVA: 0x000022CF File Offset: 0x000004CF
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060000D4 RID: 212 RVA: 0x0000F19C File Offset: 0x0000D39C
		// (set) Token: 0x060000D5 RID: 213 RVA: 0x000022D9 File Offset: 0x000004D9
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060000D6 RID: 214 RVA: 0x0000F1B4 File Offset: 0x0000D3B4
		// (set) Token: 0x060000D7 RID: 215 RVA: 0x000022E3 File Offset: 0x000004E3
		internal virtual TextBox BCityTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BCityTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BCityTextBox = value;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060000D8 RID: 216 RVA: 0x0000F1CC File Offset: 0x0000D3CC
		// (set) Token: 0x060000D9 RID: 217 RVA: 0x000022ED File Offset: 0x000004ED
		internal virtual Label Label3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label3 = value;
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060000DA RID: 218 RVA: 0x0000F1E4 File Offset: 0x0000D3E4
		// (set) Token: 0x060000DB RID: 219 RVA: 0x000022F7 File Offset: 0x000004F7
		internal virtual Label Label4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label4 = value;
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060000DC RID: 220 RVA: 0x0000F1FC File Offset: 0x0000D3FC
		// (set) Token: 0x060000DD RID: 221 RVA: 0x00002301 File Offset: 0x00000501
		internal virtual TextBox BAddressTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BAddressTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BAddressTextBox = value;
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x060000DE RID: 222 RVA: 0x0000F214 File Offset: 0x0000D414
		// (set) Token: 0x060000DF RID: 223 RVA: 0x0000230B File Offset: 0x0000050B
		internal virtual Panel AdminPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AdminPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AdminPanel = value;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x060000E0 RID: 224 RVA: 0x0000F22C File Offset: 0x0000D42C
		// (set) Token: 0x060000E1 RID: 225 RVA: 0x0000F244 File Offset: 0x0000D444
		internal virtual Panel LoginPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LoginPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				PaintEventHandler value2 = new PaintEventHandler(this.LoginPanel_Paint);
				bool flag = this._LoginPanel != null;
				if (flag)
				{
					this._LoginPanel.Paint -= value2;
				}
				this._LoginPanel = value;
				flag = (this._LoginPanel != null);
				if (flag)
				{
					this._LoginPanel.Paint += value2;
				}
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x060000E2 RID: 226 RVA: 0x0000F2A4 File Offset: 0x0000D4A4
		// (set) Token: 0x060000E3 RID: 227 RVA: 0x00002315 File Offset: 0x00000515
		internal virtual TextBox PasswordTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PasswordTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PasswordTextBox = value;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x060000E4 RID: 228 RVA: 0x0000F2BC File Offset: 0x0000D4BC
		// (set) Token: 0x060000E5 RID: 229 RVA: 0x0000231F File Offset: 0x0000051F
		internal virtual ComboBox UserNameComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._UserNameComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._UserNameComboBox = value;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x060000E6 RID: 230 RVA: 0x0000F2D4 File Offset: 0x0000D4D4
		// (set) Token: 0x060000E7 RID: 231 RVA: 0x0000F2EC File Offset: 0x0000D4EC
		internal virtual Button CancelBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CancelBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CancelBTN_Click);
				bool flag = this._CancelBTN != null;
				if (flag)
				{
					this._CancelBTN.Click -= value2;
				}
				this._CancelBTN = value;
				flag = (this._CancelBTN != null);
				if (flag)
				{
					this._CancelBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x060000E8 RID: 232 RVA: 0x0000F34C File Offset: 0x0000D54C
		// (set) Token: 0x060000E9 RID: 233 RVA: 0x0000F364 File Offset: 0x0000D564
		internal virtual Button LoginBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LoginBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.LoginBTN_Click);
				bool flag = this._LoginBTN != null;
				if (flag)
				{
					this._LoginBTN.Click -= value2;
				}
				this._LoginBTN = value;
				flag = (this._LoginBTN != null);
				if (flag)
				{
					this._LoginBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x060000EA RID: 234 RVA: 0x0000F3C4 File Offset: 0x0000D5C4
		// (set) Token: 0x060000EB RID: 235 RVA: 0x00002329 File Offset: 0x00000529
		internal virtual GroupBox GroupBox4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox4 = value;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060000EC RID: 236 RVA: 0x0000F3DC File Offset: 0x0000D5DC
		// (set) Token: 0x060000ED RID: 237 RVA: 0x00002333 File Offset: 0x00000533
		internal virtual Panel KeyboardPanel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._KeyboardPanel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._KeyboardPanel = value;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060000EE RID: 238 RVA: 0x0000F3F4 File Offset: 0x0000D5F4
		// (set) Token: 0x060000EF RID: 239 RVA: 0x0000233D File Offset: 0x0000053D
		internal virtual TabPage DriversTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DriversTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DriversTB = value;
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x0000F40C File Offset: 0x0000D60C
		// (set) Token: 0x060000F1 RID: 241 RVA: 0x00002347 File Offset: 0x00000547
		internal virtual GroupBox GroupBox5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox5 = value;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060000F2 RID: 242 RVA: 0x0000F424 File Offset: 0x0000D624
		// (set) Token: 0x060000F3 RID: 243 RVA: 0x0000F43C File Offset: 0x0000D63C
		internal virtual Button Button2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click_1);
				bool flag = this._Button2 != null;
				if (flag)
				{
					this._Button2.Click -= value2;
				}
				this._Button2 = value;
				flag = (this._Button2 != null);
				if (flag)
				{
					this._Button2.Click += value2;
				}
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x0000F49C File Offset: 0x0000D69C
		// (set) Token: 0x060000F5 RID: 245 RVA: 0x0000F4B4 File Offset: 0x0000D6B4
		internal virtual Button Button3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click_1);
				bool flag = this._Button3 != null;
				if (flag)
				{
					this._Button3.Click -= value2;
				}
				this._Button3 = value;
				flag = (this._Button3 != null);
				if (flag)
				{
					this._Button3.Click += value2;
				}
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x0000F514 File Offset: 0x0000D714
		// (set) Token: 0x060000F7 RID: 247 RVA: 0x00002351 File Offset: 0x00000551
		internal virtual ListBox DriversListBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DriversListBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DriversListBox = value;
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x0000F52C File Offset: 0x0000D72C
		// (set) Token: 0x060000F9 RID: 249 RVA: 0x0000235B File Offset: 0x0000055B
		internal virtual GroupBox GroupBox6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox6 = value;
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060000FA RID: 250 RVA: 0x0000F544 File Offset: 0x0000D744
		// (set) Token: 0x060000FB RID: 251 RVA: 0x00002365 File Offset: 0x00000565
		internal virtual Label Label8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label8 = value;
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060000FC RID: 252 RVA: 0x0000F55C File Offset: 0x0000D75C
		// (set) Token: 0x060000FD RID: 253 RVA: 0x0000F574 File Offset: 0x0000D774
		internal virtual TextBox AddDriverMobileTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AddDriverMobileTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.AddDriverMobileTextBox_GotFocus);
				bool flag = this._AddDriverMobileTextBox != null;
				if (flag)
				{
					this._AddDriverMobileTextBox.GotFocus -= value2;
				}
				this._AddDriverMobileTextBox = value;
				flag = (this._AddDriverMobileTextBox != null);
				if (flag)
				{
					this._AddDriverMobileTextBox.GotFocus += value2;
				}
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060000FE RID: 254 RVA: 0x0000F5D4 File Offset: 0x0000D7D4
		// (set) Token: 0x060000FF RID: 255 RVA: 0x0000F5EC File Offset: 0x0000D7EC
		internal virtual TextBox AddDriverNameTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AddDriverNameTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.AddDriverNameTextBox_GotFocus);
				bool flag = this._AddDriverNameTextBox != null;
				if (flag)
				{
					this._AddDriverNameTextBox.GotFocus -= value2;
				}
				this._AddDriverNameTextBox = value;
				flag = (this._AddDriverNameTextBox != null);
				if (flag)
				{
					this._AddDriverNameTextBox.GotFocus += value2;
				}
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x06000100 RID: 256 RVA: 0x0000F64C File Offset: 0x0000D84C
		// (set) Token: 0x06000101 RID: 257 RVA: 0x0000236F File Offset: 0x0000056F
		internal virtual GroupBox GroupBox7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox7 = value;
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06000102 RID: 258 RVA: 0x0000F664 File Offset: 0x0000D864
		// (set) Token: 0x06000103 RID: 259 RVA: 0x00002379 File Offset: 0x00000579
		internal virtual ComboBox DriversDeleteComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DriversDeleteComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DriversDeleteComboBox = value;
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06000104 RID: 260 RVA: 0x0000F67C File Offset: 0x0000D87C
		// (set) Token: 0x06000105 RID: 261 RVA: 0x00002383 File Offset: 0x00000583
		internal virtual Panel KeyboardDriver
		{
			[DebuggerNonUserCode]
			get
			{
				return this._KeyboardDriver;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._KeyboardDriver = value;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000106 RID: 262 RVA: 0x0000F694 File Offset: 0x0000D894
		// (set) Token: 0x06000107 RID: 263 RVA: 0x0000238D File Offset: 0x0000058D
		internal virtual Label Label9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label9 = value;
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000108 RID: 264 RVA: 0x0000F6AC File Offset: 0x0000D8AC
		// (set) Token: 0x06000109 RID: 265 RVA: 0x00002397 File Offset: 0x00000597
		internal virtual GroupBox NewPasswordGroupBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NewPasswordGroupBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._NewPasswordGroupBox = value;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x0600010A RID: 266 RVA: 0x0000F6C4 File Offset: 0x0000D8C4
		// (set) Token: 0x0600010B RID: 267 RVA: 0x0000F6DC File Offset: 0x0000D8DC
		internal virtual Button NewPasswordSaveBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NewPasswordSaveBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NewPasswordSaveBTN_Click);
				bool flag = this._NewPasswordSaveBTN != null;
				if (flag)
				{
					this._NewPasswordSaveBTN.Click -= value2;
				}
				this._NewPasswordSaveBTN = value;
				flag = (this._NewPasswordSaveBTN != null);
				if (flag)
				{
					this._NewPasswordSaveBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x0600010C RID: 268 RVA: 0x0000F73C File Offset: 0x0000D93C
		// (set) Token: 0x0600010D RID: 269 RVA: 0x000023A1 File Offset: 0x000005A1
		internal virtual Label Label11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label11 = value;
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x0600010E RID: 270 RVA: 0x0000F754 File Offset: 0x0000D954
		// (set) Token: 0x0600010F RID: 271 RVA: 0x000023AB File Offset: 0x000005AB
		internal virtual Label Label10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label10 = value;
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000110 RID: 272 RVA: 0x0000F76C File Offset: 0x0000D96C
		// (set) Token: 0x06000111 RID: 273 RVA: 0x000023B5 File Offset: 0x000005B5
		internal virtual TextBox NewPassConfirmfTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NewPassConfirmfTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._NewPassConfirmfTextBox = value;
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000112 RID: 274 RVA: 0x0000F784 File Offset: 0x0000D984
		// (set) Token: 0x06000113 RID: 275 RVA: 0x000023BF File Offset: 0x000005BF
		internal virtual TextBox NewPassTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NewPassTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._NewPassTextBox = value;
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000114 RID: 276 RVA: 0x0000F79C File Offset: 0x0000D99C
		// (set) Token: 0x06000115 RID: 277 RVA: 0x000023C9 File Offset: 0x000005C9
		internal virtual Label Label12
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label12;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label12 = value;
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000116 RID: 278 RVA: 0x0000F7B4 File Offset: 0x0000D9B4
		// (set) Token: 0x06000117 RID: 279 RVA: 0x000023D3 File Offset: 0x000005D3
		internal virtual ComboBox UserComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._UserComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._UserComboBox = value;
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000118 RID: 280 RVA: 0x0000F7CC File Offset: 0x0000D9CC
		// (set) Token: 0x06000119 RID: 281 RVA: 0x000023DD File Offset: 0x000005DD
		internal virtual ComboBox NewPassUserComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NewPassUserComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._NewPassUserComboBox = value;
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x0600011A RID: 282 RVA: 0x0000F7E4 File Offset: 0x0000D9E4
		// (set) Token: 0x0600011B RID: 283 RVA: 0x000023E7 File Offset: 0x000005E7
		internal virtual GroupBox DownloadBackupGroupBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DownloadBackupGroupBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DownloadBackupGroupBox = value;
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600011C RID: 284 RVA: 0x0000F7FC File Offset: 0x0000D9FC
		// (set) Token: 0x0600011D RID: 285 RVA: 0x0000F814 File Offset: 0x0000DA14
		internal virtual Button DownloadBackupBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DownloadBackupBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DownloadBackupBTN_Click);
				bool flag = this._DownloadBackupBTN != null;
				if (flag)
				{
					this._DownloadBackupBTN.Click -= value2;
				}
				this._DownloadBackupBTN = value;
				flag = (this._DownloadBackupBTN != null);
				if (flag)
				{
					this._DownloadBackupBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x0600011E RID: 286 RVA: 0x0000F874 File Offset: 0x0000DA74
		// (set) Token: 0x0600011F RID: 287 RVA: 0x000023F1 File Offset: 0x000005F1
		internal virtual RadioButton DownloadPostcodesRB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DownloadPostcodesRB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DownloadPostcodesRB = value;
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x06000120 RID: 288 RVA: 0x0000F88C File Offset: 0x0000DA8C
		// (set) Token: 0x06000121 RID: 289 RVA: 0x000023FB File Offset: 0x000005FB
		internal virtual RadioButton DownloadBackupCustomersRB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DownloadBackupCustomersRB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DownloadBackupCustomersRB = value;
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000122 RID: 290 RVA: 0x0000F8A4 File Offset: 0x0000DAA4
		// (set) Token: 0x06000123 RID: 291 RVA: 0x00002405 File Offset: 0x00000605
		internal virtual RadioButton DownloadBackupMenuRB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DownloadBackupMenuRB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DownloadBackupMenuRB = value;
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x06000124 RID: 292 RVA: 0x0000F8BC File Offset: 0x0000DABC
		// (set) Token: 0x06000125 RID: 293 RVA: 0x0000240F File Offset: 0x0000060F
		internal virtual ProgressBar UploadDownloadProgressBar
		{
			[DebuggerNonUserCode]
			get
			{
				return this._UploadDownloadProgressBar;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._UploadDownloadProgressBar = value;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x06000126 RID: 294 RVA: 0x0000F8D4 File Offset: 0x0000DAD4
		// (set) Token: 0x06000127 RID: 295 RVA: 0x00002419 File Offset: 0x00000619
		internal virtual Button USBBackupBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._USBBackupBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._USBBackupBTN = value;
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000128 RID: 296 RVA: 0x0000F8EC File Offset: 0x0000DAEC
		// (set) Token: 0x06000129 RID: 297 RVA: 0x00002423 File Offset: 0x00000623
		internal virtual GroupBox GroupBox8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox8 = value;
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x0600012A RID: 298 RVA: 0x0000F904 File Offset: 0x0000DB04
		// (set) Token: 0x0600012B RID: 299 RVA: 0x0000242D File Offset: 0x0000062D
		internal virtual Label Label13
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label13;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label13 = value;
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x0600012C RID: 300 RVA: 0x0000F91C File Offset: 0x0000DB1C
		// (set) Token: 0x0600012D RID: 301 RVA: 0x0000F934 File Offset: 0x0000DB34
		internal virtual Button FTPsaveBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FTPsaveBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.FTPsaveBTN_Click);
				bool flag = this._FTPsaveBTN != null;
				if (flag)
				{
					this._FTPsaveBTN.Click -= value2;
				}
				this._FTPsaveBTN = value;
				flag = (this._FTPsaveBTN != null);
				if (flag)
				{
					this._FTPsaveBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x0600012E RID: 302 RVA: 0x0000F994 File Offset: 0x0000DB94
		// (set) Token: 0x0600012F RID: 303 RVA: 0x00002437 File Offset: 0x00000637
		internal virtual TextBox FTPPasswordTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FTPPasswordTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FTPPasswordTextBox = value;
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06000130 RID: 304 RVA: 0x0000F9AC File Offset: 0x0000DBAC
		// (set) Token: 0x06000131 RID: 305 RVA: 0x00002441 File Offset: 0x00000641
		internal virtual TextBox FTPUsernameTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FTPUsernameTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FTPUsernameTextBox = value;
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x06000132 RID: 306 RVA: 0x0000F9C4 File Offset: 0x0000DBC4
		// (set) Token: 0x06000133 RID: 307 RVA: 0x0000244B File Offset: 0x0000064B
		internal virtual Label Label14
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label14;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label14 = value;
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x06000134 RID: 308 RVA: 0x0000F9DC File Offset: 0x0000DBDC
		// (set) Token: 0x06000135 RID: 309 RVA: 0x00002455 File Offset: 0x00000655
		internal virtual TextBox SoftwareDomainTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SoftwareDomainTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._SoftwareDomainTextBox = value;
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000136 RID: 310 RVA: 0x0000F9F4 File Offset: 0x0000DBF4
		// (set) Token: 0x06000137 RID: 311 RVA: 0x0000245F File Offset: 0x0000065F
		internal virtual Label Label15
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label15;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label15 = value;
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000138 RID: 312 RVA: 0x0000FA0C File Offset: 0x0000DC0C
		// (set) Token: 0x06000139 RID: 313 RVA: 0x0000FA24 File Offset: 0x0000DC24
		internal virtual Button FTPpingBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FTPpingBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.FTPping_Click);
				bool flag = this._FTPpingBTN != null;
				if (flag)
				{
					this._FTPpingBTN.Click -= value2;
				}
				this._FTPpingBTN = value;
				flag = (this._FTPpingBTN != null);
				if (flag)
				{
					this._FTPpingBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x0600013A RID: 314 RVA: 0x0000FA84 File Offset: 0x0000DC84
		// (set) Token: 0x0600013B RID: 315 RVA: 0x0000FA9C File Offset: 0x0000DC9C
		internal virtual Button USBRestoreBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._USBRestoreBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.USBRestoreBTN_Click);
				bool flag = this._USBRestoreBTN != null;
				if (flag)
				{
					this._USBRestoreBTN.Click -= value2;
				}
				this._USBRestoreBTN = value;
				flag = (this._USBRestoreBTN != null);
				if (flag)
				{
					this._USBRestoreBTN.Click += value2;
				}
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x0600013C RID: 316 RVA: 0x0000FAFC File Offset: 0x0000DCFC
		// (set) Token: 0x0600013D RID: 317 RVA: 0x00002469 File Offset: 0x00000669
		internal virtual GroupBox FlashDriverGroupBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FlashDriverGroupBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FlashDriverGroupBox = value;
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x0600013E RID: 318 RVA: 0x0000FB14 File Offset: 0x0000DD14
		// (set) Token: 0x0600013F RID: 319 RVA: 0x0000FB2C File Offset: 0x0000DD2C
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click_2);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06000140 RID: 320 RVA: 0x0000FB8C File Offset: 0x0000DD8C
		// (set) Token: 0x06000141 RID: 321 RVA: 0x0000FBA4 File Offset: 0x0000DDA4
		internal virtual CheckBox DriversAccessCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DriversAccessCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.DriversAccessCheckBox_CheckedChanged);
				bool flag = this._DriversAccessCheckBox != null;
				if (flag)
				{
					this._DriversAccessCheckBox.CheckedChanged -= value2;
				}
				this._DriversAccessCheckBox = value;
				flag = (this._DriversAccessCheckBox != null);
				if (flag)
				{
					this._DriversAccessCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06000142 RID: 322 RVA: 0x0000FC04 File Offset: 0x0000DE04
		// (set) Token: 0x06000143 RID: 323 RVA: 0x0000FC1C File Offset: 0x0000DE1C
		internal virtual CheckBox OnlineModeCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OnlineModeCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.OnlineModeCheckBox_CheckedChanged);
				bool flag = this._OnlineModeCheckBox != null;
				if (flag)
				{
					this._OnlineModeCheckBox.CheckedChanged -= value2;
				}
				this._OnlineModeCheckBox = value;
				flag = (this._OnlineModeCheckBox != null);
				if (flag)
				{
					this._OnlineModeCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x06000144 RID: 324 RVA: 0x0000FC7C File Offset: 0x0000DE7C
		// (set) Token: 0x06000145 RID: 325 RVA: 0x0000FC94 File Offset: 0x0000DE94
		internal virtual CheckBox PostcodeFinderCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PostcodeFinderCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PostcodeFinderCheckBox_CheckedChanged);
				bool flag = this._PostcodeFinderCheckBox != null;
				if (flag)
				{
					this._PostcodeFinderCheckBox.CheckedChanged -= value2;
				}
				this._PostcodeFinderCheckBox = value;
				flag = (this._PostcodeFinderCheckBox != null);
				if (flag)
				{
					this._PostcodeFinderCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06000146 RID: 326 RVA: 0x0000FCF4 File Offset: 0x0000DEF4
		// (set) Token: 0x06000147 RID: 327 RVA: 0x0000FD0C File Offset: 0x0000DF0C
		internal virtual CheckBox RemoveItemsInShoppingCartCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._RemoveItemsInShoppingCartCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CheckBox1_CheckedChanged);
				bool flag = this._RemoveItemsInShoppingCartCheckBox != null;
				if (flag)
				{
					this._RemoveItemsInShoppingCartCheckBox.CheckedChanged -= value2;
				}
				this._RemoveItemsInShoppingCartCheckBox = value;
				flag = (this._RemoveItemsInShoppingCartCheckBox != null);
				if (flag)
				{
					this._RemoveItemsInShoppingCartCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000148 RID: 328 RVA: 0x0000FD6C File Offset: 0x0000DF6C
		// (set) Token: 0x06000149 RID: 329 RVA: 0x0000FD84 File Offset: 0x0000DF84
		internal virtual CheckBox ActiveEditOrdersCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ActiveEditOrdersCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ActiveEditOrdersCheckBox_CheckedChanged);
				bool flag = this._ActiveEditOrdersCheckBox != null;
				if (flag)
				{
					this._ActiveEditOrdersCheckBox.CheckedChanged -= value2;
				}
				this._ActiveEditOrdersCheckBox = value;
				flag = (this._ActiveEditOrdersCheckBox != null);
				if (flag)
				{
					this._ActiveEditOrdersCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x0600014A RID: 330 RVA: 0x0000FDE4 File Offset: 0x0000DFE4
		// (set) Token: 0x0600014B RID: 331 RVA: 0x00002473 File Offset: 0x00000673
		internal virtual Label Label6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label6 = value;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x0600014C RID: 332 RVA: 0x0000FDFC File Offset: 0x0000DFFC
		// (set) Token: 0x0600014D RID: 333 RVA: 0x0000FE14 File Offset: 0x0000E014
		internal virtual ListBox OrderHistoryListBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderHistoryListBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.OrderHistoryListBox_SelectedIndexChanged);
				bool flag = this._OrderHistoryListBox != null;
				if (flag)
				{
					this._OrderHistoryListBox.SelectedIndexChanged -= value2;
				}
				this._OrderHistoryListBox = value;
				flag = (this._OrderHistoryListBox != null);
				if (flag)
				{
					this._OrderHistoryListBox.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x0600014E RID: 334 RVA: 0x0000FE74 File Offset: 0x0000E074
		// (set) Token: 0x0600014F RID: 335 RVA: 0x0000247D File Offset: 0x0000067D
		internal virtual GroupBox OrderHistoryGroupBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderHistoryGroupBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._OrderHistoryGroupBox = value;
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000150 RID: 336 RVA: 0x0000FE8C File Offset: 0x0000E08C
		// (set) Token: 0x06000151 RID: 337 RVA: 0x0000FEA4 File Offset: 0x0000E0A4
		internal virtual Button OrderHistoryDeleteBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderHistoryDeleteBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click);
				bool flag = this._OrderHistoryDeleteBTN != null;
				if (flag)
				{
					this._OrderHistoryDeleteBTN.Click -= value2;
				}
				this._OrderHistoryDeleteBTN = value;
				flag = (this._OrderHistoryDeleteBTN != null);
				if (flag)
				{
					this._OrderHistoryDeleteBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000152 RID: 338 RVA: 0x0000FF04 File Offset: 0x0000E104
		// (set) Token: 0x06000153 RID: 339 RVA: 0x0000FF1C File Offset: 0x0000E11C
		internal virtual Button OrderHistoryFullPrintBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderHistoryFullPrintBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click);
				bool flag = this._OrderHistoryFullPrintBTN != null;
				if (flag)
				{
					this._OrderHistoryFullPrintBTN.Click -= value2;
				}
				this._OrderHistoryFullPrintBTN = value;
				flag = (this._OrderHistoryFullPrintBTN != null);
				if (flag)
				{
					this._OrderHistoryFullPrintBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000154 RID: 340 RVA: 0x0000FF7C File Offset: 0x0000E17C
		// (set) Token: 0x06000155 RID: 341 RVA: 0x0000FF94 File Offset: 0x0000E194
		internal virtual Button OrderHistorySummaryPrintBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderHistorySummaryPrintBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click_1);
				bool flag = this._OrderHistorySummaryPrintBTN != null;
				if (flag)
				{
					this._OrderHistorySummaryPrintBTN.Click -= value2;
				}
				this._OrderHistorySummaryPrintBTN = value;
				flag = (this._OrderHistorySummaryPrintBTN != null);
				if (flag)
				{
					this._OrderHistorySummaryPrintBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000156 RID: 342 RVA: 0x0000FFF4 File Offset: 0x0000E1F4
		// (set) Token: 0x06000157 RID: 343 RVA: 0x00002487 File Offset: 0x00000687
		internal virtual CheckBox PostcodeFinderCheckBox1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PostcodeFinderCheckBox1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PostcodeFinderCheckBox1 = value;
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000158 RID: 344 RVA: 0x0001000C File Offset: 0x0000E20C
		// (set) Token: 0x06000159 RID: 345 RVA: 0x00002491 File Offset: 0x00000691
		internal virtual GroupBox ShopOwnerGroupBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ShopOwnerGroupBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ShopOwnerGroupBox = value;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x0600015A RID: 346 RVA: 0x00010024 File Offset: 0x0000E224
		// (set) Token: 0x0600015B RID: 347 RVA: 0x0000249B File Offset: 0x0000069B
		internal virtual Label Label20
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label20;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label20 = value;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x0600015C RID: 348 RVA: 0x0001003C File Offset: 0x0000E23C
		// (set) Token: 0x0600015D RID: 349 RVA: 0x000024A5 File Offset: 0x000006A5
		internal virtual Label Label21
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label21;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label21 = value;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x0600015E RID: 350 RVA: 0x00010054 File Offset: 0x0000E254
		// (set) Token: 0x0600015F RID: 351 RVA: 0x000024AF File Offset: 0x000006AF
		internal virtual TextBox BusinessEmailTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BusinessEmailTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._BusinessEmailTextBox = value;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000160 RID: 352 RVA: 0x0001006C File Offset: 0x0000E26C
		// (set) Token: 0x06000161 RID: 353 RVA: 0x000024B9 File Offset: 0x000006B9
		internal virtual TextBox ShopOwnerMobileTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ShopOwnerMobileTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ShopOwnerMobileTextBox = value;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000162 RID: 354 RVA: 0x00010084 File Offset: 0x0000E284
		// (set) Token: 0x06000163 RID: 355 RVA: 0x0001009C File Offset: 0x0000E29C
		internal virtual Button Button4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button4_Click_2);
				bool flag = this._Button4 != null;
				if (flag)
				{
					this._Button4.Click -= value2;
				}
				this._Button4 = value;
				flag = (this._Button4 != null);
				if (flag)
				{
					this._Button4.Click += value2;
				}
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000164 RID: 356 RVA: 0x000100FC File Offset: 0x0000E2FC
		// (set) Token: 0x06000165 RID: 357 RVA: 0x00010114 File Offset: 0x0000E314
		internal virtual CheckBox TableManagementCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TableManagementCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.TableManagementCheckBox_CheckedChanged);
				bool flag = this._TableManagementCheckBox != null;
				if (flag)
				{
					this._TableManagementCheckBox.CheckedChanged -= value2;
				}
				this._TableManagementCheckBox = value;
				flag = (this._TableManagementCheckBox != null);
				if (flag)
				{
					this._TableManagementCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000166 RID: 358 RVA: 0x00010174 File Offset: 0x0000E374
		// (set) Token: 0x06000167 RID: 359 RVA: 0x0001018C File Offset: 0x0000E38C
		internal virtual CheckBox SupplierCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SupplierCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.SupplierCheckBox_CheckedChanged);
				bool flag = this._SupplierCheckBox != null;
				if (flag)
				{
					this._SupplierCheckBox.CheckedChanged -= value2;
				}
				this._SupplierCheckBox = value;
				flag = (this._SupplierCheckBox != null);
				if (flag)
				{
					this._SupplierCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000168 RID: 360 RVA: 0x000101EC File Offset: 0x0000E3EC
		// (set) Token: 0x06000169 RID: 361 RVA: 0x00010204 File Offset: 0x0000E404
		internal virtual Button Button5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button5_Click_1);
				bool flag = this._Button5 != null;
				if (flag)
				{
					this._Button5.Click -= value2;
				}
				this._Button5 = value;
				flag = (this._Button5 != null);
				if (flag)
				{
					this._Button5.Click += value2;
				}
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x0600016A RID: 362 RVA: 0x00010264 File Offset: 0x0000E464
		// (set) Token: 0x0600016B RID: 363 RVA: 0x000024C3 File Offset: 0x000006C3
		internal virtual TabPage TabPage1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._TabPage1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._TabPage1 = value;
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x0600016C RID: 364 RVA: 0x0001027C File Offset: 0x0000E47C
		// (set) Token: 0x0600016D RID: 365 RVA: 0x00010294 File Offset: 0x0000E494
		internal virtual Button ResetToFactoryBTM
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ResetToFactoryBTM;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.ResetToFactoryBTM_Click);
				bool flag = this._ResetToFactoryBTM != null;
				if (flag)
				{
					this._ResetToFactoryBTM.Click -= value2;
				}
				this._ResetToFactoryBTM = value;
				flag = (this._ResetToFactoryBTM != null);
				if (flag)
				{
					this._ResetToFactoryBTM.Click += value2;
				}
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x0600016E RID: 366 RVA: 0x000102F4 File Offset: 0x0000E4F4
		// (set) Token: 0x0600016F RID: 367 RVA: 0x0001030C File Offset: 0x0000E50C
		internal virtual Button UpdateBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._UpdateBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.UpdateBTN_Click);
				bool flag = this._UpdateBTN != null;
				if (flag)
				{
					this._UpdateBTN.Click -= value2;
				}
				this._UpdateBTN = value;
				flag = (this._UpdateBTN != null);
				if (flag)
				{
					this._UpdateBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000170 RID: 368 RVA: 0x0001036C File Offset: 0x0000E56C
		// (set) Token: 0x06000171 RID: 369 RVA: 0x00010384 File Offset: 0x0000E584
		internal virtual TextBox AutoCompleteOrderTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AutoCompleteOrderTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.AutoCompleteOrderTextBox_TextChanged);
				bool flag = this._AutoCompleteOrderTextBox != null;
				if (flag)
				{
					this._AutoCompleteOrderTextBox.TextChanged -= value2;
				}
				this._AutoCompleteOrderTextBox = value;
				flag = (this._AutoCompleteOrderTextBox != null);
				if (flag)
				{
					this._AutoCompleteOrderTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000172 RID: 370 RVA: 0x000103E4 File Offset: 0x0000E5E4
		// (set) Token: 0x06000173 RID: 371 RVA: 0x000024CD File Offset: 0x000006CD
		internal virtual Label AutoCompleteLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AutoCompleteLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AutoCompleteLBL = value;
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06000174 RID: 372 RVA: 0x000103FC File Offset: 0x0000E5FC
		// (set) Token: 0x06000175 RID: 373 RVA: 0x000024D7 File Offset: 0x000006D7
		internal virtual Label CallerIDLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CallerIDLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._CallerIDLBL = value;
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000176 RID: 374 RVA: 0x00010414 File Offset: 0x0000E614
		// (set) Token: 0x06000177 RID: 375 RVA: 0x0001042C File Offset: 0x0000E62C
		internal virtual ComboBox CallerIdComboBox1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CallerIdComboBox1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.CallerIdComboBox1_SelectedIndexChanged);
				bool flag = this._CallerIdComboBox1 != null;
				if (flag)
				{
					this._CallerIdComboBox1.SelectedIndexChanged -= value2;
				}
				this._CallerIdComboBox1 = value;
				flag = (this._CallerIdComboBox1 != null);
				if (flag)
				{
					this._CallerIdComboBox1.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000178 RID: 376 RVA: 0x0001048C File Offset: 0x0000E68C
		// (set) Token: 0x06000179 RID: 377 RVA: 0x000024E1 File Offset: 0x000006E1
		internal virtual GroupBox PrinterGroupBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PrinterGroupBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PrinterGroupBox = value;
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x0600017A RID: 378 RVA: 0x000104A4 File Offset: 0x0000E6A4
		// (set) Token: 0x0600017B RID: 379 RVA: 0x000024EB File Offset: 0x000006EB
		internal virtual TextBox OrderFontSizeTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderFontSizeTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._OrderFontSizeTextBox = value;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x0600017C RID: 380 RVA: 0x000104BC File Offset: 0x0000E6BC
		// (set) Token: 0x0600017D RID: 381 RVA: 0x000024F5 File Offset: 0x000006F5
		internal virtual Label Label16
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label16;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label16 = value;
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x0600017E RID: 382 RVA: 0x000104D4 File Offset: 0x0000E6D4
		// (set) Token: 0x0600017F RID: 383 RVA: 0x000024FF File Offset: 0x000006FF
		internal virtual Label Label17
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label17;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label17 = value;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x06000180 RID: 384 RVA: 0x000104EC File Offset: 0x0000E6EC
		// (set) Token: 0x06000181 RID: 385 RVA: 0x00002509 File Offset: 0x00000709
		internal virtual TextBox OrderLineSpaceTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OrderLineSpaceTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._OrderLineSpaceTextBox = value;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x06000182 RID: 386 RVA: 0x00010504 File Offset: 0x0000E704
		// (set) Token: 0x06000183 RID: 387 RVA: 0x00002513 File Offset: 0x00000713
		internal virtual Label Label18
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label18;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label18 = value;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x06000184 RID: 388 RVA: 0x0001051C File Offset: 0x0000E71C
		// (set) Token: 0x06000185 RID: 389 RVA: 0x0000251D File Offset: 0x0000071D
		internal virtual TextBox FoodLeftAtTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FoodLeftAtTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FoodLeftAtTextBox = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06000186 RID: 390 RVA: 0x00010534 File Offset: 0x0000E734
		// (set) Token: 0x06000187 RID: 391 RVA: 0x00002527 File Offset: 0x00000727
		internal virtual TextBox SecondLinesSpaceTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SecondLinesSpaceTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._SecondLinesSpaceTextBox = value;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06000188 RID: 392 RVA: 0x0001054C File Offset: 0x0000E74C
		// (set) Token: 0x06000189 RID: 393 RVA: 0x00002531 File Offset: 0x00000731
		internal virtual Label Label19
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label19;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label19 = value;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x0600018A RID: 394 RVA: 0x00010564 File Offset: 0x0000E764
		// (set) Token: 0x0600018B RID: 395 RVA: 0x0000253B File Offset: 0x0000073B
		internal virtual Label Label22
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label22;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label22 = value;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x0600018C RID: 396 RVA: 0x0001057C File Offset: 0x0000E77C
		// (set) Token: 0x0600018D RID: 397 RVA: 0x00002545 File Offset: 0x00000745
		internal virtual TextBox PriceLeftAtTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PriceLeftAtTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._PriceLeftAtTextBox = value;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x0600018E RID: 398 RVA: 0x00010594 File Offset: 0x0000E794
		// (set) Token: 0x0600018F RID: 399 RVA: 0x0000254F File Offset: 0x0000074F
		internal virtual TextBox FoodMaxLenTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FoodMaxLenTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FoodMaxLenTextBox = value;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06000190 RID: 400 RVA: 0x000105AC File Offset: 0x0000E7AC
		// (set) Token: 0x06000191 RID: 401 RVA: 0x00002559 File Offset: 0x00000759
		internal virtual Label Label23
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label23;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label23 = value;
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000192 RID: 402 RVA: 0x000105C4 File Offset: 0x0000E7C4
		// (set) Token: 0x06000193 RID: 403 RVA: 0x000105DC File Offset: 0x0000E7DC
		internal virtual ComboBox MyPrinterFontType
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MyPrinterFontType;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.MyPrinterFontType_SelectedIndexChanged);
				bool flag = this._MyPrinterFontType != null;
				if (flag)
				{
					this._MyPrinterFontType.SelectedIndexChanged -= value2;
				}
				this._MyPrinterFontType = value;
				flag = (this._MyPrinterFontType != null);
				if (flag)
				{
					this._MyPrinterFontType.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000194 RID: 404 RVA: 0x0001063C File Offset: 0x0000E83C
		// (set) Token: 0x06000195 RID: 405 RVA: 0x00002563 File Offset: 0x00000763
		internal virtual Label Label24
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label24;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label24 = value;
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000196 RID: 406 RVA: 0x00010654 File Offset: 0x0000E854
		// (set) Token: 0x06000197 RID: 407 RVA: 0x0001066C File Offset: 0x0000E86C
		internal virtual Button Button7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button7_Click);
				bool flag = this._Button7 != null;
				if (flag)
				{
					this._Button7.Click -= value2;
				}
				this._Button7 = value;
				flag = (this._Button7 != null);
				if (flag)
				{
					this._Button7.Click += value2;
				}
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000198 RID: 408 RVA: 0x000106CC File Offset: 0x0000E8CC
		// (set) Token: 0x06000199 RID: 409 RVA: 0x000106E4 File Offset: 0x0000E8E4
		internal virtual Button Button8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button8_Click);
				bool flag = this._Button8 != null;
				if (flag)
				{
					this._Button8.Click -= value2;
				}
				this._Button8 = value;
				flag = (this._Button8 != null);
				if (flag)
				{
					this._Button8.Click += value2;
				}
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x0600019A RID: 410 RVA: 0x00010744 File Offset: 0x0000E944
		// (set) Token: 0x0600019B RID: 411 RVA: 0x0000256D File Offset: 0x0000076D
		internal virtual Label NumberOfPrintLabel
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NumberOfPrintLabel;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._NumberOfPrintLabel = value;
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x0600019C RID: 412 RVA: 0x0001075C File Offset: 0x0000E95C
		// (set) Token: 0x0600019D RID: 413 RVA: 0x00010774 File Offset: 0x0000E974
		internal virtual TextBox NumberOfPrintTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._NumberOfPrintTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.NumberOfPrintTextBox_TextChanged_1);
				bool flag = this._NumberOfPrintTextBox != null;
				if (flag)
				{
					this._NumberOfPrintTextBox.TextChanged -= value2;
				}
				this._NumberOfPrintTextBox = value;
				flag = (this._NumberOfPrintTextBox != null);
				if (flag)
				{
					this._NumberOfPrintTextBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x0600019E RID: 414 RVA: 0x000107D4 File Offset: 0x0000E9D4
		// (set) Token: 0x0600019F RID: 415 RVA: 0x00002577 File Offset: 0x00000777
		internal virtual Label Label25
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label25;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label25 = value;
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x000107EC File Offset: 0x0000E9EC
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x00010804 File Offset: 0x0000EA04
		internal virtual ComboBox PrintersComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._PrintersComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.PrintersComboBox_SelectedIndexChanged_1);
				bool flag = this._PrintersComboBox != null;
				if (flag)
				{
					this._PrintersComboBox.SelectedIndexChanged -= value2;
				}
				this._PrintersComboBox = value;
				flag = (this._PrintersComboBox != null);
				if (flag)
				{
					this._PrintersComboBox.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060001A2 RID: 418 RVA: 0x00010864 File Offset: 0x0000EA64
		// (set) Token: 0x060001A3 RID: 419 RVA: 0x00002581 File Offset: 0x00000781
		internal virtual TextBox CommentFontSieTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._CommentFontSieTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._CommentFontSieTextBox = value;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x060001A4 RID: 420 RVA: 0x0001087C File Offset: 0x0000EA7C
		// (set) Token: 0x060001A5 RID: 421 RVA: 0x0000258B File Offset: 0x0000078B
		internal virtual Label Label26
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label26;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label26 = value;
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x060001A6 RID: 422 RVA: 0x00010894 File Offset: 0x0000EA94
		// (set) Token: 0x060001A7 RID: 423 RVA: 0x00002595 File Offset: 0x00000795
		internal virtual GroupBox GroupBox1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox1 = value;
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x000108AC File Offset: 0x0000EAAC
		// (set) Token: 0x060001A9 RID: 425 RVA: 0x0000259F File Offset: 0x0000079F
		internal virtual Label DeliveryChargeLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._DeliveryChargeLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._DeliveryChargeLBL = value;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x060001AA RID: 426 RVA: 0x000108C4 File Offset: 0x0000EAC4
		// (set) Token: 0x060001AB RID: 427 RVA: 0x000108DC File Offset: 0x0000EADC
		internal virtual CheckBox Categories2RowsCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Categories2RowsCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Categories2RowsCheckBox_CheckedChanged);
				bool flag = this._Categories2RowsCheckBox != null;
				if (flag)
				{
					this._Categories2RowsCheckBox.Click -= value2;
				}
				this._Categories2RowsCheckBox = value;
				flag = (this._Categories2RowsCheckBox != null);
				if (flag)
				{
					this._Categories2RowsCheckBox.Click += value2;
				}
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x060001AC RID: 428 RVA: 0x0001093C File Offset: 0x0000EB3C
		// (set) Token: 0x060001AD RID: 429 RVA: 0x000025A9 File Offset: 0x000007A9
		internal virtual TextBox AllPostCodesTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._AllPostCodesTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._AllPostCodesTextBox = value;
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x060001AE RID: 430 RVA: 0x00010954 File Offset: 0x0000EB54
		// (set) Token: 0x060001AF RID: 431 RVA: 0x000025B3 File Offset: 0x000007B3
		internal virtual Label Label28
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label28;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label28 = value;
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x060001B0 RID: 432 RVA: 0x0001096C File Offset: 0x0000EB6C
		// (set) Token: 0x060001B1 RID: 433 RVA: 0x00010984 File Offset: 0x0000EB84
		internal virtual ComboBox Printer1ComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Printer1ComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Printer1ComboBox_SelectedIndexChanged);
				bool flag = this._Printer1ComboBox != null;
				if (flag)
				{
					this._Printer1ComboBox.SelectedIndexChanged -= value2;
				}
				this._Printer1ComboBox = value;
				flag = (this._Printer1ComboBox != null);
				if (flag)
				{
					this._Printer1ComboBox.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x000109E4 File Offset: 0x0000EBE4
		// (set) Token: 0x060001B3 RID: 435 RVA: 0x000025BD File Offset: 0x000007BD
		internal virtual Label Label29
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label29;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label29 = value;
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x000109FC File Offset: 0x0000EBFC
		// (set) Token: 0x060001B5 RID: 437 RVA: 0x00010A14 File Offset: 0x0000EC14
		internal virtual ComboBox Printer2ComboBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Printer2ComboBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Printer2ComboBox_SelectedIndexChanged);
				bool flag = this._Printer2ComboBox != null;
				if (flag)
				{
					this._Printer2ComboBox.SelectedIndexChanged -= value2;
				}
				this._Printer2ComboBox = value;
				flag = (this._Printer2ComboBox != null);
				if (flag)
				{
					this._Printer2ComboBox.SelectedIndexChanged += value2;
				}
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x00010A74 File Offset: 0x0000EC74
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x000025C7 File Offset: 0x000007C7
		internal virtual Label Label30
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label30;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label30 = value;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x060001B8 RID: 440 RVA: 0x00010A8C File Offset: 0x0000EC8C
		// (set) Token: 0x060001B9 RID: 441 RVA: 0x000025D1 File Offset: 0x000007D1
		internal virtual Label Label31
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label31;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label31 = value;
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x060001BA RID: 442 RVA: 0x00010AA4 File Offset: 0x0000ECA4
		// (set) Token: 0x060001BB RID: 443 RVA: 0x000025DB File Offset: 0x000007DB
		internal virtual GroupBox GroupBox2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox2 = value;
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x060001BC RID: 444 RVA: 0x00010ABC File Offset: 0x0000ECBC
		// (set) Token: 0x060001BD RID: 445 RVA: 0x00010AD4 File Offset: 0x0000ECD4
		internal virtual Button Button6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button6_Click);
				bool flag = this._Button6 != null;
				if (flag)
				{
					this._Button6.Click -= value2;
				}
				this._Button6 = value;
				flag = (this._Button6 != null);
				if (flag)
				{
					this._Button6.Click += value2;
				}
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x060001BE RID: 446 RVA: 0x00010B34 File Offset: 0x0000ED34
		// (set) Token: 0x060001BF RID: 447 RVA: 0x000025E5 File Offset: 0x000007E5
		internal virtual TextBox fppc6dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc6dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc6dc = value;
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x060001C0 RID: 448 RVA: 0x00010B4C File Offset: 0x0000ED4C
		// (set) Token: 0x060001C1 RID: 449 RVA: 0x000025EF File Offset: 0x000007EF
		internal virtual TextBox fppc5dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc5dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc5dc = value;
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x060001C2 RID: 450 RVA: 0x00010B64 File Offset: 0x0000ED64
		// (set) Token: 0x060001C3 RID: 451 RVA: 0x000025F9 File Offset: 0x000007F9
		internal virtual TextBox fppc4dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc4dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc4dc = value;
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x060001C4 RID: 452 RVA: 0x00010B7C File Offset: 0x0000ED7C
		// (set) Token: 0x060001C5 RID: 453 RVA: 0x00002603 File Offset: 0x00000803
		internal virtual TextBox fppc3dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc3dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc3dc = value;
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x060001C6 RID: 454 RVA: 0x00010B94 File Offset: 0x0000ED94
		// (set) Token: 0x060001C7 RID: 455 RVA: 0x0000260D File Offset: 0x0000080D
		internal virtual TextBox fppc2dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc2dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc2dc = value;
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x060001C8 RID: 456 RVA: 0x00010BAC File Offset: 0x0000EDAC
		// (set) Token: 0x060001C9 RID: 457 RVA: 0x00002617 File Offset: 0x00000817
		internal virtual TextBox fppc1dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc1dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc1dc = value;
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060001CA RID: 458 RVA: 0x00010BC4 File Offset: 0x0000EDC4
		// (set) Token: 0x060001CB RID: 459 RVA: 0x00002621 File Offset: 0x00000821
		internal virtual TextBox fppc6
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc6;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc6 = value;
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060001CC RID: 460 RVA: 0x00010BDC File Offset: 0x0000EDDC
		// (set) Token: 0x060001CD RID: 461 RVA: 0x0000262B File Offset: 0x0000082B
		internal virtual TextBox fppc5
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc5;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc5 = value;
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060001CE RID: 462 RVA: 0x00010BF4 File Offset: 0x0000EDF4
		// (set) Token: 0x060001CF RID: 463 RVA: 0x00002635 File Offset: 0x00000835
		internal virtual TextBox fppc4
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc4;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc4 = value;
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060001D0 RID: 464 RVA: 0x00010C0C File Offset: 0x0000EE0C
		// (set) Token: 0x060001D1 RID: 465 RVA: 0x0000263F File Offset: 0x0000083F
		internal virtual TextBox fppc3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc3 = value;
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060001D2 RID: 466 RVA: 0x00010C24 File Offset: 0x0000EE24
		// (set) Token: 0x060001D3 RID: 467 RVA: 0x00002649 File Offset: 0x00000849
		internal virtual TextBox fppc2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc2 = value;
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060001D4 RID: 468 RVA: 0x00010C3C File Offset: 0x0000EE3C
		// (set) Token: 0x060001D5 RID: 469 RVA: 0x00002653 File Offset: 0x00000853
		internal virtual TextBox fppc1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc1 = value;
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060001D6 RID: 470 RVA: 0x00010C54 File Offset: 0x0000EE54
		// (set) Token: 0x060001D7 RID: 471 RVA: 0x0000265D File Offset: 0x0000085D
		internal virtual Label Label33
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label33;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label33 = value;
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x00010C6C File Offset: 0x0000EE6C
		// (set) Token: 0x060001D9 RID: 473 RVA: 0x00002667 File Offset: 0x00000867
		internal virtual Label Label32
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label32;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label32 = value;
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060001DA RID: 474 RVA: 0x00010C84 File Offset: 0x0000EE84
		// (set) Token: 0x060001DB RID: 475 RVA: 0x00002671 File Offset: 0x00000871
		internal virtual TextBox OtherDeliveryChargeTextBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._OtherDeliveryChargeTextBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._OtherDeliveryChargeTextBox = value;
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060001DC RID: 476 RVA: 0x00010C9C File Offset: 0x0000EE9C
		// (set) Token: 0x060001DD RID: 477 RVA: 0x0000267B File Offset: 0x0000087B
		internal virtual TextBox fppc9dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc9dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc9dc = value;
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060001DE RID: 478 RVA: 0x00010CB4 File Offset: 0x0000EEB4
		// (set) Token: 0x060001DF RID: 479 RVA: 0x00002685 File Offset: 0x00000885
		internal virtual TextBox fppc8dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc8dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc8dc = value;
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060001E0 RID: 480 RVA: 0x00010CCC File Offset: 0x0000EECC
		// (set) Token: 0x060001E1 RID: 481 RVA: 0x0000268F File Offset: 0x0000088F
		internal virtual TextBox fppc7dc
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc7dc;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc7dc = value;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060001E2 RID: 482 RVA: 0x00010CE4 File Offset: 0x0000EEE4
		// (set) Token: 0x060001E3 RID: 483 RVA: 0x00002699 File Offset: 0x00000899
		internal virtual TextBox fppc9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc9 = value;
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x00010CFC File Offset: 0x0000EEFC
		// (set) Token: 0x060001E5 RID: 485 RVA: 0x000026A3 File Offset: 0x000008A3
		internal virtual TextBox fppc8
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc8;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc8 = value;
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x00010D14 File Offset: 0x0000EF14
		// (set) Token: 0x060001E7 RID: 487 RVA: 0x000026AD File Offset: 0x000008AD
		internal virtual TextBox fppc7
		{
			[DebuggerNonUserCode]
			get
			{
				return this._fppc7;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._fppc7 = value;
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x00010D2C File Offset: 0x0000EF2C
		// (set) Token: 0x060001E9 RID: 489 RVA: 0x000026B7 File Offset: 0x000008B7
		internal virtual GroupBox GroupBox3
		{
			[DebuggerNonUserCode]
			get
			{
				return this._GroupBox3;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._GroupBox3 = value;
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060001EA RID: 490 RVA: 0x00010D44 File Offset: 0x0000EF44
		// (set) Token: 0x060001EB RID: 491 RVA: 0x000026C1 File Offset: 0x000008C1
		internal virtual Label Label34
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label34;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label34 = value;
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060001EC RID: 492 RVA: 0x00010D5C File Offset: 0x0000EF5C
		// (set) Token: 0x060001ED RID: 493 RVA: 0x00010D74 File Offset: 0x0000EF74
		internal virtual Button Button9
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button9;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button9_Click);
				bool flag = this._Button9 != null;
				if (flag)
				{
					this._Button9.Click -= value2;
				}
				this._Button9 = value;
				flag = (this._Button9 != null);
				if (flag)
				{
					this._Button9.Click += value2;
				}
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060001EE RID: 494 RVA: 0x00010DD4 File Offset: 0x0000EFD4
		// (set) Token: 0x060001EF RID: 495 RVA: 0x000026CB File Offset: 0x000008CB
		internal virtual TextBox ReceiptAdvertTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ReceiptAdvertTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._ReceiptAdvertTB = value;
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060001F0 RID: 496 RVA: 0x00010DEC File Offset: 0x0000EFEC
		// (set) Token: 0x060001F1 RID: 497 RVA: 0x00010E04 File Offset: 0x0000F004
		internal virtual Button MenuBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._MenuBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.MenuBTN_Click);
				bool flag = this._MenuBTN != null;
				if (flag)
				{
					this._MenuBTN.Click -= value2;
				}
				this._MenuBTN = value;
				flag = (this._MenuBTN != null);
				if (flag)
				{
					this._MenuBTN.Click += value2;
				}
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x00010E64 File Offset: 0x0000F064
		// (set) Token: 0x060001F3 RID: 499 RVA: 0x00010E7C File Offset: 0x0000F07C
		internal virtual Button Button10
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button10;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button10_Click);
				bool flag = this._Button10 != null;
				if (flag)
				{
					this._Button10.Click -= value2;
				}
				this._Button10 = value;
				flag = (this._Button10 != null);
				if (flag)
				{
					this._Button10.Click += value2;
				}
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x00010EDC File Offset: 0x0000F0DC
		// (set) Token: 0x060001F5 RID: 501 RVA: 0x00010EF4 File Offset: 0x0000F0F4
		internal virtual CheckBox SafeModeCheckBox
		{
			[DebuggerNonUserCode]
			get
			{
				return this._SafeModeCheckBox;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.SafeModeCheckBox_CheckedChanged);
				bool flag = this._SafeModeCheckBox != null;
				if (flag)
				{
					this._SafeModeCheckBox.CheckedChanged -= value2;
				}
				this._SafeModeCheckBox = value;
				flag = (this._SafeModeCheckBox != null);
				if (flag)
				{
					this._SafeModeCheckBox.CheckedChanged += value2;
				}
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060001F6 RID: 502 RVA: 0x00010F54 File Offset: 0x0000F154
		// (set) Token: 0x060001F7 RID: 503 RVA: 0x00010F6C File Offset: 0x0000F16C
		internal virtual Button ExportCustomersCSV
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExportCustomersCSV;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button11_Click);
				bool flag = this._ExportCustomersCSV != null;
				if (flag)
				{
					this._ExportCustomersCSV.Click -= value2;
				}
				this._ExportCustomersCSV = value;
				flag = (this._ExportCustomersCSV != null);
				if (flag)
				{
					this._ExportCustomersCSV.Click += value2;
				}
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060001F8 RID: 504 RVA: 0x00010FCC File Offset: 0x0000F1CC
		// (set) Token: 0x060001F9 RID: 505 RVA: 0x00010FE4 File Offset: 0x0000F1E4
		internal virtual Button ExportCustomersTXT
		{
			[DebuggerNonUserCode]
			get
			{
				return this._ExportCustomersTXT;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button11_Click);
				bool flag = this._ExportCustomersTXT != null;
				if (flag)
				{
					this._ExportCustomersTXT.Click -= value2;
				}
				this._ExportCustomersTXT = value;
				flag = (this._ExportCustomersTXT != null);
				if (flag)
				{
					this._ExportCustomersTXT.Click += value2;
				}
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060001FA RID: 506 RVA: 0x00011044 File Offset: 0x0000F244
		// (set) Token: 0x060001FB RID: 507 RVA: 0x000026D5 File Offset: 0x000008D5
		internal virtual FolderBrowserDialog FolderBrowserDialogCustomersExport
		{
			[DebuggerNonUserCode]
			get
			{
				return this._FolderBrowserDialogCustomersExport;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._FolderBrowserDialogCustomersExport = value;
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060001FC RID: 508 RVA: 0x0001105C File Offset: 0x0000F25C
		// (set) Token: 0x060001FD RID: 509 RVA: 0x00011074 File Offset: 0x0000F274
		internal virtual Button Button11
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button11;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button11_Click_1);
				bool flag = this._Button11 != null;
				if (flag)
				{
					this._Button11.Click -= value2;
				}
				this._Button11 = value;
				flag = (this._Button11 != null);
				if (flag)
				{
					this._Button11.Click += value2;
				}
			}
		}

		// Token: 0x060001FE RID: 510 RVA: 0x000110D4 File Offset: 0x0000F2D4
		private void General_Settings_Load(object sender, EventArgs e)
		{
			this.ReadBusinessInfo();
			this.ReadDrivers();
			this.ReadOrderHistory();
			this.ShowAllPostcodes();
			this.FTPsaveBTN.Enabled = false;
			this.FTPPasswordTextBox.Text = MySettingsProperty.Settings.FTPpassword;
			this.FTPUsernameTextBox.Text = MySettingsProperty.Settings.FTPusername;
			this.SoftwareDomainTextBox.Text = MySettingsProperty.Settings.SoftwareWebsite;
			this.ShopOwnerMobileTextBox.Text = MySettingsProperty.Settings.ShopOwnerMobile;
			this.BusinessEmailTextBox.Text = MySettingsProperty.Settings.BusinessEmail;
			this.CallerIdComboBox.SelectedItem = MySettingsProperty.Settings.CallerIdType;
			this.CallerIdComboBox1.SelectedItem = MySettingsProperty.Settings.CallerIdType;
			bool flag = Operators.CompareString(MySettingsProperty.Settings.SoftwareType, "ONLINE MODE", false) == 0;
			if (flag)
			{
				this.OnlineModeCheckBox.Checked = true;
			}
			else
			{
				this.OnlineModeCheckBox.Checked = false;
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.RemoveItemsInShoppingCart, "y", false) == 0);
			if (flag)
			{
				this.RemoveItemsInShoppingCartCheckBox.Checked = true;
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.ActiveEditOrders, "y", false) == 0);
			if (flag)
			{
				this.ActiveEditOrdersCheckBox.Checked = true;
			}
			else
			{
				this.ActiveEditOrdersCheckBox.Checked = false;
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.SafeMode, "y", false) == 0);
			if (flag)
			{
				this.SafeModeCheckBox.Checked = true;
			}
			else
			{
				this.SafeModeCheckBox.Checked = false;
			}
			this.AutoCompleteOrderTextBox.Text = MySettingsProperty.Settings.AutoCompleteTime;
			flag = (Operators.CompareString(MySettingsProperty.Settings.AutoCompleteTime, "Disable", false) == 0);
			if (flag)
			{
				this.AutoCompleteOrderTextBox.Text = "";
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.DriversAccess, "y", false) == 0);
			if (flag)
			{
				this.DriversAccessCheckBox.Checked = true;
			}
			else
			{
				this.DriversAccessCheckBox.Checked = false;
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.PostCodeFinder, "y", false) == 0);
			if (flag)
			{
				this.PostcodeFinderCheckBox.Checked = true;
				this.PostcodeFinderCheckBox1.Checked = true;
			}
			else
			{
				this.PostcodeFinderCheckBox.Checked = false;
				this.PostcodeFinderCheckBox1.Checked = false;
			}
			flag = (Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 1.0);
			if (flag)
			{
				this.Categories2RowsCheckBox.Checked = false;
			}
			flag = (Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 2.0);
			if (flag)
			{
				this.Categories2RowsCheckBox.Checked = true;
			}
			this.NumberOfPrintTextBox.Text = MySettingsProperty.Settings.NumberOfPrint;
			this.ListOfPrinters();
			flag = (Operators.CompareString(MySettingsProperty.Settings.TableManagementSystem, "on", false) == 0);
			if (flag)
			{
				this.TableManagementCheckBox.Checked = true;
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.TableManagementSystem, "off", false) == 0);
			if (flag)
			{
				this.TableManagementCheckBox.Checked = false;
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.CashandCarry, "on", false) == 0);
			if (flag)
			{
				this.SupplierCheckBox.Checked = true;
			}
			flag = (Operators.CompareString(MySettingsProperty.Settings.CashandCarry, "off", false) == 0);
			if (flag)
			{
				this.SupplierCheckBox.Checked = false;
			}
			this.PrintersComboBox.SelectedItem = MySettingsProperty.Settings.PrinterName;
			this.Printer1ComboBox.SelectedItem = MySettingsProperty.Settings.Printer1Name;
			this.Printer2ComboBox.SelectedItem = MySettingsProperty.Settings.Printer2Name;
			this.MyPrinterFontType.Text = MySettingsProperty.Settings.MyPrinterFontType;
			this.OrderFontSizeTextBox.Text = Conversions.ToString(MySettingsProperty.Settings.OrderFontSize);
			this.FoodLeftAtTextBox.Text = Conversions.ToString(MySettingsProperty.Settings.FoodLeftAt);
			this.PriceLeftAtTextBox.Text = Conversions.ToString(MySettingsProperty.Settings.PriceLeftAt);
			this.FoodMaxLenTextBox.Text = Conversions.ToString(MySettingsProperty.Settings.FoodMaxLen);
			this.CommentFontSieTextBox.Text = Conversions.ToString(MySettingsProperty.Settings.CommentFontSie);
			this.OrderLineSpaceTextBox.Text = Conversions.ToString(MySettingsProperty.Settings.OrderLineSpace);
			this.SecondLinesSpaceTextBox.Text = Conversions.ToString(MySettingsProperty.Settings.SecondLinesSpace);
			this.fppc1.Text = MySettingsProperty.Settings.DeliveryPostCode1;
			this.fppc2.Text = MySettingsProperty.Settings.DeliveryPostCode2;
			this.fppc3.Text = MySettingsProperty.Settings.DeliveryPostCode3;
			this.fppc4.Text = MySettingsProperty.Settings.DeliveryPostCode4;
			this.fppc5.Text = MySettingsProperty.Settings.DeliveryPostCode5;
			this.fppc6.Text = MySettingsProperty.Settings.DeliveryPostCode6;
			this.fppc7.Text = MySettingsProperty.Settings.DeliveryPostCode7;
			this.fppc8.Text = MySettingsProperty.Settings.DeliveryPostCode8;
			this.fppc9.Text = MySettingsProperty.Settings.DeliveryPostCode9;
			this.fppc1dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode1;
			this.fppc2dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode2;
			this.fppc3dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode3;
			this.fppc4dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode4;
			this.fppc5dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode5;
			this.fppc6dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode6;
			this.fppc7dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode7;
			this.fppc8dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode8;
			this.fppc9dc.Text = MySettingsProperty.Settings.DeliveryChargePostCode9;
			this.OtherDeliveryChargeTextBox.Text = MySettingsProperty.Settings.DeliveryCharge;
			this.ReceiptAdvertTB.Text = MySettingsProperty.Settings.PrintBottomAdvertise;
			flag = (Operators.CompareString(MySettingsProperty.Settings.BusinessName, "Softeware Demo Version", false) == 0);
			if (flag)
			{
				this.UserNameComboBox.SelectedText = "SHOP OWNER";
				MessageBox.Show("Password is: 1234");
			}
		}

		// Token: 0x060001FF RID: 511 RVA: 0x0001176C File Offset: 0x0000F96C
		private void ListOfPrinters()
		{
			this.PrintersComboBox.Items.Add("Default");
			this.Printer1ComboBox.Items.Add("");
			this.Printer2ComboBox.Items.Add("");
			int num = 0;
			checked
			{
				int num2 = PrinterSettings.InstalledPrinters.Count - 1;
				int num3 = num;
				for (;;)
				{
					int num4 = num3;
					int num5 = num2;
					if (num4 > num5)
					{
						break;
					}
					string text = PrinterSettings.InstalledPrinters[num3];
					bool flag = Operators.CompareString(text, "Microsoft XPS Document Writer", false) == 0;
					if (!flag)
					{
						flag = (Operators.CompareString(text, "Microsoft Office Document Image Writer", false) == 0);
						if (!flag)
						{
							flag = (Operators.CompareString(text, "Fax", false) == 0);
							if (!flag)
							{
								this.PrintersComboBox.Items.Add(text);
								this.Printer1ComboBox.Items.Add(text);
								this.Printer2ComboBox.Items.Add(text);
							}
						}
					}
					num3++;
				}
			}
		}

		// Token: 0x06000200 RID: 512 RVA: 0x000026DF File Offset: 0x000008DF
		private void Button1_Click(object sender, EventArgs e)
		{
			this.CurrentUserCP = "";
			this.Close();
		}

		// Token: 0x06000201 RID: 513 RVA: 0x00011864 File Offset: 0x0000FA64
		private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool flag = Operators.ConditionalCompareObjectEqual(this.CallerIdComboBox.SelectedItem, "", false);
			if (flag)
			{
				this.CallerIdComboBox1.SelectedItem = "";
				MySettingsProperty.Settings.CallerIdEnabled = "no";
				MySettingsProperty.Settings.CallerIdType = "";
				MySettingsProperty.Settings.Save();
				M_Settings.CallerIdType = "";
			}
			flag = Operators.ConditionalCompareObjectEqual(this.CallerIdComboBox.SelectedItem, "ARTECH AD102", false);
			if (flag)
			{
				this.CallerIdComboBox1.SelectedItem = "ARTECH AD102";
				MySettingsProperty.Settings.CallerIdEnabled = "yes";
				MySettingsProperty.Settings.CallerIdType = "ARTECH AD102";
				MySettingsProperty.Settings.Save();
				M_Settings.CallerIdType = "ARTECH AD102";
				MyProject.Forms.Index.CallerIdTimer.Start();
				CallerID.LoadCallerId();
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0000221E File Offset: 0x0000041E
		private void SaveBTN_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000203 RID: 515 RVA: 0x0000221E File Offset: 0x0000041E
		private void Button2_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000204 RID: 516 RVA: 0x0001195C File Offset: 0x0000FB5C
		private void ReadBusinessInfo()
		{
			bool flag = Operators.CompareString(MySettingsProperty.Settings.SoftwareExpiryDate, "", false) != 0;
			if (flag)
			{
				string[] array = File.ReadAllText(M_Settings.DataFolder + "\\admin\\BusinessInfo.txt").Split(new char[]
				{
					'|'
				});
				this.BNameTextBox.Text = array[0];
				this.BPhoneTextBox.Text = array[1];
				this.BAddressTextBox.Text = array[2];
				this.BCityTextBox.Text = array[3];
				this.BPostcodeTextBox.Text = array[4];
			}
			else
			{
				this.BNameTextBox.Text = MySettingsProperty.Settings.BusinessName;
				this.BAddressTextBox.Text = MySettingsProperty.Settings.BusinessAddress;
				this.BCityTextBox.Text = MySettingsProperty.Settings.BusinessCity;
				this.BPostcodeTextBox.Text = MySettingsProperty.Settings.BusinessPostcode;
				this.BPhoneTextBox.Text = MySettingsProperty.Settings.BusinessTel;
			}
		}

		// Token: 0x06000205 RID: 517 RVA: 0x000026F5 File Offset: 0x000008F5
		private void Button3_Click(object sender, EventArgs e)
		{
			Process.Start("osk");
		}

		// Token: 0x06000206 RID: 518 RVA: 0x0000221E File Offset: 0x0000041E
		private void CancelBTN_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		// Token: 0x06000207 RID: 519 RVA: 0x00002704 File Offset: 0x00000904
		private void LoginPanel_Paint(object sender, PaintEventArgs e)
		{
			M_Settings.FocusedTextBoxForKeyboardTyping = this.PasswordTextBox;
			Keyboard.MyKeyboard(this.KeyboardPanel, this.KeyboardPanel.Width, this.KeyboardPanel.Height);
		}

		// Token: 0x06000208 RID: 520 RVA: 0x00011A70 File Offset: 0x0000FC70
		private void LoginBTN_Click(object sender, EventArgs e)
		{
			bool flag = false;
			if (Operators.CompareString(this.UserNameComboBox.Text, "STAFF", false) == 0 & Operators.CompareString(this.PasswordTextBox.Text, MySettingsProperty.Settings.StaffPassword, false) == 0)
			{
				this.CurrentUserCP = "STAFF";
				this.AdvancedTP.TabPages.Remove(this.AbolfazlTB);
				this.AdvancedTP.TabPages.Remove(this.GeneralTB);
				this.LoginPanel.Hide();
				M_Settings.FocusedTextBoxForKeyboardTyping = this.AddDriverNameTextBox;
				this.NewPassUserComboBox.Items.Add("STAFF");
				flag = true;
			}
			else if (Operators.CompareString(this.UserNameComboBox.Text, "ADMIN", false) == 0 & Operators.CompareString(this.PasswordTextBox.Text, MySettingsProperty.Settings.AdminPassword, false) == 0)
			{
				this.CurrentUserCP = "ADMIN";
				this.AdvancedTP.TabPages.Remove(this.AbolfazlTB);
				this.LoginPanel.Hide();
				M_Settings.FocusedTextBoxForKeyboardTyping = this.AddDriverNameTextBox;
				this.NewPassUserComboBox.Items.Add("STAFF");
				this.NewPassUserComboBox.Items.Add("ADMIN");
				this.FlashDriverGroupBox.Visible = false;
				this.UpdateBTN.Visible = true;
				flag = true;
			}
			else if (Operators.CompareString(this.UserNameComboBox.Text, "SHOP OWNER", false) == 0 & Operators.CompareString(this.PasswordTextBox.Text, MySettingsProperty.Settings.ShopOwnerPassword, false) == 0)
			{
				this.CurrentUserCP = "SHOP OWNER";
				this.AdvancedTP.TabPages.Remove(this.AbolfazlTB);
				this.LoginPanel.Hide();
				M_Settings.FocusedTextBoxForKeyboardTyping = this.AddDriverNameTextBox;
				this.NewPassUserComboBox.Items.Add("STAFF");
				this.NewPassUserComboBox.Items.Add("ADMIN");
				this.NewPassUserComboBox.Items.Add("SHOP OWNER");
				this.DownloadBackupGroupBox.Visible = true;
				this.BusinessInfoGroupBox.Visible = true;
				this.FlashDriverGroupBox.Visible = true;
				this.USBRestoreBTN.Visible = true;
				this.ShopOwnerGroupBox.Visible = true;
				this.PostcodeFinderCheckBox.Visible = true;
				this.RemoveItemsInShoppingCartCheckBox.Visible = true;
				this.AutoCompleteOrderTextBox.Visible = true;
				this.AutoCompleteLBL.Visible = true;
				this.OrderHistoryDeleteBTN.Visible = true;
				this.TableManagementCheckBox.Visible = true;
				this.CallerIdComboBox1.Visible = true;
				this.CallerIDLBL.Visible = true;
				this.OtherDeliveryChargeTextBox.Visible = true;
				this.DeliveryChargeLBL.Visible = true;
				this.DriversAccessCheckBox.Visible = true;
				this.ActiveEditOrdersCheckBox.Visible = true;
				this.UpdateBTN.Visible = true;
				flag = true;
			}
			else if (Operators.CompareString(this.UserNameComboBox.Text, "SUPER ADMIN", false) == 0 & Operators.CompareString(this.PasswordTextBox.Text, "1234", false) == 0)
			{
				this.CurrentUserCP = "SUPER ADMIN";
				this.LoginPanel.Hide();
				M_Settings.FocusedTextBoxForKeyboardTyping = this.AddDriverNameTextBox;
				this.NewPassUserComboBox.Items.Add("STAFF");
				this.NewPassUserComboBox.Items.Add("ADMIN");
				this.NewPassUserComboBox.Items.Add("SHOP OWNER");
				this.DownloadBackupGroupBox.Visible = true;
				this.BusinessInfoGroupBox.Visible = true;
				this.FlashDriverGroupBox.Visible = true;
				this.USBRestoreBTN.Visible = true;
				this.ShopOwnerGroupBox.Visible = true;
				this.PostcodeFinderCheckBox.Visible = true;
				this.RemoveItemsInShoppingCartCheckBox.Visible = true;
				this.AutoCompleteOrderTextBox.Visible = true;
				this.AutoCompleteLBL.Visible = true;
				this.OrderHistoryDeleteBTN.Visible = true;
				this.TableManagementCheckBox.Visible = true;
				this.CallerIdComboBox1.Visible = true;
				this.CallerIDLBL.Visible = true;
				this.OtherDeliveryChargeTextBox.Visible = true;
				this.DeliveryChargeLBL.Visible = true;
				this.DriversAccessCheckBox.Visible = true;
				this.ActiveEditOrdersCheckBox.Visible = true;
				this.UpdateBTN.Visible = true;
				flag = true;
			}
			if (!flag)
			{
				MessageBox.Show("Password is not correct.");
				return;
			}
			this.NewPasswordGroupBox.Text = this.CurrentUserCP + " New Password";
		}

		// Token: 0x06000209 RID: 521 RVA: 0x00011F18 File Offset: 0x00010118
		private void ReadDrivers()
		{
			string[] array = File.ReadAllText(M_Settings.DataFolder + "\\_Drivers.txt").Split(new char[]
			{
				'|'
			});
			foreach (string item in array)
			{
				this.DriversListBox.Items.Add(item);
				this.DriversDeleteComboBox.Items.Add(item);
			}
			Keyboard.MyKeyboard(this.KeyboardDriver, this.KeyboardDriver.Width, this.KeyboardDriver.Height);
		}

		// Token: 0x0600020A RID: 522 RVA: 0x0000273F File Offset: 0x0000093F
		private void AddDriverNameTextBox_GotFocus(object sender, EventArgs e)
		{
			M_Settings.FocusedTextBoxForKeyboardTyping = this.AddDriverNameTextBox;
		}

		// Token: 0x0600020B RID: 523 RVA: 0x0000274E File Offset: 0x0000094E
		private void AddDriverMobileTextBox_GotFocus(object sender, EventArgs e)
		{
			M_Settings.FocusedTextBoxForKeyboardTyping = this.AddDriverMobileTextBox;
		}

		// Token: 0x0600020C RID: 524 RVA: 0x00011FBC File Offset: 0x000101BC
		private void Button2_Click_1(object sender, EventArgs e)
		{
			try
			{
				bool flag = this.AddDriverMobileTextBox.Text.Length != 11;
				if (flag)
				{
					MessageBox.Show("Mobile number is not correct.");
				}
				flag = (Operators.CompareString(this.AddDriverNameTextBox.Text, "", false) != 0 & Conversions.ToDouble(this.AddDriverMobileTextBox.Text) > 0.0 & this.AddDriverMobileTextBox.Text.Length == 11);
				if (flag)
				{
					string text = File.ReadAllText(M_Settings.DataFolder + "\\_Drivers.txt");
					string text2 = this.AddDriverNameTextBox.Text + " - " + this.AddDriverMobileTextBox.Text;
					string text3 = text + "|" + text2;
					flag = (Operators.CompareString(text, "", false) == 0);
					if (flag)
					{
						text3 = text2;
					}
					File.WriteAllText(M_Settings.DataFolder + "\\_Drivers.txt", text3.Trim(new char[]
					{
						'|'
					}));
					this.DriversListBox.Items.Add(text2);
					this.DriversDeleteComboBox.Items.Add(text2);
					this.AddDriverMobileTextBox.Text = "";
					this.AddDriverNameTextBox.Text = "";
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Mobile or Name is not correct.");
			}
		}

		// Token: 0x0600020D RID: 525 RVA: 0x00012150 File Offset: 0x00010350
		private void Button3_Click_1(object sender, EventArgs e)
		{
			try
			{
				string text = File.ReadAllText(M_Settings.DataFolder + "\\_Drivers.txt");
				text = text.Trim();
				text = text.Replace(Conversions.ToString(this.DriversDeleteComboBox.SelectedItem), "");
				text = text.Replace("||", "|");
				File.WriteAllText(M_Settings.DataFolder + "\\_Drivers.txt", text.Trim(new char[]
				{
					'|'
				}));
				int selectedIndex = this.DriversDeleteComboBox.SelectedIndex;
				this.DriversDeleteComboBox.Items.RemoveAt(selectedIndex);
				this.DriversListBox.Items.RemoveAt(selectedIndex);
				this.DriversDeleteComboBox.Text = "";
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600020E RID: 526 RVA: 0x00012234 File Offset: 0x00010434
		private void NewPasswordSaveBTN_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.NewPassUserComboBox.Text, "", false) != 0;
			if (flag)
			{
				bool flag2 = this.NewPassTextBox.Text.Length > 3;
				if (flag2)
				{
					bool flag3 = Operators.CompareString(this.NewPassTextBox.Text, this.NewPassConfirmfTextBox.Text, false) == 0;
					if (flag3)
					{
						bool flag4 = Operators.CompareString(this.NewPassUserComboBox.Text, "STAFF", false) == 0;
						if (flag4)
						{
							MySettingsProperty.Settings.StaffPassword = this.NewPassTextBox.Text;
						}
						flag4 = (Operators.CompareString(this.NewPassUserComboBox.Text, "ADMIN", false) == 0);
						if (flag4)
						{
							flag3 = (Operators.CompareString(this.NewPassUserComboBox.Text, "STAFF", false) == 0);
							if (flag3)
							{
								MySettingsProperty.Settings.StaffPassword = this.NewPassTextBox.Text;
							}
							flag4 = (Operators.CompareString(this.NewPassUserComboBox.Text, "ADMIN", false) == 0);
							if (flag4)
							{
								MySettingsProperty.Settings.AdminPassword = this.NewPassTextBox.Text;
							}
						}
						flag4 = (Operators.CompareString(this.NewPassUserComboBox.Text, "SHOP OWNER", false) == 0);
						if (flag4)
						{
							flag3 = (Operators.CompareString(this.NewPassUserComboBox.Text, "STAFF", false) == 0);
							if (flag3)
							{
								MySettingsProperty.Settings.StaffPassword = this.NewPassTextBox.Text;
							}
							flag4 = (Operators.CompareString(this.NewPassUserComboBox.Text, "ADMIN", false) == 0);
							if (flag4)
							{
								MySettingsProperty.Settings.AdminPassword = this.NewPassTextBox.Text;
							}
							flag4 = (Operators.CompareString(this.NewPassUserComboBox.Text, "SHOP OWNER", false) == 0);
							if (flag4)
							{
								MySettingsProperty.Settings.ShopOwnerPassword = this.NewPassTextBox.Text;
							}
						}
						this.NewPassUserComboBox.Text = "";
						this.NewPassTextBox.Text = "";
						this.NewPassConfirmfTextBox.Text = "";
						MessageBox.Show("New Password Saved.");
					}
					else
					{
						MessageBox.Show("Passwords do not match.");
					}
				}
				else
				{
					MessageBox.Show("Password must be at least 4 characters.");
				}
			}
			else
			{
				MessageBox.Show("Please select user.");
			}
		}

		// Token: 0x0600020F RID: 527 RVA: 0x0000275D File Offset: 0x0000095D
		private void RePrintSaleReportBTN_Click(object sender, EventArgs e)
		{
			MyProject.Forms.RePrintSaleReport.Show();
		}

		// Token: 0x06000210 RID: 528 RVA: 0x00012484 File Offset: 0x00010684
		private void DownloadBackupBTN_Click(object sender, EventArgs e)
		{
			bool flag = !this.DownloadPostcodesRB.Checked & !this.DownloadBackupCustomersRB.Checked & !this.DownloadBackupMenuRB.Checked;
			if (flag)
			{
				MessageBox.Show("Please select a download option.");
			}
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
			flag = this.DownloadBackupCustomersRB.Checked;
			if (flag)
			{
				this.DownloadCustomers();
			}
			flag = this.DownloadBackupMenuRB.Checked;
			if (flag)
			{
				this.DownloadMenu();
			}
			flag = this.DownloadPostcodesRB.Checked;
			if (flag)
			{
				this.DownloadPostcodes();
			}
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
		}

		// Token: 0x06000211 RID: 529 RVA: 0x00012524 File Offset: 0x00010724
		public void DownloadMenu()
		{
			try
			{
				this.UploadDownloadProgressBar.Value = 0;
				string text = "partners/" + MySettingsProperty.Settings.ServerFolderName + "/menu";
				string[] array = (string[])NewLateBinding.LateGet(Online.postdata(Online.SoftwareDomain, "scan_folders_in_folder.php", text, "", "", "", "", ""), null, "Split", new object[]
				{
					"|"
				}, null, null, null);
				bool flag = Operators.CompareString(array[1], "", false) != 0;
				if (flag)
				{
					bool flag2 = Directory.Exists("menu");
					if (flag2)
					{
						FileSystem.RenameDirectory("menu", Conversions.ToString(Operators.AddObject(Operators.AddObject("menu_OLD_", M_Settings.CurrentDate()), M_Settings.CurrentTime())));
					}
					FileSystem.CreateDirectory("menu");
					foreach (string text2 in array)
					{
						Directory.CreateDirectory("menu\\" + text2);
						text = "partners/" + MySettingsProperty.Settings.ServerFolderName + "/menu/" + text2;
						string text3 = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "scan_files_in_folder.php", text, "", "", "", "", ""));
						string[] array3 = text3.Split(new char[]
						{
							'#'
						});
						int num = Conversions.ToInteger(array3[0]);
						flag2 = (num != 0);
						if (flag2)
						{
							string[] files = array3[1].Split(new char[]
							{
								'|'
							});
							Online.DownloadManyFiles(num, files, text, "menu\\" + text2);
						}
					}
					Online.DownloadFile("partners/" + MySettingsProperty.Settings.ServerFolderName + "/menu", "_Categories.txt", "menu");
					Online.DownloadFile("partners/" + MySettingsProperty.Settings.ServerFolderName + "/menu", "_offers.txt", "menu");
					this.DownloadBackupMenuRB.Checked = false;
					this.UploadDownloadProgressBar.Value = 100;
					Online.postdata(Online.SoftwareDomain, "/menu/menu_auto_download.php", "", MySettingsProperty.Settings.ServerFolderName, "", "", "", "");
					MessageBox.Show("New Menu Downloaded Successfully." + Environment.NewLine + "Program will be closed and runs again automaticaly.");
					MySettingsProperty.Settings.MenuJustDownloaded = "y";
					this.Close();
					MyProject.Forms.Index.Close();
					Process.Start("HOHA.exe");
				}
				else
				{
					MessageBox.Show("There is no menu on server.");
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000212 RID: 530 RVA: 0x00012824 File Offset: 0x00010A24
		private void DownloadPostcodes()
		{
			try
			{
				string text = "partners/" + MySettingsProperty.Settings.ServerFolderName + "/pc";
				string text2 = Conversions.ToString(Online.postdata(Online.SoftwareDomain, "scan_files_in_folder.php", text, "", "", "", "", ""));
				bool flag = Operators.CompareString(Conversions.ToString(text2[0]), "0", false) != 0;
				if (flag)
				{
					string[] array = text2.Split(new char[]
					{
						'#'
					});
					int num = Conversions.ToInteger(array[0]);
					string[] files = array[1].Split(new char[]
					{
						'|'
					});
					Online.DownloadManyFiles(num, files, text, "pc");
				}
				PostCode.GetBusinessLatLang();
				MessageBox.Show("Postcodes Downloaded Successfully.");
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000213 RID: 531 RVA: 0x00012924 File Offset: 0x00010B24
		private void DownloadCustomers()
		{
			this.UploadDownloadProgressBar.Value = 0;
			Online.DownloadFile("partners/" + MySettingsProperty.Settings.ServerFolderName + "/data", "_Customers.txt", "data");
			this.DownloadBackupCustomersRB.Checked = false;
			this.UploadDownloadProgressBar.Value = 100;
			bool flag = this.UploadDownloadProgressBar.Value == 100 & !this.DownloadPostcodesRB.Checked;
			if (flag)
			{
				MessageBox.Show("Download Completed.");
			}
		}

		// Token: 0x06000214 RID: 532 RVA: 0x000129B4 File Offset: 0x00010BB4
		private void FTPsaveBTN_Click(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.SoftwareWebsite = this.SoftwareDomainTextBox.Text;
			MySettingsProperty.Settings.FTPusername = this.FTPUsernameTextBox.Text;
			MySettingsProperty.Settings.FTPpassword = this.FTPPasswordTextBox.Text;
			MySettingsProperty.Settings.Save();
			MessageBox.Show("FTP details Saved.");
		}

		// Token: 0x06000215 RID: 533 RVA: 0x00012A1C File Offset: 0x00010C1C
		private void FTPping_Click(object sender, EventArgs e)
		{
			try
			{
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
				string left = Conversions.ToString(Online.postdata(this.SoftwareDomainTextBox.Text, "/_All_Computers_Settings/Check_Connection.php", "", "", "", "", "", ""));
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
				bool flag = Operators.CompareString(left, "connection_ok", false) == 0;
				if (flag)
				{
					this.FTPsaveBTN.Enabled = true;
				}
				else
				{
					MessageBox.Show("Ping Failed.");
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000216 RID: 534 RVA: 0x00012AD0 File Offset: 0x00010CD0
		private void USBRestoreBTN_Click(object sender, EventArgs e)
		{
			this.UploadDownloadProgressBar.Value = 0;
			string str = Conversions.ToString(Operators.AddObject(M_Settings.CurrentDate(), M_Settings.CurrentTime()));
			string text = "HOHA Software Backup\\" + str;
			bool flag = !Directory.Exists("HOHA Software Backup");
			if (flag)
			{
				Directory.CreateDirectory("HOHA Software Backup");
			}
			this.UploadDownloadProgressBar.Value = 10;
			Directory.CreateDirectory(text);
			MessageBox.Show("Please insert a flash drive into USB port and select flash drive.");
			this.UploadDownloadProgressBar.Value = 30;
			FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
			DriveInfo[] drives = DriveInfo.GetDrives();
			DriveInfo driveInfo = drives.FirstOrDefault((DriveInfo m) => m.DriveType == DriveType.Removable);
			folderBrowserDialog.SelectedPath = driveInfo.RootDirectory.FullName;
			flag = (folderBrowserDialog.ShowDialog() == DialogResult.OK);
			if (flag)
			{
				this.UploadDownloadProgressBar.Value = 50;
				this.USBRestoreBTN.Text = "Please wait...";
				this.USBRestoreBTN.Refresh();
				FileSystem.CopyDirectory("menu", text + "\\menu");
				FileSystem.CopyDirectory("pc", text + "\\pc");
				FileSystem.CopyDirectory("data", text + "\\data");
				this.UploadDownloadProgressBar.Value = 70;
				flag = (Directory.Exists(folderBrowserDialog.SelectedPath + "HOHA Software Backup\\menu") & Directory.Exists(folderBrowserDialog.SelectedPath + "HOHA Software Backup\\pc") & Directory.Exists(folderBrowserDialog.SelectedPath + "HOHA Software Backup\\data"));
				if (flag)
				{
					Directory.Delete("menu", true);
					Directory.Delete("pc", true);
					Directory.Delete("data", true);
					this.UploadDownloadProgressBar.Value = 90;
					FileSystem.CopyDirectory(folderBrowserDialog.SelectedPath + "HOHA Software Backup\\menu", "menu");
					FileSystem.CopyDirectory(folderBrowserDialog.SelectedPath + "HOHA Software Backup\\pc", "pc");
					FileSystem.CopyDirectory(folderBrowserDialog.SelectedPath + "HOHA Software Backup\\data", "data");
					this.UploadDownloadProgressBar.Value = 100;
					flag = (this.UploadDownloadProgressBar.Value == 100);
					if (flag)
					{
						MessageBox.Show("Restore Completed Successfully" + Environment.NewLine + "Software must restart.");
					}
					Process.Start("HOHA.exe");
					MyProject.Forms.Index.Close();
				}
				else
				{
					MessageBox.Show("You select the wrong flash driver OR" + Environment.NewLine + "Something is wrong with data.");
					this.UploadDownloadProgressBar.Value = 0;
					this.Close();
				}
			}
		}

		// Token: 0x06000217 RID: 535 RVA: 0x00002771 File Offset: 0x00000971
		private void Button1_Click_2(object sender, EventArgs e)
		{
			this.ResetToFactory();
		}

		// Token: 0x06000218 RID: 536 RVA: 0x00012D74 File Offset: 0x00010F74
		public void ResetToFactory()
		{
			File.Create("data\\admin\\BusinessInfo.txt").Dispose();
			MySettingsProperty.Settings.PrintBottomAdvertise = "HOHA Software - 07591158960";
			MySettingsProperty.Settings.WhiteLable = null;
			MySettingsProperty.Settings.TableManagementSystem = "on";
			MySettingsProperty.Settings.SecondLinesSpace = 15;
			MySettingsProperty.Settings.RemoveItemsInShoppingCart = "y";
			MySettingsProperty.Settings.PrinterName = "Default";
			MySettingsProperty.Settings.PriceLeftAt = 59;
			MySettingsProperty.Settings.OrderLineSpace = 17;
			MySettingsProperty.Settings.OrderFontSize = 10;
			MySettingsProperty.Settings.NumberOfPrint = Conversions.ToString(1);
			MySettingsProperty.Settings.MyPrinterFontType = "Century Gothic";
			MySettingsProperty.Settings.FoodMaxLen = 26;
			MySettingsProperty.Settings.FoodLeftAt = 6;
			MySettingsProperty.Settings.CommentFontSie = 14;
			MySettingsProperty.Settings.CategoryRows = "1";
			MySettingsProperty.Settings.CashandCarry = "on";
			MySettingsProperty.Settings.BusinessLocationLong = null;
			MySettingsProperty.Settings.BusinessLocationLat = null;
			MySettingsProperty.Settings.ActiveEditOrders = "y";
			MySettingsProperty.Settings.AbolfazlSettings = null;
			MySettingsProperty.Settings.SoftwareWebsite = null;
			MySettingsProperty.Settings.SoftwareCompany = null;
			MySettingsProperty.Settings.SoftwareAddress = null;
			MySettingsProperty.Settings.SoftwareTel = null;
			MySettingsProperty.Settings.WebsiteURL = null;
			MySettingsProperty.Settings.SoftwareType = null;
			MySettingsProperty.Settings.CallerIdEnabled = null;
			MySettingsProperty.Settings.CallerIdType = null;
			MySettingsProperty.Settings.LockSoftwareNumber = null;
			MySettingsProperty.Settings.LockSoftware = null;
			MySettingsProperty.Settings.ServerFolderName = null;
			MySettingsProperty.Settings.ShopOwnerMobile = null;
			MySettingsProperty.Settings.BusinessEmail = null;
			MySettingsProperty.Settings.FTPusername = null;
			MySettingsProperty.Settings.FTPpassword = null;
			MySettingsProperty.Settings.ComputerNo = null;
			MySettingsProperty.Settings.BusinessName = null;
			MySettingsProperty.Settings.BusinessAddress = null;
			MySettingsProperty.Settings.BusinessCity = null;
			MySettingsProperty.Settings.BusinessPostcode = null;
			MySettingsProperty.Settings.BusinessTel = null;
			MySettingsProperty.Settings.LicenseNo = null;
			MySettingsProperty.Settings.SoftwareExpiryDate = null;
			MySettingsProperty.Settings.SoftwareOnlineExpiryDate = null;
			MySettingsProperty.Settings.LicenseOnlineNo = null;
			MySettingsProperty.Settings.DeliveryCharge = null;
			MySettingsProperty.Settings.AutoCompleteTime = "5";
			MySettingsProperty.Settings.DriversAccess = "y";
			MySettingsProperty.Settings.PostCodeFinder = null;
			MySettingsProperty.Settings.AdminPassword = "1234";
			MySettingsProperty.Settings.ShopOwnerPassword = "1234";
			MySettingsProperty.Settings.StaffPassword = "1234";
			MySettingsProperty.Settings.SafeMode = "n";
			MySettingsProperty.Settings.PrintBottomAdvertise = "HOHA Software - 0800 1357 342";
			MySettingsProperty.Settings.Save();
			this.Close();
			MyProject.Forms.Index.Close();
		}

		// Token: 0x06000219 RID: 537 RVA: 0x00013084 File Offset: 0x00011284
		private void OnlineModeCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool @checked = this.OnlineModeCheckBox.Checked;
			if (@checked)
			{
				MySettingsProperty.Settings.SoftwareType = "ONLINE MODE";
			}
			else
			{
				MySettingsProperty.Settings.SoftwareType = "OFFLINE MODE";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600021A RID: 538 RVA: 0x000130D4 File Offset: 0x000112D4
		private void PostcodeFinderCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool @checked = this.PostcodeFinderCheckBox.Checked;
			if (@checked)
			{
				MySettingsProperty.Settings.PostCodeFinder = "y";
			}
			else
			{
				MySettingsProperty.Settings.PostCodeFinder = "n";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600021B RID: 539 RVA: 0x00013124 File Offset: 0x00011324
		private void CheckBox1_CheckedChanged(object sender, EventArgs e)
		{
			bool @checked = this.RemoveItemsInShoppingCartCheckBox.Checked;
			if (@checked)
			{
				MySettingsProperty.Settings.RemoveItemsInShoppingCart = "y";
				MyProject.Forms.POS_Window.EditPriceBTN.Visible = true;
				MyProject.Forms.POS_Window.DecreaseQTY.Visible = true;
				MyProject.Forms.POS_Window.IncreaseQTY.Visible = true;
			}
			else
			{
				MySettingsProperty.Settings.RemoveItemsInShoppingCart = "n";
				MyProject.Forms.POS_Window.EditPriceBTN.Visible = false;
				MyProject.Forms.POS_Window.DecreaseQTY.Visible = false;
				MyProject.Forms.POS_Window.IncreaseQTY.Visible = false;
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000277C File Offset: 0x0000097C
		private void NumberOfPrintTextBox_TextChanged(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.NumberOfPrint = this.NumberOfPrintTextBox.Text;
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600021D RID: 541 RVA: 0x000131F8 File Offset: 0x000113F8
		private void DriversAccessCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool flag = this.DriversAccessCheckBox.Checked;
			if (flag)
			{
				MySettingsProperty.Settings.DriversAccess = "y";
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
				MyProject.Forms.Index.AccessCodeNo.Text = Conversions.ToString(Operators.AddObject("Online Access Code: ", Online.postdata(Online.SoftwareDomain, "read_driver_access_code.php", "", MySettingsProperty.Settings.BusinessName, MySettingsProperty.Settings.BusinessPostcode, "", "", "")));
				M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
			}
			flag = !this.DriversAccessCheckBox.Checked;
			if (flag)
			{
				MySettingsProperty.Settings.DriversAccess = "n";
				MyProject.Forms.Index.AccessCodeNo.Text = "Online Access Code: ******";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600021E RID: 542 RVA: 0x000132E0 File Offset: 0x000114E0
		public void ReadOrderHistory()
		{
			foreach (string path in Directory.GetDirectories("data\\order_history"))
			{
				DirectoryInfo directoryInfo = new DirectoryInfo(path);
				string text = directoryInfo.Name;
				bool flag = Operators.CompareString(text, "_today", false) == 0;
				if (!flag)
				{
					text = text.Replace(MySettingsProperty.Settings.ComputerNo + "_", "");
					text = string.Concat(new string[]
					{
						text.Substring(0, 4),
						"/",
						text.Substring(4, 2),
						"/",
						text.Substring(6, 2),
						" - ",
						text.Substring(8, 2),
						":",
						text.Substring(10, 2),
						":",
						text.Substring(12, 2)
					});
					this.OrderHistoryListBox.Items.Add(text);
				}
			}
		}

		// Token: 0x0600021F RID: 543 RVA: 0x0001340C File Offset: 0x0001160C
		private void Button4_Click(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					string text = this.OrderHistoryListBox.SelectedItem.ToString();
					text = text.Replace(" ", "");
					text = text.Replace("/", "");
					text = text.Replace("-", "");
					text = text.Replace(":", "");
					text = MySettingsProperty.Settings.ComputerNo + "_" + text;
					MyProject.Forms.FreeFoodsOffer.DateToPrint = string.Concat(new string[]
					{
						text.Substring(18, 4),
						"/",
						text.Substring(22, 2),
						"/",
						text.Substring(24, 2)
					});
					MyProject.Forms.FreeFoodsOffer.FolderDayFullReportPrint = text;
					bool flag = Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0;
					if (flag)
					{
						MyProject.Forms.FreeFoodsOffer.PrintDocument2.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
					}
					int num = 1;
					int num2 = Conversions.ToInteger(MySettingsProperty.Settings.NumberOfPrint);
					int num3 = num;
					for (;;)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						MyProject.Forms.FreeFoodsOffer.PrintDocument2.Print();
						num3++;
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x06000220 RID: 544 RVA: 0x00013598 File Offset: 0x00011798
		private void Button4_Click_1(object sender, EventArgs e)
		{
			checked
			{
				try
				{
					string text = this.OrderHistoryListBox.SelectedItem.ToString();
					text = text.Replace(" ", "");
					text = text.Replace("/", "");
					text = text.Replace("-", "");
					text = text.Replace(":", "");
					text = MySettingsProperty.Settings.ComputerNo + "_" + text;
					MyProject.Forms.FreeFoodsOffer.CalculateEndSession(text);
					MyProject.Forms.FreeFoodsOffer.DateToPrint = string.Concat(new string[]
					{
						text.Substring(18, 4),
						"/",
						text.Substring(22, 2),
						"/",
						text.Substring(24, 2)
					});
					bool flag = Operators.CompareString(MySettingsProperty.Settings.PrinterName, "Default", false) != 0;
					if (flag)
					{
						MyProject.Forms.FreeFoodsOffer.PrintDocument1.PrinterSettings.PrinterName = MySettingsProperty.Settings.PrinterName;
					}
					int num = 1;
					int num2 = Conversions.ToInteger(MySettingsProperty.Settings.NumberOfPrint);
					int num3 = num;
					for (;;)
					{
						int num4 = num3;
						int num5 = num2;
						if (num4 > num5)
						{
							break;
						}
						MyProject.Forms.FreeFoodsOffer.PrintDocument1.Print();
						num3++;
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x06000221 RID: 545 RVA: 0x000027A1 File Offset: 0x000009A1
		private void Button5_Click(object sender, EventArgs e)
		{
			MyProject.Forms.Form_Glass.Show();
			MyProject.Forms.RePrintSaleReport.Show();
		}

		// Token: 0x06000222 RID: 546 RVA: 0x000027C5 File Offset: 0x000009C5
		private void OrderHistoryListBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			this.OrderHistoryDeleteBTN.Enabled = true;
			this.OrderHistorySummaryPrintBTN.Enabled = true;
			this.OrderHistoryFullPrintBTN.Enabled = true;
		}

		// Token: 0x06000223 RID: 547 RVA: 0x00013728 File Offset: 0x00011928
		private void Button4_Click_2(object sender, EventArgs e)
		{
			try
			{
				bool flag = this.BusinessEmailTextBox.Text.Contains("@") | this.BusinessEmailTextBox.Text.Contains(".") | this.ShopOwnerMobileTextBox.Text.Length == 11;
				if (flag)
				{
					MySettingsProperty.Settings.BusinessEmail = this.BusinessEmailTextBox.Text;
					MySettingsProperty.Settings.ShopOwnerMobile = this.ShopOwnerMobileTextBox.Text;
					MySettingsProperty.Settings.Save();
					this.UpdateOwnerDetails(MySettingsProperty.Settings.ServerFolderName, this.BusinessEmailTextBox.Text, this.ShopOwnerMobileTextBox.Text);
					MessageBox.Show("Saved");
				}
				else
				{
					MessageBox.Show("Some informations are not correct.");
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000224 RID: 548 RVA: 0x00013818 File Offset: 0x00011A18
		private void UpdateOwnerDetails(object ServerFolder, object OwnerEmail, object OwnerMobile)
		{
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "yes";
			Online.postdata(Online.SoftwareDomain, "change_owner_email_mobile.php", "", Conversions.ToString(ServerFolder), Conversions.ToString(OwnerEmail), Conversions.ToString(OwnerMobile), "", "");
			M_Settings.GetNecessaryDataFromServerInOfflineMode = "no";
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0001386C File Offset: 0x00011A6C
		private void SupplierCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool flag = this.SupplierCheckBox.Checked;
			if (flag)
			{
				MySettingsProperty.Settings.CashandCarry = "on";
				MyProject.Forms.Index.CashCarryBTN.Visible = true;
			}
			flag = !this.SupplierCheckBox.Checked;
			if (flag)
			{
				MySettingsProperty.Settings.CashandCarry = "off";
				MyProject.Forms.Index.CashCarryBTN.Visible = false;
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000226 RID: 550 RVA: 0x000138F8 File Offset: 0x00011AF8
		private void TableManagementCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool flag = this.TableManagementCheckBox.Checked;
			if (flag)
			{
				MyProject.Forms.Index.OccupiesTablesBTN.Visible = true;
				MyProject.Forms.Index.DineInBTN.Visible = true;
				MySettingsProperty.Settings.TableManagementSystem = "on";
				MySettingsProperty.Settings.Save();
			}
			flag = !this.TableManagementCheckBox.Checked;
			if (flag)
			{
				MyProject.Forms.Index.OccupiesTablesBTN.Visible = false;
				MyProject.Forms.Index.DineInBTN.Visible = false;
				MySettingsProperty.Settings.TableManagementSystem = "off";
				MySettingsProperty.Settings.Save();
			}
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000225A File Offset: 0x0000045A
		private void Label17_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000228 RID: 552 RVA: 0x000027F0 File Offset: 0x000009F0
		private void Button5_Click_1(object sender, EventArgs e)
		{
			MyProject.Forms.RePrintSaleReport.Show();
			MyProject.Forms.RePrintSaleReport.BringToFront();
		}

		// Token: 0x06000229 RID: 553 RVA: 0x000139B8 File Offset: 0x00011BB8
		public void ResetToFactoryBTM_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show("If you Reset to Factory, you will lose all settings." + Environment.NewLine + "Would you like to Reset to Factory", "Reset to Factory", MessageBoxButtons.YesNo);
			bool flag = dialogResult == DialogResult.Yes;
			if (flag)
			{
				this.ResetToFactory();
				StreamWriter streamWriter = new StreamWriter("settings.txt");
				streamWriter.WriteLine(string.Concat(new string[]
				{
					"n",
					Environment.NewLine,
					"y",
					Environment.NewLine,
					"ARTECH AD102"
				}));
				streamWriter.Close();
				Application.Exit();
			}
		}

		// Token: 0x0600022A RID: 554 RVA: 0x00013A50 File Offset: 0x00011C50
		private void UpdateBTN_Click(object sender, EventArgs e)
		{
			try
			{
				Process.Start(MyProject.Application.Info.DirectoryPath + "/update.exe", string.Concat(new string[]
				{
					MySettingsProperty.Settings.SoftwareWebsite,
					"|",
					MySettingsProperty.Settings.FTPusername,
					"|",
					MySettingsProperty.Settings.FTPpassword
				}));
				Application.Exit();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600022B RID: 555 RVA: 0x00013AF0 File Offset: 0x00011CF0
		private void AutoCompleteOrderTextBox_TextChanged(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.AutoCompleteTime = this.AutoCompleteOrderTextBox.Text;
			bool flag = Operators.CompareString(this.AutoCompleteOrderTextBox.Text, "", false) == 0 | Operators.CompareString(this.AutoCompleteOrderTextBox.Text, "0", false) == 0;
			if (flag)
			{
				MySettingsProperty.Settings.AutoCompleteTime = "Disable";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600022C RID: 556 RVA: 0x00013B68 File Offset: 0x00011D68
		private void CallerIdComboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			bool flag = Operators.ConditionalCompareObjectEqual(this.CallerIdComboBox1.SelectedItem, "", false);
			if (flag)
			{
				this.CallerIdComboBox.SelectedItem = "";
				MySettingsProperty.Settings.CallerIdEnabled = "no";
				MySettingsProperty.Settings.CallerIdType = "";
				MySettingsProperty.Settings.Save();
				M_Settings.CallerIdType = "";
			}
			flag = Operators.ConditionalCompareObjectEqual(this.CallerIdComboBox1.SelectedItem, "ARTECH AD102", false);
			if (flag)
			{
				this.CallerIdComboBox.SelectedItem = "ARTECH AD102";
				MySettingsProperty.Settings.CallerIdEnabled = "yes";
				MySettingsProperty.Settings.CallerIdType = "ARTECH AD102";
				MySettingsProperty.Settings.Save();
				M_Settings.CallerIdType = "ARTECH AD102";
				MyProject.Forms.Index.CallerIdTimer.Start();
				CallerID.LoadCallerId();
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600022D RID: 557 RVA: 0x0000277C File Offset: 0x0000097C
		private void NumberOfPrintTextBox_TextChanged_1(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.NumberOfPrint = this.NumberOfPrintTextBox.Text;
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600022E RID: 558 RVA: 0x00002814 File Offset: 0x00000A14
		private void PrintersComboBox_SelectedIndexChanged_1(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.PrinterName = this.PrintersComboBox.SelectedItem.ToString();
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600022F RID: 559 RVA: 0x0000283E File Offset: 0x00000A3E
		private void Printer1ComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.Printer1Name = this.Printer1ComboBox.SelectedItem.ToString();
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000230 RID: 560 RVA: 0x00002868 File Offset: 0x00000A68
		private void Printer2ComboBox_SelectedIndexChanged(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.Printer2Name = this.Printer2ComboBox.SelectedItem.ToString();
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000231 RID: 561 RVA: 0x00013C60 File Offset: 0x00011E60
		private void Button7_Click(object sender, EventArgs e)
		{
			this.MyPrinterFontType.Text = "Century Gothic";
			this.OrderFontSizeTextBox.Text = "10";
			this.FoodLeftAtTextBox.Text = "6";
			this.PriceLeftAtTextBox.Text = "59";
			this.FoodMaxLenTextBox.Text = "26";
			this.CommentFontSieTextBox.Text = "14";
			this.OrderLineSpaceTextBox.Text = "17";
			this.SecondLinesSpaceTextBox.Text = "15";
			MySettingsProperty.Settings.MyPrinterFontType = "Century Gothic";
			MySettingsProperty.Settings.OrderFontSize = Conversions.ToInteger("10");
			MySettingsProperty.Settings.FoodLeftAt = Conversions.ToInteger("6");
			MySettingsProperty.Settings.PriceLeftAt = Conversions.ToInteger("59");
			MySettingsProperty.Settings.FoodMaxLen = Conversions.ToInteger("26");
			MySettingsProperty.Settings.CommentFontSie = Conversions.ToInteger("14");
			MySettingsProperty.Settings.OrderLineSpace = Conversions.ToInteger("17");
			MySettingsProperty.Settings.SecondLinesSpace = Conversions.ToInteger("15");
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000232 RID: 562 RVA: 0x00013DA8 File Offset: 0x00011FA8
		private void Button8_Click(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.MyPrinterFontType = this.MyPrinterFontType.Text;
			MySettingsProperty.Settings.OrderFontSize = Conversions.ToInteger(this.OrderFontSizeTextBox.Text);
			MySettingsProperty.Settings.FoodLeftAt = Conversions.ToInteger(this.FoodLeftAtTextBox.Text);
			MySettingsProperty.Settings.PriceLeftAt = Conversions.ToInteger(this.PriceLeftAtTextBox.Text);
			MySettingsProperty.Settings.FoodMaxLen = Conversions.ToInteger(this.FoodMaxLenTextBox.Text);
			MySettingsProperty.Settings.CommentFontSie = Conversions.ToInteger(this.CommentFontSieTextBox.Text);
			MySettingsProperty.Settings.OrderLineSpace = Conversions.ToInteger(this.OrderLineSpaceTextBox.Text);
			MySettingsProperty.Settings.SecondLinesSpace = Conversions.ToInteger(this.SecondLinesSpaceTextBox.Text);
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000233 RID: 563 RVA: 0x00002892 File Offset: 0x00000A92
		private void MyPrinterFontType_SelectedIndexChanged(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.MyPrinterFontType = this.MyPrinterFontType.Text;
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000234 RID: 564 RVA: 0x00013E98 File Offset: 0x00012098
		private void ActiveEditOrdersCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool @checked = this.ActiveEditOrdersCheckBox.Checked;
			if (@checked)
			{
				MySettingsProperty.Settings.ActiveEditOrders = "y";
			}
			else
			{
				MySettingsProperty.Settings.ActiveEditOrders = "n";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x06000235 RID: 565 RVA: 0x00013EE8 File Offset: 0x000120E8
		private void Categories2RowsCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool flag = this.Categories2RowsCheckBox.Checked;
			if (flag)
			{
				MySettingsProperty.Settings.CategoryRows = Conversions.ToString(2);
				MySettingsProperty.Settings.Save();
			}
			flag = !this.Categories2RowsCheckBox.Checked;
			if (flag)
			{
				MySettingsProperty.Settings.CategoryRows = Conversions.ToString(1);
				MySettingsProperty.Settings.Save();
			}
			MessageBox.Show("To effect this feature, you need to exit the software and run it again.");
		}

		// Token: 0x06000236 RID: 566 RVA: 0x00013F60 File Offset: 0x00012160
		private void ShowAllPostcodes()
		{
			string[] files = Directory.GetFiles("pc");
			bool flag = files.Count<string>() == 0;
			if (flag)
			{
				this.AllPostCodesTextBox.Text = "You have no Postcodes available.";
			}
			else
			{
				this.AllPostCodesTextBox.Text = "Installed Postcodes:\r\n";
				foreach (string text in files)
				{
					TextBox allPostCodesTextBox = this.AllPostCodesTextBox;
					allPostCodesTextBox.Text = allPostCodesTextBox.Text + text.Replace("pc\\", "").Replace(".csv", "") + ", ";
				}
			}
		}

		// Token: 0x06000237 RID: 567 RVA: 0x0001400C File Offset: 0x0001220C
		private void Button6_Click(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.DeliveryPostCode1 = this.fppc1.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode2 = this.fppc2.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode3 = this.fppc3.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode4 = this.fppc4.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode5 = this.fppc5.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode6 = this.fppc6.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode7 = this.fppc7.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode8 = this.fppc8.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryPostCode9 = this.fppc9.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode1 = this.fppc1dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode2 = this.fppc2dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode3 = this.fppc3dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode4 = this.fppc4dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode5 = this.fppc5dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode6 = this.fppc6dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode7 = this.fppc7dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode8 = this.fppc8dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryChargePostCode9 = this.fppc9dc.Text.Replace(" ", "");
			MySettingsProperty.Settings.DeliveryCharge = this.OtherDeliveryChargeTextBox.Text;
			MySettingsProperty.Settings.Save();
			MessageBox.Show("All Delivery Charges have saved.");
		}

		// Token: 0x06000238 RID: 568 RVA: 0x000028B7 File Offset: 0x00000AB7
		private void Button9_Click(object sender, EventArgs e)
		{
			MySettingsProperty.Settings.PrintBottomAdvertise = this.ReceiptAdvertTB.Text;
			MySettingsProperty.Settings.Save();
			MessageBox.Show("Advert Saved.");
		}

		// Token: 0x06000239 RID: 569 RVA: 0x000142E4 File Offset: 0x000124E4
		private void MenuBTN_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(MySettingsProperty.Settings.BusinessName, "Softeware Demo Version", false) == 0;
			if (flag)
			{
				MessageBox.Show("The software is operating in demo mode." + Environment.NewLine + "Entering or updating the menu is not permitted.");
			}
			else
			{
				MyProject.Forms.POS_Window.WindowState = FormWindowState.Minimized;
				MyProject.Forms.Incoming_Calls.WindowState = FormWindowState.Minimized;
				MyProject.Forms.Index.WindowState = FormWindowState.Minimized;
				this.CurrentUserCP = "";
				this.Close();
				Process.Start("http://" + Online.SoftwareDomain + "/menu/index.php?action=pos_login&folder=" + MySettingsProperty.Settings.ServerFolderName);
			}
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00014398 File Offset: 0x00012598
		private void Button10_Click(object sender, EventArgs e)
		{
			DialogResult dialogResult = MessageBox.Show("If you Reset to Factory, you will lose all settings." + Environment.NewLine + "Would you like to Reset to Factory", "Reset to Factory", MessageBoxButtons.YesNo);
			bool flag = dialogResult == DialogResult.Yes;
			if (flag)
			{
				Application.Exit();
				Process.Start("Uninstall.exe");
			}
		}

		// Token: 0x0600023B RID: 571 RVA: 0x000143E4 File Offset: 0x000125E4
		private void SafeModeCheckBox_CheckedChanged(object sender, EventArgs e)
		{
			bool @checked = this.SafeModeCheckBox.Checked;
			if (@checked)
			{
				MySettingsProperty.Settings.SafeMode = "y";
			}
			else
			{
				MySettingsProperty.Settings.SafeMode = "n";
			}
			MySettingsProperty.Settings.Save();
		}

		// Token: 0x0600023C RID: 572 RVA: 0x00014434 File Offset: 0x00012634
		private void Button11_Click(object sender, EventArgs e)
		{
			this.FolderBrowserDialogCustomersExport.SelectedPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
			this.FolderBrowserDialogCustomersExport.ShowNewFolderButton = false;
			bool flag = this.FolderBrowserDialogCustomersExport.ShowDialog() == DialogResult.OK;
			checked
			{
				if (flag)
				{
					string[] array = new string[Customers.AllCustomersArray.Length + 1];
					string[] array2 = new string[Customers.AllCustomersArray.Length + 1];
					Array.Copy(Customers.AllCustomersArray, array, Customers.AllCustomersArray.Length);
					Array.Copy(Customers.AllCustomersArray, array2, Customers.AllCustomersArray.Length);
					flag = Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null), "ExportCustomersCSV", false);
					if (flag)
					{
						string newValue = ",";
						string str = "Customers.csv";
						int num = 0;
						int num2 = array.Length - 1;
						int num3 = num;
						for (;;)
						{
							int num4 = num3;
							int num5 = num2;
							if (num4 > num5)
							{
								break;
							}
							flag = (Operators.CompareString(array[num3], "", false) != 0);
							if (flag)
							{
								array[num3] = array[num3].Replace("|", newValue);
							}
							num3++;
						}
						File.WriteAllLines(this.FolderBrowserDialogCustomersExport.SelectedPath + "\\" + str, array);
					}
					flag = Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(sender, null, "name", new object[0], null, null, null), "ExportCustomersTXT", false);
					if (flag)
					{
						string newValue = "\t";
						string str = "Customers.txt";
						int num6 = 0;
						int num7 = array2.Length - 1;
						int num8 = num6;
						for (;;)
						{
							int num9 = num8;
							int num5 = num7;
							if (num9 > num5)
							{
								break;
							}
							flag = (Operators.CompareString(array2[num8], "", false) != 0);
							if (flag)
							{
								array2[num8] = array2[num8].Replace("|", newValue);
							}
							num8++;
						}
						File.WriteAllLines(this.FolderBrowserDialogCustomersExport.SelectedPath + "\\" + str, array2);
					}
					MessageBox.Show("Customers' data exported.");
				}
			}
		}

		// Token: 0x0600023D RID: 573 RVA: 0x000028E7 File Offset: 0x00000AE7
		private void Button11_Click_1(object sender, EventArgs e)
		{
			MyProject.Forms.Edit_Customers.Show();
		}

		// Token: 0x0400004C RID: 76
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x0400004D RID: 77
		private IContainer components;

		// Token: 0x0400004E RID: 78
		[AccessedThroughProperty("ExitBTN")]
		private Button _ExitBTN;

		// Token: 0x0400004F RID: 79
		[AccessedThroughProperty("AdvancedTP")]
		private TabControl _AdvancedTP;

		// Token: 0x04000050 RID: 80
		[AccessedThroughProperty("GeneralTB")]
		private TabPage _GeneralTB;

		// Token: 0x04000051 RID: 81
		[AccessedThroughProperty("AbolfazlTB")]
		private TabPage _AbolfazlTB;

		// Token: 0x04000052 RID: 82
		[AccessedThroughProperty("SaveExitPanel")]
		private Panel _SaveExitPanel;

		// Token: 0x04000053 RID: 83
		[AccessedThroughProperty("CallerIdComboBox")]
		private ComboBox _CallerIdComboBox;

		// Token: 0x04000054 RID: 84
		[AccessedThroughProperty("Label7")]
		private Label _Label7;

		// Token: 0x04000055 RID: 85
		[AccessedThroughProperty("BusinessInfoGroupBox")]
		private GroupBox _BusinessInfoGroupBox;

		// Token: 0x04000056 RID: 86
		[AccessedThroughProperty("BPhoneTextBox")]
		private TextBox _BPhoneTextBox;

		// Token: 0x04000057 RID: 87
		[AccessedThroughProperty("BNameTextBox")]
		private TextBox _BNameTextBox;

		// Token: 0x04000058 RID: 88
		[AccessedThroughProperty("Label5")]
		private Label _Label5;

		// Token: 0x04000059 RID: 89
		[AccessedThroughProperty("BPostcodeTextBox")]
		private TextBox _BPostcodeTextBox;

		// Token: 0x0400005A RID: 90
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x0400005B RID: 91
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x0400005C RID: 92
		[AccessedThroughProperty("BCityTextBox")]
		private TextBox _BCityTextBox;

		// Token: 0x0400005D RID: 93
		[AccessedThroughProperty("Label3")]
		private Label _Label3;

		// Token: 0x0400005E RID: 94
		[AccessedThroughProperty("Label4")]
		private Label _Label4;

		// Token: 0x0400005F RID: 95
		[AccessedThroughProperty("BAddressTextBox")]
		private TextBox _BAddressTextBox;

		// Token: 0x04000060 RID: 96
		[AccessedThroughProperty("AdminPanel")]
		private Panel _AdminPanel;

		// Token: 0x04000061 RID: 97
		[AccessedThroughProperty("LoginPanel")]
		private Panel _LoginPanel;

		// Token: 0x04000062 RID: 98
		[AccessedThroughProperty("PasswordTextBox")]
		private TextBox _PasswordTextBox;

		// Token: 0x04000063 RID: 99
		[AccessedThroughProperty("UserNameComboBox")]
		private ComboBox _UserNameComboBox;

		// Token: 0x04000064 RID: 100
		[AccessedThroughProperty("CancelBTN")]
		private Button _CancelBTN;

		// Token: 0x04000065 RID: 101
		[AccessedThroughProperty("LoginBTN")]
		private Button _LoginBTN;

		// Token: 0x04000066 RID: 102
		[AccessedThroughProperty("GroupBox4")]
		private GroupBox _GroupBox4;

		// Token: 0x04000067 RID: 103
		[AccessedThroughProperty("KeyboardPanel")]
		private Panel _KeyboardPanel;

		// Token: 0x04000068 RID: 104
		[AccessedThroughProperty("DriversTB")]
		private TabPage _DriversTB;

		// Token: 0x04000069 RID: 105
		[AccessedThroughProperty("GroupBox5")]
		private GroupBox _GroupBox5;

		// Token: 0x0400006A RID: 106
		[AccessedThroughProperty("Button2")]
		private Button _Button2;

		// Token: 0x0400006B RID: 107
		[AccessedThroughProperty("Button3")]
		private Button _Button3;

		// Token: 0x0400006C RID: 108
		[AccessedThroughProperty("DriversListBox")]
		private ListBox _DriversListBox;

		// Token: 0x0400006D RID: 109
		[AccessedThroughProperty("GroupBox6")]
		private GroupBox _GroupBox6;

		// Token: 0x0400006E RID: 110
		[AccessedThroughProperty("Label8")]
		private Label _Label8;

		// Token: 0x0400006F RID: 111
		[AccessedThroughProperty("AddDriverMobileTextBox")]
		private TextBox _AddDriverMobileTextBox;

		// Token: 0x04000070 RID: 112
		[AccessedThroughProperty("AddDriverNameTextBox")]
		private TextBox _AddDriverNameTextBox;

		// Token: 0x04000071 RID: 113
		[AccessedThroughProperty("GroupBox7")]
		private GroupBox _GroupBox7;

		// Token: 0x04000072 RID: 114
		[AccessedThroughProperty("DriversDeleteComboBox")]
		private ComboBox _DriversDeleteComboBox;

		// Token: 0x04000073 RID: 115
		[AccessedThroughProperty("KeyboardDriver")]
		private Panel _KeyboardDriver;

		// Token: 0x04000074 RID: 116
		[AccessedThroughProperty("Label9")]
		private Label _Label9;

		// Token: 0x04000075 RID: 117
		[AccessedThroughProperty("NewPasswordGroupBox")]
		private GroupBox _NewPasswordGroupBox;

		// Token: 0x04000076 RID: 118
		[AccessedThroughProperty("NewPasswordSaveBTN")]
		private Button _NewPasswordSaveBTN;

		// Token: 0x04000077 RID: 119
		[AccessedThroughProperty("Label11")]
		private Label _Label11;

		// Token: 0x04000078 RID: 120
		[AccessedThroughProperty("Label10")]
		private Label _Label10;

		// Token: 0x04000079 RID: 121
		[AccessedThroughProperty("NewPassConfirmfTextBox")]
		private TextBox _NewPassConfirmfTextBox;

		// Token: 0x0400007A RID: 122
		[AccessedThroughProperty("NewPassTextBox")]
		private TextBox _NewPassTextBox;

		// Token: 0x0400007B RID: 123
		[AccessedThroughProperty("Label12")]
		private Label _Label12;

		// Token: 0x0400007C RID: 124
		[AccessedThroughProperty("UserComboBox")]
		private ComboBox _UserComboBox;

		// Token: 0x0400007D RID: 125
		[AccessedThroughProperty("NewPassUserComboBox")]
		private ComboBox _NewPassUserComboBox;

		// Token: 0x0400007E RID: 126
		[AccessedThroughProperty("DownloadBackupGroupBox")]
		private GroupBox _DownloadBackupGroupBox;

		// Token: 0x0400007F RID: 127
		[AccessedThroughProperty("DownloadBackupBTN")]
		private Button _DownloadBackupBTN;

		// Token: 0x04000080 RID: 128
		[AccessedThroughProperty("DownloadPostcodesRB")]
		private RadioButton _DownloadPostcodesRB;

		// Token: 0x04000081 RID: 129
		[AccessedThroughProperty("DownloadBackupCustomersRB")]
		private RadioButton _DownloadBackupCustomersRB;

		// Token: 0x04000082 RID: 130
		[AccessedThroughProperty("DownloadBackupMenuRB")]
		private RadioButton _DownloadBackupMenuRB;

		// Token: 0x04000083 RID: 131
		[AccessedThroughProperty("UploadDownloadProgressBar")]
		private ProgressBar _UploadDownloadProgressBar;

		// Token: 0x04000084 RID: 132
		[AccessedThroughProperty("USBBackupBTN")]
		private Button _USBBackupBTN;

		// Token: 0x04000085 RID: 133
		[AccessedThroughProperty("GroupBox8")]
		private GroupBox _GroupBox8;

		// Token: 0x04000086 RID: 134
		[AccessedThroughProperty("Label13")]
		private Label _Label13;

		// Token: 0x04000087 RID: 135
		[AccessedThroughProperty("FTPsaveBTN")]
		private Button _FTPsaveBTN;

		// Token: 0x04000088 RID: 136
		[AccessedThroughProperty("FTPPasswordTextBox")]
		private TextBox _FTPPasswordTextBox;

		// Token: 0x04000089 RID: 137
		[AccessedThroughProperty("FTPUsernameTextBox")]
		private TextBox _FTPUsernameTextBox;

		// Token: 0x0400008A RID: 138
		[AccessedThroughProperty("Label14")]
		private Label _Label14;

		// Token: 0x0400008B RID: 139
		[AccessedThroughProperty("SoftwareDomainTextBox")]
		private TextBox _SoftwareDomainTextBox;

		// Token: 0x0400008C RID: 140
		[AccessedThroughProperty("Label15")]
		private Label _Label15;

		// Token: 0x0400008D RID: 141
		[AccessedThroughProperty("FTPpingBTN")]
		private Button _FTPpingBTN;

		// Token: 0x0400008E RID: 142
		[AccessedThroughProperty("USBRestoreBTN")]
		private Button _USBRestoreBTN;

		// Token: 0x0400008F RID: 143
		[AccessedThroughProperty("FlashDriverGroupBox")]
		private GroupBox _FlashDriverGroupBox;

		// Token: 0x04000090 RID: 144
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000091 RID: 145
		[AccessedThroughProperty("DriversAccessCheckBox")]
		private CheckBox _DriversAccessCheckBox;

		// Token: 0x04000092 RID: 146
		[AccessedThroughProperty("OnlineModeCheckBox")]
		private CheckBox _OnlineModeCheckBox;

		// Token: 0x04000093 RID: 147
		[AccessedThroughProperty("PostcodeFinderCheckBox")]
		private CheckBox _PostcodeFinderCheckBox;

		// Token: 0x04000094 RID: 148
		[AccessedThroughProperty("RemoveItemsInShoppingCartCheckBox")]
		private CheckBox _RemoveItemsInShoppingCartCheckBox;

		// Token: 0x04000095 RID: 149
		[AccessedThroughProperty("ActiveEditOrdersCheckBox")]
		private CheckBox _ActiveEditOrdersCheckBox;

		// Token: 0x04000096 RID: 150
		[AccessedThroughProperty("Label6")]
		private Label _Label6;

		// Token: 0x04000097 RID: 151
		[AccessedThroughProperty("OrderHistoryListBox")]
		private ListBox _OrderHistoryListBox;

		// Token: 0x04000098 RID: 152
		[AccessedThroughProperty("OrderHistoryGroupBox")]
		private GroupBox _OrderHistoryGroupBox;

		// Token: 0x04000099 RID: 153
		[AccessedThroughProperty("OrderHistoryDeleteBTN")]
		private Button _OrderHistoryDeleteBTN;

		// Token: 0x0400009A RID: 154
		[AccessedThroughProperty("OrderHistoryFullPrintBTN")]
		private Button _OrderHistoryFullPrintBTN;

		// Token: 0x0400009B RID: 155
		[AccessedThroughProperty("OrderHistorySummaryPrintBTN")]
		private Button _OrderHistorySummaryPrintBTN;

		// Token: 0x0400009C RID: 156
		[AccessedThroughProperty("PostcodeFinderCheckBox1")]
		private CheckBox _PostcodeFinderCheckBox1;

		// Token: 0x0400009D RID: 157
		[AccessedThroughProperty("ShopOwnerGroupBox")]
		private GroupBox _ShopOwnerGroupBox;

		// Token: 0x0400009E RID: 158
		[AccessedThroughProperty("Label20")]
		private Label _Label20;

		// Token: 0x0400009F RID: 159
		[AccessedThroughProperty("Label21")]
		private Label _Label21;

		// Token: 0x040000A0 RID: 160
		[AccessedThroughProperty("BusinessEmailTextBox")]
		private TextBox _BusinessEmailTextBox;

		// Token: 0x040000A1 RID: 161
		[AccessedThroughProperty("ShopOwnerMobileTextBox")]
		private TextBox _ShopOwnerMobileTextBox;

		// Token: 0x040000A2 RID: 162
		[AccessedThroughProperty("Button4")]
		private Button _Button4;

		// Token: 0x040000A3 RID: 163
		[AccessedThroughProperty("TableManagementCheckBox")]
		private CheckBox _TableManagementCheckBox;

		// Token: 0x040000A4 RID: 164
		[AccessedThroughProperty("SupplierCheckBox")]
		private CheckBox _SupplierCheckBox;

		// Token: 0x040000A5 RID: 165
		[AccessedThroughProperty("Button5")]
		private Button _Button5;

		// Token: 0x040000A6 RID: 166
		[AccessedThroughProperty("TabPage1")]
		private TabPage _TabPage1;

		// Token: 0x040000A7 RID: 167
		[AccessedThroughProperty("ResetToFactoryBTM")]
		private Button _ResetToFactoryBTM;

		// Token: 0x040000A8 RID: 168
		[AccessedThroughProperty("UpdateBTN")]
		private Button _UpdateBTN;

		// Token: 0x040000A9 RID: 169
		[AccessedThroughProperty("AutoCompleteOrderTextBox")]
		private TextBox _AutoCompleteOrderTextBox;

		// Token: 0x040000AA RID: 170
		[AccessedThroughProperty("AutoCompleteLBL")]
		private Label _AutoCompleteLBL;

		// Token: 0x040000AB RID: 171
		[AccessedThroughProperty("CallerIDLBL")]
		private Label _CallerIDLBL;

		// Token: 0x040000AC RID: 172
		[AccessedThroughProperty("CallerIdComboBox1")]
		private ComboBox _CallerIdComboBox1;

		// Token: 0x040000AD RID: 173
		[AccessedThroughProperty("PrinterGroupBox")]
		private GroupBox _PrinterGroupBox;

		// Token: 0x040000AE RID: 174
		[AccessedThroughProperty("OrderFontSizeTextBox")]
		private TextBox _OrderFontSizeTextBox;

		// Token: 0x040000AF RID: 175
		[AccessedThroughProperty("Label16")]
		private Label _Label16;

		// Token: 0x040000B0 RID: 176
		[AccessedThroughProperty("Label17")]
		private Label _Label17;

		// Token: 0x040000B1 RID: 177
		[AccessedThroughProperty("OrderLineSpaceTextBox")]
		private TextBox _OrderLineSpaceTextBox;

		// Token: 0x040000B2 RID: 178
		[AccessedThroughProperty("Label18")]
		private Label _Label18;

		// Token: 0x040000B3 RID: 179
		[AccessedThroughProperty("FoodLeftAtTextBox")]
		private TextBox _FoodLeftAtTextBox;

		// Token: 0x040000B4 RID: 180
		[AccessedThroughProperty("SecondLinesSpaceTextBox")]
		private TextBox _SecondLinesSpaceTextBox;

		// Token: 0x040000B5 RID: 181
		[AccessedThroughProperty("Label19")]
		private Label _Label19;

		// Token: 0x040000B6 RID: 182
		[AccessedThroughProperty("Label22")]
		private Label _Label22;

		// Token: 0x040000B7 RID: 183
		[AccessedThroughProperty("PriceLeftAtTextBox")]
		private TextBox _PriceLeftAtTextBox;

		// Token: 0x040000B8 RID: 184
		[AccessedThroughProperty("FoodMaxLenTextBox")]
		private TextBox _FoodMaxLenTextBox;

		// Token: 0x040000B9 RID: 185
		[AccessedThroughProperty("Label23")]
		private Label _Label23;

		// Token: 0x040000BA RID: 186
		[AccessedThroughProperty("MyPrinterFontType")]
		private ComboBox _MyPrinterFontType;

		// Token: 0x040000BB RID: 187
		[AccessedThroughProperty("Label24")]
		private Label _Label24;

		// Token: 0x040000BC RID: 188
		[AccessedThroughProperty("Button7")]
		private Button _Button7;

		// Token: 0x040000BD RID: 189
		[AccessedThroughProperty("Button8")]
		private Button _Button8;

		// Token: 0x040000BE RID: 190
		[AccessedThroughProperty("NumberOfPrintLabel")]
		private Label _NumberOfPrintLabel;

		// Token: 0x040000BF RID: 191
		[AccessedThroughProperty("NumberOfPrintTextBox")]
		private TextBox _NumberOfPrintTextBox;

		// Token: 0x040000C0 RID: 192
		[AccessedThroughProperty("Label25")]
		private Label _Label25;

		// Token: 0x040000C1 RID: 193
		[AccessedThroughProperty("PrintersComboBox")]
		private ComboBox _PrintersComboBox;

		// Token: 0x040000C2 RID: 194
		[AccessedThroughProperty("CommentFontSieTextBox")]
		private TextBox _CommentFontSieTextBox;

		// Token: 0x040000C3 RID: 195
		[AccessedThroughProperty("Label26")]
		private Label _Label26;

		// Token: 0x040000C4 RID: 196
		[AccessedThroughProperty("GroupBox1")]
		private GroupBox _GroupBox1;

		// Token: 0x040000C5 RID: 197
		[AccessedThroughProperty("DeliveryChargeLBL")]
		private Label _DeliveryChargeLBL;

		// Token: 0x040000C6 RID: 198
		[AccessedThroughProperty("Categories2RowsCheckBox")]
		private CheckBox _Categories2RowsCheckBox;

		// Token: 0x040000C7 RID: 199
		[AccessedThroughProperty("AllPostCodesTextBox")]
		private TextBox _AllPostCodesTextBox;

		// Token: 0x040000C8 RID: 200
		[AccessedThroughProperty("Label28")]
		private Label _Label28;

		// Token: 0x040000C9 RID: 201
		[AccessedThroughProperty("Printer1ComboBox")]
		private ComboBox _Printer1ComboBox;

		// Token: 0x040000CA RID: 202
		[AccessedThroughProperty("Label29")]
		private Label _Label29;

		// Token: 0x040000CB RID: 203
		[AccessedThroughProperty("Printer2ComboBox")]
		private ComboBox _Printer2ComboBox;

		// Token: 0x040000CC RID: 204
		[AccessedThroughProperty("Label30")]
		private Label _Label30;

		// Token: 0x040000CD RID: 205
		[AccessedThroughProperty("Label31")]
		private Label _Label31;

		// Token: 0x040000CE RID: 206
		[AccessedThroughProperty("GroupBox2")]
		private GroupBox _GroupBox2;

		// Token: 0x040000CF RID: 207
		[AccessedThroughProperty("Button6")]
		private Button _Button6;

		// Token: 0x040000D0 RID: 208
		[AccessedThroughProperty("fppc6dc")]
		private TextBox _fppc6dc;

		// Token: 0x040000D1 RID: 209
		[AccessedThroughProperty("fppc5dc")]
		private TextBox _fppc5dc;

		// Token: 0x040000D2 RID: 210
		[AccessedThroughProperty("fppc4dc")]
		private TextBox _fppc4dc;

		// Token: 0x040000D3 RID: 211
		[AccessedThroughProperty("fppc3dc")]
		private TextBox _fppc3dc;

		// Token: 0x040000D4 RID: 212
		[AccessedThroughProperty("fppc2dc")]
		private TextBox _fppc2dc;

		// Token: 0x040000D5 RID: 213
		[AccessedThroughProperty("fppc1dc")]
		private TextBox _fppc1dc;

		// Token: 0x040000D6 RID: 214
		[AccessedThroughProperty("fppc6")]
		private TextBox _fppc6;

		// Token: 0x040000D7 RID: 215
		[AccessedThroughProperty("fppc5")]
		private TextBox _fppc5;

		// Token: 0x040000D8 RID: 216
		[AccessedThroughProperty("fppc4")]
		private TextBox _fppc4;

		// Token: 0x040000D9 RID: 217
		[AccessedThroughProperty("fppc3")]
		private TextBox _fppc3;

		// Token: 0x040000DA RID: 218
		[AccessedThroughProperty("fppc2")]
		private TextBox _fppc2;

		// Token: 0x040000DB RID: 219
		[AccessedThroughProperty("fppc1")]
		private TextBox _fppc1;

		// Token: 0x040000DC RID: 220
		[AccessedThroughProperty("Label33")]
		private Label _Label33;

		// Token: 0x040000DD RID: 221
		[AccessedThroughProperty("Label32")]
		private Label _Label32;

		// Token: 0x040000DE RID: 222
		[AccessedThroughProperty("OtherDeliveryChargeTextBox")]
		private TextBox _OtherDeliveryChargeTextBox;

		// Token: 0x040000DF RID: 223
		[AccessedThroughProperty("fppc9dc")]
		private TextBox _fppc9dc;

		// Token: 0x040000E0 RID: 224
		[AccessedThroughProperty("fppc8dc")]
		private TextBox _fppc8dc;

		// Token: 0x040000E1 RID: 225
		[AccessedThroughProperty("fppc7dc")]
		private TextBox _fppc7dc;

		// Token: 0x040000E2 RID: 226
		[AccessedThroughProperty("fppc9")]
		private TextBox _fppc9;

		// Token: 0x040000E3 RID: 227
		[AccessedThroughProperty("fppc8")]
		private TextBox _fppc8;

		// Token: 0x040000E4 RID: 228
		[AccessedThroughProperty("fppc7")]
		private TextBox _fppc7;

		// Token: 0x040000E5 RID: 229
		[AccessedThroughProperty("GroupBox3")]
		private GroupBox _GroupBox3;

		// Token: 0x040000E6 RID: 230
		[AccessedThroughProperty("Label34")]
		private Label _Label34;

		// Token: 0x040000E7 RID: 231
		[AccessedThroughProperty("Button9")]
		private Button _Button9;

		// Token: 0x040000E8 RID: 232
		[AccessedThroughProperty("ReceiptAdvertTB")]
		private TextBox _ReceiptAdvertTB;

		// Token: 0x040000E9 RID: 233
		[AccessedThroughProperty("MenuBTN")]
		private Button _MenuBTN;

		// Token: 0x040000EA RID: 234
		[AccessedThroughProperty("Button10")]
		private Button _Button10;

		// Token: 0x040000EB RID: 235
		[AccessedThroughProperty("SafeModeCheckBox")]
		private CheckBox _SafeModeCheckBox;

		// Token: 0x040000EC RID: 236
		[AccessedThroughProperty("ExportCustomersCSV")]
		private Button _ExportCustomersCSV;

		// Token: 0x040000ED RID: 237
		[AccessedThroughProperty("ExportCustomersTXT")]
		private Button _ExportCustomersTXT;

		// Token: 0x040000EE RID: 238
		[AccessedThroughProperty("FolderBrowserDialogCustomersExport")]
		private FolderBrowserDialog _FolderBrowserDialogCustomersExport;

		// Token: 0x040000EF RID: 239
		[AccessedThroughProperty("Button11")]
		private Button _Button11;

		// Token: 0x040000F0 RID: 240
		private string CurrentUserCP;
	}
}
