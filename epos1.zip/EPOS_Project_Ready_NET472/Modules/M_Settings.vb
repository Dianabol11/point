using System;
using System.Collections;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x0200002E RID: 46
	[StandardModule]
	internal sealed class M_Settings
	{
		// Token: 0x060005FD RID: 1533 RVA: 0x00039668 File Offset: 0x00037868
		public static void Load_Settings()
		{
			M_Settings.CheckIfSoftwareIsAlreadyRunning();
			MyProject.Forms.Index.Timer1Min.Start();
			OrderManagment.Check_todayFolder();
			SuspiciousActivities.CheckSuspiciousActivitiesFile();
			bool flag = File.Exists(M_Settings.MenuFolder + "\\_offers.txt");
			if (flag)
			{
				offers.LoadOffers();
			}
			Online.GetSoftwareCompanyDetailsFromServer();
			flag = File.Exists(M_Settings.DataFolder + "\\admin\\BusinessInfo.txt");
			if (flag)
			{
				M_Settings.Shop = File.ReadAllText(M_Settings.DataFolder + "\\admin\\BusinessInfo.txt").Split(new char[]
				{
					'|'
				});
				flag = (M_Settings.Shop.Length >= 7);
				if (flag)
				{
					M_Settings.ShopName = M_Settings.Shop[0];
					M_Settings.ShopPhone = M_Settings.Shop[1];
					M_Settings.ShopAddress = M_Settings.Shop[2];
					M_Settings.ShopCity = M_Settings.Shop[3];
					M_Settings.ShopPostCode = M_Settings.Shop[4];
					M_Settings.OwnerMobile = M_Settings.Shop[5];
					M_Settings.ShopWebsite = M_Settings.Shop[6];
				}
				else
				{
					M_Settings.ShopName = MySettingsProperty.Settings.BusinessName;
					M_Settings.ShopPhone = MySettingsProperty.Settings.BusinessTel;
					M_Settings.ShopAddress = MySettingsProperty.Settings.BusinessAddress;
					M_Settings.ShopCity = MySettingsProperty.Settings.BusinessCity;
					M_Settings.ShopPostCode = MySettingsProperty.Settings.BusinessPostcode;
					M_Settings.OwnerMobile = MySettingsProperty.Settings.ShopOwnerMobile;
					M_Settings.ShopWebsite = MySettingsProperty.Settings.WebsiteURL;
				}
			}
			Customers.AllCustomersArray = File.ReadAllLines(M_Settings.DataFolder + "\\_Customers.txt");
			M_Settings.Right_Panel_Width = 450;
			MyProject.Forms.POS_Window.Bottom_Panel.Width = M_Settings.ScreenWidth;
			flag = (Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 1.0);
			if (flag)
			{
				M_Settings.Bottom_Panel_Height = 80;
			}
			flag = (Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 2.0);
			if (flag)
			{
				M_Settings.Bottom_Panel_Height = 120;
			}
			checked
			{
				MyProject.Forms.POS_Window.Main_Panel.Width = M_Settings.ScreenWidth - M_Settings.Right_Panel_Width;
				MyProject.Forms.POS_Window.Main_Panel.Height = M_Settings.ScreenHeight - M_Settings.Bottom_Panel_Height;
				MyProject.Forms.POS_Window.Right_Panel.Width = M_Settings.Right_Panel_Width;
				MyProject.Forms.POS_Window.Right_Panel.Height = M_Settings.ScreenHeight - M_Settings.Bottom_Panel_Height;
				flag = (Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 1.0);
				if (flag)
				{
					M_Settings.ShoppingCart.Height = M_Settings.ScreenHeight - M_Settings.Bottom_Panel_Height - MyProject.Forms.POS_Window.CompletePanel.Height - 15;
				}
				flag = (Conversions.ToDouble(MySettingsProperty.Settings.CategoryRows) == 2.0);
				if (flag)
				{
					M_Settings.ShoppingCart.Height = M_Settings.ScreenHeight - M_Settings.Bottom_Panel_Height - MyProject.Forms.POS_Window.CompletePanel.Height + 20;
				}
				MyProject.Forms.POS_Window.PgUp.Height = (int)Math.Round((double)(M_Settings.ScreenHeight - MyProject.Forms.POS_Window.Bottom_Panel.Height - MyProject.Forms.POS_Window.CompletePanel.Height - MyProject.Forms.POS_Window.Exit_Program.Height) / 2.0);
				MyProject.Forms.POS_Window.PgDown.Height = MyProject.Forms.POS_Window.PgUp.Height;
				int y = MyProject.Forms.POS_Window.Exit_Program.Height + MyProject.Forms.POS_Window.PgUp.Height;
				Point location = new Point(410, y);
				MyProject.Forms.POS_Window.PgDown.Location = location;
				MyProject.Forms.CustomerReCall.LeftPanel.Width = (int)Math.Round((double)M_Settings.ScreenWidth / 2.0);
				MyProject.Forms.CustomerReCall.RightPanel.Width = (int)Math.Round((double)M_Settings.ScreenWidth / 2.0);
				MyProject.Forms.General_Settings.AdminPanel.Width = M_Settings.ScreenWidth;
				MyProject.Forms.General_Settings.AdminPanel.Height = M_Settings.ScreenHeight;
				MyProject.Forms.POS_Window.CompletePanel.BringToFront();
				Meal.Create_TLP_Meal();
				Online.CheckWebsiteConnection();
				flag = (Operators.CompareString(MySettingsProperty.Settings.CashandCarry, "on", false) == 0);
				if (flag)
				{
					Online.CASHandCARRY();
				}
				flag = (Operators.CompareString(MySettingsProperty.Settings.CashandCarry, "off", false) == 0);
				if (flag)
				{
					MyProject.Forms.Index.CashCarryBTN.Visible = false;
				}
				flag = (Operators.CompareString(MySettingsProperty.Settings.TableManagementSystem, "off", false) == 0);
				if (flag)
				{
					MyProject.Forms.Index.DineInBTN.Visible = false;
					MyProject.Forms.Index.OccupiesTablesBTN.Visible = false;
				}
			}
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00039BA4 File Offset: 0x00037DA4
		public static object CurrentDate()
		{
			string str = DateAndTime.Year(DateAndTime.Now).ToString();
			string text = DateAndTime.Month(DateAndTime.Now).ToString();
			string text2 = DateAndTime.Day(DateAndTime.Now).ToString();
			bool flag = text.Length < 2;
			if (flag)
			{
				text = "0" + text;
			}
			flag = (text2.Length < 2);
			if (flag)
			{
				text2 = "0" + text2;
			}
			return str + text + text2;
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x00039C30 File Offset: 0x00037E30
		public static object CurrentTime()
		{
			string text = DateAndTime.Hour(DateAndTime.Now).ToString();
			string text2 = DateAndTime.Minute(DateAndTime.Now).ToString();
			string text3 = DateAndTime.Second(DateAndTime.Now).ToString();
			bool flag = text.Length < 2;
			if (flag)
			{
				text = "0" + text;
			}
			flag = (text2.Length < 2);
			if (flag)
			{
				text2 = "0" + text2;
			}
			flag = (text3.Length < 2);
			if (flag)
			{
				text3 = "0" + text3;
			}
			return text + text2 + text3;
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x00039CD8 File Offset: 0x00037ED8
		public static void ShowForm(object x)
		{
			bool flag = Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(x, null, "WindowState", new object[0], null, null, null), FormWindowState.Minimized, false);
			if (flag)
			{
				NewLateBinding.LateSet(x, null, "WindowState", new object[]
				{
					FormWindowState.Maximized
				}, null, null);
			}
			flag = Operators.ConditionalCompareObjectEqual(NewLateBinding.LateGet(x, null, "Visible", new object[0], null, null, null), false, false);
			if (flag)
			{
				NewLateBinding.LateSet(x, null, "Visible", new object[]
				{
					true
				}, null, null);
				NewLateBinding.LateCall(x, null, "BringToFront", new object[0], null, null, null, true);
			}
			else
			{
				NewLateBinding.LateCall(x, null, "BringToFront", new object[0], null, null, null, true);
			}
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x00039DA8 File Offset: 0x00037FA8
		public static void Create_AllFiles_AllFolders()
		{
			Directory.CreateDirectory("data");
			Directory.CreateDirectory("data/admin");
			Directory.CreateDirectory("data/order_history");
			Directory.CreateDirectory("data/suspicious_activities");
			Directory.CreateDirectory("HOHA Software Backup");
			Directory.CreateDirectory("pc");
			File.Create("data/_Customers.txt").Dispose();
			File.Create("data/_Drivers.txt").Dispose();
			File.Create("data/suspicious_activities/_today.txt").Dispose();
			StreamWriter streamWriter = new StreamWriter("data/admin/Payment_Methods_Delivery.txt", true);
			streamWriter.Write("PAID|NOT PAID");
			streamWriter.Close();
			StreamWriter streamWriter2 = new StreamWriter("data/admin/Payment_Methods_In_Shop.txt", true);
			streamWriter2.Write("Cash|Credit/Debit Card");
			streamWriter2.Close();
			bool flag = !File.Exists("data/admin/BusinessInfo.txt");
			if (flag)
			{
				Directory.CreateDirectory("menu");
				Directory.CreateDirectory("menu/MEAL");
				File.Create("menu/_Categories.txt").Dispose();
				StreamWriter streamWriter3 = new StreamWriter("data/admin/BusinessInfo.txt");
				streamWriter3.Write("Softeware Demo Version|12345678901|Address|City|Postcode|07777777777|stockportdesign.co.uk/demo|20500101|20500101");
				streamWriter3.Close();
			}
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x00039EC0 File Offset: 0x000380C0
		public static object GetFontFitIntoButton(string TextBTN, int MaxWidth, Font FontBTN)
		{
			Size size = TextRenderer.MeasureText(TextBTN, FontBTN);
			string text = "";
			Font font = FontBTN;
			checked
			{
				bool flag = size.Width <= MaxWidth - 8;
				object result;
				if (flag)
				{
					result = font;
				}
				else
				{
					flag = (size.Width > MaxWidth - 8 & !TextBTN.Contains(" "));
					if (flag)
					{
						text = TextBTN;
					}
					flag = (size.Width > MaxWidth & TextBTN.Contains(" "));
					if (flag)
					{
						string text2 = TextBTN.Split(new char[]
						{
							' '
						})[0];
						string text3 = TextBTN.Replace(text2 + " ", "");
						flag = (text2.Length >= text3.Length);
						if (flag)
						{
							text = text2;
						}
						flag = (text2.Length < text3.Length);
						if (flag)
						{
							text = text3;
						}
					}
					int num = (int)Math.Round((double)FontBTN.Size);
					for (;;)
					{
						int num2 = num;
						int num3 = 8;
						if (num2 < num3)
						{
							break;
						}
						font = new Font(FontBTN.Name, (float)num);
						flag = (TextRenderer.MeasureText(text, font).Width <= MaxWidth - 8);
						if (flag)
						{
							break;
						}
						num += -1;
					}
					result = font;
				}
				return result;
			}
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x00039FF8 File Offset: 0x000381F8
		private static void CheckIfSoftwareIsAlreadyRunning()
		{
			checked
			{
				try
				{
					int num = 0;
					foreach (Process process in Process.GetProcesses())
					{
						bool flag = Operators.CompareString(process.ProcessName, "HOHA", false) == 0;
						if (flag)
						{
							num++;
							flag = (num > 1);
							if (flag)
							{
								bool flag2 = Operators.CompareString(MySettingsProperty.Settings.MenuJustDownloaded, "y", false) != 0;
								if (flag2)
								{
									Application.Exit();
									Process.Start("HARW.exe");
								}
								MySettingsProperty.Settings.MenuJustDownloaded = "n";
								break;
							}
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x04000281 RID: 641
		public static int SoftwareExpiryDaysLeft;

		// Token: 0x04000282 RID: 642
		public static int SoftwareOnlineExpiryDaysLeft;

		// Token: 0x04000283 RID: 643
		public static string SoftwareOnlineStatus;

		// Token: 0x04000284 RID: 644
		public static string BusinessDetailsOnServer;

		// Token: 0x04000285 RID: 645
		public static string OrderType;

		// Token: 0x04000286 RID: 646
		public static string PaymentType;

		// Token: 0x04000287 RID: 647
		public static string OrderTakenFrom;

		// Token: 0x04000288 RID: 648
		public static string OrderComment = "";

		// Token: 0x04000289 RID: 649
		public static string AutoCompleteTime;

		// Token: 0x0400028A RID: 650
		public static string AutoCompleteActive;

		// Token: 0x0400028B RID: 651
		public static string[] Shop;

		// Token: 0x0400028C RID: 652
		public static string ShopName;

		// Token: 0x0400028D RID: 653
		public static string ShopPhone;

		// Token: 0x0400028E RID: 654
		public static string ShopAddress;

		// Token: 0x0400028F RID: 655
		public static string ShopCity;

		// Token: 0x04000290 RID: 656
		public static string ShopPostCode;

		// Token: 0x04000291 RID: 657
		public static string ShopWebsite;

		// Token: 0x04000292 RID: 658
		public static string OwnerMobile;

		// Token: 0x04000293 RID: 659
		public static TextBox FocusedTextBoxForKeyboardTyping;

		// Token: 0x04000294 RID: 660
		public static int CursorLocationInTextbox;

		// Token: 0x04000295 RID: 661
		public static string MenuFolder = Environment.CurrentDirectory.ToString() + "\\Menu";

		// Token: 0x04000296 RID: 662
		public static string PostCodesFolder = Environment.CurrentDirectory.ToString() + "\\PC";

		// Token: 0x04000297 RID: 663
		public static string DataFolder = Environment.CurrentDirectory.ToString() + "\\Data";

		// Token: 0x04000298 RID: 664
		public static string ImageFolder = Environment.CurrentDirectory.ToString() + "\\images";

		// Token: 0x04000299 RID: 665
		public static ArrayList Category_ArrayList = new ArrayList();

		// Token: 0x0400029A RID: 666
		public static string CallerIdEnabled = MySettingsProperty.Settings.CallerIdEnabled;

		// Token: 0x0400029B RID: 667
		public static string CallerIdType = MySettingsProperty.Settings.CallerIdType;

		// Token: 0x0400029C RID: 668
		public static string FirstTimeCallerIdLoop = "y";

		// Token: 0x0400029D RID: 669
		public static string CustomerTel = "";

		// Token: 0x0400029E RID: 670
		public static string CustomerAddress = "";

		// Token: 0x0400029F RID: 671
		public static string CustomerPostCode = "";

		// Token: 0x040002A0 RID: 672
		public static string CustomerCity = "";

		// Token: 0x040002A1 RID: 673
		public static string CustomerNote = "";

		// Token: 0x040002A2 RID: 674
		public static string CustomerNumberOfOrders = "0";

		// Token: 0x040002A3 RID: 675
		public static string CustomerType = "";

		// Token: 0x040002A4 RID: 676
		public static string CustomerLastCallDate = "";

		// Token: 0x040002A5 RID: 677
		public static string DriverName = "";

		// Token: 0x040002A6 RID: 678
		public static string LatestCustomerTel = "";

		// Token: 0x040002A7 RID: 679
		public static string CallingCustomerTel = "";

		// Token: 0x040002A8 RID: 680
		public static int rows;

		// Token: 0x040002A9 RID: 681
		public static int columns;

		// Token: 0x040002AA RID: 682
		public static string SelectedCategory;

		// Token: 0x040002AB RID: 683
		public static string SelectedSize;

		// Token: 0x040002AC RID: 684
		public static string SelectedFood;

		// Token: 0x040002AD RID: 685
		public static decimal SelectedFoodPrice;

		// Token: 0x040002AE RID: 686
		public static string SelectedOption;

		// Token: 0x040002AF RID: 687
		public static decimal SelectedOptionPrice;

		// Token: 0x040002B0 RID: 688
		public static string SelectedOptionTLP;

		// Token: 0x040002B1 RID: 689
		public static string BeforeOptionTXT = "    ";

		// Token: 0x040002B2 RID: 690
		public static ListView ShoppingCart = new ListView();

		// Token: 0x040002B3 RID: 691
		public static int Right_Panel_Width;

		// Token: 0x040002B4 RID: 692
		public static int Bottom_Panel_Height;

		// Token: 0x040002B5 RID: 693
		public static int ScreenWidth = Screen.PrimaryScreen.Bounds.Width;

		// Token: 0x040002B6 RID: 694
		public static int ScreenHeight = Screen.PrimaryScreen.Bounds.Height;

		// Token: 0x040002B7 RID: 695
		public static string Button_bgColor = "336699";

		// Token: 0x040002B8 RID: 696
		public static string Button_TextColor = "66ffff";

		// Token: 0x040002B9 RID: 697
		public static string TLPs_bgColor = "#0066CC";

		// Token: 0x040002BA RID: 698
		public static string TableNumber;

		// Token: 0x040002BB RID: 699
		public static string NumberOfGuests;

		// Token: 0x040002BC RID: 700
		public static string TableNumberAction;

		// Token: 0x040002BD RID: 701
		public static string GetNecessaryDataFromServerInOfflineMode = "no";

		// Token: 0x040002BE RID: 702
		public static string OrderToDriverStatus;

		// Token: 0x040002BF RID: 703
		public static string OrderNoToEdit;

		// Token: 0x040002C0 RID: 704
		public static string OrderNoToEditAddress;
	}
}
