using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000013 RID: 19
	[DesignerGenerated]
	public class LockSoftware : Form
	{
		// Token: 0x06000316 RID: 790 RVA: 0x0001F1D0 File Offset: 0x0001D3D0
		[DebuggerNonUserCode]
		public LockSoftware()
		{
			base.Load += this.LockSoftware_Load;
			List<WeakReference> _ENCList = LockSoftware.__ENCList;
			lock (_ENCList)
			{
				LockSoftware.__ENCList.Add(new WeakReference(this));
			}
			this.InitializeComponent();
		}

		// Token: 0x06000317 RID: 791 RVA: 0x0001F23C File Offset: 0x0001D43C
		[DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x06000318 RID: 792 RVA: 0x0001F28C File Offset: 0x0001D48C
		[DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.LockedMessage = new Label();
			this.Label1 = new Label();
			this.LockSoftwareLBL = new Label();
			this.Button1 = new Button();
			this.BuyLicenceBTN = new Button();
			this.Label2 = new Label();
			this.UnlockCodeTB = new TextBox();
			this.SuspendLayout();
			this.LockedMessage.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.LockedMessage.AutoSize = true;
			this.LockedMessage.BackColor = Color.Transparent;
			this.LockedMessage.Font = new Font("Arial", 24f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.LockedMessage.ForeColor = Color.RoyalBlue;
			Control lockedMessage = this.LockedMessage;
			Point location = new Point(60, 29);
			lockedMessage.Location = location;
			this.LockedMessage.Name = "LockedMessage";
			Control lockedMessage2 = this.LockedMessage;
			Size size = new Size(495, 37);
			lockedMessage2.Size = size;
			this.LockedMessage.TabIndex = 33;
			this.LockedMessage.Text = "Your software has been locked.";
			this.Label1.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.Label1.AutoSize = true;
			this.Label1.BackColor = Color.Transparent;
			this.Label1.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label1.ForeColor = Color.RoyalBlue;
			Control label = this.Label1;
			location = new Point(69, 83);
			label.Location = location;
			this.Label1.Name = "Label1";
			Control label2 = this.Label1;
			size = new Size(461, 27);
			label2.Size = size;
			this.Label1.TabIndex = 34;
			this.Label1.Text = "To unlock your software please contact us";
			this.LockSoftwareLBL.AutoSize = true;
			this.LockSoftwareLBL.BackColor = Color.Transparent;
			this.LockSoftwareLBL.Font = new Font("Arial", 21.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.LockSoftwareLBL.ForeColor = Color.Crimson;
			Control lockSoftwareLBL = this.LockSoftwareLBL;
			location = new Point(68, 137);
			lockSoftwareLBL.Location = location;
			this.LockSoftwareLBL.Name = "LockSoftwareLBL";
			Control lockSoftwareLBL2 = this.LockSoftwareLBL;
			size = new Size(471, 33);
			lockSoftwareLBL2.Size = size;
			this.LockSoftwareLBL.TabIndex = 39;
			this.LockSoftwareLBL.Text = "+447591158960 (WhatsApp ONLY)";
			this.Button1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.Button1.BackColor = Color.Crimson;
			this.Button1.FlatStyle = FlatStyle.Flat;
			this.Button1.Font = new Font("Arial", 12f, FontStyle.Bold);
			this.Button1.ForeColor = Color.White;
			Control button = this.Button1;
			location = new Point(185, 305);
			button.Location = location;
			Control button2 = this.Button1;
			Padding margin = new Padding(4);
			button2.Margin = margin;
			this.Button1.Name = "Button1";
			Control button3 = this.Button1;
			size = new Size(207, 60);
			button3.Size = size;
			this.Button1.TabIndex = 40;
			this.Button1.Text = "Exit";
			this.Button1.UseVisualStyleBackColor = false;
			this.BuyLicenceBTN.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.BuyLicenceBTN.BackColor = Color.LimeGreen;
			this.BuyLicenceBTN.FlatStyle = FlatStyle.Flat;
			this.BuyLicenceBTN.Font = new Font("Arial", 12f, FontStyle.Bold);
			this.BuyLicenceBTN.ForeColor = Color.White;
			Control buyLicenceBTN = this.BuyLicenceBTN;
			location = new Point(407, 215);
			buyLicenceBTN.Location = location;
			Control buyLicenceBTN2 = this.BuyLicenceBTN;
			margin = new Padding(4);
			buyLicenceBTN2.Margin = margin;
			this.BuyLicenceBTN.Name = "BuyLicenceBTN";
			Control buyLicenceBTN3 = this.BuyLicenceBTN;
			size = new Size(148, 41);
			buyLicenceBTN3.Size = size;
			this.BuyLicenceBTN.TabIndex = 53;
			this.BuyLicenceBTN.Text = "Unlock";
			this.BuyLicenceBTN.UseVisualStyleBackColor = false;
			this.Label2.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.Label2.AutoSize = true;
			this.Label2.BackColor = Color.Transparent;
			this.Label2.Font = new Font("Arial", 18f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Label2.ForeColor = Color.LimeGreen;
			Control label3 = this.Label2;
			location = new Point(41, 223);
			label3.Location = location;
			this.Label2.Name = "Label2";
			Control label4 = this.Label2;
			size = new Size(157, 27);
			label4.Size = size;
			this.Label2.TabIndex = 54;
			this.Label2.Text = "Unlock Code:";
			this.UnlockCodeTB.BorderStyle = BorderStyle.None;
			this.UnlockCodeTB.CharacterCasing = CharacterCasing.Upper;
			this.UnlockCodeTB.Font = new Font("Arial", 26.25f);
			Control unlockCodeTB = this.UnlockCodeTB;
			location = new Point(204, 215);
			unlockCodeTB.Location = location;
			this.UnlockCodeTB.Name = "UnlockCodeTB";
			this.UnlockCodeTB.PasswordChar = '*';
			Control unlockCodeTB2 = this.UnlockCodeTB;
			size = new Size(188, 41);
			unlockCodeTB2.Size = size;
			this.UnlockCodeTB.TabIndex = 55;
			SizeF autoScaleDimensions = new SizeF(6f, 13f);
			this.AutoScaleDimensions = autoScaleDimensions;
			this.AutoScaleMode = AutoScaleMode.Font;
			size = new Size(598, 378);
			this.ClientSize = size;
			this.Controls.Add(this.UnlockCodeTB);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.BuyLicenceBTN);
			this.Controls.Add(this.Button1);
			this.Controls.Add(this.LockSoftwareLBL);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.LockedMessage);
			this.FormBorderStyle = FormBorderStyle.None;
			this.Name = "LockSoftware";
			this.ShowInTaskbar = false;
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "LockSoftware";
			this.TopMost = true;
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000319 RID: 793 RVA: 0x0001F958 File Offset: 0x0001DB58
		// (set) Token: 0x0600031A RID: 794 RVA: 0x00002C52 File Offset: 0x00000E52
		internal virtual Label LockedMessage
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LockedMessage;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._LockedMessage = value;
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x0600031B RID: 795 RVA: 0x0001F970 File Offset: 0x0001DB70
		// (set) Token: 0x0600031C RID: 796 RVA: 0x00002C5C File Offset: 0x00000E5C
		internal virtual Label Label1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label1 = value;
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x0600031D RID: 797 RVA: 0x0001F988 File Offset: 0x0001DB88
		// (set) Token: 0x0600031E RID: 798 RVA: 0x00002C66 File Offset: 0x00000E66
		internal virtual Label LockSoftwareLBL
		{
			[DebuggerNonUserCode]
			get
			{
				return this._LockSoftwareLBL;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._LockSoftwareLBL = value;
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600031F RID: 799 RVA: 0x0001F9A0 File Offset: 0x0001DBA0
		// (set) Token: 0x06000320 RID: 800 RVA: 0x0001F9B8 File Offset: 0x0001DBB8
		internal virtual Button Button1
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Button1;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click_1);
				bool flag = this._Button1 != null;
				if (flag)
				{
					this._Button1.Click -= value2;
				}
				this._Button1 = value;
				flag = (this._Button1 != null);
				if (flag)
				{
					this._Button1.Click += value2;
				}
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x06000321 RID: 801 RVA: 0x0001FA18 File Offset: 0x0001DC18
		// (set) Token: 0x06000322 RID: 802 RVA: 0x0001FA30 File Offset: 0x0001DC30
		internal virtual Button BuyLicenceBTN
		{
			[DebuggerNonUserCode]
			get
			{
				return this._BuyLicenceBTN;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.BuyLicenceBTN_Click);
				bool flag = this._BuyLicenceBTN != null;
				if (flag)
				{
					this._BuyLicenceBTN.Click -= value2;
				}
				this._BuyLicenceBTN = value;
				flag = (this._BuyLicenceBTN != null);
				if (flag)
				{
					this._BuyLicenceBTN.Click += value2;
				}
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x06000323 RID: 803 RVA: 0x0001FA90 File Offset: 0x0001DC90
		// (set) Token: 0x06000324 RID: 804 RVA: 0x00002C70 File Offset: 0x00000E70
		internal virtual Label Label2
		{
			[DebuggerNonUserCode]
			get
			{
				return this._Label2;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._Label2 = value;
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000325 RID: 805 RVA: 0x0001FAA8 File Offset: 0x0001DCA8
		// (set) Token: 0x06000326 RID: 806 RVA: 0x00002C7A File Offset: 0x00000E7A
		internal virtual TextBox UnlockCodeTB
		{
			[DebuggerNonUserCode]
			get
			{
				return this._UnlockCodeTB;
			}
			[DebuggerNonUserCode]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				this._UnlockCodeTB = value;
			}
		}

		// Token: 0x06000327 RID: 807 RVA: 0x00002C84 File Offset: 0x00000E84
		private void LockSoftware_Load(object sender, EventArgs e)
		{
			MyProject.Forms.Index.Enabled = false;
		}

		// Token: 0x06000328 RID: 808 RVA: 0x00002107 File Offset: 0x00000307
		private void Button1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x06000329 RID: 809 RVA: 0x00002107 File Offset: 0x00000307
		private void Button1_Click_1(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x0600032A RID: 810 RVA: 0x0001FAC0 File Offset: 0x0001DCC0
		private void BuyLicenceBTN_Click(object sender, EventArgs e)
		{
			bool flag = Operators.CompareString(this.UnlockCodeTB.Text, "07513973726", false) == 0;
			if (flag)
			{
				MySettingsProperty.Settings.LockSoftware = null;
				StreamWriter streamWriter = new StreamWriter("data/admin/BusinessInfo.txt");
				streamWriter.Write("");
				streamWriter.Close();
				Application.Exit();
				Process.Start("HOHA.exe");
			}
			else
			{
				MessageBox.Show("Unlock code is not correct.");
			}
		}

		// Token: 0x0400015F RID: 351
		private static List<WeakReference> __ENCList = new List<WeakReference>();

		// Token: 0x04000160 RID: 352
		private IContainer components;

		// Token: 0x04000161 RID: 353
		[AccessedThroughProperty("LockedMessage")]
		private Label _LockedMessage;

		// Token: 0x04000162 RID: 354
		[AccessedThroughProperty("Label1")]
		private Label _Label1;

		// Token: 0x04000163 RID: 355
		[AccessedThroughProperty("LockSoftwareLBL")]
		private Label _LockSoftwareLBL;

		// Token: 0x04000164 RID: 356
		[AccessedThroughProperty("Button1")]
		private Button _Button1;

		// Token: 0x04000165 RID: 357
		[AccessedThroughProperty("BuyLicenceBTN")]
		private Button _BuyLicenceBTN;

		// Token: 0x04000166 RID: 358
		[AccessedThroughProperty("Label2")]
		private Label _Label2;

		// Token: 0x04000167 RID: 359
		[AccessedThroughProperty("UnlockCodeTB")]
		private TextBox _UnlockCodeTB;
	}
}
