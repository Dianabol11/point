using System;
using System.IO;
using Microsoft.VisualBasic.CompilerServices;
using POS.My;

namespace POS
{
	// Token: 0x02000030 RID: 48
	[StandardModule]
	internal sealed class SuspiciousActivities
	{
		// Token: 0x0600060D RID: 1549 RVA: 0x0003BECC File Offset: 0x0003A0CC
		public static void CheckSuspiciousActivitiesEditedOrders(object OrderNoToEdit, object NewOrderTotal)
		{
			string contents = Conversions.ToString(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject("EDITED_ORDER|", OrderNoToEdit), "|"), OrderManagment.EditOrderOldDateTime), "|"), OrderManagment.EditOrderOldDTotal.ToString()), "|"), M_Settings.CurrentDate()), M_Settings.CurrentTime()), "|"), NewOrderTotal.ToString()), Environment.NewLine));
			File.AppendAllText(M_Settings.DataFolder + "\\suspicious_activities\\_today.txt", contents);
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x0003BF6C File Offset: 0x0003A16C
		public static void SuspiciousActivitiesTillOpened()
		{
			string contents = Conversions.ToString(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject("TILL-OPENED||||", M_Settings.CurrentDate()), M_Settings.CurrentTime()), "|"), Environment.NewLine));
			File.AppendAllText(M_Settings.DataFolder + "\\suspicious_activities\\_today.txt", contents);
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x0003BFC4 File Offset: 0x0003A1C4
		public static void SuspiciousActivitiesAutoCompleteOrders()
		{
			bool flag = Operators.CompareString(M_Settings.AutoCompleteActive, "yes", false) == 0;
			checked
			{
				if (flag)
				{
					string value = Operators.AddObject(M_Settings.CurrentDate(), M_Settings.CurrentTime()).ToString().Substring(4);
					string value2 = M_Settings.AutoCompleteTime.Substring(4);
					flag = (Conversions.ToInteger(value) - Conversions.ToInteger(value2) > 500 & Operators.CompareString(MySettingsProperty.Settings.AutoCompleteTime, "5", false) == 0);
					if (flag)
					{
						string text = Conversions.ToString(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject("AUTO-COMPLETE|" + OrderManagment.NextOrderNumberString + "|||", M_Settings.CurrentDate()), M_Settings.CurrentTime()), "|"), MyProject.Forms.POS_Window.TotalTextBox.Text), Environment.NewLine));
						File.AppendAllText(M_Settings.DataFolder + "\\suspicious_activities\\_today.txt", text);
						Online.postdata(Online.SoftwareDomain, "suspicious_activities.php", "new_suspicious_activity", MySettingsProperty.Settings.ServerFolderName + "/data/suspicious_activities", text, "", "", "");
						MyProject.Forms.POS_Window.ReadyToTakeNewOrder("yes");
						offers.CleanOffer();
					}
					flag = (Conversions.ToInteger(value) - Conversions.ToInteger(value2) > 800 & Operators.CompareString(MySettingsProperty.Settings.AutoCompleteTime, "8", false) == 0);
					if (flag)
					{
						string text2 = Conversions.ToString(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject(Operators.AddObject("AUTO-COMPLETE|" + OrderManagment.NextOrderNumberString + "|||", M_Settings.CurrentDate()), M_Settings.CurrentTime()), "|"), MyProject.Forms.POS_Window.TotalTextBox.Text), Environment.NewLine));
						File.AppendAllText(M_Settings.DataFolder + "\\suspicious_activities\\_today.txt", text2);
						Online.postdata(Online.SoftwareDomain, "suspicious_activities.php", "new_suspicious_activity", MySettingsProperty.Settings.ServerFolderName + "/data/suspicious_activities", text2, "", "", "");
						MyProject.Forms.POS_Window.ReadyToTakeNewOrder("yes");
						offers.CleanOffer();
					}
				}
			}
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x0003C21C File Offset: 0x0003A41C
		public static void CheckSuspiciousActivitiesFile()
		{
			bool flag = !File.Exists(M_Settings.DataFolder + "\\suspicious_activities\\_today.txt");
			if (flag)
			{
				File.Create(M_Settings.DataFolder + "\\suspicious_activities\\_today.txt");
			}
		}
	}
}
